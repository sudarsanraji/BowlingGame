package com.caweco.esra.dao.core;

import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.OeRegion;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class OeRegionDAO
{
	
	public static Set<OeRegion> findAll(Client parent)
	{
		return parent.getOeRegions(true);
	}
	
	public static void insert(final Client parent, final OeRegion it)
	{
	
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		if(Objects.isNull(it.getId()))
		{
			it.setId(UUID.randomUUID());
		}
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oeRegion/");
		
		Response response = webTarget.request().post(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the Office region "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	public static void update(final Client parent, final OeRegion it)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oeRegion/" + it.getId());
		
		Response response = webTarget.request().put(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the Office region "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	public static boolean delete(final Client parent, final OeRegion it)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oeRegion/" + it.getId());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the Office region "  + it.getName() + " to the client : " +  parent.getClientDescription());	
		return true;
	}
}
