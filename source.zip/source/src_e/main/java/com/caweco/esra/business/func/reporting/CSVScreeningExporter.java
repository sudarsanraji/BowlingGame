
package com.caweco.esra.business.func.reporting;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.tinylog.Logger;

import com.caweco.esra.business.utils.ChronoUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.applog.ChangeEntry;
import com.caweco.esra.ui.main.helper.TemporaryBinaryElement;


public class CSVScreeningExporter implements ScreeningExporter
{
	private static final String BASENAME = "Screenings";
	
	public static String createFileName(boolean isFullExport)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(BASENAME).append("_");
		if(isFullExport)
			sb.append("all_");
		sb.append(ChronoUtil.getUtcLocaldateStringForFile()).append(".xlsx");
		String filename = sb.toString();
		
		return filename;
	}
	
	public static enum Column
	{
		
		DATE(0, "Date"),
		NAME(1, "Name"),
		OFFICE(2, "Office"),
		OFFICEREGION(3, "Office region"),
		FUNCTION(4, "Function"),
		LINE_OF_BUSINESS(5, "Line of Business"),
		STATUS(6, "Status"),
		ESU_TAGS(7, "ESU Tags"),
		REFERRAL_REASON(8, "Referral Reason"),
		PRC_COUNTRIES(9, "PRC Countries"),
		ID(10, "Case ID"),
		REFERRAL_REQUEST_DATE(11, "Referral Request Date"),
		REFERRAL_FINALIZED_DATE(12, "Referral Finalized Date"),
		CASE_OWNER(13, "Case Owner");
		
		
		public String headerValue;
		public int    colNumber;
		
		Column(int colNumber, String headerValue)
		{
			this.colNumber   = colNumber;
			this.headerValue = headerValue;
		}
		
		public String getHeader()
		{
			return this.headerValue;
		}
	}
	
	private int             maxColWidth     = 130; // in chars
	private int             defaultColWidth = 20;  // in chars
	private List<ScreeningMetadataBase> screenings;
	private String          filename;
	private Client client;
	
	public CSVScreeningExporter(Client client, List<ScreeningMetadataBase> screenings, boolean isFullExport)
	{
		super();
		this.client = client;
		this.screenings = screenings != null ? screenings : Collections.emptyList();
		this.filename   = createFileName(isFullExport);
	}
	
	@Override
	public TemporaryBinaryElement createBinaryElement() throws InterruptedException
	{
		TemporaryBinaryElement temporaryBinaryElement = new TemporaryBinaryElement(createWorkbook());
		temporaryBinaryElement.setFileName(filename);
		return temporaryBinaryElement;
	}
	
	@Override
	public byte[] createWorkbook() throws InterruptedException
	{
		Instant startTime = Instant.now();
		
		try(SXSSFWorkbook workbook = new SXSSFWorkbook(SXSSFWorkbook.DEFAULT_WINDOW_SIZE))
		{
			// Styles & Colors
			final Map<String, XSSFColor>     colors = this.generateColors(workbook.getXSSFWorkbook());
			final Map<String, XSSFCellStyle> styles = this.generateStyles(workbook.getXSSFWorkbook(), colors, true);
			
			final SXSSFSheet                 sheet  = workbook.createSheet(BASENAME);
			sheet.setDefaultColumnWidth(defaultColWidth);
			sheet.trackColumnForAutoSizing(Column.NAME.colNumber);
			sheet.trackColumnForAutoSizing(Column.ESU_TAGS.colNumber);
			sheet.trackColumnForAutoSizing(Column.REFERRAL_REASON.colNumber);
			sheet.trackColumnForAutoSizing(Column.PRC_COUNTRIES.colNumber);
			
			// ROW NR
			int            currentRowNr = 0;
			
			//// HEADER ROW
			
			final SXSSFRow firstRow     = sheet.createRow(currentRowNr++);
			this.addHeaderCells(firstRow, styles);
			
			//// DATA ROWs
			
			for(int i = 0; i < screenings.size(); i++)
			{
				final ScreeningMetadataBase rowData = screenings.get(i);
				currentRowNr = this.addContentEntry(sheet, currentRowNr, rowData, styles);
			}
			
			//// METADATA rows
			
			//// COMMENT rows
			
			//// Column Sizes
			
			int colWidth_small1 = 15 * 265;
			int colWidth_medium2 = 30 * 265;
			
			sheet.setColumnWidth(Column.DATE.colNumber, colWidth_small1);
			autoSizeColumnWithMax(sheet, Column.NAME.colNumber);
			
//			sheet.setColumnWidth(Column.OFFICE.colNumber, colWidth_medium1);
			sheet.setColumnWidth(Column.OFFICEREGION.colNumber, colWidth_medium2);
			
//			sheet.setColumnWidth(Column.FUNCTION.colNumber, colWidth_medium1);
			sheet.setColumnWidth(Column.LINE_OF_BUSINESS.colNumber, colWidth_medium2);
			
//			sheet.setColumnWidth(Column.STATUS.colNumber, colWidth_medium1);
			autoSizeColumnWithMax(sheet, Column.ESU_TAGS.colNumber);
			
			autoSizeColumnWithMax(sheet, Column.REFERRAL_REASON.colNumber);
			autoSizeColumnWithMax(sheet, Column.PRC_COUNTRIES.colNumber);
			
			final ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			
			workbook.close();
			
			byte[]  byteArray = bos.toByteArray();
			
			Instant endTime   = Instant.now();
			
			Logger.debug("Time for composing Xlsx report: (duration/start/end): {} / {} / {}", Duration.between(startTime, endTime), startTime, endTime);
			
			return byteArray;
		}
		catch(IOException e)
		{
			Logger.error("Error creating excel.", e);
			return null;
		}
	}
	
	protected void autoSizeColumnWithMax(SXSSFSheet sheet, int colNr)
	{
		sheet.autoSizeColumn(colNr);
		final int newColumnWidth = Math.min(sheet.getColumnWidth(colNr), this.maxColWidth * 256);
		sheet.setColumnWidth(colNr, newColumnWidth);
	}
	
	/*************************************************************************/
	
	protected void addHeaderCells(final SXSSFRow row, final Map<String, XSSFCellStyle> styles)
	{
		final XSSFCellStyle cellStyle = styles.get("header");
		
		PoiHelper.newCell(row, cellStyle, Column.DATE.colNumber).setCellValue(Column.DATE.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.NAME.colNumber).setCellValue(Column.NAME.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.OFFICE.colNumber).setCellValue(Column.OFFICE.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.OFFICEREGION.colNumber).setCellValue(Column.OFFICEREGION.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.FUNCTION.colNumber).setCellValue(Column.FUNCTION.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.LINE_OF_BUSINESS.colNumber).setCellValue(Column.LINE_OF_BUSINESS.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.STATUS.colNumber).setCellValue(Column.STATUS.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.ESU_TAGS.colNumber).setCellValue(Column.ESU_TAGS.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.REFERRAL_REASON.colNumber).setCellValue(Column.REFERRAL_REASON.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.PRC_COUNTRIES.colNumber).setCellValue(Column.PRC_COUNTRIES.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.ID.colNumber).setCellValue(Column.ID.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.REFERRAL_REQUEST_DATE.colNumber).setCellValue(Column.REFERRAL_REQUEST_DATE.getHeader());
		
		PoiHelper.newCell(row, cellStyle, Column.REFERRAL_FINALIZED_DATE.colNumber).setCellValue(Column.REFERRAL_FINALIZED_DATE.getHeader());
		PoiHelper.newCell(row, cellStyle, Column.CASE_OWNER.colNumber).setCellValue(Column.CASE_OWNER.getHeader());
	}
	
	/*************************************************************************/
	
	protected int addContentEntry(
		final SXSSFSheet sheet,
		final int startRowNum,
		final ScreeningMetadataBase screening,
		final Map<String, XSSFCellStyle> styles)
	{
		
		final int internalRowNum = startRowNum;
		
		final Row row            = sheet.createRow(internalRowNum);
		Logger.trace("Created row nr. {}", internalRowNum);
		
		final XSSFCellStyle defaultStyle = styles.get("default");
		final XSSFCellStyle dateStyle = styles.get("date");
		
		PoiHelper.newCell(row, dateStyle, Column.DATE.colNumber).setCellValue(screening.getScreeningDate());
		PoiHelper.newCell(row, defaultStyle, Column.NAME.colNumber).setCellValue(screening.getName());
		
		if(screening.getOe() != null)
		{
			PoiHelper.newCell(row, defaultStyle, Column.OFFICE.colNumber).setCellValue(screening.getOe().getName());
			
			PoiHelper.newCell(row, defaultStyle, Column.OFFICEREGION.colNumber)
			.setCellValue(screening.getOe().getRegion() != null ? screening.getOe().getRegion().getName() : "");
		}

		PoiHelper.newCell(row, defaultStyle, Column.FUNCTION.colNumber).setCellValue(screening.getFunction() != null ? screening.getFunction().getName() : "");
		PoiHelper.newCell(row, defaultStyle, Column.LINE_OF_BUSINESS.colNumber)
			.setCellValue(screening.getLineOfBusiness() != null ? screening.getLineOfBusiness().getName() : "");
		
		PoiHelper.newCell(row, defaultStyle, Column.STATUS.colNumber).setCellValue(screening.getStatus().getStatus());
		String esuTags = screening.getEsuTags().stream().collect(Collectors.joining(", "));
		PoiHelper.newCell(row, defaultStyle, Column.ESU_TAGS.colNumber).setCellValue(esuTags);
		
		String esuCountries = screening.getEsuCountries().stream().collect(Collectors.joining(", "));
		PoiHelper.newCell(row, defaultStyle, Column.REFERRAL_REASON.colNumber).setCellValue(esuCountries);
		
		String prcCountries = screening.getPrcCountries().stream().collect(Collectors.joining(", "));
		PoiHelper.newCell(row, defaultStyle, Column.PRC_COUNTRIES.colNumber).setCellValue(prcCountries);
		
		String id = screening.getScreeningID();
		PoiHelper.newCell(row, defaultStyle, Column.ID.colNumber).setCellValue(id);
		
		String esuDate = screening.getScreeningEsuDate() != null ? screening.getScreeningEsuDate().toString() : "";
		PoiHelper.newCell(row, defaultStyle, Column.REFERRAL_REQUEST_DATE.colNumber).setCellValue(esuDate);
		
		String esuReviewDate = screening.getScreeningPublishDate() != null ? screening.getScreeningPublishDate().toString() : "";
		PoiHelper.newCell(row, defaultStyle, Column.REFERRAL_FINALIZED_DATE.colNumber).setCellValue(esuReviewDate);
		
		return internalRowNum + 1;
	}
	

	/* ********************************************************************** */
	/* CUSTOM COLORS & STYLES */
	
	
	protected Map<String, XSSFColor> generateColors(final XSSFWorkbook workbook)
	{
		final Map<String, XSSFColor> colorMap = new HashMap<>();
		colorMap.put("header", PoiHelper.generateColor(workbook, 210, 210, 210));
		return colorMap;
	}
	
	protected Map<String, XSSFCellStyle> generateStyles(
		final XSSFWorkbook wb,
		final Map<String, XSSFColor> colors,
		final boolean colored)
	{
		final Map<String, XSSFCellStyle> styles        = new HashMap<>();
		
		final XSSFCellStyle              style_default = PoiHelper.createMultilineCellStyle(wb);
		styles.put("default", style_default);
		
		final XSSFCellStyle style_header = createHeaderStyle(wb);
		if(colored)
		{
			style_header.setFillForegroundColor(colors.get("header"));
			style_header.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}
		styles.put("header", style_header);
		
		final XSSFCellStyle style_date = PoiHelper.createDateStyle(wb);
		styles.put("date", style_date);
		
		return styles;
	}
	

	
	private XSSFCellStyle createHeaderStyle(final XSSFWorkbook workbook)
	{
		final XSSFCellStyle style = PoiHelper.createMultilineCellStyle(workbook);
		final Font          font  = workbook.createFont();
		font.setBold(true);
		style.setFont(font);
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setVerticalAlignment(VerticalAlignment.CENTER);
		// style.setBorderBottom(BorderStyle.THICK);
		return style;
	}
	
	

}
