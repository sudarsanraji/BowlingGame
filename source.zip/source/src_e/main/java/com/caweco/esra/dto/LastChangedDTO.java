package com.caweco.esra.dto;

import java.time.Instant;

import com.caweco.esra.entities.core.Screening;

public class LastChangedDTO
{
	public static LastChangedDTO fromScreening(final Screening screening)
	{
		return new LastChangedDTO(screening.getLastChanged(), screening.getLastChangedBy());
	}

	private Instant lastChanged;
	private String lastChangedBy;

	public LastChangedDTO()
	{
		super();
	}

	public LastChangedDTO(final Instant lastChanged, final String lastChangedBy)
	{
		super();
		this.lastChanged = lastChanged;
		this.lastChangedBy = lastChangedBy;
	}

	public Instant getLastChanged()
	{
		return this.lastChanged;
	}

	public void setLastChanged(final Instant lastChanged)
	{
		this.lastChanged = lastChanged;
	}

	public String getLastChangedBy()
	{
		return this.lastChangedBy;
	}

	public void setLastChangedBy(final String lastChangedBy)
	{
		this.lastChangedBy = lastChangedBy;
	}
}
