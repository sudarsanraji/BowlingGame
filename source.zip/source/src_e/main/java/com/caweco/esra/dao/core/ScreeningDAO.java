
package com.caweco.esra.dao.core;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.func.rest.data.QueryDescription;
import com.caweco.esra.business.func.rest.data.QueryHelper;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.BinaryElementNoDataDTO;
import com.caweco.esra.dto.ClientMetadataDTO;
import com.caweco.esra.dto.LastChangedDTO;
import com.caweco.esra.dto.QuestionnaireResultDTO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.dto.ScreeningMetadataDTO;
import com.caweco.esra.dto.ScreeningMetadataEsuBase;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.QuestionnaireResultCreator;
import com.caweco.esra.dto.creator.ScreeningCreator;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.dto.screening.ScreeningInfoDTO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.applog.ChangeEntry;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.core.SearchEntryGsss;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;
import com.caweco.esra.ui.dialogs.DialogBigMessage;
import com.caweco.esra.ui.main.helper.ScreeningSearchResult;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElementPendingDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.StreamReadConstraints;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.server.VaadinSession;

import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;


public class ScreeningDAO
{
	private static StreamReadConstraints src = StreamReadConstraints.builder().maxNameLength(Integer.MAX_VALUE).build();
	private static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	static
	{
		om.getFactory().setStreamReadConstraints(src);
	}
	
	public static final String CL_CURRENT                   = "/client/{clientUuid}";
	public static final String SCR_CURRENT                  = "/client/{clientUuid}/screening";
	
	public static final String CL_ARCHIVE                   = "/client/{clientUuid}/archive";
	
	public static final String TEMPLATE_ALL_BASE            = CL_CURRENT + "/screenings_base";
	public static final String TEMPLATE_ARCHIVE_BASE        = CL_ARCHIVE + "/screenings_base";
	
	public static final String SCR_CURRENT_SINGLE           = SCR_CURRENT + "/{screeningUuid}";
	
	// TODO: CHANGE!!
	public static String       TEMPLATE_ARCHIVED_SCREENING  = "/client/{clientUuid}/screening/{screeningUuid}";
	public static String       TEMPLATE_ESU_BASE            = CL_CURRENT + "/esu/{userEmail}/screenings_base";
	public static String       TEMPLATE_ESU_INBOX_BASE      = CL_CURRENT + "/esu_inbox/{userEmail}/screenings_base";
	public static String       TEMPLATE_ESU_FAVORITES_BASE  = CL_CURRENT + "/esu_favorites/{userEmail}/screenings_base";
	public static String       TEMPLATE_ALL_COUNT           = CL_CURRENT + "/screenings_count";
	public static String       TEMPLATE_ARCHIVE_COUNT       = CL_ARCHIVE + "/screenings_count";
	public static String       TEMPLATE_ESU_COUNT           = CL_CURRENT + "/esu/screenings_count";
	public static String       TEMPLATE_ESU_INBOX_COUNT     = CL_CURRENT + "/esu_inbox/{userEmail}/screenings_count";
	public static String       TEMPLATE_ESU_FAVORITES_COUNT =
		CL_CURRENT + "/esu_favorites/{userEmail}/screenings_count";
	public static String       TEMPLATE_READ                = CL_CURRENT + "/screenings/{screeningUuid}";
	
	public static String       TEMPLATE_SINGLE_SCREENING    = CL_CURRENT + "/screening/{screeningUuid}";
	
	public static final String SCR_CURRENT_LAST_CHANGED     = SCR_CURRENT + "/{screeningUuid}/lastchanged";
	public static final String SCR_CURRENT_BUSINESS         = SCR_CURRENT + "/{screeningUuid}/business";
	public static final String SCR_CURRENT_FOLLOW_PUBLIC    = SCR_CURRENT + "/{screeningUuid}/public/follow";
	public static final String SCR_CURRENT_UNFOLLOW_PUBLIC  = SCR_CURRENT + "/{screeningUuid}/public/unfollow";
	public static final String SCR_CURRENT_TRADESANCTIONS   = SCR_CURRENT + "/{screeningUuid}/tradeSanctions";
	public static final String SCR_CURRENT_NOTABLECHANGES   = SCR_CURRENT + "/{screeningUuid}/notablechanges";
	public static final String SCR_CURRENT_NOTABLECHANGE    = SCR_CURRENT + "/{screeningUuid}/addnotablechange";
	public static final String SCR_CURRENT_FILES            = SCR_CURRENT + "/{screeningUuid}/files";
	public static final String SCR_CURRENT_FILES_SINGLE     = SCR_CURRENT + "/{screeningUuid}/files/{fileId}";
	public static final String SCR_CURRENT_WL_COMPANY       = SCR_CURRENT + "/{screeningUuid}/watchlist/company";
	public static final String SCR_CURRENT_WL_GSSS          = SCR_CURRENT + "/{screeningUuid}/watchlist/gsss";
	public static final String SCR_CURRENT_WL_VESSEN        = SCR_CURRENT + "/{screeningUuid}/watchlist/vessel";
	
	public static final String SCR_CURR_DEL_MESSAGE_GROUP   = SCR_CURRENT + "/{screeningUuid}/messaging/{groupId}";
	
	public static final String SCR_SEAWEB_ENTRY             = SCR_CURRENT_WL_VESSEN + "/seaweb";
	
	/**
	 * Special:
	 */
	public static final String TEMPLATE_FUNC_ISBLOCKED      = "/commons/isblocked/{screeningId}";
	
	/**
	 * Special: Search for a screeningId in <b>ALL</b> Clients.
	 */
	public static final String TEMPLATE_SCR_FIND            = "/screening/{screeningId}";
	
	/* ******************************************************************* */
	
	/**
	 * If this is done without Exception: updates the Screening's "lastChanged" metadata.
	 */
	public static void logChange(final Screening screening, final User currentUser, final boolean force)
	{
		screening.updateLastChanged(currentUser);
		Logger.tag("REST").debug("{}: Updating LAST CHANGED", screening.getName());

		final WebTarget webTarget = RestUtil.getRestClient_ESRADB()
			.getMethodTarget(SCR_CURRENT_LAST_CHANGED)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());

		final Response response = webTarget.queryParam("forced", force)
			.request()
			.post(Entity.entity(LastChangedDTO.fromScreening(screening), MediaType.APPLICATION_JSON));
		
		org.tinylog.Logger.tag("REST").info(response.toString());
	}
	
	public static ConcurrentHashMap<String, Screening> findAll(final Client client)
	{
		return client.getScreenings();
	}
	
	public static synchronized void insert(final Client client, final Screening screening)
	{
		final ConcurrentHashMap<String, Screening> holder = findAll(client);
		
		if(screening != null)
		{
			Objects.requireNonNull(screening.getScreeningID());
			final String  key         = screening.getScreeningID().toString();
					
			holder.put(key, screening);
			
			ScreeningDAO.saveScreening(screening, false);
			
		}
		
		Logger.tag("REST").info("New NUMBER OF SCREENINGS: " + holder.size());
	}
	
	/* ******************************************************************* */
	
	/**
	 * Update screening.
	 * @param screening
	 * @param force
	 */
	public static void update(final Screening screening, final boolean force)
	{
		if(screening != null)
		{
			if(!ScreeningDAO.hasFrozenState(screening) || force)
			{
				ScreeningDAO.saveScreening(screening, force);
				// Files
				// -> On save, new Lazy references & maps are generated and set -> done by storing the item itself
				
				// Screening Watchlist
				// -> On save, new Lazy references & maps are generated and set -> done by storing the item itself
				
			}
			else
			{
				// Screening is FROZEN!
				throw new RuntimeException("Updating frozen Screening is not allowed!");
			}
		}
	}
	
	/**
	 * Update screening.<br />
	 * Uses <b>force: false</b> 
	 * @param pair
	 */
	public static void update(final Pair<Screening, VaadinSession> pair)
	{
		update(pair.getLeft(), false);
	}
	
	/* ******************************************************************* */
	
	/* ******************************************************************* */	
	
	/**
	 * Add an entry in screening's "notableChange" list.
	 * 
	 * @param changeEntry
	 */
	public static void addNotableChange(final Screening screening, final ChangeEntry changeEntry, final boolean forced)
	{
		final WebTarget        webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_NOTABLECHANGE)
				.resolveTemplate("clientUuid", CurrentUtil.getClient().getUuid().toString())
				.resolveTemplate("screeningUuid", screening.getScreeningID().toString())
				.queryParam("forced", forced);
		
		final Response         response  =
			webTarget.request().put(Entity.entity(changeEntry, MediaType.APPLICATION_JSON));
		
		Logger.tag("REST").info(response.toString());
	}
	
	/* ******************************************************************* */
	//// State ops.
	
	/**
	 * Returns <code>true</code> if screening is not null and <br />
	 * {@link ScreeningStatus} is
	 * <ul>
	 * <li>{@link ScreeningStatus#REVIEW_REQUESTED} or</li>
	 * <li>{@link ScreeningStatus#REVIEW_ONGOING} or</li>
	 * <li>{@link ScreeningStatus#REVIEW_FINALIZED}</li>
	 * </ul>
	 * 
	 * @param in
	 * @return
	 */
	public static boolean hasEsuState(final Screening in)
	{
		if(in == null)
		{
			return false;
		}
		if(in.getStatus()
			.equals(ScreeningStatus.REVIEW_REQUESTED)
			||
			in.getStatus().equals(ScreeningStatus.REVIEW_ONGOING)
			||
			in.getStatus().equals(ScreeningStatus.REVIEW_FINALIZED))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Returns <code>true</code> if screening is not null and <br />
	 * {@link ScreeningStatus} is
	 * <ul>
	 * <li>{@link ScreeningStatus#NO_EXPOSURE} or</li>
	 * <li>{@link ScreeningStatus#REVIEW_FINALIZED}</li>
	 * </ul>
	 * 
	 * @param in
	 * @return
	 */
	public static boolean hasFrozenState(final Screening in)
	{
		if(in == null)
		{
			return false;
		}
		if(in.getStatus().equals(ScreeningStatus.NO_EXPOSURE)
			||
			in.getStatus().equals(ScreeningStatus.REVIEW_FINALIZED))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static boolean hasFrozenState(final ScreeningSearchResult<?> in)
	{
		if(in == null)
		{
			return false;
		}
		if(in.getStatus().equals(ScreeningStatus.NO_EXPOSURE)
			||
			in.getStatus().equals(ScreeningStatus.REVIEW_FINALIZED))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Uses {@link CurrentUtil#getClient()} to obtain the necessary (parent-)client.
	 * 
	 * @return <code>true</code> if the screening is already saved. <code>false</code> otherwise.
	 */
	public static boolean existsInStorage(final Screening in)
	{
		if(in == null)
		{
			return false;
		}
		
		return existsInStorage(CurrentUtil.getClient(), in.getScreeningID().toString());
	}
	
	public static boolean existsInStorage(final Client client, final String screeningId)
	{
		try
		{
			return ScreeningDAO.getScreening(client, screeningId) != null;
		}
		catch(final NotFoundException e)
		{
			return false;
		}
	}
	
	/* ******************************************************************* */
	
	/**
	 * Checks if User is ScreeningOwner or ScreeningServiceUser.
	 * 
	 * @param screening
	 * @param user
	 * @return
	 */
	public static boolean isScreeningUser(final Screening screening, final User user)
	{
		if(screening == null || user == null)
		{
			return false;
		}
		if(Objects.equals(user, screening.getScreeningOwner()))
		{
			return true;
		}
		if(Objects.equals(user, screening.getScreeningServiceUser()))
		{
			return true;
		}
		return false;
	}
	
	/* ******************************************************************* */
	
	
	/**
	 * Search for Screening with this ID in given Client<br />
	 * If found, returns a Pair with Client/Screening, or a Pair of <code>null</code> otherwise.
	 * 
	 * @param client
	 * @param screeningIdAsUUID
	 * @return
	 */
	public static Pair<Client, Screening> find(final Client client, final UUID screeningIdAsUUID)
	{
		final Optional<Screening> find = find2(client.getUuid().toString(), screeningIdAsUUID.toString());
		
		if(find.isPresent())
		{
			return Pair.of(client, find.get());
		}
		return Pair.of(null, null);
	}
	
	/**
	 * 
	 * @param clientId
	 * @param screeningId
	 * @return
	 */
	public static Optional<Screening> find2(final String clientId, final String screeningId)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_SINGLE_SCREENING)
				.resolveTemplate("clientUuid", clientId)
				.resolveTemplate("screeningUuid", screeningId);
		

		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 200)
		{
			final ScreeningMetadataDTO dto       = response.readEntity(ScreeningMetadataDTO.class);
			final Screening            screening = ScreeningCreator.convertMetadataDTOToScreening(clientId, dto);
			return Optional.ofNullable(screening);
		}
		
		return Optional.empty();
	}
	
	/**
	 * Search for Screening with this ID in <b>ALL</b> Clients.<br />
	 * 
	 * @param screeningIdAsUUID
	 * @return
	 */
	public static Optional<Pair<ClientMetadataDTO, Screening>> find_unknown_client(final String screeningId)
	{
		final WebTarget        webTarget = RestUtil.getRestClient_ESRADB()
			.getMethodTarget(TEMPLATE_SCR_FIND)
			.resolveTemplate("screeningId", screeningId);
		
		final List<ScreeningInfoDTO> result    =
			webTarget.request().get(new GenericType<List<ScreeningInfoDTO>>(){});
		
		if(result.isEmpty())
		{
			return Optional.empty();
		}
		else
		{
			final Screening scr = ScreeningCreator.convertMetadataDTOToScreening(result.get(0).client.getUuid().toString(),
				result.get(0).screening);
			return Optional.of(Pair.of(result.get(0).client, scr));
		}
		
	}
	
	public static void saveScreeningMetadata(final Screening screening, final VaadinSession session)
	{
		 final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_SINGLE)
		.resolveTemplate("clientUuid", screening.getClientId())
		.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final ScreeningMetadataDTO dto       = ScreeningCreator.convertScreening(screening);
		final Response             response  = webTarget.request().put(Entity.entity(dto, MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() != 404)
		{
			screening.setExistsInBackend(true);
		}
	}
	
	/**
	 * TODO: rewrite code to use {@link #saveScreening(Screening, boolean)}
	 * @param screening
	 * @param session
	 * @param forced
	 * @deprecated use {@link #saveScreening(Screening, boolean)}
	 */
	@Deprecated
	public static void saveScreening(final Screening screening, final VaadinSession session, final boolean forced)
	{
		saveScreening(screening, forced);
	}
	
	public static void saveScreening(final Screening screening, final boolean forced)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		boolean errorOccurred = false;
		
		final WebTarget                  webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_SINGLE_SCREENING)
		.resolveTemplate("clientUuid", screening.getClientId())
		.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final ScreeningMetadataDTO dto       = ScreeningCreator.convertScreening(screening);
		
		Response                   response  =
			webTarget.queryParam("forced", forced).request().put(Entity.entity(dto, MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(response.toString());
		String responseBody = response.readEntity(String.class);
		StringBuilder failedReqs = new StringBuilder("");
		
		if(response.getStatus() != 404)
		{
			screening.setExistsInBackend(true);
		}
		
		if(response.getStatus() / 100 == 5)
		{
			errorOccurred = true;
			failedReqs.append("metadata ");
		}
		
		final WebTarget webTargetWatchlistCompany =
			client.getMethodTarget(SCR_CURRENT_WL_COMPANY)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response  responseWatchlistCompany  = webTargetWatchlistCompany.queryParam("forced", forced).request()
			.put(Entity.entity(screening.getWatchlistCompanyEntries(false), MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(responseWatchlistCompany.toString());
		
		if(responseWatchlistCompany.getStatus() / 100 == 5)
		{
			errorOccurred = true;
			failedReqs.append("companyWatchlist ");
		}
		
		final WebTarget webTargetWatchlistGsss =
				client.getMethodTarget(SCR_CURRENT_WL_GSSS)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response  responseWatchlistGsss  = webTargetWatchlistGsss.queryParam("forced", forced).request()
			.put(Entity.entity(screening.getWatchlistSearchEntriesGsss(false), MediaType.APPLICATION_JSON));
		responseBody = responseWatchlistGsss.readEntity(String.class);
		org.tinylog.Logger.tag("REST").info(responseBody);
		
		if(responseWatchlistGsss.getStatus() / 100 == 5)
		{
			errorOccurred = true;
			failedReqs.append("watchlistGsss ");
		}
		
		final WebTarget webTargetWatchlistVessel =
			client.getMethodTarget(SCR_CURRENT_WL_VESSEN)
		.resolveTemplate("clientUuid", screening.getClientId())
		.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response  responseWatchlistVessel  = webTargetWatchlistVessel.queryParam("forced", forced).request()
			.put(Entity.entity(screening.getVesselsSeaWeb(false), MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(responseWatchlistVessel.toString());
		
		if(responseWatchlistVessel.getStatus() / 100 == 5)
		{
			errorOccurred = true;
			failedReqs.append("watchlistVessel ");
		}
		
		final List<ChangeEntry> notableChanges = screening.getNotableChanges(false);
		
		if(notableChanges != null && !notableChanges.isEmpty())
		{
			// Add changes from db, so we don't overwrite them!
			final var dbList = ScreeningDAO.getNotableChanges(screening).orElse(null);
			if(dbList != null && !dbList.isEmpty())
			{
				dbList.addAll(notableChanges);
				screening.setNotableChanges(dbList);

				final List<ChangeEntry> uniqueEntries = screening.getNotableChanges(false)
					.stream()
					.distinct()
					.collect(Collectors.toList());

				screening.setNotableChanges(uniqueEntries);
			}
		}
		
		// Only store if we have actually gained a notable change
		if(notableChanges != null && !notableChanges.isEmpty())
		{
			final WebTarget webTargetNotableChanges =
				client.getMethodTarget(SCR_CURRENT_NOTABLECHANGES)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());
			
			final Response  responseNotableChanges  = webTargetNotableChanges.queryParam("forced", forced).request()
				.put(Entity.entity(screening.getNotableChanges(false), MediaType.APPLICATION_JSON));
			org.tinylog.Logger.tag("REST").info(responseNotableChanges.toString());
			
			if(responseNotableChanges.getStatus() / 100 == 5)
			{
				errorOccurred = true;
				failedReqs.append("notableChanges ");
			}
		}
		
		if(screening.getBusinessInformationResult(false).getQuestionnaire() != null)
		{
			final WebTarget webTargetBusinessInformation =
					client.getMethodTarget(SCR_CURRENT_BUSINESS)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
			
			final QuestionnaireResultDTO dtoResult =
				QuestionnaireResultCreator.convertResultToDto(screening.getBusinessInformationResult(false));
			response = webTargetBusinessInformation.queryParam("forced", forced).request()
				.put(Entity.entity(dtoResult, MediaType.APPLICATION_JSON));
			org.tinylog.Logger.tag("REST").info(response.toString());
			
			if(response.getStatus() / 100 == 5)
			{
				errorOccurred = true;
				failedReqs.append("business ");
			}
		}
		
		if(screening.getTradeSanctionResult(false).getQuestionnaire() != null)
		{
			final WebTarget webTargetTradeSanctions =
					client.getMethodTarget(SCR_CURRENT_TRADESANCTIONS)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());

			final QuestionnaireResultDTO dtoResult2 =
				QuestionnaireResultCreator.convertResultToDto(screening.getTradeSanctionResult(false));
			response = webTargetTradeSanctions.queryParam("forced", forced).request()
				.put(Entity.entity(dtoResult2, MediaType.APPLICATION_JSON));
			org.tinylog.Logger.tag("REST").info(response.toString());
			
			if(response.getStatus() / 100 == 5)
			{
				errorOccurred = true;
				failedReqs.append("tradeSanction ");
			}
		}
		
		if(errorOccurred)
		{
			System.err.println("Error occurred while saving screening");
			if(UI.getCurrent() != null)
			{
				UI.getCurrent().access(() -> {
					
					DialogBigMessage dbm = DialogBigMessage.New().withTopic("An issue occured!")
							.withContent("An issue occured with your screening. One or several sections were not saved. "
									+ "To prevent data inconsistency and further issues, please re-open the screening on the homepage. "
									+ "You may also report this error message to the ESRA Helpdesk, with a list of steps you did shortly before recieving this message. "
									+ "List of failed requests: " + failedReqs.toString())
							.withWidth("500px").withColor("red");
					dbm.open();
				});
			}
			Thread.dumpStack();
		}
	}
	
	public static void saveBusinessResult(final Screening screening)
	{		
		final WebTarget webTarget =
				RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_BUSINESS)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final QuestionnaireResultDTO dtoResult =
			QuestionnaireResultCreator.convertResultToDto(screening.getBusinessInformationResult(false));	
		
		Response response = webTarget.request().put(Entity.entity(dtoResult, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	public static void saveTradeSanctionResult(final Screening screening)
	{
		final RestClientESRADB       client    = RestUtil.getRestClient_ESRADB();
		
		final WebTarget              webTarget = 
				client.getMethodTarget(SCR_CURRENT_TRADESANCTIONS)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final QuestionnaireResultDTO dtoResult =
			QuestionnaireResultCreator.convertResultToDto(screening.getTradeSanctionResult(false));
		final Response               response  =
			webTarget.queryParam("forced", true).request().put(Entity.entity(dtoResult, MediaType.APPLICATION_JSON));
		System.out.println("==== saveTradeSanctionResult =====");
		System.out.println("" + response);
		final String responseBody = response.readEntity(String.class);
		System.out.println(responseBody);
		System.out.println("==== saveTradeSanctionResult =====");
		
	}
	
	// get Screening Entities
	
	public static Optional<List<SearchEntryGsss>> getWatchlistSearchEntriesGsss(final Screening screening)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget =
				restClient.getMethodTarget(SCR_CURRENT_WL_GSSS)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response         response   = webTarget.request().get();
		System.out.println("ScreeningDAO getWatchlistSearchEntriesGsss " + response);
		
		if(response.getStatus() == 404)
		{
			return Optional.of(new ArrayList<>());
		}
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(List.class, SearchEntryGsss.class);
		
		try
		{
			return Optional.of(om.readValue(responseBody, type));
			
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
	}
	
	public static Optional<List<SearchEntryCompany>> getWatchlistCompanyEntries(final Screening screening)
	{
		final WebTarget        webTarget  = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_WL_COMPANY)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response         response   = webTarget.request().get();
		
		if(response.getStatus() == 404)
		{
			return Optional.of(new ArrayList<>());
		}
		
		final String responseBody = response.readEntity(String.class);
		System.out.println("ScreeningDAO getWatchlistCompanyEntries " + response);
		
		final JavaType type = om.getTypeFactory().constructCollectionType(List.class, SearchEntryCompany.class);
		
		try
		{
			final List<SearchEntryCompany> allCompanies = om.readValue(responseBody, type);
			
			return Optional.of(allCompanies);
			
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
	}
	
	public static Optional<List<SearchEntrySeaweb2Vessel>> getVesselsSeaWeb(final Screening screening)
	{
		final WebTarget        webTarget  = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_WL_VESSEN)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());

		final Response         response   = webTarget.request().get();
		
		System.out.println("ScreeningDAO getVesselsSeaWeb " + response);
		
		if(response.getStatus() == 404)
		{
			return Optional.empty();
		}
		
		final String   responseBody = response.readEntity(String.class);
		final JavaType type         =
			om.getTypeFactory().constructCollectionType(List.class, SearchEntrySeaweb2Vessel.class);
		
		try
		{
			return Optional.of(om.readValue(responseBody, type));
			
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Optional.empty();
		}
	}
	
	public static Optional<List<ChangeEntry>> getNotableChanges(final Screening screening)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget              webTarget  = restClient.getMethodTarget(SCR_CURRENT_NOTABLECHANGES)
			.resolveTemplate("clientUuid", screening.getClientId())
			.resolveTemplate("screeningUuid", screening.getScreeningID().toString());
		
		try
		{
			final List<ChangeEntry> result = webTarget.request().get(new GenericType<List<ChangeEntry>>()
			{});
			return Optional.ofNullable(result);
		}
		catch(final Exception e)
		{
			Logger.debug(e);
			return Optional.empty();
		}
	}
	
	public static void followPublicMessages(final User user, final String clientID, final String screeningID)
	{

		final WebTarget        webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_FOLLOW_PUBLIC)
			.resolveTemplate("clientUuid", clientID)
			.resolveTemplate("screeningUuid", screeningID);
		
		final UserMetadataDTO  dto       = UserCreator.convertUserToMetadataDTO(user);
		final Response         response  = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
	}
	
	public static void unfollowPublicMessages(final User user, final String clientID, final String screeningID)
	{	
		final WebTarget        webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_UNFOLLOW_PUBLIC)
				.resolveTemplate("clientUuid", clientID)
				.resolveTemplate("screeningUuid", screeningID);
		final UserMetadataDTO  dto       = UserCreator.convertUserToMetadataDTO(user);
		final Response         response  = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	public static void deleteMessagingGroup(final Screening item, final MessageGroup group)
	{
		final WebTarget        webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURR_DEL_MESSAGE_GROUP)
				.resolveTemplate("clientUuid", CurrentUtil.getClient().getUuid())
				.resolveTemplate("screeningUuid", item.getScreeningID())
				.resolveTemplate("groupId", group.getId());
		
		final Response         response  = webTarget.request().delete();
		System.out.println(response);
	}
	
	public static void storeFiles(final Screening screening, final List<BinaryElement> pendingFiles)
	{
		pendingFiles.removeIf(file -> file instanceof BinaryElementNoDataDTO);
		
		final List<BinaryElementPendingDTO> actualPendings = new ArrayList<>();
		pendingFiles.forEach(file -> {
			actualPendings.add((BinaryElementPendingDTO) file);
		});

		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_FILES)
				.resolveTemplate("clientUuid", CurrentUtil.getClient().getUuid())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response  response  = webTarget.request().post(Entity.entity(actualPendings, MediaType.APPLICATION_JSON));
		System.out.println("==== STOREFILES =====");
		System.out.println("" + response);
		final String responseBody = response.readEntity(String.class);
		System.out.println(responseBody);
		System.out.println("==== STOREFILES =====");
	}
	
	public static Optional<List<BinaryElement>> getFiles(final Screening screening)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_FILES)
				.resolveTemplate("clientUuid", CurrentUtil.getClient().getUuid())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response         response   = webTarget.request().get();
		System.out.println("==== GETFILES =====");
		System.out.println("" + response);
		final String responseBody = response.readEntity(String.class);
		System.out.println("==== GETFILES =====");
		
		final JavaType type = om.getTypeFactory().constructCollectionType(List.class, BinaryElementNoDataDTO.class);
		
		try
		{
			final List<BinaryElementNoDataDTO> fileList = om.readValue(responseBody, type);
			
			final List<BinaryElement> otherList = new ArrayList<>();
		
			fileList.forEach(file -> otherList.add(file));
			
			return Optional.of(otherList);
			
		}
		catch(final JsonProcessingException e)
		{
			return Optional.empty();
		}
	}
	
	public static void deleteFile(final Client client, final Screening screening, final BinaryElement element)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_FILES_SINGLE)
				.resolveTemplate("clientUuid", CurrentUtil.getClient().getUuid())
				.resolveTemplate("screeningUuid", screening.getScreeningID())
				.resolveTemplate("fileId", element.getId());
		
		final Response         response   = webTarget.request().delete();
		final String responseBody = response.readEntity(String.class);
		System.out.println(responseBody);
	}
	
	public static Optional<QuestionnaireResult> getTradeSanctionResult(final Screening screening)
	{
		final WebTarget        webTarget  = RestUtil.getRestClient_ESRADB().getMethodTarget(SCR_CURRENT_TRADESANCTIONS)
				.resolveTemplate("clientUuid", screening.getClientId())
				.resolveTemplate("screeningUuid", screening.getScreeningID());
		
		final Response         response   = webTarget.request().get();
		final String responseBody = response.readEntity(String.class);
		
		try
		{
			final QuestionnaireResultDTO dto = om.readValue(responseBody, QuestionnaireResultDTO.class);
			
			return Optional
				.of(QuestionnaireResultCreator.convertDtoToQuestionnaireResult(screening.getClientId(), dto));
		}
		catch(final JsonProcessingException e)
		{
			System.err.print(e);
			return Optional.empty();
		}
		
	}
	
	public static Optional<QuestionnaireResult> getBusinessInformationResult(final Screening screening)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient
			.getMethodTarget(
				"/client/" + screening.getClientId() + "/screening/" + screening.getScreeningID() + "/business");
		
		final Response         response   = webTarget.request().get();
		System.out.println(response);
		
		try
		{
			final String responseBody = response.readEntity(String.class);
			final QuestionnaireResultDTO dto = om.readValue(responseBody, QuestionnaireResultDTO.class);
			
			return Optional
				.of(QuestionnaireResultCreator.convertDtoToQuestionnaireResult(screening.getClientId(), dto));
		}
		catch(final JsonProcessingException e)
		{
			System.err.print(e);
			return Optional.empty();
		}
		
	}

	
	/* ******************************************************************* */
	
	// public static String TEMPLATE_ALL_BASE = "/client/{clientUuid}/screenings_base";
	// public static String TEMPLATE_ALL_COUNT = "/client/{clientUuid}/screenings_count";
	
	public static synchronized Integer countScreenings(final Client client, final QueryDescription desc)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ALL_COUNT)
			.resolveTemplate("clientUuid", client.getUuid().toString());
		
		webTarget = QueryHelper.enhance(webTarget, desc, null);
		
		System.out.println(webTarget.getUri());
		
		final Integer result = webTarget.request().get(Integer.class);
		return result;
	}
	
	public static Integer countArchivedScreenings(final Client client, final QueryDescription desc)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ARCHIVE_COUNT)
			.resolveTemplate("clientUuid", client.getUuid().toString());
		
		webTarget = QueryHelper.enhance(webTarget, desc, null);
		
		System.out.println(webTarget.getUri());
		
		final Integer result = webTarget.request().get(Integer.class);
		return result;
	}
	
	public static Integer countEsuScreenings(
		final Client client,
		final QueryDescription desc,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_COUNT)
			.resolveTemplate("clientUuid", client.getUuid().toString());
		
		webTarget = QueryHelper.enhanceEsu(webTarget, desc, null, tags, countries);
		
		System.out.println(webTarget.getUri());
		
		final Integer result = webTarget.request().get(Integer.class);
		return result;
	}
	
	public static Integer countEsuInboxScreenings(
		final Client client,
		final User user,
		final QueryDescription desc,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_INBOX_COUNT)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("userEmail", user.getEmailAddress());
		
		webTarget = QueryHelper.enhanceEsu(webTarget, desc, null, tags, countries);
		
		System.out.println(webTarget.getUri());
		
		final Integer result = webTarget.request().get(Integer.class);
		return result;
	}
	
	public static Integer countEsuFavoriteScreenings(
		final Client client,
		final User user,
		final QueryDescription desc,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_FAVORITES_COUNT)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("userEmail", user.getEmailAddress());
		
		webTarget = QueryHelper.enhanceEsu(webTarget, desc, null, tags, countries);
		
		System.out.println(webTarget.getUri());
		
		final Integer result = webTarget.request().get(Integer.class);
		return result;
	}
	
	
	/**
	 * Used in DataProvider / FetchCallback
	 * @param clientId
	 * @param desc
	 * @param query
	 * @return
	 */
	public static synchronized List<ScreeningMetadataBase> getScreenings(
		final String clientId,
		final QueryDescription desc,
		final Query<?, ?> query)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ALL_BASE)
			.resolveTemplate("clientUuid", clientId);
		webTarget = QueryHelper.enhance(webTarget, desc, query);
		
		Logger.tag("REST").info("Call pageable screenings - " + webTarget.getUri());
		
		final Response response = webTarget.request().get();
		
		Logger.tag("REST").info("Response - " + response.getStatus());
		
		final List<ScreeningMetadataBase> returningValue =
			response.readEntity(new GenericType<List<ScreeningMetadataBase>>()
			{});
		
		Logger.tag("REST").info("Pagesize - " + returningValue.size());
		
		return returningValue;
	}
	
	public static List<ScreeningMetadataBase>
		getArchivedScreenings(final String clientId, final QueryDescription desc, final Query<?, ?> query)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ARCHIVE_BASE)
			.resolveTemplate("clientUuid", clientId);
		
		webTarget = QueryHelper.enhance(webTarget, desc, query);
		
		Logger.tag("REST").info(webTarget.getUri().toString());
		
		return webTarget.request().get(new GenericType<List<ScreeningMetadataBase>>()
		{});
	}
	
	public static List<ScreeningMetadataEsuBase> getEsuScreenings(
		final Client client,
		final User user,
		final QueryDescription desc,
		final Query<?, ?> query,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_BASE)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("userEmail", user.getEmailAddress());
		
		webTarget = QueryHelper.enhanceEsu(webTarget, desc, query, tags, countries);
		final Response response = webTarget.request().get();
		
		System.out.println(response);
		final List<ScreeningMetadataEsuBase> returningValue =
			response.readEntity(new GenericType<List<ScreeningMetadataEsuBase>>()
			{});
		
		return returningValue;
	}
	
	public static List<ScreeningMetadataEsuBase> getEsuInboxScreenings(
		final Client client,
		final User user,
		final QueryDescription desc,
		final Query<?, ?> query,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_INBOX_BASE)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("userEmail", user.getEmailAddress());
		
		webTarget = QueryHelper.enhance(webTarget, desc, query);
		
		return webTarget.request().get(new GenericType<List<ScreeningMetadataEsuBase>>()
		{});
	}
	
	public static List<ScreeningMetadataEsuBase> getEsuFavoriteScreenings(
		final Client client,
		final User user,
		final QueryDescription desc,
		final Query<?, ?> query,
		final Set<String> tags,
		final Set<String> countries)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ESU_FAVORITES_BASE)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("userEmail", user.getEmailAddress());
		
		webTarget = QueryHelper.enhanceEsu(webTarget, desc, query, tags, countries);
		
		return webTarget.request().get(new GenericType<List<ScreeningMetadataEsuBase>>()
		{});
	}
	
	public static ScreeningMetadataBase getScreening(final Client client, final String id)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_READ)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("screeningUuid", id);
		
		return webTarget.request().get(ScreeningMetadataBase.class);
	}
	
	public static ScreeningMetadataDTO getArchivedScreening(final String clientId, final String screeningID)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ARCHIVED_SCREENING)
			.resolveTemplate("clientUuid", clientId)
			.resolveTemplate("screeningUuid", screeningID);

		Logger.tag("REST").info(webTarget.getUri());
		
		return webTarget.request().get(ScreeningMetadataDTO.class);
	}
	
	/* ******************************************************************* */
	
	/**
	 * SubsidiaryScreening tasks add new SearchEntryCompanyitems.<br />
	 * Additionally, the Screening should be blocked in this state which should prevent saving.<br />
	 * <b>FOR NOW: Blocking on frontend side!</b> -> Do NOT check for "blocked" and save anyway.
	 * 
	 * @param screening
	 * @param taskCreatedBy
	 * @param taskId
	 */
	public static void updateAfterSubsidiaryScreening(
		final String clientId,
		final Screening screening,
		final String taskId,
		final String taskCreatedBy)
	{
		// Update if Screening is finished (readonly)
		final boolean forcedUpdate = false;
		
		screening.setLastChangedBy("SubsidiaryScreening task " + taskId + " started by " + taskCreatedBy);
		screening.setLastChanged(Instant.now());
		
		final ScreeningMetadataDTO dto        = ScreeningCreator.convertScreening(screening);
		
		final RestClientESRADB     restclient = RestUtil.getRestClient_ESRADB();
		
		//// Save Screening itself
		
		// @Put("{clientUuid}/screening/{screeningUuid}")
		final WebTarget            webTarget1 = restclient.getMethodTarget(SCR_CURRENT_SINGLE)
			.resolveTemplate("clientUuid", clientId)
			.resolveTemplate("screeningUuid", screening.getScreeningID())
			.queryParam("forced", forcedUpdate);
		
		final Response             response1  =
			webTarget1.request().put(Entity.entity(dto, MediaType.APPLICATION_JSON));
		
		// TODO: rework error handling
		final Family                     family     = response1.getStatusInfo().getFamily();
		// closes the "original response entity data stream if open" -- NEEDED?
		final String                     readEntity = response1.readEntity(String.class);
		if(family != Response.Status.Family.SUCCESSFUL)
		{
			throw new RuntimeException("REST error: " + readEntity);
		}
		
		Logger.tag("REST").info(response1.toString());
		
		//// Save Watchlist Company entries
		
		// @Put("{clientUuid}/screening/{screeningUuid}/watchlist/company")
		final WebTarget webTarget2  = restclient.getMethodTarget(SCR_CURRENT_SINGLE + "/watchlist/company")
			.resolveTemplate("clientUuid", clientId)
			.resolveTemplate("screeningUuid", screening.getScreeningID())
			.queryParam("forced", forcedUpdate);
		
		final Response  response2   = webTarget2.request()
			.put(Entity.entity(screening.getWatchlistCompanyEntries(false), MediaType.APPLICATION_JSON));
		
		// TODO: rework error handling
		final Family          family2     = response2.getStatusInfo().getFamily();
		// closes the "original response entity data stream if open" -- NEEDED?
		final String          readEntity2 = response2.readEntity(String.class);
		if(family2 != Response.Status.Family.SUCCESSFUL)
		{
			throw new RuntimeException("REST error: " + readEntity2);
		}
		
		Logger.tag("REST").info(response2.toString());
	}
	
	/**
	 * Is this screening blocked by a subsidiary task?
	 * 
	 * @param screening
	 * @return true if blocked
	 */
	public static boolean isBlocked(final Screening screening)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_FUNC_ISBLOCKED)
			.resolveTemplate("screeningId", screening.getScreeningID().toString());
		
		final Response  response  = webTarget.request().get();
		
		if(response.getStatus() == 404)
		{
			return false;
		}
		
		return response.readEntity(Boolean.class);
	}

	public static void deleteScreening(final String clientId, final String screeningId) {
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ARCHIVED_SCREENING)
				.resolveTemplate("clientUuid", clientId)
				.resolveTemplate("screeningUuid", screeningId);
		
		final Response response = webTarget.request().delete();
		
		Logger.tag("REST").info(response);
			
		return;
	}
	
}
