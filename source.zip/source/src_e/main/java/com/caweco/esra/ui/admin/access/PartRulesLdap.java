package com.caweco.esra.ui.admin.access;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.ClientAssignmentRuleLdapDAO;
import com.caweco.esra.dao.access.AccessControlRuleDAO;
import com.caweco.esra.dao.access.ClientAssignmentRuleDAO;
import com.caweco.esra.dto.ClientAssignmentRuleLdapDTO;
import com.caweco.esra.dto.creator.ClientAssignmentRuleLdapCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.access.AccessControlRuleLdap;
import com.caweco.esra.entities.access.ClientAssignmentRuleLdap;
import com.caweco.esra.entities.ldap.LdapOrg;
import com.caweco.esra.entities.saml.SamlCountry;
import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.caweco.esra.ui.dialogs.DialogContentImpl;
import com.rapidclipse.framework.server.data.renderer.CaptionRenderer;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;


public class PartRulesLdap extends VerticalLayout
{
	private List<ClientAssignmentRuleLdap> carsAllClients;
	
	Comparator<ClientAssignmentRuleLdap>   car0 = Comparator.comparing(car -> car.getCompany().getRepresentation());
	Comparator<ClientAssignmentRuleLdap>   car1 = Comparator
		.comparing(car -> car.getSamlCountry() != null ? car.getSamlCountry().getCountryName() : "");
	
	
	Comparator<ClientAssignmentRuleLdap>   car2 = Comparator
		.comparing(car -> car.getDepartment() != null ? car.getDepartment().getRepresentation() : "");
	
	
	public PartRulesLdap()
	{
		super();
		this.initUI();
		
		UiHelper.setAriaLabel(this.btnNewAR, Aria.get("PageAccessControl_ar_add"));
		UiHelper.setAriaLabel(this.btnDeleteAR, Aria.get("PageAccessControl_ar_remove"));
		UiHelper.setAriaLabel(this.btnNewCAR, Aria.get("PageAccessControl_car_add"));
		UiHelper.setAriaLabel(this.btnDeleteCAR, Aria.get("PageAccessControl_car_remove"));
		
		this.initGrids();
		
	}
	
	private void initGrids()
	{
		// Add Column(s)
		this.gridCAR
			.addColumn(
			new CaptionRenderer<>(car -> car.getClientToAssignTo().getClientDescription())).setKey(
				"clientToAssignTo").setHeader("Client").setSortable(false);
		
		// Sorting
		Column<AccessControlRuleLdap>    depCompanyColumn = this.gridAR.getColumnByKey("company.representation");
		this.gridAR.sort(GridSortOrder.asc(depCompanyColumn).build());
		
		//// Grid data
		this.gridAR.setItems(AccessControlRuleDAO.findAll_Ldap());
		
		Set<ClientAssignmentRuleLdap> carsAllClientsS = ClientAssignmentRuleDAO.findAll_allClients_ldap();
		this.carsAllClients = new ArrayList<ClientAssignmentRuleLdap>(carsAllClientsS);
		this.carsAllClients.sort(this.car0.thenComparing(this.car1).thenComparing(this.car2));
		
		this.gridCAR.setItems(this.carsAllClients);
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDeleteAR}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDeleteAR_onClick(ClickEvent<Button> event)
	{
		Optional<AccessControlRuleLdap> firstSelectedItem = this.gridAR.getSelectionModel().getFirstSelectedItem();
		
		if (firstSelectedItem.isPresent())
		{
			DialogConfirm.show(() ->
			{
				Set<AccessControlRuleLdap> items = AccessControlRuleDAO.findAll_Ldap();
				items.remove(firstSelectedItem.get());
				AccessControlRuleDAO.delete(firstSelectedItem.get());
				Notificator.success("Removed ACL.");
				
				this.gridAR.setItems(items);
			}, "Delete rule \"" + firstSelectedItem.get().getRepresentation() + "\"?");
		}
		else
		{
			Notificator.error("No rule selected.");
		}
		
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewAR}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewAR_onClick(ClickEvent<Button> event)
	{
		DialogContentImpl.New(new DialogNewAccessRule()).setTextHeader("New access rule").setOnOk(it ->
		{
			
			AccessControlRuleLdap           rule     = it.getRule();
			
			Optional<AccessControlRuleLdap> ruleSame = AccessControlRuleDAO.findAll_Ldap().stream()
				.filter(ex -> ex.mayFitSameSamlAttributeSet(rule)).findFirst();
			
			if (rule == null)
			{
				Notificator.error("No company selected!");
				throw new RuntimeException();
			}
			
			Set<AccessControlRuleLdap> items = AccessControlRuleDAO.findAll_Ldap();
			if (ruleSame.isPresent())
			{
				Notificator.warn("Existing rule \"" + ruleSame.get().getRepresentation() + "\" may be valid for same Users!");
			}
				
				AccessControlRuleDAO.create(rule);
				items.add(rule);
				
				Notificator.success("New rule saved!");
				
				this.gridAR.setItems(items);
			
		}).setWidth("600px").setHeight("400px").show();
		
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDeleteCAR}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDeleteCAR_onClick(ClickEvent<Button> event)
	{
		Optional<ClientAssignmentRuleLdap> firstSelectedItem = this.gridCAR.getSelectionModel().getFirstSelectedItem();
		
		if (firstSelectedItem.isPresent())
		{			
			DialogConfirm.show(() ->
			{
				Client                        client = firstSelectedItem.get().getClientToAssignTo();
		
				RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
				
				WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/assignmentRules/" + firstSelectedItem.get().getUuid().toString());
				
				Response response = webTarget.request().delete();
				
				ClientAssignmentRuleLdapDTO responseBody = response.readEntity(ClientAssignmentRuleLdapDTO.class);

				ClientAssignmentRuleLdapCreator.convertDTOToClientAssignment(responseBody);
				Notificator.success("Removed Client-assignment rule.");
				
				this.carsAllClients.remove(firstSelectedItem.get());
				this.gridCAR.setItems(this.carsAllClients);
				
				
			}, "Delete rule \"" + firstSelectedItem.get().getRepresentation() + "\"?");
		}
		else
		{
			Notificator.error("No rule selected.");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewCAR}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewCAR_onClick(ClickEvent<Button> event)
	{
		
		DialogContentImpl.New(new DialogNewClientAssignmentRule()).setTextHeader("New client assignment rule").setOnOk(it ->
		{
			
			ClientAssignmentRuleLdap           rule     = it.getRule();
			
			Optional<ClientAssignmentRuleLdap> ruleSame = this.carsAllClients.stream()
				.filter(ex -> ex.mayFitSameAttributeSet(rule)).findFirst();
			
			if (rule == null)
			{
				Notificator.error("No company selected!");
				throw new RuntimeException();
			}
			else if (this.carsAllClients.contains(rule))
			{
				Notificator.error("There is already a rule with this settings!");
				throw new RuntimeException();
			}
			else if (ruleSame.isPresent())
			{
				Notificator.warn("Existing rule \"" + ruleSame.get().getRepresentation() + "\" may be valid for same Users!");
				throw new RuntimeException();
			}
			else
			{
				// ClientAssignmentRule
				ClientAssignmentRuleLdapDAO.create(rule);
				
				Notificator.success("New rule saved!");
				
				this.carsAllClients.add(rule);
				this.gridCAR.setItems(this.carsAllClients);
			}
			
		}).setWidth("600px").setHeight("400px").show();
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridAR}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridAR_selectionChange(SelectionEvent<Grid<AccessControlRuleLdap>, AccessControlRuleLdap> event)
	{
		Optional<AccessControlRuleLdap> firstSelectedItem = event.getFirstSelectedItem();
		this.btnDeleteAR.setEnabled(firstSelectedItem.isPresent());
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCAR}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCAR_selectionChange(SelectionEvent<Grid<ClientAssignmentRuleLdap>, ClientAssignmentRuleLdap> event)
	{
		Optional<ClientAssignmentRuleLdap> firstSelectedItem = event.getFirstSelectedItem();
		this.btnDeleteCAR.setEnabled(firstSelectedItem.isPresent());
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.hlAR = new HorizontalLayout();
		this.h3AccessRules = new H3();
		this.btnDeleteAR = new Button();
		this.btnNewAR = new Button();
		this.gridAR = new Grid<>(AccessControlRuleLdap.class, false);
		this.hlCAR = new HorizontalLayout();
		this.h3ClientAssignmentRules = new H3();
		this.btnDeleteCAR = new Button();
		this.btnNewCAR = new Button();
		this.gridCAR = new Grid<>(ClientAssignmentRuleLdap.class, false);
		
		this.setSpacing(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.hlAR.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.h3AccessRules.setClassName("esra");
		this.h3AccessRules.setText("Access rules");
		this.btnDeleteAR.setEnabled(false);
		this.btnDeleteAR.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDeleteAR.setIcon(VaadinIcon.TRASH.create());
		this.btnNewAR.setIcon(VaadinIcon.PLUS.create());
		this.gridAR.getStyle().set("flex-basis", "0");
		this.gridAR.addColumn(v -> Optional.ofNullable(v).map(AccessControlRuleLdap::getCompany)
			.map(AccessControlCompany::getRepresentation).orElse(null)).setKey("company.representation").setHeader("Company")
			.setSortable(true);
		this.gridAR
			.addColumn(v -> Optional.ofNullable(v).map(AccessControlRuleLdap::getDepartment).map(LdapOrg::getRepresentation)
				.orElse(null))
			.setKey("department.representation").setHeader("Department").setSortable(true);
		this.gridAR.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.hlCAR.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.h3ClientAssignmentRules.setClassName("esra");
		this.h3ClientAssignmentRules.setText("Client Assignment Rules");
		this.btnDeleteCAR.setEnabled(false);
		this.btnDeleteCAR.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDeleteCAR.setIcon(VaadinIcon.TRASH.create());
		this.btnNewCAR.setIcon(VaadinIcon.PLUS.create());
		this.gridCAR.getStyle().set("flex-basis", "0");
		this.gridCAR
			.addColumn(v -> Optional.ofNullable(v).map(ClientAssignmentRuleLdap::getCompany)
				.map(AccessControlCompany::getRepresentation).orElse(null))
			.setKey("company.representation").setHeader("Company").setSortable(true);
		this.gridCAR.addColumn(v -> Optional.ofNullable(v).map(ClientAssignmentRuleLdap::getSamlCountry)
			.map(SamlCountry::getRepresentation).orElse(null)).setKey("samlCountry.representation").setHeader("Country")
			.setSortable(true);
		this.gridCAR.addColumn(v -> Optional.ofNullable(v).map(ClientAssignmentRuleLdap::getDepartment)
			.map(LdapOrg::getRepresentation).orElse(null)).setKey("department.representation").setHeader("Department")
			.setSortable(true);
		this.gridCAR.setSelectionMode(Grid.SelectionMode.SINGLE);
		
		this.h3AccessRules.setSizeUndefined();
		this.btnDeleteAR.setSizeUndefined();
		this.btnNewAR.setSizeUndefined();
		this.hlAR.add(this.h3AccessRules, this.btnDeleteAR, this.btnNewAR);
		this.hlAR.setFlexGrow(1.0, this.h3AccessRules);
		this.h3ClientAssignmentRules.setSizeUndefined();
		this.btnDeleteCAR.setSizeUndefined();
		this.btnNewCAR.setSizeUndefined();
		this.hlCAR.add(this.h3ClientAssignmentRules, this.btnDeleteCAR, this.btnNewCAR);
		this.hlCAR.setFlexGrow(1.0, this.h3ClientAssignmentRules);
		this.hlAR.setSizeUndefined();
		this.gridAR.setSizeUndefined();
		this.hlCAR.setSizeUndefined();
		this.gridCAR.setSizeUndefined();
		this.add(this.hlAR, this.gridAR, this.hlCAR, this.gridCAR);
		this.setFlexGrow(1.0, this.gridAR);
		this.setFlexGrow(1.0, this.gridCAR);
		this.setSizeFull();
		
		this.btnDeleteAR.addClickListener(this::btnDeleteAR_onClick);
		this.btnNewAR.addClickListener(this::btnNewAR_onClick);
		this.gridAR.addSelectionListener(this::gridAR_selectionChange);
		this.btnDeleteCAR.addClickListener(this::btnDeleteCAR_onClick);
		this.btnNewCAR.addClickListener(this::btnNewCAR_onClick);
		this.gridCAR.addSelectionListener(this::gridCAR_selectionChange);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Grid<AccessControlRuleLdap>    gridAR;
	private Button                         btnDeleteAR, btnNewAR, btnDeleteCAR, btnNewCAR;
	private Grid<ClientAssignmentRuleLdap> gridCAR;
	private HorizontalLayout               hlAR, hlCAR;
	private H3                             h3AccessRules, h3ClientAssignmentRules;
	// </generated-code>
	
}
