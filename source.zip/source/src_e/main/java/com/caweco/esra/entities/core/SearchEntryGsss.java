
package com.caweco.esra.entities.core;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.namematch.NMResponse;
import com.caweco.esra.microstream.converters.GenericObjectKeyDeserializer;
import com.caweco.esra.microstream.converters.GenericObjectKeySerializer;
import com.caweco.esra.ui.sanctions.bean.SearchType;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


public class SearchEntryGsss implements HasMatchDataCollection
{
	
	private final Instant             created                   = Instant.now();
	private String                    createdBy;
	
	private SearchType                searchtype;
	private String                    comment                   = "";
	private Integer                   appliedThreshold;
	private String			          country					= "";
	
	// from NMResponse
	private String[]                  response_statusMessage;
	// from NMResponse
	private String                    response_nameToSearch;
	// from NMResponse
	private long                      response_numberOfGSSSHitsOrig;
	
	private List<GsssMatch>           filtered_gsssMatchResults = new ArrayList<>();
	
	@JsonSerialize(keyUsing = GenericObjectKeySerializer.class)
	@JsonDeserialize(keyUsing = GenericObjectKeyDeserializer.class)
	private Map<GsssMatch, MatchData> matchData                 = new HashMap<>();
	
	private UUID                      id                        = UUID.randomUUID();
	
	public SearchEntryGsss()
	{
		// Required for Jackson
	}
	
	/**
	 * HINT: Uses user from supplied VaadinSession.
	 * 
	 * @param searchtype
	 * @param results
	 */
	public SearchEntryGsss(final SearchType searchtype, final NMResponse results, Client client, String mail, final String country)
	{
		super();
		this.createdBy                     = mail;
		this.searchtype                    = searchtype;
		this.country                       = country;
		
		this.response_statusMessage        = results.getStatusMessage();
		this.response_nameToSearch         = results.getNameToSearch();
		this.response_numberOfGSSSHitsOrig = results.getNumberOfGSSSHits();
		
		final Optional<Integer> treshold = Optional.ofNullable(client.getClientConfiguration().getThresholdGsssResultScore());

		if(treshold.isPresent())
		{
			this.appliedThreshold = treshold.get();
			
			if(results.getGsssMatchResults() != null)
			{
				final List<GsssMatch> toRemove = results.getGsssMatchResults().stream()
					.filter(gsssMatch -> gsssMatch.getHitScoreNormalized() < treshold.get())
					.collect(Collectors.toList());
				
				results.getGsssMatchResults().removeAll(toRemove);
				// LOG.info(" - Removed {} item(s) from CompanyGsssMatchResult", toRemove.size());
				
				this.filtered_gsssMatchResults.addAll(results.getGsssMatchResults());
			}
		}
		else
		{
			this.appliedThreshold = null;
			
			if(results.getGsssMatchResults() != null)
			{
				this.filtered_gsssMatchResults.addAll(results.getGsssMatchResults());
			}
		}
	}
		
	public UUID getId()
	{
		return this.id;
	}
	
	public void setId(final UUID id)
	{
		this.id = id;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public SearchType getSearchtype()
	{
		return this.searchtype;
	}
	
	public String[] getResponse_statusMessage()
	{
		return this.response_statusMessage;
	}
	
	public String getResponse_nameToSearch()
	{
		return this.response_nameToSearch;
	}
	
	public long getResponse_numberOfGSSSHitsOrig()
	{
		return this.response_numberOfGSSSHitsOrig;
	}
	
	public List<GsssMatch> getGsssMatchResults()
	{
		return this.filtered_gsssMatchResults;
	}
	
	public Integer getAppliedThreshold()
	{
		return this.appliedThreshold;
	}
	
	@Override
	public String getComment()
	{
		return this.comment;
	}
	
	@Override
	public SearchEntryGsss setComment(final String comment)
	{
		this.comment = comment;
		return this;
	}
	
	@Override
	public Map<GsssMatch, MatchData> getMatchData()
	{
		return this.matchData;
	}
	
	@Override
	public SearchEntryGsss setMatchData(final Map<GsssMatch, MatchData> matchData)
	{
		this.matchData = matchData;
		return this;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString() {
		return "SearchEntryGsss [created=" + created + ", createdBy=" + createdBy + ", searchtype=" + searchtype
				+ ", comment=" + comment + ", appliedThreshold=" + appliedThreshold + ", country=" + country
				+ ", response_statusMessage=" + Arrays.toString(response_statusMessage) + ", response_nameToSearch="
				+ response_nameToSearch + ", response_numberOfGSSSHitsOrig=" + response_numberOfGSSSHitsOrig
				+ ", filtered_gsssMatchResults=" + filtered_gsssMatchResults + ", matchData=" + matchData + ", id=" + id
				+ "]";
	}
	
	
}
