package com.caweco.esra.business.utils;

import static java.time.temporal.ChronoField.HOUR_OF_DAY;
import static java.time.temporal.ChronoField.MINUTE_OF_HOUR;
import static java.time.temporal.ChronoField.NANO_OF_SECOND;
import static java.time.temporal.ChronoField.SECOND_OF_MINUTE;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.FormatStyle;
import java.time.format.ResolverStyle;
import java.util.Locale;
import com.caweco.esra.business.properties.ESRABaseSettingsProvider;


public class ChronoUtil
{
	
	public static final DateTimeFormatter LOCAL_DATE_TIME_FORFILE;
	static
	{
		// Derived from DateTimeFormatter.ISO_LOCAL_DATE_TIME
		
		// @formatter:off
		
		LOCAL_DATE_TIME_FORFILE = new DateTimeFormatterBuilder()
			.parseCaseInsensitive()
			.append(DateTimeFormatter.ISO_LOCAL_DATE)
			.appendLiteral('_')
			.appendValue(HOUR_OF_DAY, 2)
			.appendLiteral('-')
			.appendValue(MINUTE_OF_HOUR, 2)
            .optionalStart()
            .appendLiteral('-')
            .appendValue(SECOND_OF_MINUTE, 2)
            .optionalStart()
            .appendLiteral('_')
            .appendFraction(NANO_OF_SECOND, 0, 9, false)
			.toFormatter()
			.withResolverStyle(ResolverStyle.STRICT)
			.withChronology(IsoChronology.INSTANCE);
		
		// @formatter:on
	}
	
	
	/**
	 * Produces something like "2022-12-05 16:20 (UTC)"
	 */
	public static final DateTimeFormatter X_DATE_TIME;
	static
	{
		X_DATE_TIME = new DateTimeFormatterBuilder()
			.append(DateTimeFormatter.ISO_LOCAL_DATE)
			.appendLiteral(' ')
			.appendValue(HOUR_OF_DAY, 2)
			.appendLiteral(':')
			.appendValue(MINUTE_OF_HOUR, 2)
			.optionalStart()
			.appendLiteral(' ')
			.appendLiteral('(')
			.parseCaseSensitive()
			.appendZoneRegionId()
			.appendLiteral(')')
			.toFormatter()
			.withResolverStyle(ResolverStyle.STRICT)
			.withChronology(IsoChronology.INSTANCE);
	}
	
	
	/**
	 * Formats a instant with pattern "dd MMMM yyyy HH:mm" and system default ZoneId.
	 * 
	 * @param i a {@link Instant}
	 * @return
	 */
	public static String formatInstant(final Instant i)
	{
		return DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss").withZone(ZoneId.systemDefault()).format(i);
	}
	
	/**
	 * Formats a instant like 2022-12-05 17:20 (Europe/Berlin). Uses {@link ESRABaseSettingsProvider#DEFAULT_ZONEID}
	 * @param i
	 * @return
	 */
	public static String formatInstant2(final Instant i)
	{
		StringBuilder sb = new StringBuilder();
		if (i != null)
			X_DATE_TIME.withZone(ZoneId.of(ESRABaseSettingsProvider.DEFAULT_ZONEID)).formatTo(i, sb);
		return sb.toString();
	}

	/**
	 * Instant to LocalizedDate-String. Uses FormatStyle.MEDIUM and the provided {@link Locale} and {@link ZoneId}
	 * 
	 * @param a the Appendable
	 * @param i the instant
	 * @param l the Locale
	 * @param z the ZoneId
	 */
	public static void append_InstantAsLocalizedDateString(Appendable a, final Instant i, final Locale l, final ZoneId z)
	{
		if(i != null)
		{
			DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(l).withZone(z).formatTo(i, a);
		}
	}
	
	/**
	 * Convenience method: uses {@link ChronoUtil#append_InstantAsLocalizedDateString(Appendable, Instant, Locale, ZoneId)}
	 * with values from {@link ESRABaseSettingsProvider#DEFAULT_LOCALE} and
	 * {@link ESRABaseSettingsProvider#DEFAULT_ZONEID}
	 * 
	 * @param d
	 * @return
	 */
	public static String convert_InstantAsLocaldateString(final Instant d)
	{
		StringBuilder sb = new StringBuilder();
		Locale l = ESRABaseSettingsProvider.DEFAULT_LOCALE;
		ZoneId z = ZoneId.of(ESRABaseSettingsProvider.DEFAULT_ZONEID);
		append_InstantAsLocalizedDateString(sb, d, l, z);
		return sb.toString();
	}
	
	/**
	 * Current {@link LocalDateTime} of Zone "UTC" formatted by {@link ChronoUtil#LOCAL_DATE_TIME_FORFILE} formatter 
	 * followed by "_utc".
	 * @return
	 */
	public static String getUtcLocaldateStringForFile()
	{
		String out = ChronoUtil.LOCAL_DATE_TIME_FORFILE.format(LocalDateTime.now(ZoneId.of("UTC")));
		return out + "_utc";
	}
	
}
