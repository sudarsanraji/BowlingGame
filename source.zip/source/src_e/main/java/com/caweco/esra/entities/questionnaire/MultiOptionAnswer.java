package com.caweco.esra.entities.questionnaire;

import java.util.HashSet;
import java.util.Set;


public class MultiOptionAnswer extends Answer
{
	
	Set<ChooseableValues> answers = new HashSet<>();
	
	/**
	 * 
	 */
	public MultiOptionAnswer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Set<ChooseableValues> getAnswers()
	{
		if(this.answers == null)
		{
			this.answers = new HashSet<>();
		}
		return this.answers;
	}
	
	public void setAnswers(final Set<ChooseableValues> answers)
	{
		this.answers = answers;
	}
}
