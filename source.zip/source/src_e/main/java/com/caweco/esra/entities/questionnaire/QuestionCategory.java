package com.caweco.esra.entities.questionnaire;

import java.util.Objects;
import java.util.UUID;

import com.rapidclipse.framework.server.resources.Caption;


public class QuestionCategory
{
	private UUID uid;
	private int		id;
	private String	category;
	
	public QuestionCategory()
	{
		super();
	}
	
	public QuestionCategory(int id, String category)
	{
		super();
		this.id = id;
		this.category = category;
	}
	
	public QuestionCategory(QuestionCategory cat)
	{
		super();
		this.id = cat.getId();
		this.category = cat.getCategory();
	}
	
	public UUID getUid()
	{
		return uid;
	}

	public void setUid(UUID uid)
	{
		this.uid = uid;
	}

	@Caption("ID")
	public int getId()
	{
		return id;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	@Caption("Category")
	public String getCategory()
	{
		return category;
	}
	
	public void setCategory(String category)
	{
		this.category = category;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuestionCategory other = (QuestionCategory) obj;
		return id == other.id;
	}
	
	
	
}
