package com.caweco.esra.dto.creator;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.dao.questionnaire.QuestionnaireDAO;
import com.caweco.esra.dto.QuestionResultDTO;
import com.caweco.esra.dto.QuestionnaireResultDTO;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionResult;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;


public class QuestionnaireResultCreator
{
	public static QuestionnaireResult convertDtoToQuestionnaireResult(String clientId, QuestionnaireResultDTO dto)
	{
		QuestionnaireResult result = new QuestionnaireResult();
		result.setFinishedDate(dto.getFinishedDate());
		result.setResultID(dto.getResultID());
		result.setYear(dto.getYear());
		result.setQuestionnaire(QuestionnaireDAO.findById(clientId, dto.getQuestionnaireID()));
		
		List<QuestionResult> resultList = new ArrayList<>();
		
		if(dto.getResults() != null)
		{
			
			List<Question> questions = QuestionDAO.getQuestions(String.valueOf(dto.getQuestionnaireID()), clientId);
			
			dto.getResults().forEach(resultDto ->
			{
				
				QuestionResult resultActual = new QuestionResult();
				
				resultActual.setAnswer(AnswerCreator.convertDTOToAnswer(resultDto.getAnswer()));
				resultActual.setCompleted(resultDto.getCompleted());
				
				Optional<Question> optionalQuestion =
					questions.stream().filter(q -> q.getId().equals(resultDto.getQuestionId())).findFirst();
				
				if(optionalQuestion.isPresent())
				{
					resultActual.setQuestion(optionalQuestion.get());					
					resultList.add(resultActual);
				}
			});
			
		}
		
		result.setResults(resultList);
		
		return result;
	}
	
	public static QuestionnaireResultDTO convertResultToDto(QuestionnaireResult original)
	{
		QuestionnaireResultDTO dto = new QuestionnaireResultDTO();
		dto.setFinishedDate(original.getFinishedDate());
		dto.setQuestionnaireID(original.getQuestionnaire().getQuestionnaireID());
		dto.setResultID(original.getResultID());
		
		List<QuestionResultDTO> dtoList = new ArrayList<>();
		
		original.getResults().forEach(result ->
		{
			QuestionResultDTO resultDto = new QuestionResultDTO();
			resultDto.setAnswer(AnswerCreator.convertAnswerToDTO(result.getAnswer()));
			resultDto.setCompleted(result.getCompleted());
			resultDto.setQuestionId(result.getQuestion().getId());
			
			dtoList.add(resultDto);
		});
		
		dto.setResults(dtoList);
		return dto;
		
	}
}
