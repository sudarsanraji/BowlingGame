
package com.caweco.esra.subsidary.common;

import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.rest.general.Subsidiary;

// Usage: Frontend, Backend & as DTO
public class SubNode
{
	public boolean      isRoot   = false;
	public Set<SubNode> children = new HashSet<>(0);
	public SubNodeState state    = SubNodeState.CREATED_WAITING;
	public String       companyID;
	public Subsidiary   rawSubsidiaryData;
	
	/**
	 * Root node: Level 0, direct children of root: level 1 and so on..
	 */
	public int          level    = 0;
}
