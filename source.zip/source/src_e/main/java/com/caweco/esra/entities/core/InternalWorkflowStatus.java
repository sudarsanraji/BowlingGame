package com.caweco.esra.entities.core;

public enum InternalWorkflowStatus
{
	RISK_EVALUATION,
	TRADE_SANCTIONS, // NO_UCD - kept for data consistency reasons
	BUSINESS_INFO; // NO_UCD - kept for data consistency reasons
}
