package com.caweco.esra.dao.esu;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.ESUTemplateMetadataDTO;
import com.caweco.esra.dto.creator.ESUTemplateCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.ESUTemplate;
import com.caweco.esra.entities.core.ESUTemplateCS;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class ESUTemplateDAO
{
	
	
	public static String TEMPLATE_CREATE = "/client/{clientUuid}/esuTemplate/";
	public static String TEMPLATE_READ = "/client/{clientUuid}/esuTemplate/{esuTemplateId}";
	public static String TEMPLATE_ALL = "/client/{clientUuid}/esuTemplates/";
	public static String TEMPLATE_UPDATE = TEMPLATE_CREATE;
	public static String TEMPLATE_DELETE = TEMPLATE_READ;
	
	
	public static ESUTemplateMetadataDTO createEsuTemplate(Client client, ESUTemplate it) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget(TEMPLATE_CREATE).resolveTemplate("clientUuid", client.getUuid().toString());
		
		ESUTemplateMetadataDTO response = webTarget.request().post(Entity.entity(it, MediaType.APPLICATION_JSON), ESUTemplateMetadataDTO.class);
		Logger.tag("REST").info(response);
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the esu template  " + it.getName() + " belonging to the client " + client.getClientDescription());	
		return response;
	}
	
	public static List<ESUTemplateMetadataDTO> getEsuTemplates(Client client)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ALL).resolveTemplate("clientUuid", client.getUuid().toString());
		
		return webTarget.request().get(new GenericType<List<ESUTemplateMetadataDTO>>(){});
	}
	
	public static String getEsuTemplateContent(Client client, Integer esuTemplateId) {
		
		Map<String, Object> params = new HashMap<>(2);
		params.put("clientUuid", client.getUuid().toString());
		params.put("esuTemplateId", esuTemplateId);
		
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_READ).resolveTemplates(params);
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		String result = response.readEntity(String.class);
		
		System.out.println("## Fetched EsuTemplateContent");
		
		return result;
	}
	
	public static void updateEsuTemplate(Client client, ESUTemplate it) {
		
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_UPDATE).resolveTemplate("clientUuid", client.getUuid().toString());
		
		Response response = webTarget.request().put(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the esu template  " + it.getName() + " belonging to the client " + client.getClientDescription());	
	}
	
	public static void deleteEsuTemplate(Client client, int esuTemplateId) {
		
		Map<String, Object> params = new HashMap<>(2);
		params.put("clientUuid", client.getUuid().toString());
		params.put("esuTemplateId", esuTemplateId);
		
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_DELETE).resolveTemplates(params);
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the esu template  " + esuTemplateId + " belonging to the client " + client.getClientDescription());	
	}
	

	/****************************************/
	
	public static Set<ESUTemplateCS> getAll(Client client)
	{
		Set<ESUTemplateCS> collect = getEsuTemplates(client).stream().map(ESUTemplateCreator::convert).collect(Collectors.toSet());
		return collect;
	}
	
	public static ESUTemplateCS createEsuTemplate(Client client, ESUTemplateCS it) {
		ESUTemplateMetadataDTO createEsuTemplate = createEsuTemplate(client, ESUTemplateCreator.convert(client, it));
		it.updateMetadata(createEsuTemplate);
		return it;
	}
	
	public static void updateEsuTemplate(Client client, ESUTemplateCS it) {
		updateEsuTemplate(client, ESUTemplateCreator.convert(client, it));
	}
	
	public static void deleteEsuTemplate(Client client, ESUTemplateCS it) {
		deleteEsuTemplate(client, it.getId());
	}
	
	public static ESUTemplateCS cloneTemplate(ESUTemplateCS orig, String newName) {
		ESUTemplateMetadataDTO metadataDTO = new ESUTemplateMetadataDTO(-1, newName, true, orig.getVersion());
		return new ESUTemplateCS(metadataDTO, orig.getContentRaw());
	}
	
	/****************************************/
	
	

	
	public static List<ESUTemplateCS> findAll_active(Client client)
	{
		List<ESUTemplateCS> collect = client.getEsuTemplates(false).stream().filter(ESUTemplateCS::isActive).collect(Collectors.toList());
//		collect.sort(Comparator.comparing(ESUTemplate::getName, Comparator.nullsFirst(Comparator.naturalOrder())));
		return collect;
	}


}
