package com.caweco.esra.dao;

import java.util.HashSet;
import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class LineOfBusinessDAO {
	
	static RestClientESRADB client = RestUtil.getRestClient_ESRADB();
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();

	public static void saveExistingLob(final LineOfBusiness element, final String clientId) {
		final WebTarget webTarget = client.getMethodTarget("/client/" + clientId + "/lob/" + element.getId());
		final Response response = webTarget.request().put(Entity.entity(element, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the LOB "  + element.getName() + " to the client : " +  clientId);
	}

	public static void saveNewLob(final LineOfBusiness element, final String clientId) {
		final WebTarget webTarget = client.getMethodTarget("/client/" + clientId + "/lob/");
		final Response response = webTarget.request().post(Entity.entity(element, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the LOB "  + element.getName() + " to the client : " +  clientId);
	}

	public static void deleteExistingLob(final LineOfBusiness element, final String clientId) {
		final WebTarget webTarget = client.getMethodTarget("/client/" + clientId + "/lob/" + element.getId());
		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" ddleted the LOB "  + element.getName() + " to the client : " +  clientId);
	}

	public static Set<LineOfBusiness> getLobs(final Client client2) {
		final WebTarget webTarget = client.getMethodTarget("/client/" + client2.getUuid() + "/lob/");
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 404)
		{
			return new HashSet<>();
		}
		
		final String responseBody = response.readEntity(String.class);
		
		final JavaType type = om.getTypeFactory().constructCollectionType(Set.class, LineOfBusiness.class);
		
		try {
			final Set<LineOfBusiness> lobSet = om.readValue(responseBody, type);
			
			return lobSet;
			
		} catch (final JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	
		
	}

}
