package com.caweco.esra.ui.admin.clients;

import java.time.Instant;
import java.util.Map;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ManualClientUserAssignment;
import com.rapidclipse.framework.server.resources.Caption;


public class UserClientAssignment
{
	private User						user;
	private ManualClientUserAssignment	assignmentInfo;
	
	public UserClientAssignment(Map.Entry<User, ManualClientUserAssignment> it)
	{
		this.user = it.getKey();
		this.assignmentInfo = it.getValue();
	}
	
	@Caption("User")
	public User getUser()
	{
		return this.user;
	}
	
	public void setUser(User user)
	{
		this.user = user;
	}
	
	public ManualClientUserAssignment getAssignmentInfo()
	{
		return this.assignmentInfo;
	}
	
	public void setAssignmentInfo(ManualClientUserAssignment assignmentInfo)
	{
		this.assignmentInfo = assignmentInfo;
	}
	
	@Caption("Assignment")
	public boolean isManuallyAssigned()
	{
		return (this.assignmentInfo != null);
	}
	
	public String getAssignedBy()
	{
		return this.assignmentInfo != null ? this.assignmentInfo.getAssignedBy() : null;
	}
	
	public Instant getAssignedAt()
	{
		return this.assignmentInfo != null ? this.assignmentInfo.getAssignedAt() : null;
	}
	
}
