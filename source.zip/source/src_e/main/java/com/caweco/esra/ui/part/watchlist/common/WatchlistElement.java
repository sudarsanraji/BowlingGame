package com.caweco.esra.ui.part.watchlist.common;

import java.util.Optional;

import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.function.SerializableBiConsumer;


public interface WatchlistElement<C extends Component & WatchlistElement<C>>
{
	public Optional<PartWatchList> getWatchListRoot();
	
	/**
	 * Called "setReadOnlyCustom" to not accidentally interfere with vaadin's {@link HasValue#setReadOnly(boolean)}
	 * @param readOnly
	 */
	public void setReadOnlyCustom(boolean readOnly);
	
	/**
	 * 
	 */
	default void asEsuPart() {};
	

	/**
	 * Just gets the current flag value. <br />
	 * Does not recalc the flag value.
	 * 
	 * @return
	 */
	public int getFlagValue();
	
	public int getFlagValueOld();
	
	public String getName();
	
	public void setFlagChangeListener(SerializableBiConsumer<C, Boolean> flagChangeListener);
	
	/**
	 * To be called if something was changed and the change affects the flag value. <br />
	 * Commonly called from the WatchlistElement's children.
	 */
	public void recalcFlag();
	
}
