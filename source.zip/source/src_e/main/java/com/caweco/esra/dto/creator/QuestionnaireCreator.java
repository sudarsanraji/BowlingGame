package com.caweco.esra.dto.creator;

import java.util.ArrayList;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.questionnaire.QuestionnaireDAO;
import com.caweco.esra.dto.QuestionDTO;
import com.caweco.esra.dto.QuestionnaireDTO;
import com.caweco.esra.dto.QuestionnaireExportDTO;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.Questionnaire;

public class QuestionnaireCreator {

	public static QuestionnaireDTO questionnaireToDto(Questionnaire object)
	{
		QuestionnaireDTO dto = new QuestionnaireDTO();
		dto.setActive(object.getActive());
		dto.setCategories(object.getCategories());
		dto.setCategory(object.getCategory());
		dto.setDescription(object.getDescription());
		dto.setQuestionnaireID(object.getQuestionnaireID());
		dto.setVersion(object.getVersion());
		return dto;
	}
	
	public static QuestionnaireExportDTO questionnaireToExportDto(Questionnaire object)
	{
		QuestionnaireExportDTO dto = new QuestionnaireExportDTO();
		dto.setActive(object.getActive());
		dto.setCategories(object.getCategories());
		dto.setCategory(object.getCategory());
		dto.setDescription(object.getDescription());
		
		ArrayList<QuestionDTO> list = new ArrayList<>();
		
		object.getQuestions(false).forEach(q -> {
			list.add(QuestionCreator.convertQuestionToDTO(q));
		});
		
		dto.setQuestions(list);
		dto.setVersion(object.getVersion());
		return dto;
	}
	
	public static Questionnaire exportDtoToQuestionnaire(QuestionnaireExportDTO object)
	{
		Questionnaire q = new Questionnaire();
		q.setQuestionnaireID(QuestionnaireDAO.getNextQuestionnaireID());
		q.setActive(object.getActive());
		q.setCategories(object.getCategories());
		q.setCategory(object.getCategory());
		q.setDescription(object.getDescription());
		ArrayList<Question> list = new ArrayList<>();
		
		object.getQuestions().forEach(question -> {
			list.add(QuestionCreator.convertDTOToQuestion(q.getQuestionnaireID(), question));
		});
		
		q.setQuestions(list);

		q.setVersion(object.getVersion());
		return q;
	}
	
	public static Questionnaire dtoToQuestionnaire(QuestionnaireDTO dto)
	{
		Questionnaire object = new Questionnaire();
		object.setActive(dto.getActive());
		object.setCategories(dto.getCategories());
		object.setCategory(dto.getCategory());
		object.setDescription(dto.getDescription());
		object.setQuestionnaireID(dto.getQuestionnaireID());

		object.setVersion(dto.getVersion());
		return object;
	}
}
