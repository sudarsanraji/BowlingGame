package com.caweco.esra.entities.rest.information;

import com.caweco.esra.business.properties.RestSettingsProvider;


/**
 * https://paas-cara-dev.apps.adp.allianz/api/v1/cara/rest/CompanyInfoService/
 * 
 * @author JA
 *
 */
public class CISearch
{
	private String	username		= "";
	private String	password		= "";
	private String	systemName		= "";
	private String	searchType		= "";
	private String	sessionHandle	= "";
	
	private String	companyBvdId	= "";
	
	private String	customField1	= "";
	private String	customField2	= "";
	private String	customField3	= "";
	private String	customField4	= "";
	private String	customField5	= "";
	
	/**
	 * *******************
	 * Constructors ******
	 * *******************
	 */
	public CISearch()
	{
		// Standard Constructor for Customization
	}
	
	/**
	 * Mandatory search Parameter
	 * 
	 * @param username
	 * @param password
	 * @param system
	 * @param searchType
	 * @param companyBvDId
	 */
	public CISearch(
		final String username,
		final String password,
		final String system,
		final String searchType,
		final String companyBvDId)
	{
		super();
		this.username = username;
		this.password = password;
		this.systemName = system;
		this.searchType = searchType;
		this.companyBvdId = companyBvDId;
		
		this.customField1 = RestSettingsProvider.DEFAULT_SEARCHDEFINITION_VALUE;
		this.customField2 = RestSettingsProvider.DEFAULT_BUSINESSUNIT_VALUE;
	}
	
	/**
	 * *******************
	 * getter/setter *****
	 * *******************
	 */
	
	public String getUsername()
	{
		return this.username;
	}
	
	public CISearch setUsername(final String username) // NO_UCD - setter
	{
		this.username = username;
		return this;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public CISearch setPassword(final String password) // NO_UCD - setter
	{
		this.password = password;
		return this;
	}
	
	public String getSystemName()
	{
		return this.systemName;
	}
	
	public CISearch setSystemName(final String systemName) // NO_UCD - setter
	{
		this.systemName = systemName;
		return this;
	}
	
	public String getSearchType()
	{
		return this.searchType;
	}
	
	public CISearch setSearchType(final String searchType) // NO_UCD - setter
	{
		this.searchType = searchType;
		return this;
	}
	
	public String getSessionHandle()
	{
		return this.sessionHandle;
	}
	
	public CISearch setSessionHandle(final String sessionHandle) // NO_UCD - setter
	{
		this.sessionHandle = sessionHandle;
		return this;
	}
	
	public String getCompanyBvdId()
	{
		return this.companyBvdId;
	}
	
	public CISearch setCompanyBvdId(final String companyBvdId) // NO_UCD - setter
	{
		this.companyBvdId = companyBvdId;
		return this;
	}
	
	public String getCustomField1()
	{
		return this.customField1;
	}
	
	public CISearch setCustomField1(final String customField1)
	{
		this.customField1 = customField1;
		return this;
	}
	
	public String getCustomField2()
	{
		return this.customField2;
	}
	
	public CISearch setCustomField2(final String customField2) // NO_UCD - setter
	{
		this.customField2 = customField2;
		return this;
	}
	
	public String getCustomField3()
	{
		return this.customField3;
	}
	
	public CISearch setCustomField3(final String customField3) // NO_UCD - setter
	{
		this.customField3 = customField3;
		return this;
	}
	
	public String getCustomField4()
	{
		return this.customField4;
	}
	
	public CISearch setCustomField4(final String customField4) // NO_UCD - setter
	{
		this.customField4 = customField4;
		return this;
	}
	
	public String getCustomField5()
	{
		return this.customField5;
	}
	
	public CISearch setCustomField5(final String customField5) // NO_UCD - setter
	{
		this.customField5 = customField5;
		return this;
	}
	
}
