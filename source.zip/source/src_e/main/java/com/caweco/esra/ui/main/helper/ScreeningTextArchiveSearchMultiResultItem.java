
package com.caweco.esra.ui.main.helper;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.dto.ScreeningMetadataDTO;
import com.caweco.esra.dto.creator.ScreeningCreator;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.rapidclipse.framework.server.resources.Caption;


public class ScreeningTextArchiveSearchMultiResultItem implements ScreeningSearchResult<ScreeningMetadataBase>
{
	
	// This is the root of all of the items below.
	private final ScreeningMetadataBase screening;
	private final String                clientId;
	
	public ScreeningTextArchiveSearchMultiResultItem(String clientId, final ScreeningMetadataBase screening)
	{
		super();
		this.clientId  = clientId;
		this.screening = screening;
	}
	
	@Caption("Process ID")
	@Override
	public String getId()
	{
		return this.screening.getScreeningID();
	}
	
	@Override
	public String getRepresentation()
	{
		if(this.screening.getMatches() != null)
		{
			
			// A entry of "combined" is e.g. ["Company Profile, Organization", "Sulzer AG"]
			final TreeMap<String, String> combined = this.screening.getMatches().entrySet().stream().collect(Collectors
				.toMap(ScreeningTextArchiveSearchMultiResultItem::combineTypes, e -> e.getKey(), (a, b) -> a,
					TreeMap::new));
			
			final StringBuilder           sb       = new StringBuilder();
			combined.forEach((k, v) -> {
				if(!k.isEmpty())
				{
					sb.append("<div>");
					sb.append("<b>");
					sb.append(k);
					sb.append(":</b> ").append(v);
					sb.append("</div>\n");
				}
			});
			
			return sb.toString();
		}
		else
		{
			return "";
		}
	}
	
	private static String combineTypes(final Entry<String, Set<String>> typesEntry)
	{
		if(typesEntry.getValue() == null)
		{
			return "";
		}
		else
		{
			return typesEntry.getValue()
				.stream()
				.filter(Objects::nonNull)
				.sorted(Comparator.naturalOrder())
				.collect(Collectors.joining(", "));
		}
		
	}
	
	@Override
	public ScreeningMetadataBase getScreeningRaw()
	{
		return screening;
	}
	
	@Override
	public Optional<Screening> fetchScreening()
	{
		ScreeningMetadataDTO archivedScreening =
			ScreeningDAO.getArchivedScreening(clientId, this.screening.getScreeningID());
		if(archivedScreening != null)
		{
			return Optional.of(ScreeningCreator.convertMetadataDTOToScreening(clientId, archivedScreening));
		}
		return Optional.empty();
	}
	
	@Override
	public ScreeningSearchResult.Type getType()
	{
		return this.screening.getMatches() != null ? ScreeningSearchResult.Type.MULTI
			: ScreeningSearchResult.Type.COMMON_MATCH;
	}
	
	@Override
	public Set<Pair<String, String>> getMatches()
	{
		if(this.screening.getMatches() != null)
		{
			final Set<Pair<String, String>> collect = this.screening.getMatches().entrySet().stream()
				.map(it -> Pair.of(it.getValue().stream().collect(Collectors.joining(", ")), it.getKey()))
				.collect(Collectors.toSet());
			return collect;
		}
		else
		{
			final Set<Pair<String, String>> res = new HashSet<>();
			res.add(Pair.of("Name", this.getRepresentation()));
			return res;
		}
	}
	
	@Override
	public String getName()
	{
		return this.screening.getName();
	}
	
	@Override
	public LineOfBusiness getLob()
	{
		return this.screening.getLineOfBusiness();
	}
	
	@Override
	public Function getFunction()
	{
		return this.screening.getFunction();
	}
	
	@Override
	public OE getOe()
	{
		return this.screening.getOe();
	}
	
	@Override
	public ScreeningStatus getStatus()
	{
		return this.screening.getStatus();
	}
	
	@Override
	public LocalDate getScreeningDate()
	{
		return this.screening.getScreeningDate();
	}
	
	@Override
	public String getScreeningOwnerEmail()
	{
		return this.screening.getScreeningOwner();
	}
	
	@Override
	public String getScreeningServiceUserEmail()
	{
		return this.screening.getScreeningServiceUser();
	}
	
	public ScreeningMetadataBase getScreeningMetadata()
	{
		return this.screening;
	}
	
	@Override
	public String getClientId()
	{
		return clientId;
	}
	
}
