package com.caweco.esra.entities.rest.general;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * CARA v5
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class ShareHolder
{
	private String	name;
	private String	country;
	private String	direct;
	private String	total;
	private String	infoDate;
	@JsonProperty("bvDId")
	private String	bvdId;
	@JsonProperty("lEI")
	private String	lei;
	
	private String	type;
	
	// 2022-01-12: "Unrecognized field "salutation""
	// private String	salutation;
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(String country)
	{
		this.country = country;
	}
	
	public String getDirect()
	{
		return this.direct;
	}
	
	public void setDirect(String direct)
	{
		this.direct = direct;
	}
	
	public String getTotal()
	{
		return this.total;
	}
	
	public void setTotal(String total)
	{
		this.total = total;
	}
	
	public String getInfoDate()
	{
		return this.infoDate;
	}
	
	public void setInfoDate(String infoDate)
	{
		this.infoDate = infoDate;
	}
	
	public String getBvdId()
	{
		return this.bvdId;
	}
	
	public void setBvdId(String bvdId)
	{
		this.bvdId = bvdId;
	}
	
	public String getLEI()
	{
		return this.lei;
	}
	
	public void setLEI(String LEI)
	{
		this.lei = LEI;
	}
	
	public String getType()
	{
		return this.type;
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
}
