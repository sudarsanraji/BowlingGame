package com.caweco.esra.dto;

import java.time.LocalDate;
import java.util.Set;

import com.caweco.esra.entities.questionnaire.AnswerType;
import com.caweco.esra.entities.questionnaire.ChooseableValues;


public class AnswerDTO {

	private Integer answerID;
	private String comment;
	private AnswerType answerType;
	
	//AnswerType specific fields
	//DateAnswer
	private LocalDate dateTime;
	
	//DurationAnswer
	private LocalDate start;
	private LocalDate end;
	
	//FreeText
	private String text;
	
	//MultiOption
	private Set<ChooseableValues> answers;
	
	//SingleOption
	ChooseableValues value;
	
	
	public Integer getAnswerID() {
		return answerID;
	}

	public void setAnswerID(Integer answerID) {
		this.answerID = answerID;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public AnswerType getAnswerType() {
		return answerType;
	}

	public void setAnswerType(AnswerType answerType) {
		this.answerType = answerType;
	}

	public LocalDate getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDate dateTime) {
		this.dateTime = dateTime;
	}

	public LocalDate getStart() {
		return start;
	}

	public void setStart(LocalDate start) {
		this.start = start;
	}

	public LocalDate getEnd() {
		return end;
	}

	public void setEnd(LocalDate end) {
		this.end = end;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Set<ChooseableValues> getAnswers() {
		return answers;
	}

	public void setAnswers(Set<ChooseableValues> answers) {
		this.answers = answers;
	}

	public ChooseableValues getValue() {
		return value;
	}

	public void setValue(ChooseableValues value) {
		this.value = value;
	}
	
	
}
