package com.caweco.esra.ui.beans.mvcb;

import com.vaadin.flow.data.binder.HasItemsAndComponents.ItemComponent;

public interface HasTags_20210201<T>
{
	void delete(final ItemComponent<T> l);
}
