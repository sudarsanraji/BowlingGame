package com.caweco.esra.entities.core;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;

import com.caweco.esra.entities.meta.HasRepresentation;


public class Monitoring implements HasRepresentation
{
	public static Monitoring New(String starterUserMail, LocalDate end, String reference, @Nullable Monitoring previous)
	{
		Objects.requireNonNull(end);
		Objects.requireNonNull(reference);
		Monitoring monitoring = new Monitoring();
		monitoring.setEnd(end);
		monitoring.setReference(reference);
		if(previous != null)
		{
			previous.setPrevious(null);
			monitoring.setPrevious(previous);
		}

		monitoring.setStartedBy(starterUserMail);

		return monitoring;
	}
	
	private Instant				start	= Instant.now();
	private LocalDate			end;
	private String				reference;
	
	private String				startedBy;
	private Monitoring	previous;
	
	public Instant getStart()
	{
		return this.start;
	}
	
	public void setStart(Instant start)
	{
		this.start = start;
	}
	
	public LocalDate getEnd()
	{
		return this.end;
	}
	
	public void setEnd(LocalDate end)
	{
		this.end = end;
	}
	
	public String getReference()
	{
		return this.reference;
	}
	
	public void setReference(String reference)
	{
		this.reference = reference;
	}
	
	public String getStartedBy()
	{
		return this.startedBy;
	}
	
	public void setStartedBy(String startedBy)
	{
		this.startedBy = startedBy;
	}
	
	public Monitoring getPrevious()
	{
		return this.previous;
	}
	
	public Monitoring setPrevious(Monitoring previous)
	{
		this.previous = previous;
		return this;
	}
	
	////
	
	public static boolean isActive(@Nullable Monitoring m)
	{
		if(m == null)
			return false;
		boolean isRunning = LocalDate.now().isAfter(m.getEnd());
		return isRunning;
	}
	
	@Override
	public String getRepresentation()
	{
		StringBuilder sb = new StringBuilder();
		if(this.getReference() != null)
		{
			sb.append(this.getReference());
			sb.append(" / ");
		}
		sb.append(this.getEnd());
		
		return sb.toString();
	}
}
