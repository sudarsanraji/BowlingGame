package com.caweco.esra.ui.part.watchlist.seawebimo.ck;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.rest.seaweb2.APSCompanyComplianceDetails_v2;
import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

public class KeyContentElemOwnerInfo extends VerticalLayout
{
	static String UN = "N/A";
	
	enum CompanyRole
	{
		GROUP_OWNER("Group Owner", APSShipDetail_v2::getGroupBeneficialOwner),
		SHIPMANAGER("Shipmanager", APSShipDetail_v2::getShipManager),
		OPERATOR("Operator", APSShipDetail_v2::getOperator),
		DOC_COMPANY("DOC Company", APSShipDetail_v2::getDOCCompany),
		REGISTERED_OWNER("Registered Owner", APSShipDetail_v2::getRegisteredOwner),
		TECHNICAL_MANAGER("Technical Manager", APSShipDetail_v2::getTechnicalManager),
		BAREBOAT_OWNER("Bareboat Owner", (it) -> null);
		
		String                             representation;
		Function<APSShipDetail_v2, String> provider;
		
		CompanyRole(String prepresentation, Function<APSShipDetail_v2, String> provider)
		{
			this.representation = prepresentation;
			this.provider = provider;
		}
		
		String getRepresentation()
		{
			return this.representation;
		}
		
		String getProvidedValue(APSShipDetail_v2 item)
		{
			return this.provider.apply(item);
		}
	}
	
	enum CompanyField
	{
		F1_COMPLIANCE("Compliance", APSCompanyComplianceDetails_v2::getCompanyOverallComplianceStatus),
		F2_PARENT("Parent", APSCompanyComplianceDetails_v2::getParentCompanyComplianceRisk),
		F3_OFAC("OFAC", APSCompanyComplianceDetails_v2::getCompanyOnOFACSanctionList),
		F4_SSI("SSI", APSCompanyComplianceDetails_v2::getCompanyOnOFACSSIList),
		F5_UN("UN", APSCompanyComplianceDetails_v2::getCompanyOnUNSanctionList),
		F6_EU("EU", APSCompanyComplianceDetails_v2::getCompanyOnEUSanctionList),
		F7_BES("BES", APSCompanyComplianceDetails_v2::getCompanyOnBESSanctionList),
		F8_CANADA("Canada", APSCompanyComplianceDetails_v2::getCompanyOnCanadianSanctionList),
		F9_AUSTRALIA("Australia", APSCompanyComplianceDetails_v2::getCompanyOnAustralianSanctionList),
		F10_SWISS("Swiss", APSCompanyComplianceDetails_v2::getCompanyOnSwissSanctionList),
		F11_OFAC_COUNTRY("OFAC Country", APSCompanyComplianceDetails_v2::getCompanyInOFACSanctionedCountry),
		F12_FATF_COUNTRY("FATF Country", APSCompanyComplianceDetails_v2::getCompanyInFATFJurisdiction);
		
		
		String                                           representation;
		Function<APSCompanyComplianceDetails_v2, String> provider;
		
		CompanyField(String prepresentation, Function<APSCompanyComplianceDetails_v2, String> provider)
		{
			this.representation = prepresentation;
			this.provider = provider;
		}
		
		String getRepresentation()
		{
			return this.representation;
		}
		
		String getProvidedValue(APSCompanyComplianceDetails_v2 item)
		{
			return this.provider.apply(item);
		}
	}
	
	private SearchEntrySeaweb2Vessel item;
	
	
	public KeyContentElemOwnerInfo()
	{
		super();
		this.initUI();
	}
	
	public void setItem(SearchEntrySeaweb2Vessel item)
	{
		this.item = item;
		
		this.refreshUI();
		
		
	}
	
	private void refreshUI()
	{
		this.div.removeAll();
		
		if (this.item.getShipCount() > 0 && this.item.getShipDetails() != null)
		{
			this.addHeadRow();
			this.addRoleRow(CompanyRole.GROUP_OWNER);
			this.addRoleRow(CompanyRole.SHIPMANAGER);
			this.addRoleRow(CompanyRole.OPERATOR);
			this.addRoleRow(CompanyRole.DOC_COMPANY);
			this.addRoleRow(CompanyRole.REGISTERED_OWNER);
			this.addRoleRow(CompanyRole.TECHNICAL_MANAGER);
			this.addRoleRow(CompanyRole.BAREBOAT_OWNER);
		}
		else
		{
			this.div.setText("No content found");
		}
	}
	
	private void addHeadRow()
	{
		List<Div> headItems = this.addRowUncheck(
			"Relationship",
			"Company",
			CompanyField.F1_COMPLIANCE.getRepresentation(),
			CompanyField.F2_PARENT.getRepresentation(),
			CompanyField.F3_OFAC.getRepresentation(),
			CompanyField.F4_SSI.getRepresentation(),
			CompanyField.F5_UN.getRepresentation(),
			CompanyField.F6_EU.getRepresentation(),
			CompanyField.F7_BES.getRepresentation(),
			CompanyField.F8_CANADA.getRepresentation(),
			CompanyField.F9_AUSTRALIA.getRepresentation(),
			CompanyField.F10_SWISS.getRepresentation(),
			CompanyField.F11_OFAC_COUNTRY.getRepresentation(),
			CompanyField.F12_FATF_COUNTRY.getRepresentation());
		headItems.forEach(div ->
		{
			div.getClassNames().add("head");
		});
		
	}
	
	
	private void addRoleRow(CompanyRole role)
	{
		APSShipDetail_v2 shipDetails = this.item.getShipDetails();
		
		String roleName = role.getRepresentation();
		String companyName = role.getProvidedValue(shipDetails);
		Optional<APSCompanyComplianceDetails_v2> company = shipDetails.getCompanyComplianceDetails()
			.stream()
			.filter(it -> StringUtils.equalsIgnoreCase(it.getShortCompanyName(), companyName)).findFirst();
		
		if (company.isPresent())
		{
			this.addRow(roleName,
				companyName,
				CompanyField.F1_COMPLIANCE.getProvidedValue(company.get()),
				CompanyField.F2_PARENT.getProvidedValue(company.get()),
				CompanyField.F3_OFAC.getProvidedValue(company.get()),
				CompanyField.F4_SSI.getProvidedValue(company.get()),
				CompanyField.F5_UN.getProvidedValue(company.get()),
				CompanyField.F6_EU.getProvidedValue(company.get()),
				CompanyField.F7_BES.getProvidedValue(company.get()),
				CompanyField.F8_CANADA.getProvidedValue(company.get()),
				CompanyField.F9_AUSTRALIA.getProvidedValue(company.get()),
				CompanyField.F10_SWISS.getProvidedValue(company.get()),
				CompanyField.F11_OFAC_COUNTRY.getProvidedValue(company.get()),
				CompanyField.F12_FATF_COUNTRY.getProvidedValue(company.get()));
		}
		else
		{
			this.addRowUncheck(roleName, "", UN, UN, UN, UN, UN, UN, UN, UN, UN, UN, UN, UN);
		}
	}
	
	
	private List<Div> addRow(String first, String sec, String s01, String s02, String s03, String s04, String s05,
		String s06,
		String s07, String s08, String s09, String s10, String s11, String s12)
	{
		List<Div> items = new ArrayList<Div>();
		items.add(this.addDiv(first, false));
		items.add(this.addDiv(sec, false));
		items.add(this.addDiv(s01, true));
		items.add(this.addDiv(s02, true));
		items.add(this.addDiv(s03, true));
		items.add(this.addDiv(s04, true));
		items.add(this.addDiv(s05, true));
		items.add(this.addDiv(s06, true));
		items.add(this.addDiv(s07, true));
		items.add(this.addDiv(s08, true));
		items.add(this.addDiv(s09, true));
		items.add(this.addDiv(s10, true));
		items.add(this.addDiv(s11, true));
		items.add(this.addDiv(s12, true));
		return items;
	}
	
	private List<Div> addRowUncheck(String first, String sec, String s01, String s02, String s03, String s04, String s05,
		String s06,
		String s07, String s08, String s09, String s10, String s11, String s12)
	{
		List<Div> items = new ArrayList<Div>();
		items.add(this.addDiv(first, false));
		items.add(this.addDiv(sec, false));
		items.add(this.addDiv(s01, false));
		items.add(this.addDiv(s02, false));
		items.add(this.addDiv(s03, false));
		items.add(this.addDiv(s04, false));
		items.add(this.addDiv(s05, false));
		items.add(this.addDiv(s06, false));
		items.add(this.addDiv(s07, false));
		items.add(this.addDiv(s08, false));
		items.add(this.addDiv(s09, false));
		items.add(this.addDiv(s10, false));
		items.add(this.addDiv(s11, false));
		items.add(this.addDiv(s12, false));
		return items;
	}
	
	private Div addDiv(String content, boolean check)
	{
		Div newDiv = new Div();
		newDiv.getClassNames().add("it");
		
		String contentClean = StringUtils.stripToEmpty(content);
		
		if (check)
		{
			if (StringUtils.equalsIgnoreCase("0", contentClean))
			{
				newDiv.setText("OK");
			}
			else if (StringUtils.equalsIgnoreCase("1", contentClean))
			{
				newDiv.setText("Warning");
				newDiv.getClassNames().add("warn");
			}
			else if (StringUtils.equalsIgnoreCase("2", contentClean))
			{
				newDiv.setText("Severe");
				newDiv.getClassNames().add("severe");
			}
			else
			{
				newDiv.setText(contentClean);
			}
		}
		else
		{
			newDiv.setText(contentClean);
		}
		this.div.add(newDiv);
		
		return newDiv;
	}

	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.div = new Div();
		
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.div.setClassName("esra-keycontent1");
		
		this.div.setSizeUndefined();
		this.add(this.div);
		this.setWidthFull();
		this.setHeight(null);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Div div;
	// </generated-code>
	
}
