package com.caweco.esra.ui.admin.questionnaire;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.QuestionnaireUtils;
import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.dao.questionnaire.QuestionnaireDAO;
import com.caweco.esra.dto.QuestionnaireExportDTO;
import com.caweco.esra.dto.creator.QuestionnaireCreator;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.QuestionnaireCategory;
import com.caweco.esra.ui.admin.AdminBackendContainer;
import com.caweco.esra.ui.admin.dialogs.DialogImportQuestionnaire;
import com.caweco.esra.ui.admin.questionnaire.dialogs.DialogQuestionCreate;
import com.caweco.esra.ui.admin.questionnaire.dialogs.DialogQuestionnaireForm;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColActiveIndicator;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColCategoryGrid;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColQuestionGrid;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColQuestionHasAnswerSelections;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColQuestionHasRules;
import com.caweco.esra.ui.admin.questionnaire.gencols.GenColQuestionnaireGrid;
import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.caweco.esra.ui.dialogs.DialogContainer;
import com.caweco.esra.ui.interfaces.HasRefreshableGrid;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.SubsetDataProvider;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.ColumnTextAlign;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.grid.dnd.GridDragEndEvent;
import com.vaadin.flow.component.grid.dnd.GridDragStartEvent;
import com.vaadin.flow.component.grid.dnd.GridDropEvent;
import com.vaadin.flow.component.grid.dnd.GridDropLocation;
import com.vaadin.flow.component.grid.dnd.GridDropMode;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.renderer.TextRenderer;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.StreamRegistration;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.server.VaadinSession;

@AccessibleRule(AuthorizationResources.CLIENTADMINCOMMON)
@PageTitle("Backend: Questionnaires | ESRA")
@Route(value = "questionnaires", layout = AdminBackendContainer.class)
public class PageQuestionnaireOverview extends HorizontalLayout implements HasRefreshableGrid
{
	private Questionnaire questionnaire;
	private boolean questionnaireIsInUse = false;

	private QuestionCategory draggedCategory;
	private Question draggedQuestion;

	private Predicate<Questionnaire> questFilter = qu -> BooleanUtils.isTrue(qu.getActive());
	private final ObjectMapper om = new ObjectMapper().findAndRegisterModules();

	public PageQuestionnaireOverview()
	{
		super();
		this.initUI();

		this.filterComponent.addSubsetDataProvider(
			QuestionnaireCategory.class,
			SubsetDataProvider.New(QuestionnaireCategory.asList_byCategory())
		);

		final Column<Questionnaire> nameColumn = this.gridQuestionnaires.getColumnByKey("description");
		this.gridQuestionnaires.sort(GridSortOrder.asc(nameColumn).build());

		this.rbgQuestFilter.setItems("Show active only", "Show inactiv only", "Show all");
		this.rbgQuestFilter.setValue("Show active only");

		this.refreshGridData();

		this.setCurrentQuestionnaire(new Questionnaire());
	}

	public Pair<Questionnaire, Boolean> getCurrentQuestionnaire()
	{
		return Pair.of(this.questionnaire, this.questionnaireIsInUse);
	}

	protected void setCurrentQuestionnaire(@Nullable final Questionnaire newCurrent)
	{
		this.questionnaire = newCurrent;
		this.questionnaireIsInUse = newCurrent != null ? QuestionnaireUtils.isAlreadyInUse(newCurrent) : false;

		CurrentUtil.toSession("overviewCurrentQuestionnaire", this.getCurrentQuestionnaire());

		if (newCurrent != null)
		{
			this.btnSaveCategory.setEnabled(!this.questionnaireIsInUse);
			this.btnAddCategory.setEnabled(!this.questionnaireIsInUse);
		}
		else
		{
			this.btnSaveCategory.setEnabled(false);
			this.btnAddCategory.setEnabled(false);
			this.btnNewQuestion.setEnabled(false);
		}

		this.refreshCategoryGrid();
		this.refreshQuestionGrid();
	}

	@Override
	public void refreshGridData()
	{
		this.gridQuestionnaires.setItems(QuestionnaireDAO.findAll(this.questFilter));
		this.filterComponent.connectWith(this.gridQuestionnaires);
	}

	public void refreshGridDataShowAll()
	{
		if (this.rbgQuestFilter.getValue().equalsIgnoreCase("Show all"))
		{
			this.refreshGridData();
		}
		else
		{
			this.rbgQuestFilter.setValue("Show all");
			// -> "rbgQuestFilter_valueChanged(..)" also calls "this.refreshGridData();"

		}
	}

	public void refreshCategoryGrid()
	{
		if (this.questionnaire == null)
		{
			this.gridCategories.setItems(new HashSet<QuestionCategory>());
		}
		else
		{
			this.gridCategories.setItems(
				this.questionnaire.getCategories().stream().sorted(Comparator.comparingInt(QuestionCategory::getId))
			);
		}
	}

	public void refreshQuestionGrid()
	{
		if (this.questionnaire == null || this.questionnaire.getQuestionnaireID() == null)
		{
			this.gridQuestions.setItems(new HashSet<Question>());
		}
		else
		{
			this.gridQuestions.setItems(
				this.questionnaire.getQuestions(true)
					.stream()
					.filter(
						qu -> qu.getCategory() != null && qu.getCategory()
							.equals(this.gridCategories.asSingleSelect().getValue())
					)
					.collect(Collectors.toList())
			);
		}
	}

	/**
	 * Event handler delegate method for the {@link Grid}
	 * {@link #gridQuestionnaires}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridQuestionnaires_selectionChange(final SelectionEvent<Grid<Questionnaire>, Questionnaire> event)
	{
		this.setCurrentQuestionnaire(event.getFirstSelectedItem().orElse(null));
	}

	/**
	 * Event handler delegate method for the {@link Button}
	 * {@link #btnNewQuestionnaire}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewQuestionnaire_onClick(final ClickEvent<Button> event)
	{
		this.gridQuestionnaires.deselectAll();
		// this.questionnaire = new Questionnaire();

		new DialogContainer<>(new DialogQuestionnaireForm(new Questionnaire(), false)).onOk(c ->
		{
			this.rbgQuestFilter.setValue("Show active only");
			this.refreshGridData();
			this.gridQuestionnaires.select(c.getQuestionnaire());
		}).open();
	}

	/**
	 * Event handler delegate method for the {@link Button}
	 * {@link #btnSaveCategory}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSaveCategory_onClick(final ClickEvent<Button> event)
	{
		final Optional<QuestionCategory> firstSelectedItem = this.gridCategories.getSelectionModel()
			.getFirstSelectedItem();
		if (firstSelectedItem.isPresent())
		{
			final QuestionCategory questionCategory = firstSelectedItem.get();
			questionCategory.setCategory(this.textField.getValue());

			QuestionnaireDAO.saveExistingCategory(questionCategory, CurrentUtil.getClient(), this.questionnaire);
			this.gridCategories.getDataProvider().refreshItem(questionCategory);
		}
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnAddCategory}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnAddCategory_onClick(final ClickEvent<Button> event)
	{
		this.questionnaire.getCategories()
			.add(
				new QuestionCategory(
					QuestionDAO.getNextCategoryID(this.questionnaire.getCategories()),
					this.textField.getValue()
				)
			);

		QuestionnaireDAO.update(this.questionnaire);

		this.gridCategories.setItems(this.questionnaire.getCategories());

		this.textField.clear();
		this.textField.focus();
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCategories}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCategories_selectionChange(final SelectionEvent<Grid<QuestionCategory>, QuestionCategory> event)
	{
		final Optional<QuestionCategory> catO = event.getFirstSelectedItem();

		if (catO.isPresent())
		{
			this.textField.setValue(catO.get().getCategory());
			this.btnSaveCategory.setEnabled(!this.questionnaireIsInUse);
			this.btnNewQuestion.setEnabled(!this.questionnaireIsInUse);
			UI.getCurrent().getSession().setAttribute(QuestionCategory.class, catO.get());
			this.refreshQuestionGrid();
		}
		else
		{
			this.textField.setValue("");
			this.btnNewQuestion.setEnabled(false);
			this.gridQuestions.setItems(new HashSet<Question>());
		}

		this.btnSaveCategory.setVisible(catO.isPresent());
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCategories}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCategories_onGridDragStart(final GridDragStartEvent<QuestionCategory> event)
	{
		this.draggedCategory = event.getDraggedItems().get(0);
		this.gridCategories.setDropMode(GridDropMode.BETWEEN);
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCategories}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCategories_onGridDrop(final GridDropEvent<QuestionCategory> event)
	{
		if (this.questionnaireIsInUse)
		{
			// We don't allow changes made for questionnaires already in use
			return;
		}

		final Optional<QuestionCategory> dropTargetItem = event.getDropTargetItem();

		QuestionnaireDAO.reorderCategories(
			this.questionnaire,
			this.draggedCategory,
			dropTargetItem.get(),
			event.getDropLocation()
		);

		this.gridCategories.setItems(
			this.questionnaire.getCategories().stream().sorted(Comparator.comparingInt(QuestionCategory::getId))
		);
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCategories}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCategories_onGridDragEnd(final GridDragEndEvent<QuestionCategory> event)
	{
		this.draggedCategory = null;
		this.gridCategories.setDropMode(null);
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewQuestion}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewQuestion_onClick(final ClickEvent<Button> event)
	{
		this.openNewQuestionDialog();
	}

	private void openNewQuestionDialog()
	{
		new DialogQuestionCreate(this.questionnaire, this.gridCategories.asSingleSelect().getValue()).onOkListener(
			page ->
			{
				this.refreshQuestionGrid();

				if (page.getContinueWithNewQuestion())
				{
					this.openNewQuestionDialog();
				}
			}
		).open();
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridQuestions}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridQuestions_onGridDragStart(final GridDragStartEvent<Question> event)
	{
		this.draggedQuestion = event.getDraggedItems().get(0);
		this.gridQuestions.setDropMode(GridDropMode.BETWEEN);
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridQuestions}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridQuestions_onGridDragEnd(final GridDragEndEvent<Question> event)
	{
		this.gridQuestions.setDropMode(null);
	}

	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridQuestions}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridQuestions_onGridDrop(final GridDropEvent<Question> event)
	{
		if (
			// We don't allow changes made for questionnaires already in use
			this.questionnaireIsInUse ||
			// Only change things if we actually change ordering
				event.getDropTargetItem().isEmpty() ||
				// Ignore if we drop the item on itself
				event.getDropTargetItem().get() == this.draggedQuestion
		)
		{
			return;
		}

		// Check if rules would be changed due to the changes
		final var ruleCheckList = this.getRuleCheckList(
			this.draggedQuestion,
			event.getDropTargetItem().get(),
			event.getDropLocation()
		);

		if (!ruleCheckList.isEmpty())
		{
			new DialogConfirm(() ->
			{
				this.removeInvalidRules(this.draggedQuestion, event.getDropTargetItem().get(), event.getDropLocation());
				this.moveQuestion(event);
			}).setMainText("Rule validation necessary")
				.setAdditionalText("Moving the question will delete invalid Rules. Are u sure to move this question?")
				.open();
		}
		else
		{
			this.moveQuestion(event);
		}
	}

	/**
	 * Check which questions will need re-evaluation after a move would be performed
	 * and delete the invalid conditions from those rules.
	 */
	private void removeInvalidRules(final Question source, final Question target, final GridDropLocation location)
	{
		final List<Question> list = this.questionnaire.getQuestions(false)
			.stream()
			.filter(
				qu -> qu.getCategory() != null && qu.getCategory()
					.equals(this.gridCategories.asSingleSelect().getValue())
			)
			.collect(Collectors.toList());

		final int oldIdx = list.indexOf(source);
		int newIdx = list.indexOf(target);

		if (location != GridDropLocation.ABOVE)
		{
			newIdx++;
		}

		if (oldIdx < newIdx)
		{
			// Remove source from the questions that might have referenced it
			for (int i = oldIdx + 1; i < newIdx; i++)
			{
				System.out.println("Removing the dragged item from " + list.get(i).getId());
				this.removeConditionsWithQuestion(list.get(i), source);
			}
		}
		else if (oldIdx > newIdx)
		{
			// Remove the questions from the source, which source might have referenced
			for (int i = newIdx; i < oldIdx; i++)
			{
				System.out.println("Removing " + list.get(i).getId() + " from the dragged item");
				this.removeConditionsWithQuestion(source, list.get(i));
			}
		}
	}

	private void removeConditionsWithQuestion(final Question toCheck, final Question badQuestion)
	{
		if (toCheck.getRule() != null && toCheck.getRule().getAnds() != null)
		{
			boolean needsUpdate = false;

			for (final var condition : toCheck.getRule().getAnds())
			{
				final var removed = condition.getAnds()
					.removeIf(c -> c.getQuestion().isPresent() && c.getQuestion().get().equals(badQuestion));

				if (removed)
				{
					needsUpdate = true;
				}
			}

			if (needsUpdate)
			{
				toCheck.getRule().getAnds().removeIf(c -> c.getAnds().isEmpty());

				if (toCheck.getRule().getAnds().isEmpty())
				{
					toCheck.setRule(null);
				}

				QuestionDAO.update(this.questionnaire, toCheck);
			}
		}
	}

	/**
	 * Get a list of questions, where the rules need to be checked for conditions
	 * that reference the <code>source</code> question, as these will have to be
	 * removed.
	 */
	private List<Question> getRuleCheckList(
		final Question source,
		final Question target,
		final GridDropLocation location
	)
	{
		final List<Question> list = this.questionnaire.getQuestions(false)
			.stream()
			.filter(
				qu -> qu.getCategory() != null && qu.getCategory()
					.equals(this.gridCategories.asSingleSelect().getValue())
			)
			.collect(Collectors.toList());

		final int oldIdx = list.indexOf(source);
		int newIdx = list.indexOf(target);

		if (location != GridDropLocation.ABOVE)
		{
			newIdx++;
		}

		if (oldIdx == newIdx)
		{
			// Nothing will change in this case
			return new ArrayList<>();
		}
		else if (oldIdx < newIdx)
		{
			return new ArrayList<>(list.subList(oldIdx + 1, newIdx));
		}
		else // oldIdx > newIdx
		{
			// In this case we only need to check the source item itself
			return Arrays.asList(source);
		}
	}

	private void moveQuestion(final GridDropEvent<Question> event)
	{
		final Optional<Question> dropTargetItem = event.getDropTargetItem();

		QuestionnaireDAO.reorderQuestions(
			this.questionnaire,
			this.draggedQuestion,
			dropTargetItem.get(),
			event.getDropLocation()
		);

		QuestionnaireDAO.replaceQuestions(CurrentUtil.getClient(), this.questionnaire);

		this.refreshQuestionGrid();
	}

	/**
	 * Event handler delegate method for the {@link RadioButtonGroup}
	 * {@link #rbgQuestFilter}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void rbgQuestFilter_valueChanged(final ComponentValueChangeEvent<RadioButtonGroup<String>, String> event)
	{

		if (event.getValue().equalsIgnoreCase("Show active only"))
		{
			this.questFilter = qu -> BooleanUtils.isTrue(qu.getActive());
		}
		else if (event.getValue().equalsIgnoreCase("Show inactiv only"))
		{
			this.questFilter = qu -> BooleanUtils.isNotTrue(qu.getActive());
		}
		else
		{
			this.questFilter = qu -> true;
		}
		this.refreshGridData();
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnExport}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnExport_onClick(final ClickEvent<Button> event)
	{
		final Questionnaire currentQuestionnaire = this.gridQuestionnaires.asSingleSelect().getValue();

		currentQuestionnaire.getQuestions(true);
		final QuestionnaireExportDTO dto = QuestionnaireCreator.questionnaireToExportDto(currentQuestionnaire);

		try
		{
			final String q = this.om.writeValueAsString(dto);

			final StreamResource file = new StreamResource(
				currentQuestionnaire.getDescription() + ".esraquestionnaire",
				() -> new ByteArrayInputStream(q.getBytes())
			);
			final StreamRegistration registration = VaadinSession.getCurrent()
				.getResourceRegistry()
				.registerResource(file);

			UI.getCurrent()
				.getPage()
				.executeJs("window.open($0, $1)", registration.getResourceUri().toString(), "_blank");
		}
		catch (final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnImport}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnImport_onClick(final ClickEvent<Button> event)
	{
		final DialogImportQuestionnaire dialog = new DialogImportQuestionnaire();

		dialog.setOnImport(() ->
		{
			UI.getCurrent().getPage().reload();
		});

		dialog.open();
	}

	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.vlLeft = new VerticalLayout();
		this.label = new Label();
		this.filterComponent = new FilterComponent();
		this.gridQuestionnaires = new Grid<>(Questionnaire.class, false);
		this.rbgQuestFilter = new RadioButtonGroup<>();
		this.horizontalLayout = new HorizontalLayout();
		this.btnNewQuestionnaire = new Button();
		this.btnExport = new Button();
		this.btnImport = new Button();
		this.vlRight = new VerticalLayout();
		this.label2 = new Label();
		this.horizontalLayout2 = new HorizontalLayout();
		this.textField = new TextField();
		this.btnSaveCategory = new Button();
		this.btnAddCategory = new Button();
		this.gridCategories = new Grid<>(QuestionCategory.class, false);
		this.label3 = new Label();
		this.btnNewQuestion = new Button();
		this.gridQuestions = new Grid<>(Question.class, false);
		
		this.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.vlLeft.setMinWidth("500px");
		this.vlLeft.getStyle().set("flex-basis", "0");
		this.label.setText("Questionnaire");
		this.gridQuestionnaires.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridQuestionnaires.addColumn(Questionnaire::getDescription).setKey("description").setHeader(
			CaptionUtils.resolveCaption(Questionnaire.class, "description")).setSortable(true);
		this.gridQuestionnaires.addColumn(
			v -> Optional.ofNullable(v).map(Questionnaire::getCategory).map(QuestionnaireCategory::getCategory).orElse(
				null)).setKey("category.category").setHeader(
					CaptionUtils.resolveCaption(Questionnaire.class, "category.category")).setSortable(true);
		this.gridQuestionnaires.addColumn(Questionnaire::getVersion).setKey("version").setHeader(
			CaptionUtils.resolveCaption(Questionnaire.class, "version")).setSortable(true).setAutoWidth(true).setFlexGrow(
				0).setTextAlign(ColumnTextAlign.CENTER);
		this.gridQuestionnaires.addColumn(RenderedComponent.Renderer(GenColActiveIndicator::new)).setKey(
			"renderer2").setHeader("Active").setSortable(false).setAutoWidth(true).setFlexGrow(0).setTextAlign(
				ColumnTextAlign.CENTER);
		this.gridQuestionnaires.addColumn(RenderedComponent.Renderer(GenColQuestionnaireGrid::new)).setKey(
			"renderer").setHeader("...").setSortable(false).setAutoWidth(true).setFlexGrow(0).setTextAlign(
				ColumnTextAlign.CENTER);
		this.gridQuestionnaires.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.rbgQuestFilter.setRenderer(
			new TextRenderer<>(ItemLabelGeneratorFactory.NonNull(CaptionUtils::resolveCaption)));
		this.btnNewQuestionnaire.setText("New");
		this.btnNewQuestionnaire.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnNewQuestionnaire.setIcon(VaadinIcon.PLUS.create());
		this.btnExport.setText("Export selected");
		this.btnExport.setIcon(VaadinIcon.DOWNLOAD.create());
		this.btnImport.setText("Import Questionnaire");
		this.btnImport.setIcon(VaadinIcon.UPLOAD.create());
		this.vlRight.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.vlRight.getStyle().set("flex-basis", "0");
		this.label2.setText("Categories");
		this.btnSaveCategory.setText("Save");
		this.btnSaveCategory.setVisible(false);
		this.btnSaveCategory.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSaveCategory.setIcon(IronIcons.SAVE.create());
		this.btnAddCategory.setText("Add");
		this.btnAddCategory.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnAddCategory.setIcon(VaadinIcon.PLUS.create());
		this.gridCategories.setRowsDraggable(true);
		this.gridCategories.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridCategories.getStyle().set("flex-basis", "0");
		this.gridCategories.addColumn(QuestionCategory::getCategory).setKey("category").setHeader(
			CaptionUtils.resolveCaption(QuestionCategory.class, "category")).setSortable(true);
		this.gridCategories.addColumn(RenderedComponent.Renderer(GenColCategoryGrid::new)).setKey("renderer").setHeader(
			"...").setSortable(false).setAutoWidth(true).setFlexGrow(0).setTextAlign(ColumnTextAlign.CENTER);
		this.gridCategories.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.label3.setText("Questions");
		this.btnNewQuestion.setText("New");
		this.btnNewQuestion.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnNewQuestion.setIcon(VaadinIcon.PLUS.create());
		this.gridQuestions.setRowsDraggable(true);
		this.gridQuestions.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridQuestions.getStyle().set("flex-basis", "0");
		this.gridQuestions.addColumn(Question::getId).setKey("id").setHeader(
			CaptionUtils.resolveCaption(Question.class, "id")).setSortable(true).setWidth("50px").setFlexGrow(0);
		this.gridQuestions.addColumn(Question::getQuestionText).setKey("questionText").setHeader(
			CaptionUtils.resolveCaption(Question.class, "questionText")).setSortable(true);
		this.gridQuestions.addColumn(RenderedComponent.Renderer(GenColQuestionHasAnswerSelections::new)).setKey(
			"renderer3").setSortable(false).setAutoWidth(true).setFlexGrow(0);
		this.gridQuestions.addColumn(RenderedComponent.Renderer(GenColQuestionHasRules::new)).setKey(
			"renderer2").setSortable(false).setAutoWidth(true).setFlexGrow(0).setTextAlign(ColumnTextAlign.CENTER);
		this.gridQuestions.addColumn(RenderedComponent.Renderer(GenColQuestionGrid::new)).setKey("renderer").setHeader(
			"...").setSortable(false).setAutoWidth(true).setFlexGrow(0).setTextAlign(ColumnTextAlign.CENTER);
		this.gridQuestions.setSelectionMode(Grid.SelectionMode.SINGLE);
		
		this.btnNewQuestionnaire.setSizeUndefined();
		this.btnExport.setSizeUndefined();
		this.btnImport.setSizeUndefined();
		this.horizontalLayout.add(this.btnNewQuestionnaire, this.btnExport, this.btnImport);
		this.label.setSizeUndefined();
		this.filterComponent.setWidthFull();
		this.filterComponent.setHeight(null);
		this.gridQuestionnaires.setWidthFull();
		this.gridQuestionnaires.setHeight("300px");
		this.horizontalLayout.setWidthFull();
		this.horizontalLayout.setHeight(null);
		this.vlLeft.add(
			this.label,
			this.filterComponent,
			this.gridQuestionnaires,
			this.rbgQuestFilter,
			this.horizontalLayout);
		this.vlLeft.setFlexGrow(1.0, this.gridQuestionnaires);
		this.textField.setSizeUndefined();
		this.btnSaveCategory.setSizeUndefined();
		this.btnAddCategory.setSizeUndefined();
		this.horizontalLayout2.add(this.textField, this.btnSaveCategory, this.btnAddCategory);
		this.horizontalLayout2.setFlexGrow(1.0, this.textField);
		this.label2.setSizeUndefined();
		this.horizontalLayout2.setWidthFull();
		this.horizontalLayout2.setHeight(null);
		this.gridCategories.setSizeUndefined();
		this.label3.setSizeUndefined();
		this.btnNewQuestion.setSizeUndefined();
		this.gridQuestions.setSizeUndefined();
		this.vlRight.add(
			this.label2,
			this.horizontalLayout2,
			this.gridCategories,
			this.label3,
			this.btnNewQuestion,
			this.gridQuestions);
		this.vlRight.setFlexGrow(1.0, this.gridCategories);
		this.vlRight.setHorizontalComponentAlignment(FlexComponent.Alignment.START, this.btnNewQuestion);
		this.vlRight.setFlexGrow(2.0, this.gridQuestions);
		this.vlLeft.setSizeUndefined();
		this.vlRight.setSizeUndefined();
		this.add(this.vlLeft, this.vlRight);
		this.setFlexGrow(3.0, this.vlLeft);
		this.setFlexGrow(6.0, this.vlRight);
		this.setSizeFull();
		
		this.gridQuestionnaires.addSelectionListener(this::gridQuestionnaires_selectionChange);
		this.rbgQuestFilter.addValueChangeListener(this::rbgQuestFilter_valueChanged);
		this.btnNewQuestionnaire.addClickListener(this::btnNewQuestionnaire_onClick);
		this.btnExport.addClickListener(this::btnExport_onClick);
		this.btnImport.addClickListener(this::btnImport_onClick);
		this.btnSaveCategory.addClickListener(this::btnSaveCategory_onClick);
		this.btnAddCategory.addClickListener(this::btnAddCategory_onClick);
		this.gridCategories.addSelectionListener(this::gridCategories_selectionChange);
		this.gridCategories.addDragStartListener(this::gridCategories_onGridDragStart);
		this.gridCategories.addDropListener(this::gridCategories_onGridDrop);
		this.gridCategories.addDragEndListener(this::gridCategories_onGridDragEnd);
		this.btnNewQuestion.addClickListener(this::btnNewQuestion_onClick);
		this.gridQuestions.addDragStartListener(this::gridQuestions_onGridDragStart);
		this.gridQuestions.addDragEndListener(this::gridQuestions_onGridDragEnd);
		this.gridQuestions.addDropListener(this::gridQuestions_onGridDrop);
	} // </generated-code>

	// <generated-code name="variables">
	private Button btnNewQuestionnaire, btnExport, btnImport, btnSaveCategory, btnAddCategory, btnNewQuestion;
	private Grid<Question> gridQuestions;
	private VerticalLayout vlLeft, vlRight;
	private HorizontalLayout horizontalLayout, horizontalLayout2;
	private Label label, label2, label3;
	private FilterComponent filterComponent;
	private Grid<Questionnaire> gridQuestionnaires;
	private RadioButtonGroup<String> rbgQuestFilter;
	private TextField textField;
	private Grid<QuestionCategory> gridCategories;
	// </generated-code>

}
