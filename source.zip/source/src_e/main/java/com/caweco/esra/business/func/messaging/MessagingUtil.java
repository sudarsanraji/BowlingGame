package com.caweco.esra.business.func.messaging;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jfree.util.Log;

import com.caweco.esra.business.func.mailing.Mailer;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.MessageGroup;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class MessagingUtil
{
	/**
	 * Currently, just adds user to group immediately (without invitation) and sends notification mail if desired.
	 * <p>
	 * (No further "invitation -> accept/decline -> add/remove" process is implemented.)<br />
	 * User gets always group notifications. See also {@link Mailer#sendMail_newGroupMessage(User, Screening, MessageGroup)}
	 * </p>
	 * 
	 * @param parentItem
	 * @param group
	 * @param toInvite
	 * @param sendMail
	 */
	public static void inviteUser(
		final HasMessages parentItem,
		final MessageGroup group,
		final Collection<User> toInvite,
		final boolean sendMail)
	{
		// Further improvement possible: "invitation (with Token) -> User accepts/declines -> add/remove User"
		
		addUserToGroup(group, toInvite);
		
		if (sendMail)
		{
			sendMail_groupInvitation(CurrentUtil.getUser(), parentItem, group, toInvite);
		}
		
	}
	
	public static void addUserToGroup(
		final MessageGroup group,
		final Collection<User> toInvite)
	{
		// Further improvement possible: "invitation (with Token) -> User accepts/declines -> add/remove User"
		final List<UserMetadataDTO> dtoList = new ArrayList<>();
		
		toInvite.forEach(user -> {
			dtoList.add(UserCreator.convertUserToMetadataDTO(user));
		});
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId() + "/members/add");
		
		final Response response = webTarget.request().post(Entity.entity(dtoList, MediaType.APPLICATION_JSON));
		Log.info("REST: " + response);
	}
	
	public static void sendMail_groupInvitation(
		final User user,
		final HasMessages parentItem,
		final MessageGroup group,
		final Collection<User> toInvite)
	{
		Mailer.sendMail_inviteUserToExpertGroup(user, (Screening)parentItem, group, toInvite);
	}
	
	public static void sendMail_newGroupMessage(
		final User author,
		final HasMessages r,
		final MessageGroup g)
	{
		
		Mailer.sendMail_newGroupMessage(author, (Screening)r, g);
	}
	
	public static void sendMail_newPublicMessage(
		final User author,
		final HasMessages r)
	{
		
		Mailer.sendMail_newPublicMessage(author, (Screening)r);
	}
}
