package com.caweco.esra.ui.beans;

public interface HasTags<T>
{
	void delete(final MultiValueComboBoxTagLabel<T> l);
}
