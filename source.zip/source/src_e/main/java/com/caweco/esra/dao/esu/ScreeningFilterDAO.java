
package com.caweco.esra.dao.esu;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.ScreeningMetadataDTO;
import com.caweco.esra.dto.creator.ScreeningCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.esu.ScreeningFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.server.VaadinSession;

import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class ScreeningFilterDAO
{
	
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	////////
	
	public static ScreeningFilter getOrCreateFilter()
	{
		User             user       = CurrentUtil.getUser();
		Client           client     = CurrentUtil.getClient();
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		String           path       =
			"/user/" + user.getEmailAddress() + "/screeningFilter/" + client.getUuid().toString();
		
		WebTarget        webTarget  = restClient.getMethodTarget(path);
		
		try
		{
			Response         response   = webTarget.request().get();
			Logger.tag("REST").info(response.toString());
			
			String   responseBody = response.readEntity(String.class);
			ScreeningFilter screeningFilter = om.readValue(responseBody, ScreeningFilter.class);
			
			return screeningFilter;
			// Response response = webTarget.request().get(ScreeningFilter.class);
			// Logger.tag("REST").info(response.toString());
			// return response.readEntity(ScreeningFilter.class);
		}
		catch(NotFoundException | JsonProcessingException exc)
		{
			return new ScreeningFilter();
		}
		
		// ScreeningFilter screeningFilter = new ScreeningFilter();
		// insert(user, client, screeningFilter);
		// return screeningFilter;
	}
	
	/**
	 * Needs current user and current client to be set in {@link VaadinSession}
	 * 
	 * @return
	 */
	public static Set<Screening> getOrCreateFavourites()
	{
		User             user       = CurrentUtil.getUser();
		String           clientId   = CurrentUtil.getClient().getUuid().toString();
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		String           path       = "/user/" + user.getEmailAddress() + "/screeningFavorites/" + clientId;
		
		WebTarget        webTarget  = restClient.getMethodTarget(path);
		
		Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String   responseBody = response.readEntity(String.class);
		
		JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, ScreeningMetadataDTO.class);
		
		try
		{
			Set<ScreeningMetadataDTO> readValue = om.readValue(responseBody, type);
			if(readValue == null)
			{
				Set<Screening> x = new HashSet<>(0);
				return x;
			}
			else
			{
				return readValue.stream().map(it -> ScreeningCreator.convertMetadataDTOToScreening(clientId, it))
					.collect(Collectors.toSet());
			}
		}
		catch(JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
		
	}
	
	/**
	 * Needs current user and current client to be set in {@link VaadinSession}
	 * 
	 * @return
	 */
	public static boolean addFavourite(Screening screening)
	{	
		RestClientESRADB client     = RestUtil.getRestClient_ESRADB();
		
		String           path       = "/user/" + CurrentUtil.getUser().getEmailAddress() + "/screeningFavorites/"
			+ CurrentUtil.getClient().getUuid().toString() + "/add";
		
		WebTarget        webTarget  = client.getMethodTarget(path);
		
		webTarget.request()
			.post(Entity.entity(ScreeningCreator.convertScreening(screening), MediaType.APPLICATION_JSON));
		return true;
	}
	
	// public static boolean addFavourite(String clientId, String screeningId, String userEmail)
	// {
	// Set<Screening> favourites = ScreeningFilterDAO.getOrCreateFavourites();
	//
	// RestClientESRADB client = RestUtil.getRestClient_ESRADB();
	//
	// String path = "/user/" + userEmail + "/screeningFavorites/" + clientId + "/" + screeningId;
	//
	// WebTarget webTarget = client.getMethodTarget(path);
	//
	// webTarget.request().post(Entity.entity(ScreeningCreator.convertScreening(screening),
	// MediaType.APPLICATION_JSON));
	// return true;
	// }
	
	/**
	 * Needs current user and current client to be set in {@link VaadinSession}
	 * 
	 * @return
	 */
	public static boolean removeFavourite(Screening screening)
	{	
		RestClientESRADB client     = RestUtil.getRestClient_ESRADB();
		
		String           path       = "/user/" + CurrentUtil.getUser().getEmailAddress() + "/screeningFavorites/"
			+ CurrentUtil.getClient().getUuid().toString() + "/remove";
		
		WebTarget        webTarget  = client.getMethodTarget(path);
		
		webTarget.request()
			.post(Entity.entity(ScreeningCreator.convertScreening(screening), MediaType.APPLICATION_JSON));
		return true;
	}
}
