
package com.caweco.esra.subsidary.frontend;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections4.SetUtils;
import org.apache.commons.lang3.StringUtils;
import org.tinylog.Logger;

import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.func.mailing.Mailer;
import com.caweco.esra.business.func.rest.RestClientBIH;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.usernotifications.UserNotificationManager;
import com.caweco.esra.business.usertask.UserTaskManager;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.rest.general.Subsidiary;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.subsidary.common.SubNode;
import com.caweco.esra.subsidary.common.SubNodeState;
import com.caweco.esra.subsidary.common.SubsidiaryDataDefines;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningAppliedData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskRunData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.common.event.TaskStateChangeEvent;


public class SubsidiaryScreeningRunnable implements Runnable
{
	
	public static SubsidiaryScreeningRunnable New(
		final SubsidiaryScreeningCachedTask parent)
	{
		return new SubsidiaryScreeningRunnable(parent);
	}
	
	private final SubsidiaryScreeningCachedTask parent;
	private final RestClientBIH                 restClient;
	
	public SubsidiaryScreeningRunnable(
		final SubsidiaryScreeningCachedTask parent)
	{
		this.parent     = parent;
		this.restClient = RestUtil.getRestClient_BIH(parent.getClientId().toString());
	}
	
	private ConcurrentHashMap<String, CompletionStage<CIResponse>> rawScreeningData;
	
	private ConcurrentHashMap<String, CIResponse>                  rawResultData;
	private ConcurrentHashMap<String, String>                      rawErrorData;
	
	private ConcurrentHashMap<String, Duration>                    rawDurationData;
	private SubNode                                                root;
	
	private AtomicInteger counter;
	
	/**
	 * Exists only after "applyDataToScreening"!
	 */
	private Optional<Client> availableAfterAppliedTo_Client = Optional.empty();
	private Optional<Screening> availableAfterAppliedTo_Screening = Optional.empty();
	
	@Override
	public void run()
	{
		final UUID    taskId        = this.parent.getId();
		final String  rootItemBvdId = this.parent.wrapped.getRootBvdId();
		
		final Instant start         = Instant.now();
		
		Logger.info("Task {} started. Start fetching Subsidiaries of company {}", taskId.toString(), rootItemBvdId);
		
		// CompanyID & REST Data
		this.rawScreeningData = new ConcurrentHashMap<>();
		this.rawDurationData  = new ConcurrentHashMap<>();
		this.rawResultData    = new ConcurrentHashMap<>();
		this.rawErrorData     = new ConcurrentHashMap<>();
		this.counter = new AtomicInteger(0);
		
		this.root             = new SubNode();
		this.root.companyID   = rootItemBvdId;
		this.root.isRoot      = true;
		
		// Root item & subsidiaries
		CIResponse rootItem = this.parent.root_;
		try
		{
			if(rootItem == null || rootItem.getCompanyInfoBvd() == null
				|| rootItem.getCompanyInfoBvd().getSubsidiaryData() == null)
			{
				Logger.info("Task {} | Root Subsidiary Data not available. Fetching data from BIH/CARA", taskId.toString());
				// rootItem may be not available for Tasks that are restarted by cron..
				
				// SubsidiaryData may be null for older CIResponse items. BIH Data did not always contain them. See
				// issue ESRA-??
				
				Logger.debug("..Fetching Subsidiaries of root company {}", rootItemBvdId);
				
				rootItem = this.fetchRootNode(this.root);
			}
			else
			{
				// Existing Data
				this.rawScreeningData.put(rootItem.getCompanyBvdId(), CompletableFuture.completedFuture(rootItem));
				this.root.state = SubNodeState.FETCHED;
				Logger.debug("..Data of root company {} ok.", rootItemBvdId);
			}
		}
		catch(final InterruptedException e1)
		{
			this.parent.cancelTaskC("Data error. " + e1.getMessage(), true);
			this.rawErrorData.put("error", e1.getMessage());
			Logger.error(e1);
		}
		catch(final ExecutionException e2)
		{
			this.parent.cancelTaskC("Data error. " + e2.getCause().getMessage(), true);
			this.rawErrorData.put("error", e2.getCause().getMessage());
			Logger.error(e2);
		}
		
		try
		{
			
			if(!this.parent.cancelTask.get())
			{
				final CompletableFuture<Void> watchdog =
					SubsidiaryScreeningRunnable.getWatchdog(taskId.toString(), this.parent.cancelTask);
				
				final CompletableFuture<Void> subsidiarySubTasks      = this.processFetchedNodeSerial(this.root, rootItem);
				
				CompletableFuture.anyOf(watchdog, subsidiarySubTasks).get();
			}
			
			final Instant end = Instant.now();
			
			// Stop watchdog if running
			this.parent.cancelTask.set(true);
			
			// Store
			
			final SubsidiaryScreeningTaskF wrapped = this.parent.getWrapped();
			
			SubsidiaryScreeningTaskRunData taskRunData = new SubsidiaryScreeningTaskRunData();
			
			taskRunData.runStart = start;
			taskRunData.runEnd = end;
			
			wrapped.setRunData(taskRunData);
			
			
			
			//// Apply Result data to Task
			final SubsidiaryScreeningData  data    = new SubsidiaryScreeningData(rootItem,
				this.rawResultData, this.rawErrorData, this.rawDurationData);
			wrapped.setResultData(data);
			wrapped.setResultTree(this.root);
			
			
			
			final String cancelledNote = this.parent.cancelledNote.get();
			if(cancelledNote != null && !cancelledNote.isEmpty())
			{
				// On ERROR and SKIP
				taskRunData.cancelledNote = cancelledNote;

				if (this.parent.cancelledOnError.get())
				{
					// ERROR
					wrapped.setState(SubsidiaryScreeningTaskState.DONE_ERROR);
				}
				else {
					// SKIPPED
					wrapped.setState(SubsidiaryScreeningTaskState.DONE_SKIPPED);
				}
				
				//// Remove Result data from Task if ERROR or SKIPPED
				wrapped.setResultData(null);
			}
			else
			{
				wrapped.setState(SubsidiaryScreeningTaskState.DONE_OK);
				
				// Apply Data to Screening
				final boolean appliedData = this.applyDataToScreening(taskId.toString());
				
				//// Removes Result data from Task if applied to Screening
				if(appliedData)
				{
					wrapped.setState(SubsidiaryScreeningTaskState.APPLIED);
				}
				
			}
			
			SubsidiaryTaskDAO.frontend_updateTask(wrapped);
			
			
			Logger.info("Subsidiary Screening Task {} finished with state {}. Notify listener...", taskId.toString(), wrapped.getState());
			
			// Notify
			
			UserTaskManager.notifyOnTaskStateChange(taskId.toString());
			UserNotificationManager.send(TaskStateChangeEvent.New("Subsidiary Screening finished.", wrapped.getUser(), taskId.toString()));
			
			this.sendMailOnTaskFinished();
			
			Logger.info("Subsidiary Screening Task {} finished, Listener notified.", taskId.toString());
			
		}
		catch(final Exception e)
		{
			Logger.error(e, "Error at processing Subsidiary Screening Task " + taskId.toString());
		}
		finally
		{
			// Cancel watchdog at all
			this.parent.cancelTask.set(true);
		}
	}
	
	
	private void sendMailOnTaskFinished()
	{
		try
		{
			final SubsidiaryScreeningTaskF task = this.parent.getWrapped();
			
			// For cases when client or screening are not fetched yet, e.g. on errors 
			if (availableAfterAppliedTo_Client.isEmpty()) 
			{
				Optional<Client> findById = ClientDAO.findById(task.getClientId());
				availableAfterAppliedTo_Client = findById;
			}
			if (availableAfterAppliedTo_Screening.isEmpty()) 
			{
				Optional<Screening> findScreening = ScreeningDAO.find2(task.getClientId().toString(), task.getScreeningId().toString());
				availableAfterAppliedTo_Screening = findScreening;
			}
			
			final Client         client      = this.availableAfterAppliedTo_Client.get();
			final Screening screening = this.availableAfterAppliedTo_Screening.get();

			Mailer.sendMail_subsidiaryScreeningTaskFinished(client, screening, task);

		}
		catch (NoSuchElementException e) 
		{
			Logger.error(e, "Error sending mail notification at end of \"Subsidiary Screening\" Task: Could not fetch Client or Screening from backend.");
		}
		catch (final Exception e) 
		{
			Logger.warn(e, "Error sending mail notification at end of \"Subsidiary Screening\".");
		}
	}
	
	private boolean applyDataToScreening(final String taskId)
	{
		try
		{
			final SubsidiaryScreeningTaskF task = this.parent.getWrapped();
			final Map<String, CIResponse>  dataFetches = this.parent.getWrapped().getResultData(false).dataFetches;
			
			final UUID                     clientId    = this.parent.getWrapped().getClientId();
			this.availableAfterAppliedTo_Client = ClientDAO.findById(clientId);
			final Client         client      = this.availableAfterAppliedTo_Client.get();
			
			
			final UUID                     screeningId = this.parent.getWrapped().getScreeningId();
			this.availableAfterAppliedTo_Screening  = ScreeningDAO.find2(clientId.toString(), screeningId.toString());
			final Screening screening = this.availableAfterAppliedTo_Screening.get();
			final List<SearchEntryCompany> screening_companyEntries = screening.getWatchlistCompanyEntries(true);
			
			////////
			// Cleanup CIResonses - Only GsssMatches above threshold
			
			final Optional<Integer>        CIResponseTreshold    = SanctionUtil.getThresholdCIResponseMatches(client);
			final List<CIResponse>         dataFetches_cleaned     = dataFetches.values().stream()
				.map(it -> SanctionUtil.cleanupCIResponseMatches(it, CIResponseTreshold)).collect(Collectors.toList());
			
			assert dataFetches.size() ==  dataFetches_cleaned.size();
			
			////////
			// Red Flags
			
			// Group CIResonses by "red-flag-or-not"
			final Map<Boolean, Map<String, CIResponse>> dataFetches_cleaned_redFlaggedOrNot2 = dataFetches_cleaned.stream()
				.collect(Collectors.partitioningBy(
					it -> SanctionUtil.isMarked(client, it),
					Collectors.toMap(itt -> itt.getCompanyBvdId(), ittt -> ittt)));
			
			final Set<String> dataFetches_redFlaggedIDs = dataFetches_cleaned_redFlaggedOrNot2.get(true).keySet();
			final Set<String> dataFetches_notRedFlaggedIDs = dataFetches_cleaned_redFlaggedOrNot2.get(false).keySet();
			
			assert dataFetches_cleaned.size() == dataFetches_redFlaggedIDs.size() + dataFetches_notRedFlaggedIDs.size();
			
			
			////////
			// New SearchEntryCompany items
			
			// Find duplicates
			final Set<String> screening_companyEntryIDs = screening_companyEntries.stream().map(SearchEntryCompany::getItem).map(CIResponse::getCompanyBvdId).collect(Collectors.toSet());

			final Set<String> redFlaggedID_duplicated = SetUtils.intersection(dataFetches_redFlaggedIDs, screening_companyEntryIDs).toSet();
			final Set<String> redFlaggedID_toApply = SetUtils.difference(dataFetches_redFlaggedIDs, screening_companyEntryIDs).toSet();
			
			assert dataFetches_redFlaggedIDs.size() == redFlaggedID_toApply.size() + redFlaggedID_duplicated.size();
			
			// Generate new SearchEntryCompany items without duplicates
			final Set<SearchEntryCompany> newCompanyEntries = dataFetches_cleaned_redFlaggedOrNot2.get(true).entrySet().stream()
				.filter(ent -> redFlaggedID_toApply.contains(ent.getKey()))
				.map(it -> SearchEntryCompany.New(it.getValue(), task))
				.collect(Collectors.toSet());
			
			assert redFlaggedID_toApply.size() == newCompanyEntries.size();
			
			////////
			// Apply new SearchEntryCompany items to screening
			
			screening_companyEntries.addAll(newCompanyEntries);
			
			ScreeningDAO.updateAfterSubsidiaryScreening(clientId.toString(), screening, taskId, this.parent.getWrapped().getCreatedBy());
			
			//////
			// Now, Screening is updated and saved.
			// -> Task: Update State, Metadata and cleanup
			
			task.setState(SubsidiaryScreeningTaskState.APPLIED);
			
			// Cleanup result data
			task.setResultData(null);;
			
			// Add some meta information regarding "apply-to-screening" functionality
			final Set<String> bvdIds_all = new HashSet<>(dataFetches.keySet());
			final SubsidiaryScreeningAppliedData infos = SubsidiaryScreeningAppliedData.New(
				CIResponseTreshold.orElse(null),
				new HashSet<>(bvdIds_all),
				new HashSet<>(dataFetches_notRedFlaggedIDs),
				new HashSet<>(redFlaggedID_toApply),
				new HashSet<>(redFlaggedID_duplicated));
			
			task.setAppliedData(infos);
			
			// Saving "Task" happens in calling method

			return true;
		}
		catch(final Exception e)
		{
			Logger.error(e);
			return false;
		}
	}
	
	private CIResponse fetchRootNode(final SubNode node) throws InterruptedException, ExecutionException
	{
		final String id = node.companyID;
		
		Logger.debug(" Get root node [{}]", id);
		
		final Instant start = Instant.now();
		
		final CompletionStage<CIResponse> cs =
			this.rawScreeningData.computeIfAbsent(id, idd -> this.restClient.getCompanyInfoStage(idd));
		
		final CompletableFuture<CIResponse>     it = cs.toCompletableFuture().handle((r, t) -> {
													
													Logger.debug(" Got root node data..", id);
													
													final Instant end = Instant.now();
													
													try
													{
														final Duration duration = Duration.between(start, end);
														this.rawDurationData.putIfAbsent(id, duration);
													}
													catch(final Exception e)
													{
														Logger.warn(e);
													}
													
													if(t != null)
													{
														// ON ERROR
														node.state = SubNodeState.DATA_ERROR;
														this.rawErrorData.putIfAbsent(id, t.getMessage());
														// TODO: UPDATE UI HERE [node state change]
														
														this.parent.cancelTaskC("Could not fetch root data: " + t.getMessage(), true);
														
														Logger.error(t, "Could not fetch root node data.");
														
														return null;
													}
													else
													{
														
														this.rawResultData.putIfAbsent(id, r);
														
														final Optional<String> checkData = checkData(r);
														
														// ON ERROR
														if(checkData.isPresent())
														{
															node.state = SubNodeState.DATA_ERROR;
															this.rawErrorData.putIfAbsent(id,
																"Data error within an BIH response: "
																	+ checkData.get());
															// TODO: UPDATE UI HERE [node state change]
															
															Logger.error("Could not handle root node data. Data error within an BIH response: " + checkData.get() );
															
															this.parent.cancelTaskC("Data error within an BIH response: " + checkData.get(), true);
															
															return null;
														}
														else
														{
															// All OK
															node.state = SubNodeState.FETCHED;
															return r;
														}
													}
													
												});
		
		return it.get();
	}
	
	private static CompletableFuture<Void> getWatchdog(final String taskId, final AtomicBoolean stopFlag)
	{
		final CompletableFuture<Void> watchdog = CompletableFuture.runAsync(() -> {
			
			Logger.info("Task {} | Start Watchdog", taskId);
			
			int counter = 0;
			try
			{
				while(stopFlag.get() != true)
				{
					counter++;
					
					Logger.info("Task {} | FRONTEND | HEARTBEAT [ no. {} ]", taskId, counter);
					
					SubsidiaryTaskDAO.frontend_sendHeartbeat(taskId);
					Thread.sleep(1000);

				}
				Logger.info("Task {} | Stop Watchdog", taskId);
			}
			catch(final InterruptedException e)
			{
				Logger.info(e, "Task "+taskId+" | Stop Watchdog");
			}
		});
		return watchdog;
	}
	
	
	/**
	 * 
	 * @param node
	 * @param item
	 * @return
	 */
	private CompletableFuture<Void> processFetchedNodeSerial(final SubNode node, final CIResponse item)
	{
		
		//// CHECK RESPONSE DATA
		if(item == null)
		{
			this.parent.cancelTaskC("Processing error: REST data (CIResponse) does not exist.", true);
			node.state = SubNodeState.DATA_ERROR;
			
			Logger.error("Processing error: REST data (CIResponse) does not exist.");
			
			return CompletableFuture.completedFuture(null);
		}
		
		if(!Objects.equals(node.companyID, item.getCompanyBvdId()))
		{
			this.parent.cancelTaskC("Processing error: Tree item does not fit to REST data.", true);
			node.state = SubNodeState.DATA_ERROR;
			
			Logger.error("Processing error: Node-bvdId {} does not fit to bvdId {} of REST data", node.companyID, item.getCompanyBvdId() );
			
			return CompletableFuture.completedFuture(null);
		}
		
		final Optional<String> checkData = checkData(item);
		
		// ON ERROR
		if(checkData.isPresent())
		{
			node.state = SubNodeState.DATA_ERROR;
			this.rawErrorData.putIfAbsent(node.companyID,
				"Data error within an BIH response: "
					+ checkData.get());
			
			Logger.error("Could not handle root node data. Data error within an BIH response: " + checkData.get() );
			
			this.parent.cancelTaskC("Data error within an BIH response: " + checkData.get(), true);
			
			return CompletableFuture.completedFuture(null);
		}
		
		
		final Collection<Subsidiary>     children = item.getCompanyInfoBvd().getSubsidiaryData() != null ? item.getCompanyInfoBvd().getSubsidiaryData().values() : Collections.emptySet();
		
		final List<CompletableFuture<?>> childTasks    = new ArrayList<>(children.size());
		
		for(final Subsidiary child : children)
		{
			final SubNode            childNode = this.addChildNode(node, child);
			
			final CompletionStage<?> childTask = this.processNode(childNode);
			if(childTask != null)
			{
				childTasks.add(childTask.toCompletableFuture());
			}
		}
		
		node.state = SubNodeState.PROCESSING_DONE;
		
		if (!childTasks.isEmpty()) 
		{
			final CompletableFuture<Void> allFutures =
				CompletableFuture.allOf(childTasks.toArray(new CompletableFuture[childTasks.size()]));
			
			return allFutures;
		}
		else 
		{
			return CompletableFuture.completedFuture(null);
		}
	}
	
	private CompletionStage<? extends Void> processNode(final SubNode node)
	{
		final String id = node.companyID;
		
		Logger.debug(" Node {} - 1: processNode", id);
		
		if(node.state == SubNodeState.IN_PROGRESS)
		{
			final Instant                     start = Instant.now();
			
			final CompletionStage<CIResponse> cs    =
				this.rawScreeningData.computeIfAbsent(id, idd -> this.restClient.getCompanyInfoStage(idd));
			
			return cs.handle((r, t) -> {
				
				Logger.debug(" Node {} - 2: Got Data", id);
				
				final Instant end = Instant.now();
				
				try
				{
					final Duration duration = Duration.between(start, end);
					this.rawDurationData.putIfAbsent(id, duration);
				}
				catch(final Exception e)
				{
					Logger.warn(e);
				}
				
				if(t != null)
				{
					node.state = SubNodeState.DATA_ERROR;
					this.rawErrorData.putIfAbsent(id, t.getMessage());
					// TODO: UPDATE UI HERE [node state change]
					
					this.parent.cancelTaskC("Could not fetch data: " + t.getMessage(), true);
					
					Logger.error(t, " Node " + id + " - 3: Data error! ");
					
					return null;
				}
				else
				{
					this.rawResultData.putIfAbsent(id, r);
					
					node.state = SubNodeState.FETCHED;
					
					try
					{
						CompletableFuture<Void> cf_withAllChildren = this.processFetchedNodeSerial(node, r);
						if (cf_withAllChildren != null)
						{
							// Wait for CompletableFuture to complete - 
							// This CF is completed when all of the child CompletableFutures complete
							cf_withAllChildren.get();
						}
					}
					catch(final InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					catch(final ExecutionException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// No UI Update, as this ´can be done in "processFetchedNode"
				}
				return null;
			});
		}
		else {
			Logger.debug(" Node {} - 2: Skip [{}]", id, node.state);
		}
		
		return null;
	}
	
	private SubNode addChildNode(final SubNode parent, final Subsidiary sub)
	{
		final SubNode child = this.toNode(sub);
		this.connect(parent, child);
		this.nodeState(child, child.level);
		return child;
	}
	
	private SubNode toNode(final Subsidiary sub)
	{
		final SubNode node = new SubNode();
		node.companyID         = sub.getBvdId();
		node.rawSubsidiaryData = sub;
		return node;
	}
	
	private void connect(final SubNode parent, final SubNode child)
	{
		parent.children.add(child);
		child.level = parent.level + 1;
	}
	
	/**
	 * Calculate state of a node.
	 * @param node
	 * @param nodeLevel
	 */
	private void nodeState(final SubNode node, int nodeLevel)
	{
		try
		{
			if(nodeLevel > SubsidiaryDataDefines.THRESHOLD_MAXLEVEL)
			{
				node.state = SubNodeState.STOP_MAXLEVEL;
				
				Logger.debug(" - node {} : nodeLevel={} / STOP", node.companyID, nodeLevel);
				return;
			}
			
			final Float result    = SubsidiaryScreeningRunnable.getShare(node);
			Logger.debug(" - node {} : nodeLevel={}, share={}", node.companyID, nodeLevel, result);
			
			if(result == null)
			{
				node.state = SubNodeState.STOP_UNKNOWN_SHARE;
			}
			else if(result < SubsidiaryDataDefines.THRESHOLD_DIRECT)
			{
				node.state = SubNodeState.STOP_THRESHOLD;
			}
			else
			{
				final int c = this.counter.incrementAndGet();
				
				if (nodeLevel <2)
				{
					// Fetch all direct children of the root company item n matter of the counter and THRESHOLD_MAXSUBSIDIARIES
					node.state = SubNodeState.IN_PROGRESS;
				}
				else
				{
					if (SubsidiaryDataDefines.THRESHOLD_MAXSUBSIDIARIES > c)
					{
						node.state = SubNodeState.IN_PROGRESS;
					}
					else
					{
						node.state = SubNodeState.STOP_MAXSUBSIDIARIES;
					}
				}

			}
		}
		catch(final Exception e)
		{
			Logger.debug(e);
			node.state = SubNodeState.DATA_ERROR;
		}
	}
	
	public static Float getShare(final SubNode node)
	{
		////
		
		String total = node.rawSubsidiaryData.getTotal();
		
		if(total != null && !total.isBlank())
		{
			boolean totalIsGreaterThan = false;
			
			// Handle values with greaterthan sign e.g. ">50.00"
			if(total.startsWith(">"))
			{
				totalIsGreaterThan = true;
				total              = total.substring(1);
			}
			
			try
			{
				final float resultTotal = Float.parseFloat(total);
				if(resultTotal > 0)
				{
					if(totalIsGreaterThan)
					{
						if(resultTotal < SubsidiaryDataDefines.THRESHOLD_DIRECT)
						{
							// UNDEFINED:
							// result may be bigger or smaller than SubsidiaryDataDefines.THRESHOLD_DIRECT
							// e.g. ">20.00" can be 22.00 but also 30.00 so can be below or above threshold "25.00"
							// -> continue with "direct" share
						}
						else
						{
							// ">25.00" or ">30.00" are both above threshold "25.00".
							// Add 1 to be sure..
							return resultTotal + 1;
						}
					}
					else
					{
						return resultTotal;
					}
				}
			}
			catch(final Exception e)
			{
				Logger.error("Cannot parse total share value for Subsidiary {} [raw = {}]",
					node.rawSubsidiaryData.getBvdId(), node.rawSubsidiaryData.getTotal());
			}
		}
		
		/////
		
		String direct = node.rawSubsidiaryData.getDirect();
		
		if(direct != null && !direct.isBlank())
		{
			boolean directIsGreaterThan = false;
			// Handle values with greaterthan sign e.g. ">50.00"
			if(direct.startsWith(">"))
			{
				directIsGreaterThan = true;
				direct              = direct.substring(1);
			}
			
			try
			{
				final float resultDirect = Float.parseFloat(direct);
				if(resultDirect > 0)
				{
					if(directIsGreaterThan)
					{
						if(resultDirect < SubsidiaryDataDefines.THRESHOLD_DIRECT)
						{
							// UNDEFINED:
							// result may be bigger or smaller than SubsidiaryDataDefines.THRESHOLD_DIRECT
							// e.g. ">20.00" can be 22.00 but also 30.00 so can be below or above threshold "25.00"
							// -> return null to indicate that
							return null;
						}
						else
						{
							// ">25.00" or ">30.00" are both above threshold "25.00".
							// Add 1 to be sure..
							return resultDirect + 1;
						}
					}
					else
					{
						return resultDirect;
					}
				}
			}
			catch(final Exception e)
			{
				Logger.error("Cannot parse direct share value for Subsidiary {} [raw = {}]",
					node.rawSubsidiaryData.getBvdId(), node.rawSubsidiaryData.getDirect());
			}
		}
		
		return null;
	}
	
	
	//
	//
	//
	//
	
	/**
	 * OK if returned Optional is empty. Otherwise the returned Optional contains the status messages with "201", "202" and "301" that indicates errors.
	 * @param statusMessages
	 * @return
	 */
	public static Optional<String> checkStatusMessages(final String... statusMessages)
	{
		
		if(statusMessages == null || statusMessages.length == 0)
		{
			// Accept empty statusMessages as ok
			return Optional.empty();
		}
		
		final Set<String> errors = Stream.of(statusMessages)
			.filter(StringUtils::isNotBlank)
			.filter(isErrorMessage()).collect(Collectors.toSet());
		
		if(!errors.isEmpty())
		{
			final String errorMessagesJoined = Stream.of(statusMessages).collect(Collectors.joining(", "));
			return Optional.of(errorMessagesJoined);
		}
		else
		{
			// OK
			return Optional.empty();
		}
	}
	
	public static Predicate<String> isErrorMessage()
	{
		return statusMessage -> (statusMessage.startsWith("201")
			|| statusMessage.startsWith("202")
			|| statusMessage.startsWith("301"));
	}
	
	
	
	
	/**
	 * Checks
	 * <ul><li>the statusMessages of the response</li>
	 * <li>and of the child items.</li>
	 * </ul>
	 * <b>If an error is detected,</b> returns the error message, otherwise an empty optional.
	 * 
	 * @param responseToCheck
	 * @return
	 */
	public static Optional<String> checkData(final CIResponse responseToCheck)
	{
		Optional<String> checkMessages = checkData_(responseToCheck);
		if (checkMessages.isPresent()) 
		{
			String cBvdId = Optional.ofNullable(responseToCheck).map(CIResponse::getCompanyBvdId).orElse("unset");
			Logger.error("Error in CIResponse data : bvdId={} | {}", cBvdId, checkMessages.get());
		}
		return checkMessages;
	}
	
	protected static Optional<String> checkData_(final CIResponse response)
	{
		// Check main item
		
		final Optional<String> checkMessages = checkStatusMessages(response.getStatusMessage());
		// response.getStatusMessage()
		
		if(checkMessages.isPresent())
		{
			return checkMessages;
		}
		
		if (response.getCompanyBvdId() == null) {
			return Optional.of("Response incomplete: Does not contain a BvdId");
		}
		
		if (response.getCompanyInfoBvd() == null) {
			return Optional.of("Response incomplete: Does not contain a CompanyInfo");
		}
		
		// Check children
		final Set<CompanyGsssMatch> childGsssMatches = new HashSet<>();
		if (response.getCompanyGsssMatchResults() != null)
		{
			childGsssMatches.add(response.getCompanyGsssMatchResults());
		}
		if (response.getGuoGsssMatchResults() != null)
		{
			childGsssMatches.add(response.getGuoGsssMatchResults());
		}
		if(response.getBenOwnGsssMatchResults() != null)
		{
			childGsssMatches.addAll(response.getBenOwnGsssMatchResults().values());
		}
		if(response.getInterGsssMatchResults() != null)
		{
			childGsssMatches.addAll(response.getInterGsssMatchResults().values());
		}
		
		for(final CompanyGsssMatch cs : childGsssMatches)
		{
			final Optional<String> checkIt = checkStatusMessages(cs.getStatusMessage());
			if(checkIt.isPresent())
			{
				return checkIt;
		}
		}
		
		return Optional.empty();
	}
	
}
