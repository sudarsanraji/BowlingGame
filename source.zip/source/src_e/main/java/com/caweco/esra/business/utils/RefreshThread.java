package com.caweco.esra.business.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.func.rest.RestClientSeaWeb2;
import com.caweco.esra.business.func.rest.RestErrorHelper;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.func.rest.seaweb.GetShipsByIHSLRorIMONumbersAllv2;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.core.SearchEntryGsss;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.namematch.NMResponse;
import com.caweco.esra.entities.rest.seaweb2.APSShipResult_v2;
import com.caweco.esra.ui.dialogs.DialogBigMessage;
import com.caweco.esra.ui.sanctions.RefreshDataPage;
import com.vaadin.flow.component.UI;


class RefreshThread extends Thread
{
	private static ExecutorService          executor = Executors.newCachedThreadPool();
	
	private static final Logger LOG = LoggerFactory.getLogger(RefreshThread.class);
	
	private final Screening                 screening;
	private final Optional<RefreshDataPage> page;
	private final Optional<UI> 				ui;
	private String                          email;
	private Client                          client;
	
	public RefreshThread(final Screening screening, final Optional<RefreshDataPage> page, Client client, String email, Optional<UI> ui)
	{
		this.screening = screening;
		this.page = page;
		this.client = client;
		this.email = email;
		this.ui = ui;
	}
	
	@Override
	public void run()
	{
		
		LOG.info("Refresh screening task started with Client {} on Screening {}", client == null ? "UNSET" : client.getUuid(), screening == null ? "UNSET" : screening.getScreeningID());
		
		if (this.page.isPresent() && this.ui.isPresent())
		{
			this.ui.get().access(() -> {
				this.page.get().setRefreshing(true);				
			});
		}
		
		// TODO: Filter items-to-refresh: Basically, not all items have to be refreshed e.g. when there are already duplicated items added by a previous refresh run..
		
		final List<SearchEntryCompany>       newWatchList       = this.screening.getWatchlistCompanyEntries(true);
		final List<SearchEntrySeaweb2Vessel> newWatchListSeaweb = this.screening.getVesselsSeaWeb(true);
		final List<SearchEntryGsss>          newWatchListGsss   = this.screening.getWatchlistSearchEntriesGsss(true);
		
		final CountDownLatch                 latch              = new CountDownLatch(
			newWatchList.size() + newWatchListSeaweb.size() + newWatchListGsss.size());
		
		
		
		
		// ============= Fetch Companies ================
		
		final List<Future>                   futures            = new ArrayList<>();
		
		// We're going async, so I'll need to store the session in order to get the REST Clients
		
		new ArrayList<>(newWatchList).forEach(company ->
		{
			
			final Future<Boolean> singleFuture = executor.submit(() ->
			{
				final CompletionStage<CIResponse> getCompanyInfoStage = RestUtil.getRestClient_BIH(screening.getClientId())
					.getCompanyInfoStage(company.getItem().getCompanyBvdId());
				
				getCompanyInfoStage.handle((result_RAW, throwable) ->
				{
					System.out.println("getCompanyInfoStage whenCompleteAsync");
					
					if (throwable != null)
					{
						// REST call failed
						
						this.showDialog(
							DialogBigMessage.New().withTopic("Data error").withContent("Could not fetch company data from backend.")
							.withWidth("500px").withColor("red")
						);

						
						// sf.showTextResult(throwable.getMessage(), true);
						
						LOG.error("REST call failed.", throwable);
						
						latch.countDown();
						return null;
					}
					else
					{
						System.out.println("no throwable");
						// REST call succeeded
						
						// Result for "Unknown" search
						final Optional<String> error = RestErrorHelper.getError(result_RAW);
						
						if (error.isPresent())
						{
							
							this.showDialog(
								DialogBigMessage.New().withTopic("Data error")
									.withContent("An error has occured when fetching the data. We are currently working on a solution with AZ Technology and will be back soon. Please contact the ESRA Helpdesk for any queries: agcs-esra@allianz.com")
									.withWidth("500px").withColor("red")
							);
							
							LOG.warn("REST Call successful but there was error on BIH/CARA side: [ {} ]", error.get());
							
							latch.countDown();
							return null;
						}
						else
						{
							LOG.debug("new data handling for company {}", company.getId().toString());
							
							// Clean Data
							final CIResponse         companyInfoResult = SanctionUtil
								.cleanupCIResponseMatches(result_RAW, client);
							
							final SearchEntryCompany newCompany        = SearchEntryCompany.New(companyInfoResult, email);
							
							int                      oldValue          = SanctionUtil
								.toFlag(SanctionUtil.isMarked(client, company));
							int                      newValue          = SanctionUtil
								.toFlag(SanctionUtil.isMarked(client, newCompany));
							
							LOG.debug("oldValue is " + oldValue + " - " + (null != company ? company.toString() : "none"));
							LOG.debug("newValue is " + newValue + " - " + (null != newCompany ? newCompany.toString() : "none"));
							
							synchronized(newWatchList)
							{
								newWatchList.add(newCompany);
								
								if (oldValue == newValue)
								{
									newWatchList.remove(company);
								}	
							}
							
							latch.countDown();
							return companyInfoResult;
						}
					}
				}).toCompletableFuture().get();
				
				return true;
			});
			
			futures.add(singleFuture);
		});
		
		for (final Future future : futures)
		{
			try
			{
				future.get();
			}
			catch (InterruptedException | ExecutionException e)
			{
				LOG.error("Get Company failed", e);
			} // wait for each
		}
		
		// ============= Fetch Seaweb ================
		
		final RestClientSeaWeb2       instance        = RestUtil.getRestClient_SEAWEB(screening.getClientId());
		
		/// Fetch Data from Seaweb rest endpoint
		
		Map<String, APSShipResult_v2> shipRestResults = new HashMap<>();
		
		try
		{
			// ImoNumbers to refresh - No duplicates here:
			Set<String> imoNumbersInScreening_noDuplicates = this.screening.getVesselsSeaWeb(false).stream()
				.map(ship -> ship.getShipDetails().getIHSLRorIMOShipNo()).collect(Collectors.toSet());
			if (!imoNumbersInScreening_noDuplicates.isEmpty())
			{
				
				// Throws exception if REST call fails or
				List<APSShipResult_v2> restResults = GetShipsByIHSLRorIMONumbersAllv2
					.fetchImoNumbers_withCheck_useBatches(instance, new ArrayList<>(imoNumbersInScreening_noDuplicates))
					.toCompletableFuture().get();
				
				restResults.forEach(shipInfo -> shipRestResults.put(shipInfo.getAPSShipDetail().getIHSLRorIMOShipNo(), shipInfo));
			}
			
		}
		catch (InterruptedException | ExecutionException e1)
		{
			LOG.error("Seaweb REST call failed.", e1);
			latch.countDown();
		}
		
		/// Replace SearchEntrySeaweb2Vessel items
		
		// (new List to prevent ConcurrentModificationException)
		new ArrayList<>(newWatchListSeaweb).stream().forEach(ship ->
		{
			
			System.out.println("actual handling - " + ship.getShipDetails().getShipName());
			
			APSShipResult_v2               newShipData = shipRestResults.get(ship.getShipDetails().getIHSLRorIMOShipNo());
			
			// (2022-09-29 MH): Hardcoding 0 for now, as we dont expect more than one ship anyway.
			final SearchEntrySeaweb2Vessel newVessel   = SearchEntrySeaweb2Vessel.New(newShipData, email);
			
			final int                      oldValue    = SanctionUtil.toFlag(SanctionUtil.isMarked_internal(client, ship));
			final int                      newValue    = SanctionUtil.toFlag(SanctionUtil.isMarked_internal(client, newVessel));
			
			String shipName = null != ship && null != ship.getShipDetails() ? ship.getShipDetails().getShipName() : "none";
			LOG.debug("oldValue is " + oldValue + " - " + (null != ship ? ship.toString() : "none")+ " - " + shipName);
			LOG.debug("newValue is " + newValue + " - " + (null != newVessel ? newVessel.toString() : "none") + " - " + shipName);
			
			newWatchListSeaweb.add(newVessel);
			
			if (oldValue == newValue)
			{
				newWatchListSeaweb.remove(ship);
			}
			
			latch.countDown();
			
		});
		
		// ============= Fetch GSSS ================
		
		System.out.println("starting fetch gsss area...");
		
		new ArrayList<>(newWatchListGsss).forEach(gsss ->
		{
			
			System.out.println("entered foreach gsss - " + gsss.getResponse_nameToSearch());
			
			executor.submit(() ->
			{
				final CompletionStage<NMResponse> getInfo = RestUtil.getRestClient_BIH(screening.getClientId())
					.getNameMatchStage(gsss.getResponse_nameToSearch(), String.valueOf(gsss.getSearchtype().getId()), gsss
						.getCountry());
				
				getInfo.handle((result, throwable) ->
				{
					if (throwable != null)
					{
						// REST call failed
						LOG.error("REST call failed.", throwable);
						
						this.showDialog(
							DialogBigMessage.New().withTopic("Data error").withContent("Could not fetch data from backend.")
							.withWidth("500px").withColor("red")
						);
						
						latch.countDown();
						return false;
					}
					else
					{
						// REST Call succeeded
						System.out.println("rest call succeeded gsss - " + gsss.getResponse_nameToSearch());
						
						final Optional<String> error = RestErrorHelper.getError(result);
						
						if (error.isPresent())
						{
							this.showDialog(
								DialogBigMessage.New().withTopic("Data error")
								.withContent("An error has occured when fetching the data. We are currently working on a solution with AZ Technology and will be back soon. Please contact the ESRA Helpdesk for any queries: agcs-esra@allianz.com")
								.withWidth("500px").withColor("red")
							);
							
							LOG.warn("REST Call successful but there was error on BIH/CARA side: [ {} ]", error.get());
							latch.countDown();
							return false;
						}
						else
						{
							LOG.debug("evaluating newGsss - " + result.getNameToSearch());
							final SearchEntryGsss newGsss  = new SearchEntryGsss(gsss.getSearchtype(), result, client, email,
								gsss.getCountry());
							
							final int             oldValue = SanctionUtil.toFlag(SanctionUtil.isMarked(client, gsss));
							final int             newValue = SanctionUtil.toFlag(SanctionUtil.isMarked(client, newGsss));
							
							LOG.debug("oldValue is " + oldValue + " - " + (null != gsss ? gsss.toString() : "none") + " - ");
							LOG.debug("newValue is " + newValue + " - " + (null != newGsss ? newGsss.toString() : "none") + " - ");
							
							newWatchListGsss.add(newGsss);
							
							if (oldValue == newValue)
							{
								newWatchListGsss.remove(gsss);
							}
							latch.countDown();
							return true;
						}
					}
				}).toCompletableFuture().get();
				
				return true;
				
			});
		});
		
		try
		{
			boolean finished = latch.await(60L, TimeUnit.MINUTES);
			
			if(!finished)
			{
				LOG.error("Timed out waiting for entity refresh calls to finish");
				this.showDialog(
					DialogBigMessage.New().withTopic("Data error").withContent("Entity refresh timed out, not all entities were updated!")
					.withWidth("500px").withColor("red")
				);
			}
		}
		catch (final InterruptedException e)
		{
			LOG.error("Failed to wait for entity refresh calls", e);
		}
		LOG.trace("reached the saving part");
		
		if (this.screening != null) {
			this.screening.setWatchlistCompanyEntries(newWatchList);
			this.screening.setVesselsSeaWeb(newWatchListSeaweb);
			this.screening.setWatchlistSearchEntriesGsss(newWatchListGsss);
			ScreeningDAO.saveScreening(this.screening, false);
		}
		
		LOG.debug("copied screening saved");
		
		if (this.page.isPresent() && this.ui.isPresent())
		{
			ui.get().access(() -> {
				this.page.get().setRefreshing(false);
				this.page.get().refreshDisplay();
			});
		}
		
	}
	
	private void showDialog(DialogBigMessage dbm)
	{
		ui.ifPresent(ui -> 
			ui.access(dbm::go)
		);
	}
}
