package com.caweco.esra.ui.page.usertasks.subscr;

import java.util.Set;

import com.caweco.esra.entities.rest.general.Subsidiary;
import com.caweco.esra.subsidary.common.SubNode;
import com.caweco.esra.subsidary.common.SubNodeState;
import com.caweco.esra.subsidary.frontend.SubsidiaryStateRepresentationHelper;

public class SubNodeWrapper1
{
	public static SubNodeWrapper1 Wrap(SubNode wrapped) {
		return new SubNodeWrapper1(wrapped);
	}
	
	final SubNode wrapped;

	public SubNodeWrapper1(SubNode wrapped)
	{
		super();
		this.wrapped = wrapped;
	}


	public boolean isRoot()
	{
		return wrapped.isRoot;
	}
	public Set<SubNode> getChildren()
	{
		return wrapped.children;
	}
	public SubNodeState getState()
	{
		return wrapped.state;
	}
	public String getCompanyID()
	{
		return wrapped.companyID;
	}
	public Subsidiary getRawSubsidiaryData()
	{
		return wrapped.rawSubsidiaryData;
	}
	public SubNode getWrapped()
	{
		return wrapped;
	}
	
	/**
	 * Generated value
	 * @return
	 */
	public String getCompanyText()
	{
		final String out =
			wrapped.companyID + (wrapped.rawSubsidiaryData != null ? (" / " + wrapped.rawSubsidiaryData.getName()) : "");
		return out;
	}
	
	/**
	 * Generated value
	 * @return
	 */
	public String getStateText()
	{
		return SubsidiaryStateRepresentationHelper.getNodeRepresentation(getState());
	}
	
	/**
	 * Generated value
	 * @return
	 */
	public String getShareText()
	{
		String out = wrapped.rawSubsidiaryData != null ? 
			("Total: " + wrapped.rawSubsidiaryData.getTotal() + " / Direct: " + wrapped.rawSubsidiaryData.getDirect()) : "";
		return out;
	}
}
