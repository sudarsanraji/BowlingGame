package com.caweco.esra.entities.questionnaire;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class SingleOptionQuestion extends Question implements HasChooseableValues
{
	private List<ChooseableValues> values = new ArrayList<ChooseableValues>();
	
	public SingleOptionQuestion()
	{
		super();
	}
	
	/**
	 * @param questionText
	 * @param helperText
	 * @param active
	 * @param standard
	 */
	public SingleOptionQuestion(
		final String questionText,
		final String helperText,
		final Boolean active,
		final Boolean standard)
	{
		super(questionText, helperText, active, standard);
	}
	
	@Override
	public List<ChooseableValues> getValues()
	{
		return this.values;
	}
	
	@Override
	public void setValues(final List<ChooseableValues> values)
	{
		this.values = values;
	}
	
	
	public SingleOptionQuestion copyNoRules()
	{
		final var copy = new SingleOptionQuestion();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		
		copy.setValues(this.values == null ? null : this.values.stream().map(v ->
		{
			final var ret = new ChooseableValues();
			ret.setId(v.getId());
			ret.setText(v.getText());
			ret.setValue(v.getValue());
			return ret;
		}).collect(Collectors.toList()));
		return copy;
	}
}
