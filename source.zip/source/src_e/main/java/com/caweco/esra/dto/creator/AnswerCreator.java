package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.AnswerDTO;
import com.caweco.esra.entities.questionnaire.Answer;
import com.caweco.esra.entities.questionnaire.AnswerType;
import com.caweco.esra.entities.questionnaire.FreeTextAnswer;
import com.caweco.esra.entities.questionnaire.MultiOptionAnswer;
import com.caweco.esra.entities.questionnaire.DurationChooserAnswer;
import com.caweco.esra.entities.questionnaire.DateChooserAnswer;
import com.caweco.esra.entities.questionnaire.SingleOptionAnswer;

public class AnswerCreator {
	public static AnswerDTO convertAnswerToDTO(Answer answer)
	{
		AnswerDTO dto = new AnswerDTO();
		dto.setAnswerID(answer.getAnswerID());
		dto.setComment(answer.getComment());
		
		if(answer instanceof FreeTextAnswer)
		{
			dto.setAnswerType(AnswerType.FREETEXT);
			dto.setText(((FreeTextAnswer) answer).getText());
		}
		else if(answer instanceof DateChooserAnswer)
		{
			dto.setAnswerType(AnswerType.DATE);
			dto.setDateTime(((DateChooserAnswer) answer).getDatetime());
		}
		else if(answer instanceof DurationChooserAnswer)
		{
			dto.setAnswerType(AnswerType.DURATION);
			dto.setStart(((DurationChooserAnswer) answer).getStart());
			dto.setEnd(((DurationChooserAnswer) answer).getEnde());
		}
		else if(answer instanceof MultiOptionAnswer)
		{
			dto.setAnswerType(AnswerType.MULTI);
			dto.setAnswers(((MultiOptionAnswer) answer).getAnswers());
		}
		else if(answer instanceof SingleOptionAnswer)
		{
			dto.setAnswerType(AnswerType.SINGLE);
			dto.setValue(((SingleOptionAnswer) answer).getValue());
		}
		
		return dto;
	}

	public static Answer convertDTOToAnswer(AnswerDTO dto) {
		
		Answer answer;
		

		
		if(dto.getAnswerType().equals(AnswerType.FREETEXT))
		{
			answer = new FreeTextAnswer();
			((FreeTextAnswer) answer).setText(dto.getText());
		}
		else if(dto.getAnswerType().equals(AnswerType.DURATION))
		{
			answer = new DurationChooserAnswer();
			((DurationChooserAnswer) answer).setStart(dto.getStart());
			((DurationChooserAnswer) answer).setEnde(dto.getEnd());
		}
		else if(dto.getAnswerType().equals(AnswerType.DATE))
		{
			answer = new DateChooserAnswer();
			((DateChooserAnswer) answer).setDatetime(dto.getDateTime());
		}
		else if(dto.getAnswerType().equals(AnswerType.MULTI))
		{
			answer = new MultiOptionAnswer();
			((MultiOptionAnswer) answer).setAnswers(dto.getAnswers());
		}
		else if(dto.getAnswerType().equals(AnswerType.SINGLE))
		{
			answer = new SingleOptionAnswer();
			((SingleOptionAnswer) answer).setValue(dto.getValue());
		}
		else
		{
			answer = new Answer();
		}
		
		answer.setAnswerID(dto.getAnswerID());
		answer.setComment(dto.getComment());
		
		return answer;
	}
}
