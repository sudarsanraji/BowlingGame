package com.caweco.esra.business.usernotifications;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.subsidary.common.usernotifications.UserNotification;
import com.vaadin.flow.shared.Registration;


public class UserNotificationManager
{
	/**
	 * NotificationId <-> UserNotification
	 */
	static ConcurrentHashMap<String, UserNotification>                         CACHE                     = new ConcurrentHashMap<>();
	
	static Executor                                                            executor                  = Executors
		.newSingleThreadExecutor();
	
	/**
	 * userId <-> Listener
	 */
	static ConcurrentHashMap<String, Pair<String, Consumer<UserNotification>>> userNotificationListeners = new ConcurrentHashMap<>();
	
	public static synchronized Registration registerNotificationListener(String userId, Consumer<UserNotification> listener)
	{
		String registrationKey = UUID.randomUUID().toString();
		userNotificationListeners.put(registrationKey, Pair.of(userId, listener));
		
		return () ->
		{
			synchronized (UserNotificationManager.class)
			{
				userNotificationListeners.remove(registrationKey);
			}
		};
	}
	
	public static synchronized void send(UserNotification notification)
	{
		CACHE.put(notification.getId(), notification);
		for (Pair<String, Consumer<UserNotification>> listener : userNotificationListeners.values())
		{
			if (Objects.equals(notification.getTargetUserId(), listener.getLeft()))
			{
				executor.execute(() -> listener.getRight().accept(notification));
			}
		}
	}
	
	public static List<UserNotification> getNotificationsForUser(String userId)
	{
		List<UserNotification> items = getNotificationsStream()
			.filter(ut -> Objects.equals(ut.getTargetUserId(), userId))
			.collect(Collectors.toList());
		items.sort(Comparator.comparing(UserNotification::getCreated));
		
		return items;
	}
	
	private static Stream<UserNotification> getNotificationsStream()
	{
		return CACHE.values().stream();
	}
	
	public static void removeNotification(UserNotification it)
	{
		CACHE.remove(it.getId());
	}
}
