package com.caweco.esra.entities.questionnaire;

public class Answer
{
	
	private Integer	answerID;
	private String	comment;
	
	public Integer getAnswerID()
	{
		return this.answerID;
	}
	
	public void setAnswerID(final Integer answerID)
	{
		this.answerID = answerID;
	}
	
	public String getComment()
	{
		return this.comment;
	}
	
	public void setComment(final String comment)
	{
		this.comment = comment;
	}
}
