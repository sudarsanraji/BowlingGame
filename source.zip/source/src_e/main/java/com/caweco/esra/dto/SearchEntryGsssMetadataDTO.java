package com.caweco.esra.dto;

import java.time.Instant;

import com.caweco.esra.ui.sanctions.bean.SearchType;

public class SearchEntryGsssMetadataDTO {

	private Instant created;
	private String createdBy;
	private SearchType searchtype;
	private String comment;
	private Integer appliedThreshold;
	private String[] response_statusMessage;
	private String response_nameToSearch;
	private long response_numberOfGSSSHitsOrig;
	private String id;
	public Instant getCreated() {
		return created;
	}
	public void setCreated(Instant created) {
		this.created = created;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public SearchType getSearchtype() {
		return searchtype;
	}
	public void setSearchtype(SearchType searchtype) {
		this.searchtype = searchtype;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Integer getAppliedThreshold() {
		return appliedThreshold;
	}
	public void setAppliedThreshold(Integer appliedThreshold) {
		this.appliedThreshold = appliedThreshold;
	}
	public String[] getResponse_statusMessage() {
		return response_statusMessage;
	}
	public void setResponse_statusMessage(String[] response_statusMessage) {
		this.response_statusMessage = response_statusMessage;
	}
	public String getResponse_nameToSearch() {
		return response_nameToSearch;
	}
	public void setResponse_nameToSearch(String response_nameToSearch) {
		this.response_nameToSearch = response_nameToSearch;
	}
	public long getResponse_numberOfGSSSHitsOrig() {
		return response_numberOfGSSSHitsOrig;
	}
	public void setResponse_numberOfGSSSHitsOrig(long response_numberOfGSSSHitsOrig) {
		this.response_numberOfGSSSHitsOrig = response_numberOfGSSSHitsOrig;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
