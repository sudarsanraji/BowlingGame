package com.caweco.esra.dto.creator;

import java.util.HashSet;
import java.util.UUID;

import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dto.ClientAssignmentRuleLdapDTO;
import com.caweco.esra.dto.RoleMetadataDTO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.access.ClientAssignmentRuleLdap;

public class ClientAssignmentRuleLdapCreator {

	public static ClientAssignmentRuleLdapDTO convertAssignmentRuleToDTO(ClientAssignmentRuleLdap object)
	{
		ClientAssignmentRuleLdapDTO dto = new ClientAssignmentRuleLdapDTO();
		dto.setClientId(object.getClientToAssignTo().getUuid().toString());
		dto.setCompany(AccessControlCompanyCreator.convertAccessControlToDTO(object.getCompany()));
		dto.setCreated(object.getCreated());
		dto.setDepartment(object.getDepartment() != null ? object.getDepartment() : null);
		dto.setId(object.getUuid().toString());
		
		HashSet<RoleMetadataDTO> roles = new HashSet<>();
		
		if(object.getRolesToAssign() != null)
		{
			object.getRolesToAssign().forEach((role) -> {
				roles.add(RoleCreator.convertRoleToMetadataDTO(role));
			});
		}
		
		dto.setRoles(roles);
		dto.setSamlCountry(object.getSamlCountry());
		return dto;
	}
	
	public static ClientAssignmentRuleLdap convertDTOToClientAssignment(ClientAssignmentRuleLdapDTO dto)
	{
		Client client = ClientDAO.findById(UUID.fromString(dto.getClientId())).get();
		AccessControlCompany acc = AccessControlCompanyCreator.convertDTOToAccessControlCompany(dto.getCompany());
		
		
		ClientAssignmentRuleLdap object = new ClientAssignmentRuleLdap(client, acc);
		object.setUuid(UUID.fromString(dto.getId()));
		object.setSamlCountry(dto.getSamlCountry());
		
		HashSet<Role> roles = new HashSet<>();
		
		if(dto.getRoles() != null)
		{
			dto.getRoles().forEach((roleDto) -> {
				roles.add(RoleCreator.convertMetadataDTOToRole(roleDto));
			});
		}
		
		object.setRolesToAssign(roles);
		return object;
	}



}
