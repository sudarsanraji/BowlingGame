package com.caweco.esra.ui.beans;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.flow.component.ItemLabelGenerator;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.function.SerializableConsumer;
import com.vaadin.flow.function.SerializableFunction;


public class MultiValueComboBox<T> extends VerticalLayout implements HasTags<T>
{
	private SerializableConsumer<T>			consumer		= null;
	private boolean							activConsumer;
	private final ComboBox<String>				cb				= new ComboBox<>();
	private ItemLabelGenerator<T>			itemToString	= it -> it.toString();
	private SerializableFunction<String, T>	itemBuilder;
	
	private Map<String, T>					availableItems;
	private Set<T>							items			= new HashSet<>();
	
	private Collection<T>					availableItemsOrig;
	private Collection<T>					itemsOrig		= new HashSet<>();
	
	public MultiValueComboBox(final SerializableFunction<String, T> itemBuilder)
	{
		super();
		Objects.requireNonNull(itemBuilder);
		this.itemBuilder = itemBuilder;
		
		this.initUI();
		
		this.cb.setSizeUndefined();
		this.horizontalLayout.add(this.cb);
		this.horizontalLayout.setFlexGrow(1.0, this.cb);
		
		this.cb.addValueChangeListener(event ->
		{
			
			if(StringUtils.isNotBlank(event.getValue()))
			{
				final T valueItem = this.availableItems.get(event.getValue());
				
				if(!this.items.contains(valueItem))
				{
					this.items.add(valueItem);
					
					final MultiValueComboBoxTagLabel<T> tagLabel =
						new MultiValueComboBoxTagLabel<>(valueItem, this.itemToString.apply(valueItem), this);
					this.flexLayout.add(tagLabel);
				}
				
				System.out.println("cb_valueChanged: " + event.getValue());
				event.getSource().setValue("");
				if(this.activConsumer)
				{
					this.consumer.accept(valueItem);
				}
				
			}
		});
		
		this.cb.addCustomValueSetListener(event ->
		{
			
			if(StringUtils.isNotBlank(event.getDetail()))
			{
				final String possibleNewEntry = StringUtils.trim(event.getDetail());
				
				this.handlePossibleNewEntry(possibleNewEntry);
				
				System.out.println("cb_onCustomValueSet: " + event.getDetail());
				event.getSource().setValue("");
			}
		});
	}
	
	public void setConsumer(final SerializableConsumer<T> consumer)
	{
		this.consumer = consumer;
		this.activConsumer = true;
	}
	
	private void handlePossibleNewEntry(final String possibleNewEntry)
	{
		final boolean isAlreadyAItem = this.items.stream().filter(
			it -> StringUtils.equalsIgnoreCase(this.itemToString.apply(it), possibleNewEntry))
			//
			.findFirst().isPresent();
		
		if(!isAlreadyAItem)
		{
			T item = this.availableItems.get(possibleNewEntry);
			
			if(item == null)
			{
				item = this.itemBuilder.apply(possibleNewEntry);
				this.availableItems.put(possibleNewEntry, item);
				
				this.cb.getDataProvider().refreshAll();
			}
			
			this.items.add(item);
			
			final MultiValueComboBoxTagLabel<T> tagLabel =
				new MultiValueComboBoxTagLabel<>(item, this.itemToString.apply(item), this);
			this.flexLayout.add(tagLabel);
		}
	}
	
	public MultiValueComboBox<T> setItems(final Collection<T> items) // NO_UCD - setter
	{
		this.flexLayout.removeAll();
		
		this.itemsOrig = items;
		// this.items = this.itemsOrig != null ? new HashSet<>(this.itemsOrig) : new HashSet<>(); ?? erzeugt immer
		this.items = (Set<T>)items;
		this.items.forEach(i ->
		{
			final MultiValueComboBoxTagLabel<T> tagLabel =
				new MultiValueComboBoxTagLabel<>(i, this.itemToString.apply(i), this);
			this.flexLayout.add(tagLabel);
		});
		return this;
	}
	
	public MultiValueComboBox<T> setAvailableItems(final Collection<T> items)
	{
		this.availableItemsOrig = items != null ? items : new HashSet<>();
		this.availableItems =
			this.availableItemsOrig.stream().collect(Collectors.toMap(it -> this.itemToString.apply(it), it -> it));
		
		final ListDataProvider<String> dataProvider = DataProvider.ofCollection(this.availableItems.keySet());
		dataProvider.setSortOrder(it -> it, SortDirection.ASCENDING);
		this.cb.setDataProvider(dataProvider);
		
		return this;
	}
	
	public void resetItems()
	{
		this.items.clear();
		this.flexLayout.removeAll();
	}
	
	public void setItemBuilder(final SerializableFunction<String, T> itemBuilder)
	{
		Objects.requireNonNull(itemBuilder);
		this.itemBuilder = itemBuilder;
	}
	
	public void setItemToStringConverter(final ItemLabelGenerator<T> itemToString)
	{
		Objects.requireNonNull(itemToString);
		this.itemToString = itemToString;
	}
	
	public ComboBox<String> getComboBox()
	{
		return this.cb;
	}
	
	public String getTitle()
	{
		return this.label.getText();
	}
	
	public MultiValueComboBox<T> setTitle(final String title) // NO_UCD - setter
	{
		if(title != null)
		{
			this.label.setText(title);
			this.label.setVisible(true);
		}
		else
		{
			this.label.setText("");
			this.label.setVisible(false);
		}
		return this;
	}
	
	public String getPlaceholder()
	{
		return this.cb.getPlaceholder();
	}
	
	public MultiValueComboBox<T> setPlaceholder(final String placeholder)
	{
		
		if(placeholder != null)
		{
			this.cb.setPlaceholder("Add " + placeholder + " ...");
		}
		else
		{
			this.cb.setPlaceholder(null);
		}
		return this;
	}
	
	////
	// Tb be called from Tags
	
	@Override
	public void delete(final MultiValueComboBoxTagLabel<T> tag)
	{
		this.flexLayout.remove(tag);
		this.items.remove(tag.getItem());
		if(this.activConsumer)
		{
			this.consumer.accept(tag.getItem());
		}
	}
	
	public Set<T> getItems()
	{
		return this.items;
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.flexLayout = new FlexLayout();
		
		this.setSpacing(false);
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout.getStyle().set("margin-left", "5px");
		this.label.setText("Label");
		this.label.setVisible(false);
		this.label.setMinWidth("70px");
		this.flexLayout.getStyle().set("flex-flow", "wrap");
		this.flexLayout.getStyle().set("flex-direction", "row");
		
		this.label.setSizeUndefined();
		this.horizontalLayout.add(this.label);
		this.horizontalLayout.setSizeUndefined();
		this.flexLayout.setWidthFull();
		this.flexLayout.setHeight(null);
		this.add(this.horizontalLayout, this.flexLayout);
		this.setFlexGrow(1.0, this.flexLayout);
		this.setSizeUndefined();
	} // </generated-code>
	
	// <generated-code name="variables">
	private FlexLayout			flexLayout;
	private HorizontalLayout	horizontalLayout;
	private Label				label;
	// </generated-code>
	
}
