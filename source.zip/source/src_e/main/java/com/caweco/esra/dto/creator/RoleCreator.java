package com.caweco.esra.dto.creator;

import java.util.UUID;

import com.caweco.esra.dto.RoleMetadataDTO;
import com.caweco.esra.entities.Role;

public class RoleCreator {
	
	public static RoleMetadataDTO convertRoleToMetadataDTO(Role role)
	{
		RoleMetadataDTO dto = new RoleMetadataDTO();
		
		dto.setId(role.getId().toString());
		dto.setName(role.getName());
		dto.setDescription(role.getDescription());
		
		dto.setResources(role.getResources());
		
		return dto;
	}

	public static Role convertMetadataDTOToRole(RoleMetadataDTO dto) {
		Role object = new Role();
		
		object.setId(UUID.fromString(dto.getId()));
		object.setDescription(dto.getDescription());
		object.setName(dto.getName());
		if (dto.getResources() != null) {
	        dto.getResources().forEach(object::addResource);
	    }		
		return object;
	}
	

}
