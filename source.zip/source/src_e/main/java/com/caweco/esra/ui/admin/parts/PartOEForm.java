package com.caweco.esra.ui.admin.parts;

import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.core.OeDAO;
import com.caweco.esra.dao.core.OeRegionDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.InputEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializableBiFunction;



public class PartOEForm extends VerticalLayout
{
	
	private OE				item;
	private final Set<OE>	items;
	
	private SerializableBiFunction<OE, Client, Boolean> deletableRule;
	private Client                                      client;
	
	/**
	 *
	 */
	public PartOEForm(final Set<OE> items, final String name)
	{
		super();
		this.items = items;
		this.initUI();
		Column<OE> nameColumn = this.grid.getColumnByKey("name");
		this.grid.sort(GridSortOrder.asc(nameColumn).build());
		
		this.lblType.setText(name);
		this.grid.setItems(items);
		
		this.setNewItemToForm();
		
		ListDataProvider<OeRegion> dataProvider =
			DataProvider.ofCollection(OeRegionDAO.findAll(CurrentUtil.getClient()));
		dataProvider.setSortOrder(OeRegion::getName, SortDirection.ASCENDING);
		this.comboBox.setDataProvider(dataProvider);
		
		UiHelper.setAriaLabel(this.btnNew, Aria.get("Values_add"));
		UiHelper.setAriaLabel(this.btnDelete, Aria.get("Values_remove"));
		UiHelper.setAriaLabel(this.btnSave, Aria.get("Values_save"));
	}
	

	
	public void refreshRegions()
	{
		this.comboBox.setItems(OeRegionDAO.findAll(CurrentUtil.getClient()));
	}
	
	public PartOEForm withDeleteButton()
	{
		this.btnDelete.setVisible(true);
		return this;
	}
	
	public PartOEForm withDeletableRule(SerializableBiFunction<OE, Client, Boolean> deletableRule, Client client)
	{
		this.deletableRule = deletableRule;
		this.client = client;
		return this;
	}
	
	protected boolean evalSaveEnabled()
	{
		String value = StringUtils.stripToEmpty(this.txtName.getValue());
		boolean no1 = (value.length() >= 3);
		boolean no2 = (this.comboBox.getValue() != null);
		return (no1 && no2);
	}
	
	protected void setNewItemToForm()
	{
		this.setItemToForm(new OE(), true);
	}
	
	protected void setItemToForm(OE item, boolean isNew)
	{
		this.item = item;
		this.binder.readBean(this.item);
		this.btnSave.setEnabled(this.evalSaveEnabled());
		if (!isNew && this.deletableRule != null && this.client != null)
		{
			Boolean isDeletable = this.deletableRule.apply(this.item, this.client);
			this.btnDelete.setEnabled(BooleanUtils.isTrue(isDeletable));
		}
		else
		{
			this.btnDelete.setEnabled(!isNew);
		}
		this.txtName.focus();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		try
		{
			this.binder.writeBean(this.item);
			
			if(this.items.contains(this.item))
			{
				
				OeDAO.update(CurrentUtil.getClient(), this.item);
				this.grid.setItems(CurrentUtil.getClient().getOes(true));
				this.grid.getDataProvider().refreshAll();
			}
			else
			{
				OeDAO.insert(CurrentUtil.getClient(), this.item);
				this.grid.setItems(CurrentUtil.getClient().getOes(true));
				this.grid.getDataProvider().refreshAll();
			}
			
			this.setNewItemToForm();
		}
		catch(final ValidationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void grid_selectionChange(SelectionEvent<Grid<OE>, OE> event)
	{
		Optional<OE> selected = event.getFirstSelectedItem();
		if (selected.isPresent())
		{
			this.setItemToForm(selected.get(), false);
		}
		else
		{
			this.setNewItemToForm();
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNew_onClick(final ClickEvent<Button> event)
	{
		this.grid.deselectAll();
		this.setNewItemToForm();
	}
	
	/**
	 * Event handler delegate method for the {@link TextField} {@link #txtName}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtName_onInput(final InputEvent event)
	{
		this.btnSave.setEnabled(this.evalSaveEnabled());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDelete_onClick(ClickEvent<Button> event)
	{
		this.grid.getSelectionModel().getFirstSelectedItem().ifPresent(it ->
		{
			this.items.remove(it);
			OeDAO.delete(CurrentUtil.getClient(), it);
			this.grid.setItems(CurrentUtil.getClient().getOes(true));
			this.grid.deselectAll();
			
			this.setNewItemToForm();
		});
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #comboBox}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void comboBox_valueChanged(ComponentValueChangeEvent<ComboBox<OeRegion>, OeRegion> event)
	{
		if (event.isFromClient())
		{
			this.btnSave.setEnabled(this.evalSaveEnabled());
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout2 = new HorizontalLayout();
		this.lblType = new Label();
		this.btnDelete = new Button();
		this.btnNew = new Button();
		this.grid = new Grid<>(OE.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.div = new Div();
		this.lblName = new Label();
		this.txtName = new TextField();
		this.lblRegion = new Label();
		this.comboBox = new ComboBox<>();
		this.btnSave = new Button();
		this.binder = new Binder<>();
		
		this.setSpacing(false);
		this.setMaxHeight("500px");
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout2.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.lblType.setText("Label");
		this.btnDelete.setEnabled(false);
		this.btnDelete.setVisible(false);
		this.btnDelete.setIcon(VaadinIcon.TRASH.create());
		this.btnNew.setIcon(VaadinIcon.PLUS.create());
		this.grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT, GridVariant.LUMO_WRAP_CELL_CONTENT);
		this.grid.getStyle().set("flex-basis", "0");
		this.grid.addColumn(OE::getId).setKey("id").setHeader(CaptionUtils.resolveCaption(OE.class, "id")).setResizable(true)
			.setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.grid.addColumn(OE::getName).setKey("name").setHeader(CaptionUtils.resolveCaption(OE.class, "name")).setResizable(
			true)
			.setSortable(true).setFlexGrow(2);
		this.grid.addColumn(v -> Optional.ofNullable(v).map(OE::getRegion).map(OeRegion::getName).orElse(null))
			.setKey("region.name")
			.setHeader(CaptionUtils.resolveCaption(OE.class, "region.name")).setResizable(true).setSortable(true).setAutoWidth(
				true)
			.setFlexGrow(0);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.horizontalLayout.setSpacing(false);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.END);
		this.div.setClassName("asGrid twoCol");
		this.lblName.setText("Office Name");
		this.lblName.getStyle().set("margin-right", "10px");
		this.txtName.setValueChangeTimeout(0);
		this.txtName.setValueChangeMode(ValueChangeMode.TIMEOUT);
		this.lblRegion.setText("Office Region");
		this.lblRegion.getStyle().set("margin-right", "10px");
		this.comboBox.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(OeRegion::getName));
		this.btnSave.setEnabled(false);
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		
		this.binder.forField(this.txtName).withNullRepresentation("").bind(OE::getName, OE::setName);
		this.binder.forField(this.comboBox).bind(OE::getRegion, OE::setRegion);
		
		this.lblType.setWidthFull();
		this.lblType.setHeight(null);
		this.btnDelete.setSizeUndefined();
		this.btnNew.setSizeUndefined();
		this.horizontalLayout2.add(this.lblType, this.btnDelete, this.btnNew);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblType);
		this.lblName.setSizeUndefined();
		this.txtName.setSizeUndefined();
		this.lblRegion.setSizeUndefined();
		this.comboBox.setSizeUndefined();
		this.div.add(this.lblName, this.txtName, this.lblRegion, this.comboBox);
		this.div.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.div, this.btnSave);
		this.horizontalLayout.setFlexGrow(1.0, this.div);
		this.horizontalLayout2.setSizeUndefined();
		this.grid.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.horizontalLayout2, this.grid, this.horizontalLayout);
		this.setFlexGrow(1.0, this.grid);
		this.setWidth("350px");
		this.setHeight(null);
		
		this.btnDelete.addClickListener(this::btnDelete_onClick);
		this.btnNew.addClickListener(this::btnNew_onClick);
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.txtName.addInputListener(this::txtName_onInput);
		this.comboBox.addValueChangeListener(this::comboBox_valueChanged);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Binder<OE>         binder;
	private Button             btnDelete, btnNew, btnSave;
	private HorizontalLayout   horizontalLayout2, horizontalLayout;
	private Label              lblType, lblName, lblRegion;
	private Div                div;
	private Grid<OE>           grid;
	private TextField          txtName;
	private ComboBox<OeRegion> comboBox;
	// </generated-code>
	
	
}
