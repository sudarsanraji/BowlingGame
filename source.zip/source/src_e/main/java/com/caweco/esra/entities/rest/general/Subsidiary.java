package com.caweco.esra.entities.rest.general;

import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * CARA v5
 */
public class Subsidiary
{
	private String	name;
	private String	country;
	private String	direct;
	private String	total;
	private String	infoDate;
	@JsonProperty("bvDId")
	private String	bvdId;
	@JsonProperty("lEI")
	private String	lei;
	
	private String	totalAssets;
	private String	operRevenue;
	private String	noOfEmployees;
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(String country)
	{
		this.country = country;
	}
	
	public String getDirect()
	{
		return this.direct;
	}
	
	public void setDirect(String direct)
	{
		this.direct = direct;
	}
	
	public String getTotal()
	{
		return this.total;
	}
	
	public void setTotal(String total)
	{
		this.total = total;
	}
	
	public String getInfoDate()
	{
		return this.infoDate;
	}
	
	public void setInfoDate(String infoDate)
	{
		this.infoDate = infoDate;
	}
	
	public String getBvdId()
	{
		return this.bvdId;
	}
	
	public void setBvdId(String bvdId)
	{
		this.bvdId = bvdId;
	}
	
	public String getLEI()
	{
		return this.lei;
	}
	
	public void setLEI(String LEI)
	{
		this.lei = LEI;
	}
	
	public String getTotalAssets()
	{
		return this.totalAssets;
	}
	
	public void setTotalAssets(String totalAssets)
	{
		this.totalAssets = totalAssets;
	}
	
	public String getOperRevenue()
	{
		return this.operRevenue;
	}
	
	public void setOperRevenue(String operRevenue)
	{
		this.operRevenue = operRevenue;
	}
	
	public String getNoOfEmployees()
	{
		return this.noOfEmployees;
	}
	
	public void setNoOfEmployees(String noOfEmployees)
	{
		this.noOfEmployees = noOfEmployees;
	}
}
