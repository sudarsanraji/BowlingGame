package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.SearchEntryCompanyMetadataDTO;
import com.caweco.esra.dto.SearchEntryGsssMetadataDTO;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.core.SearchEntryGsss;

public class SearchEntryCompanyCreator {

	public static SearchEntryGsssMetadataDTO convertSearchEntryCompanyToDto(SearchEntryGsss object)
	{
		SearchEntryGsssMetadataDTO dto = new SearchEntryGsssMetadataDTO();
		dto.setAppliedThreshold(object.getAppliedThreshold());
		dto.setComment(object.getComment());
		dto.setCreated(object.getCreated());
		dto.setCreatedBy(object.getCreatedBy());
		dto.setId(object.getId().toString());
		dto.setResponse_nameToSearch(object.getResponse_nameToSearch());
		dto.setResponse_numberOfGSSSHitsOrig(object.getResponse_numberOfGSSSHitsOrig());
		dto.setResponse_statusMessage(object.getResponse_statusMessage());
		return dto;
	}

	public static SearchEntryCompanyMetadataDTO convertSearchEntryCompanyToDto(SearchEntryCompany company) {
		SearchEntryCompanyMetadataDTO dto = new SearchEntryCompanyMetadataDTO();
		dto.setComment(company.getComment());
		dto.setCreated(company.getCreated());
		dto.setCreatedBy(company.getCreatedBy());
		dto.setId(company.getId().toString());
		return dto;
	}
}
