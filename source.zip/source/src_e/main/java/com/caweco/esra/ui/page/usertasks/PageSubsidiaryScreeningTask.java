
package com.caweco.esra.ui.page.usertasks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.caweco.esra.entities.rest.general.Subsidiary;
import com.caweco.esra.subsidary.common.SubNode;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningAppliedData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;
import com.caweco.esra.subsidary.frontend.SubsidiaryStateRepresentationHelper;
import com.caweco.esra.ui.page.usertasks.subscr.SubNodeWrapper1;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;


public class PageSubsidiaryScreeningTask extends FlexLayout
{
	SubsidiaryScreeningTaskF task;
	
	public PageSubsidiaryScreeningTask()
	{
		super();
		this.initUI();
	}

	public PageSubsidiaryScreeningTask setTask(SubsidiaryScreeningTaskF task)
	{
		this.task = task;
		
		//// Common infos
		final SubsidiaryInfoBox1 readTask = new SubsidiaryInfoBox1().readTask(task);
		this.objInfo.addComponentAsFirst(readTask);
		
		//// State
		this.lblState2.setText(SubsidiaryStateRepresentationHelper.getRepresentation(task.getState()));
		
		//// ERROR state - additional infos
		if(task.getState() == SubsidiaryScreeningTaskState.DONE_ERROR
			|| task.getState() == SubsidiaryScreeningTaskState.DONE_SKIPPED)
		{
			
			Div divError = new Div();
			divError.add(new Label("Message: "));
			Object object = Optional.ofNullable(task.getRunData()).map(rd -> rd.cancelledNote).orElse(null);
			divError.add(new Label(object != null ? object.toString() : "not available"));
			
			this.objInfo.add(divError);
		}
		
		//// APPLIED state
		if(task.getState() == SubsidiaryScreeningTaskState.APPLIED
			|| task.getState() == SubsidiaryScreeningTaskState.APPLIED_REPLACED)
		{
			//// INFOS
			
			final SubsidiaryInfoBoxApplied applied = new SubsidiaryInfoBoxApplied().readTask(task);
			
			this.objInfo.add(applied);
			this.objInfo.add(new Hr());
			
			//// APPLIED DATA
			
			tabs.setVisible(true);
			this.tabs.setSelectedIndex(0);
		}
		
		
		
		//// Result data
		// (maybe available in DONE_ERROR and DONE_SKIPPED states, MUST be available in state DONE_OK, NOT available in
		//// APPLIED states
		// SubsidiaryScreeningData resultData = task.getResultData();
		
		// List
		
		
		// TreeNodes
		final Optional<SubNode> tree = Optional.ofNullable(task.getResultTree());
		if(tree.isPresent())
		{
			// Tree
			final SubsidiaryTree3 subsidiaryTree = new SubsidiaryTree3();
			subsidiaryTree.setSizeFull();
			this.divTree.add(subsidiaryTree);
			
			subsidiaryTree.asRootNode(() -> task, tree.get());
			
			// List
			List<SubNodeWrapper1> flatNodesAndFilter = flatNodesAndFilter(tree.get());
			this.grid.setItems(flatNodesAndFilter);
		}
		else
		{
			Div div = new Div();
			div.setText("No result tree available.");
			this.divTree.add(div);
		}
		
		// List
		
		
		return this;
	}
	
	private List<SubNodeWrapper1> flatNodesAndFilter(SubNode rootNode)
	{
		Optional<SubsidiaryScreeningAppliedData> taskAppliedData = Optional.ofNullable(task.getAppliedData());
		
		if (taskAppliedData.isEmpty() || taskAppliedData.get().getRedApplied().isEmpty()) 
		{
			return Collections.emptyList();
		}
		
		Set<String> appliedRedIDs = taskAppliedData.get().getRedApplied();
		Map<String, SubNode> subNodesFlatted_onlyOnePerBvdId = getAllChildren(rootNode).stream().collect(Collectors.toMap(it -> it.companyID, it -> it, (a,b)-> a));

		List<SubNodeWrapper1> collect = subNodesFlatted_onlyOnePerBvdId.values().stream()
			.filter(sn -> appliedRedIDs.contains(sn.companyID)) // Is Red & was applied to screening by this task
			.map(SubNodeWrapper1::Wrap).collect(Collectors.toList());
		return collect;
	}
	
	private List<SubNode> getAllChildren(SubNode node)
	{
		if (node.children == null || node.children.isEmpty()) {
			return Collections.emptyList();
		}
		
		List<SubNode> subNodes = new ArrayList<>(node.children);
		node.children.forEach(ch -> {
			subNodes.addAll(getAllChildren(ch));
		});
		return subNodes;
	}
	
	
	/**
	 * Event handler delegate method for the {@link Tabs} {@link #tabs}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void tabs_onSelectedChange(final SelectedChangeEvent event)
	{
		event.getPreviousTab();
		if(event.getSelectedTab() != null)
		{
			boolean first = (event.getSelectedTab() == tabList);
			divList.setVisible(first);
			divTree.setVisible(!first);
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.objInfo     = new FlexLayout();
		this.obInfoState = new FlexLayout();
		this.lblState1   = new Label();
		this.lblState2   = new Label();
		this.divInfo     = new Div();
		this.tabs        = new Tabs();
		this.tabList     = new Tab();
		this.tabTree     = new Tab();
		this.divList     = new Div();
		this.grid        = new Grid<>(SubNodeWrapper1.class, false);
		this.divTree     = new Div();
		
		this.getStyle().set("display", "flex");
		this.getStyle().set("flex-direction", "column");
		this.objInfo.getStyle().set("flex-direction", "column");
		this.objInfo.getStyle().set("row-gap", ".5em");
		this.obInfoState.setClassName("esra-sub-state");
		this.obInfoState.setAlignContent(FlexLayout.ContentAlignment.CENTER);
		this.obInfoState.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
		this.obInfoState.setAlignItems(FlexComponent.Alignment.CENTER);
		this.lblState1.setText("State:");
		this.lblState1.getStyle().set("font-weight", "bold");
		this.lblState2.setText("--");
		this.tabs.setVisible(false);
		this.tabList.setFlexGrow(1.0);
		this.tabList.setLabel("Applied Subsidiary Companies");
		this.tabList.getStyle().set("flex-basis", "0");
		this.tabTree.setFlexGrow(1.0);
		this.tabTree.setLabel("All Subsidiaries");
		this.tabTree.getStyle().set("flex-basis", "0");
		this.divList.setVisible(false);
		this.divList.getStyle().set("flex-basis", "0");
		this.divList.getStyle().set("flex-grow", "1");
		this.divList.getStyle().set("overflow", "hidden auto");
		this.grid.addColumn(SubNodeWrapper1::getCompanyID).setKey("companyID").setHeader("Company ID").setResizable(true)
			.setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.grid
			.addColumn(v -> Optional.ofNullable(v).map(SubNodeWrapper1::getRawSubsidiaryData).map(Subsidiary::getName)
				.orElse(null))
			.setKey("rawSubsidiaryData.name").setHeader("Company Name").setResizable(true).setSortable(true)
			.setAutoWidth(true);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.divTree.setVisible(false);
		this.divTree.getStyle().set("flex-basis", "0");
		this.divTree.getStyle().set("flex-grow", "1");
		this.divTree.getStyle().set("overflow", "hidden auto");
		
		this.lblState1.setSizeUndefined();
		this.lblState2.setSizeUndefined();
		this.obInfoState.add(this.lblState1, this.lblState2);
		this.obInfoState.setSizeUndefined();
		this.objInfo.add(this.obInfoState);
		this.tabs.add(this.tabList, this.tabTree);
		this.grid.setSizeFull();
		this.divList.add(this.grid);
		this.objInfo.setSizeUndefined();
		this.divInfo.setWidthFull();
		this.divInfo.setHeight(null);
		this.tabs.setSizeUndefined();
		this.divList.setWidthFull();
		this.divList.setHeight(null);
		this.divTree.setWidthFull();
		this.divTree.setHeight(null);
		this.add(this.objInfo, this.divInfo, this.tabs, this.divList, this.divTree);
		this.setSizeUndefined();
		
		this.tabs.setSelectedIndex(-1);
		
		this.tabs.addSelectedChangeListener(this::tabs_onSelectedChange);
	} // </generated-code>

	// <generated-code name="variables">
	private FlexLayout            objInfo, obInfoState;
	private Tab                   tabList, tabTree;
	private Label                 lblState1, lblState2;
	private Div                   divInfo, divList, divTree;
	private Tabs                  tabs;
	private Grid<SubNodeWrapper1> grid;
	// </generated-code>
	
}
