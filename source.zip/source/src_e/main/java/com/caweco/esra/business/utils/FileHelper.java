package com.caweco.esra.business.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FileHelper
{
	private static Logger LOG = LoggerFactory.getLogger(FileHelper.class);
	
	// ************************************************************************** //
	
	/**
	 * Read Properties file from resources folder.
	 * 
	 * @param fileName
	 * @return
	 */
	public static Properties loadPropertiesFromResources(String fileName)
	{
		Properties prop = new Properties();
		try(InputStream input =
			FileHelper.class.getClassLoader().getResourceAsStream(fileName))
		{
			prop.load(input);
			return prop;
		}
		catch(IOException e)
		{
			LOG.error("Could not load " + fileName + ".", e);
			return prop;
		}
	}
	
	// ************************************************************************** //
}
