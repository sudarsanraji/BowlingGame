package com.caweco.esra.business.report;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.general.Identification;
import com.caweco.esra.entities.rest.general.Profile;
import com.caweco.esra.entities.rest.namematch.Roles;

public class ReportGsssMatch
{
	public static class Builder
	{
		private Instant created;
		private String name;
		private double hitScore;
		private Map<String, String> aliases = new HashMap<>();
		private String gender;
		private Map<String, String> dateOfBirth = new HashMap<>();
		private Map<String, String> placeOfBirth = new HashMap<>();
		private String deceasedDate;
		private Map<String, String> addresses = new HashMap<>();
		private String citizenshipAndResidency;
		private String factivaEntryID;
		private Map<String, Identification> identification = new HashMap<>();
		private String sanctionsIds;
		private String sanctionsReferences;
		private Map<String, String> categories = new HashMap<>();
		private String sources;
		private Roles pepRoles;
		private Map<String, Profile> linkedProfiles = new HashMap<>();
		private String profileNotes;
		private String rating;
		private String ratingStatement;

		public Builder withName(final String name)
		{
			this.name = name;
			return this;
		}

		public Builder withHitScore(final double hitScore)
		{
			this.hitScore = hitScore;
			return this;
		}

		public Builder withAliases(final Map<String, String> aliases)
		{
			this.aliases = aliases;
			return this;
		}

		public Builder withGender(final String gender)
		{
			this.gender = gender;
			return this;
		}

		public Builder withDateOfBirth(final Map<String, String> dateOfBirth)
		{
			this.dateOfBirth = dateOfBirth;
			return this;
		}

		public Builder withPlaceOfBirth(final Map<String, String> placeOfBirth)
		{
			this.placeOfBirth = placeOfBirth;
			return this;
		}

		public Builder withDeceasedDate(final String deceasedDate)
		{
			this.deceasedDate = deceasedDate;
			return this;
		}

		public Builder withAddresses(final Map<String, String> addresses)
		{
			this.addresses = addresses;
			return this;
		}

		public Builder withCitizenshipAndResidency(final String citizenshipAndResidency)
		{
			this.citizenshipAndResidency = citizenshipAndResidency;
			return this;
		}

		public Builder withFactivaEntryID(final String factivaEntryID)
		{
			this.factivaEntryID = factivaEntryID;
			return this;
		}

		public Builder withIdentification(final Map<String, Identification> identification)
		{
			this.identification = identification;
			return this;
		}

		public Builder withSanctionsIds(final String sanctionsIds)
		{
			this.sanctionsIds = sanctionsIds;
			return this;
		}

		public Builder withSanctionsReferences(final String sanctionsReferences)
		{
			this.sanctionsReferences = sanctionsReferences;
			return this;
		}

		public Builder withCategories(final Map<String, String> categories)
		{
			this.categories = categories;
			return this;
		}

		public Builder withSources(final String sources)
		{
			this.sources = sources;
			return this;
		}

		public Builder withPepRoles(final Roles pepRoles)
		{
			this.pepRoles = pepRoles;
			return this;
		}

		public Builder withLinkedProfiles(final Map<String, Profile> linkedProfiles)
		{
			this.linkedProfiles = linkedProfiles;
			return this;
		}

		public Builder withProfileNotes(final String profileNotes)
		{
			this.profileNotes = profileNotes;
			return this;
		}

		public Builder withRating(final String rating)
		{
			this.rating = rating;
			return this;
		}

		public Builder withRatingStatement(final String ratingStatement)
		{
			this.ratingStatement = ratingStatement;
			return this;
		}

		public Builder withCreated(final Instant created)
		{
			this.created = created;
			return this;
		}

		public ReportGsssMatch build()
		{
			return new ReportGsssMatch(
				this.name,
				this.hitScore,
				this.gender,
				this.deceasedDate,
				this.citizenshipAndResidency,
				this.factivaEntryID,
				this.sanctionsIds,
				this.sanctionsReferences,
				this.sources,
				this.pepRoles,
				this.profileNotes,
				this.rating,
				this.ratingStatement,
				this.created
			);
		}
	}

	private final String name;
	private final double hitScore;
	private final Map<String, String> aliases = new HashMap<>();
	private final String gender;
	private final Map<String, String> dateOfBirth = new HashMap<>();
	private final Map<String, String> placeOfBirth = new HashMap<>();
	private final String deceasedDate;
	private final Map<String, String> addresses = new HashMap<>();
	private final String citizenshipAndResidency;
	private final String factivaEntryID;
	private final Map<String, Identification> identification = new HashMap<>();
	private final String sanctionsIds;
	private final String sanctionsReferences;
	private final Map<String, String> categories = new HashMap<>();
	private final String sources;
	private final Roles pepRoles;
	private final Map<String, Profile> linkedProfiles = new HashMap<>();
	private final String profileNotes;
	private final String rating;
	private final String ratingStatement;
	private final Instant created;

	public static ReportGsssMatch from(final GsssMatch match, final Instant created)
	{
		return from(match, null, created);
	}

	public static ReportGsssMatch from(final GsssMatch match, final MatchData data, final Instant created)
	{
		final Builder builder = new ReportGsssMatch.Builder().withAddresses(match.getAddresses())
			.withAliases(match.getAliases())
			.withCategories(match.getCategories())
			.withCitizenshipAndResidency(match.getCitizenshipAndResidency())
			.withDateOfBirth(match.getDateOfBirth())
			.withDeceasedDate(match.getDeceasedDate())
			.withFactivaEntryID(match.getFactivaEntryID())
			.withGender(match.getGender())
			.withHitScore(match.getHitScore())
			.withIdentification(match.getIdentification())
			.withLinkedProfiles(match.getLinkedProfiles())
			.withName(match.getName())
			.withPepRoles(match.getPepRoles())
			.withPlaceOfBirth(match.getPlaceOfBirth())
			.withProfileNotes(match.getProfileNotes())
			.withSanctionsIds(match.getSanctionsIds())
			.withSanctionsReferences(match.getSanctionsReferences())
			.withSources(match.getSources())
			.withCreated(created);

		if (data != null)
		{
			builder.withRating(data.getRating()).withRatingStatement(data.getRatingStatement());
		}

		return builder.build();
	}

	public ReportGsssMatch(
		final String name,
		final double hitScore,
		final String gender,
		final String deceasedDate,
		final String citizenshipAndResidency,
		final String factivaEntryID,
		final String sanctionsIds,
		final String sanctionsReferences,
		final String sources,
		final Roles pepRoles,
		final String profileNotes,
		final String rating,
		final String ratingStatement,
		final Instant created
	)
	{
		this.name = name;
		this.hitScore = hitScore;
		this.gender = gender;
		this.deceasedDate = deceasedDate;
		this.citizenshipAndResidency = citizenshipAndResidency;
		this.factivaEntryID = factivaEntryID;
		this.sanctionsIds = sanctionsIds;
		this.sanctionsReferences = sanctionsReferences;
		this.sources = sources;
		this.pepRoles = pepRoles;
		this.profileNotes = profileNotes;
		this.rating = rating;
		this.ratingStatement = ratingStatement;
		this.created = created;
	}

	public Instant getCreated()
	{
		return this.created;
	}

	public String getName()
	{
		return this.name;
	}

	public double getHitScore()
	{
		return this.hitScore;
	}

	public double getHitScoreNormalized()
	{
		return Math.round(this.hitScore * 100 / 120);
	}

	public Map<String, String> getAliases()
	{
		return this.aliases;
	}

	public String getGender()
	{
		return this.gender;
	}

	public Map<String, String> getDateOfBirth()
	{
		return this.dateOfBirth;
	}

	public Map<String, String> getPlaceOfBirth()
	{
		return this.placeOfBirth;
	}

	public String getDeceasedDate()
	{
		return this.deceasedDate;
	}

	public Map<String, String> getAddresses()
	{
		return this.addresses;
	}

	public String getCitizenshipAndResidency()
	{
		return this.citizenshipAndResidency;
	}

	public String getFactivaEntryID()
	{
		return this.factivaEntryID;
	}

	public Map<String, Identification> getIdentification()
	{
		return this.identification;
	}

	public String getSanctionsIds()
	{
		return this.sanctionsIds;
	}

	public String getSanctionsReferences()
	{
		return this.sanctionsReferences;
	}

	public Map<String, String> getCategories()
	{
		return this.categories;
	}

	public String getSources()
	{
		return this.sources;
	}

	public Roles getPepRoles()
	{
		return this.pepRoles;
	}

	public Map<String, Profile> getLinkedProfiles()
	{
		return this.linkedProfiles;
	}

	public String getProfileNotes()
	{
		return this.profileNotes;
	}

	public String getRating()
	{
		return this.rating;
	}

	public String getRatingStatement()
	{
		return this.ratingStatement;
	}
}
