package com.caweco.esra.entities.questionnaire;

public enum AnswerType {
	DATE("Date Answer"), 
	DURATION("Duration Answer"),
	FREETEXT("Freetext Answer"),
	MULTI("Multi-option Answer"),
	SINGLE("Single-option Answer");
	
	private String name;
	
	AnswerType(String name)
	{
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
