package com.caweco.esra.ui.admin.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.tuple.Triple;

public class BihServerWrapper
{
	public static BihServerWrapper wrap(Triple<String, String, List<Integer>> in)
	{
		return new BihServerWrapper(in);
	}
	
	String        name;
	String        url;
	List<Integer> ports = new ArrayList<Integer>();
	Triple<String, String, List<Integer>> orig;
	
	public BihServerWrapper(Triple<String, String, List<Integer>> in)
	{
		super();
		this.orig = in;
		this.url = this.orig.getLeft();
		this.name = this.orig.getMiddle();
		this.ports = this.orig.getRight();
	}
	
	public Triple<String, String, List<Integer>> getOrig()
	{
		return this.orig;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getUrl()
	{
		return this.url;
	}
	
	public void setUrl(String url)
	{
		this.url = url;
	}
	
	public List<Integer> getPorts()
	{
		return this.ports;
	}
	
	public void setPorts(List<Integer> ports)
	{
		this.ports = ports;
	}
}
