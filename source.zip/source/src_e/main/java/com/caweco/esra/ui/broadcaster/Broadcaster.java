package com.caweco.esra.ui.broadcaster;

import java.util.LinkedList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.BiConsumer;

import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.vaadin.flow.shared.Registration;


public class Broadcaster {
	static Executor executor = Executors.newSingleThreadExecutor();
	
	static LinkedList<BiConsumer<Message, MessageGroup>> listeners = new LinkedList<>();
	
	public static synchronized Registration register(
		final BiConsumer<Message, MessageGroup> listener)
	{
		Broadcaster.listeners.add(listener);
		
		return () -> {
			synchronized(Broadcaster.class)
			{
				Broadcaster.listeners.remove(listener);
			}
		};
	}
	
	public static synchronized void broadcast(final Message message, final MessageGroup group)
	{
		for(final BiConsumer<Message, MessageGroup> listener : Broadcaster.listeners)
		{
			Broadcaster.executor.execute(() -> listener.accept(message, group));
		}
	}
}
