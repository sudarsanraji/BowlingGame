package com.caweco.esra.entities.questionnaire;

public class DurationChooserQuestion extends Question
{
	
	public DurationChooserQuestion()
	{
		super();
	}
	
	public DurationChooserQuestion(
		final String questionText,
		final String helperText,
		final Boolean active,
		final Boolean standard)
	{
		super(questionText, helperText, active, standard);
	}
	

	public DurationChooserQuestion copyNoRules()
	{
		final var copy = new DurationChooserQuestion();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		return copy;
	}
}
