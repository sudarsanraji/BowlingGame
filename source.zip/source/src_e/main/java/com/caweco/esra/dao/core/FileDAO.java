package com.caweco.esra.dao.core;

import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElementPendingDTO;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

public class FileDAO {

	public static List<BinaryElement> getPendingFiles(Screening screening) {
		return screening.getFiles(true).stream().filter(file -> file instanceof BinaryElementPendingDTO).collect(Collectors.toList());
	}
	
	public static InputStream allowFileDownload(String clientUuid, String screeningUuid, String fileUuid)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + clientUuid + "/screening/" + screeningUuid + "/files/" + fileUuid);
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response);
		
		return response.readEntity(InputStream.class);
	}

}
