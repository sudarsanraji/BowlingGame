package com.caweco.esra.entities.rest.namematch;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class Roles
{
	private String				primaryOccupation;
	private Map<String, String>	otherRoles		= new HashMap<>();
	private Map<String, String>	previousRoles	= new HashMap<>();
	
	public Roles()
	{
		// empty Constructor for Framework
	}
	
	public String getPrimaryOccupation()
	{
		return this.primaryOccupation;
	}
	
	public void setPrimaryOccupation(final String primaryOccupation)
	{
		this.primaryOccupation = primaryOccupation;
	}
	
	public Map<String, String> getOtherRoles()
	{
		return this.otherRoles;
	}
	
	public void setOtherRoles(final Map<String, String> otherRoles)
	{
		this.otherRoles = otherRoles;
	}
	
	public Map<String, String> getPreviousRoles()
	{
		return this.previousRoles;
	}
	
	public void setPreviousRoles(final Map<String, String> previousRoles)
	{
		this.previousRoles = previousRoles;
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.otherRoles, this.previousRoles, this.primaryOccupation);
	}

	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(this.getClass() != obj.getClass())
		{
			return false;
		}
		final Roles other = (Roles)obj;
		return Objects.equals(this.otherRoles, other.otherRoles)
			&& Objects.equals(this.previousRoles, other.previousRoles)
			&& Objects.equals(this.primaryOccupation, other.primaryOccupation);
	}
	
	
}
