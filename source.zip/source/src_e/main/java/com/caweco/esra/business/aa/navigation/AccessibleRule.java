package com.caweco.esra.business.aa.navigation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import com.caweco.esra.business.aa.AuthorizationResources;


@Retention(RUNTIME)
@Target(TYPE)
public @interface AccessibleRule
{
	public AuthorizationResources[] value() default {};
	
	public boolean appAdmin() default false;
}
