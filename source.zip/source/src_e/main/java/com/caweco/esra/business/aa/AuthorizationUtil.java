package com.caweco.esra.business.aa;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.User;
import com.rapidclipse.framework.security.authorization.Subject;


public class AuthorizationUtil
{
	/**
	 * True if {@link CurrentUtil#getUser()} is available and user is appAdmin, false otherwise.
	 * 
	 * @return
	 */
	public static boolean isAppAdmin()
	{
		User user = CurrentUtil.getUser();
		return user != null ? user.isAppAdmin() : false;
	}
	
	/**
	 * True if {@link CurrentUtil#getSubject()} is available and has {@link AuthorizationResources#ESUACCESS}, false
	 * otherwise.
	 * 
	 * @return
	 */
	public static boolean isEsuUser()
	{
		Subject user = CurrentUtil.getSubject();
		return user != null ? user.hasPermission(AuthorizationResources.ESUACCESS.resource()) : false;
	}
	
}
