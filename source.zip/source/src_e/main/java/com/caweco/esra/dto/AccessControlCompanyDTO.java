package com.caweco.esra.dto;

import java.util.Set;

import com.caweco.esra.entities.ldap.LdapOrg;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AccessControlCompanyDTO {
	
	@JsonProperty("allowedDepartments")
	private Set<LdapOrg> allowedDepartments;
	
	@JsonProperty("displayName")
	private String displayName;
	
	@JsonProperty("cnId")
	private String cnId;
	
	@JsonProperty("distinguishedName")
	private String distinguishedName;
	
	@JsonProperty("representation")
	private String representation;
	
	public Set<LdapOrg> getAllowedDepartments() {
		return allowedDepartments;
	}
	public void setAllowedDepartments(Set<LdapOrg> allowedDepartments) {
		this.allowedDepartments = allowedDepartments;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getCnId() {
		return cnId;
	}
	public void setCnId(String cnId) {
		this.cnId = cnId;
	}
	public String getDistinguishedName() {
		return distinguishedName;
	}
	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}
	public String getRepresentation() {
		return representation;
	}
	public void setRepresentation(String representation) {
		this.representation = representation;
	}
	
	
}
