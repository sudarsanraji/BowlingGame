package com.caweco.esra.dto;

import java.time.Instant;
import java.util.List;

public class QuestionnaireResultDTO {
	private Integer resultID;
	private Integer questionnaireID;
	private Integer year;
	private List<QuestionResultDTO> results;
	private Instant finishedDate;
	
	
	public Integer getResultID() {
		return resultID;
	}
	public void setResultID(Integer resultID) {
		this.resultID = resultID;
	}
	public Integer getQuestionnaireID() {
		return questionnaireID;
	}
	public void setQuestionnaireID(Integer questionnaireID) {
		this.questionnaireID = questionnaireID;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public List<QuestionResultDTO> getResults() {
		return results;
	}
	public void setResults(List<QuestionResultDTO> results) {
		this.results = results;
	}
	public Instant getFinishedDate() {
		return finishedDate;
	}
	public void setFinishedDate(Instant finishedDate) {
		this.finishedDate = finishedDate;
	}
	
	
}
