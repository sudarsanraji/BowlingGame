
package com.caweco.esra.entities;

import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.rapidclipse.framework.server.resources.Caption;
import com.rapidclipse.framework.server.security.authorization.AuthorizationResource;
import com.rapidclipse.framework.server.security.authorization.AuthorizationRole;


public class Role implements AuthorizationRole
{
	
	private UUID						id;
	private String						name;
	private String						description;
	private Set<Role>					parentRoles	= new HashSet<>();
	private Set<Role>					childRoles	= new HashSet<>();
	private Set<AuthorizationResources>	resources	= new HashSet<>();
	
	public Role()
	{
		super();
	}
	
	@Caption("Role")
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	@Caption("Description")
	public String getDescription()
	{
		return this.description;
	}
	
	public void setDescription(final String description)
	{
		this.description = description;
	}
	
	@Caption("Permissions")
	public Set<AuthorizationResources> getResources()
	{
		return new HashSet<>(this.resources);
	}

	public void addResource(AuthorizationResources resource)
	{
		if (resource != null)
		{
			this.resources.add(resource);
		}
	}

	public void removeResource(AuthorizationResources resource)
	{
		this.resources.remove(resource);
	}

	public boolean hasResource(AuthorizationResources resource)
	{
		return this.resources.contains(resource);
	}
	
	public void setResources(final Set<AuthorizationResources> resources)
	{
		this.resources = resources;
	}
	
	@Caption("ChildRoles")
	public Set<Role> getChildRoles()
	{
		if(this.childRoles == null)
		{
			this.childRoles = new HashSet<>();
		}
		return this.childRoles;
	}
	
	public void setChildRoles(final Set<Role> childRoles)
	{
		this.childRoles = childRoles;
	}
	
	@Caption("ParentRoles")
	public Set<Role> getParentRoles()
	{
		if(this.parentRoles == null)
		{
			this.parentRoles = new HashSet<>();
		}
		return this.parentRoles;
	}
	
	public void setParentRoles(final Set<Role> parentRoles)
	{
		this.parentRoles = parentRoles;
	}
	
	@Override
	public String roleName()
	{
		return this.getName();
	}
	
	@Override
	public Collection<? extends AuthorizationResource> resources()
	{
		return this.getResources();
	}
	
	@Override
	public Collection<? extends AuthorizationRole> roles()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Role other = (Role) obj;
		return Objects.equals(id, other.id);
	}
	
	
	
	
}
