package com.caweco.esra.dao.core;

import java.util.Set;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.LineOfBusiness;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;


public class LobDAO
{
	public static String TEMPLATE_ALL = "/client/{clientUuid}/lob";
	

	public static Set<LineOfBusiness> getLineOfBusinesses(Client client)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_ALL)
			.resolveTemplate("clientUuid", client.getUuid().toString());
		
		return webTarget.request().get(new GenericType<Set<LineOfBusiness>>(){});
	}
}
