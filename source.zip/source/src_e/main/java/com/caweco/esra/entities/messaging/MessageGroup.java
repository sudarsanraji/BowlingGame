package com.caweco.esra.entities.messaging;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import com.caweco.esra.dao.messaging.MessageDAO;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.rapidclipse.framework.server.resources.Caption;


@Caption("{%name}")
public class MessageGroup
{
	private UUID id = UUID.randomUUID();
	private Instant created = Instant.now();
	private String createdBy;
	
	private String name = "MessageGroup";
	
	private Optional<Map<User, Boolean>> members = Optional.empty();
	private Optional<List<User>> admins = Optional.empty();
	
	private boolean isActive;
	private Map<String, Instant> invitations = new HashMap<>();
	private Optional<List<Message>> messages = Optional.empty();
	
	private Screening parent;
	
	public MessageGroup()
	{
	}
	
	public MessageGroup(final User currentUser)
	{
		this.createdBy = currentUser.getEmailAddress();
		
		Map<User, Boolean> userMap = new HashMap<>();
		userMap.put(currentUser, true);
		
		List<User> adminList = new ArrayList<>();
		adminList.add(currentUser);
		
		this.members = Optional.of(userMap);
		this.admins = Optional.of(adminList);
	}
	
	public MessageGroup(final User currentUser, final String groupName)
	{
		this(currentUser);
		this.name = groupName;
		this.messages = Optional.of(new ArrayList<>());
	}
	
	public UUID getId()
	{
		return this.id;
	}
	
	public void setId(final UUID id)
	{
		this.id = id;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public void setCreated(final Instant created)
	{
		this.created = created;
	}
	
	public boolean isActive()
	{
		return this.isActive;
	}
	
	public void setActive(final boolean isActive)
	{
		this.isActive = isActive;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public List<User> getAdmins(boolean forceUpdate)
	{
		if(this.admins.isPresent() && !forceUpdate)
		{
			return this.admins.get();
		}
		else
		{
			Optional<List<User>> serverResult = MessageGroupDAO.getGroupAdmins(this);
			
			if(serverResult.isPresent())
			{
				this.admins = serverResult;
			}
			return this.admins.get();
		}
	}
	
	public void setAdmins(final List<User> admins)
	{
		this.admins = Optional.of(admins);
	}
	
	public Map<User, Boolean> getMembers(boolean forceUpdate)
	{
		if(this.members.isPresent() && !forceUpdate)
		{
			return this.members.get();
		}
		else
		{
			Optional<Map<User, Boolean>> serverResult = MessageGroupDAO.getGroupMembers(this);
			
			if(serverResult.isPresent())
			{
				this.members = serverResult;
			}
			return this.members.get();
		}
	}
	
	public void setMembers(final Map<User, Boolean> members)
	{
		this.members = Optional.of(members);
		
	}
	
	public Map<String, Instant> getInvitations()
	{
		return this.invitations;
	}
	
	public void setInvitations(final Map<String, Instant> invitations)
	{
		this.invitations = invitations;
	}
	
	public Set<User> getFollower()
	{
		if(members.isPresent())
		{
			return this.members.get().entrySet().stream().filter(e -> BooleanUtils.isTrue(e.getValue())).map(
					e -> e.getKey()).collect(Collectors.toSet());
		}
		else
		{
			return new HashSet<>();
		}
		

	}

	public Screening getParent() {
		return parent;
	}

	public void setParent(Screening parent) {
		this.parent = parent;
	}

	public List<Message> getMessages(boolean forceUpdate) {
		if(this.messages.isPresent() && !forceUpdate)
		{
			return this.messages.get();
		}
		else
		{
			Optional<List<Message>> serverResult = MessageDAO.getGroupMessages(this);
			
			if(serverResult.isPresent())
			{

				this.messages = serverResult;
				return this.messages.get();
			}
			
			return new ArrayList<>();
		}
	}

	public void setMessages(List<Message> messages) {
		this.messages = Optional.of(messages);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MessageGroup other = (MessageGroup) obj;
		return Objects.equals(id, other.id);
	}
	
	
	
	
}
