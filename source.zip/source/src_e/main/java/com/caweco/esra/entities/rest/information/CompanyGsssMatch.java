package com.caweco.esra.entities.rest.information;

import java.util.ArrayList;
import java.util.List;

import com.caweco.esra.entities.rest.general.GsssMatch;


public class CompanyGsssMatch
{
	private String			nameToSearch;
	private String			statusMessage;
	private String			numberOfHits;
	private List<GsssMatch>	gsssMatchResults	= new ArrayList<>();
	
	public CompanyGsssMatch()
	{
		// Empty Constructor for Framework
	}
	
	public CompanyGsssMatch(String nameToSearch)
	{
		this.nameToSearch = nameToSearch;
	}
	
	public String getNameToSearch()
	{
		return this.nameToSearch;
	}
	
	public void setNameToSearch(final String nameToSearch)
	{
		this.nameToSearch = nameToSearch;
	}
	
	public String getStatusMessage()
	{
		return this.statusMessage;
	}
	
	public void setStatusMessage(final String statusMessage)
	{
		this.statusMessage = statusMessage;
	}
	
	public String getNumberOfHits()
	{
		return this.numberOfHits;
	}
	
	public void setNumberOfHits(final String numberOfHits)
	{
		this.numberOfHits = numberOfHits;
	}
	
	public List<GsssMatch> getGsssMatchResults()
	{
		if (this.gsssMatchResults == null) {
			this.gsssMatchResults = new ArrayList<>();
		}
		return new ArrayList<>(this.gsssMatchResults);
	}
	
	public void setGsssMatchResults(final List<GsssMatch> gsssMatchResults)
	{
		this.gsssMatchResults = gsssMatchResults;
	}

	@Override
	public String toString() {
		return "CompanyGsssMatch [nameToSearch=" + nameToSearch + ", statusMessage=" + statusMessage + ", numberOfHits="
				+ numberOfHits + ", gsssMatchResults=" + gsssMatchResults + "]";
	}
	
	
	
}
