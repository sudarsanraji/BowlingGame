package com.caweco.esra.entities.config;

public class EsraClientConfiguration
{
	private String clientRepresentation;
	private ConfigRestEndpoint configRestCara = ConfigRestEndpoint.getConfigBIH();

	private ConfigRestEndpoint configRestSeaWeb = ConfigRestEndpoint.getConfigSEAWEB();
	private ConfigMailServer configMailServer = new ConfigMailServer();

	// TODO: repair typo
	private int tresholdGsssResultScore = 80;
	private int esraMonitoringPeriodDefaultDays = 365;
	private int esraScreeningRetentionPeriodDays = 3650;
	private int esraScreeningArchivalPeriodDays = 540;
	private int esraScreeningReminderPeriodDays = 30;
	private int esraScreeningRecurringReminderPeriodDays = 7;

	private int esuAutosavePeriodMinutes = 5;

	private String supportEmail = "not set";
	
	public String getClientRepresentation()
	{
		return this.clientRepresentation;
	}
	
	public void setClientRepresentation(final String clientRepresentation)
	{
		this.clientRepresentation = clientRepresentation;
	}
	
	public ConfigRestEndpoint getConfigRestCara()
	{
		return this.configRestCara;
	}
	
	public void setConfigRestCara(final ConfigRestEndpoint configRestCara)
	{
		this.configRestCara = configRestCara;
	}
	
	public ConfigRestEndpoint getConfigRestSeaWeb()
	{
		return this.configRestSeaWeb;
	}
	
	public void setConfigRestSeaWeb(final ConfigRestEndpoint configRestSeaWeb)
	{
		this.configRestSeaWeb = configRestSeaWeb;
	}
	
	public ConfigMailServer getConfigMailServer()
	{
		return this.configMailServer;
	}
	
	public void setConfigMailServer(final ConfigMailServer configMailServer)
	{
		this.configMailServer = configMailServer;
	}
	
	public Integer getThresholdGsssResultScore()
	{
		return this.tresholdGsssResultScore;
	}
	
	public void setThresholdGsssResultScore(final Integer thresholdGsssResultScore)
	{
		this.tresholdGsssResultScore = thresholdGsssResultScore;
	}
	
	public Integer getEsraMonitoringPeriodDefaultDays()
	{
		return this.esraMonitoringPeriodDefaultDays;
	}
	
	public void setEsraMonitoringPeriodDefaultDays(final Integer esraMonitoringPeriodDefaultDays)
	{
		this.esraMonitoringPeriodDefaultDays = esraMonitoringPeriodDefaultDays;
	}

	public int getEsraScreeningRetentionPeriodDays()
	{
		return this.esraScreeningRetentionPeriodDays;
	}

	public void setEsraScreeningRetentionPeriodDays(final int esraScreeningRetentionPeriodDays)
	{
		this.esraScreeningRetentionPeriodDays = esraScreeningRetentionPeriodDays;
	}

	public String getSupportEmail() {
		return this.supportEmail;
	}

	public void setSupportEmail(final String supportEmail) {
		this.supportEmail = supportEmail;
	}

	public int getEsraScreeningArchivalPeriodDays() {
		return this.esraScreeningArchivalPeriodDays;
	}

	public void setEsraScreeningArchivalPeriodDays(final int esraScreeningArchivalPeriodDays) {
		this.esraScreeningArchivalPeriodDays = esraScreeningArchivalPeriodDays;
	}

	public int getEsuAutosavePeriodMinutes()
	{
		return this.esuAutosavePeriodMinutes;
	}

	public void setEsuAutosavePeriodMinutes(final int esuAutosavePeriodMinutes)
	{
		this.esuAutosavePeriodMinutes = esuAutosavePeriodMinutes;
	}
	
	public int getEsraScreeningReminderPeriodDays()
	{
		return this.esraScreeningReminderPeriodDays;
	}

	public void setEsraScreeningReminderPeriodDays(final int esraScreeningReminderPeriodDays)
	{
		this.esraScreeningReminderPeriodDays = esraScreeningReminderPeriodDays;
	}
	
	public int getEsraScreeningRecurringReminderPeriodDays() {
		return esraScreeningRecurringReminderPeriodDays;
	}

	public void setEsraScreeningRecurringReminderPeriodDays(final int esraScreeningRecurringReminderPeriodDays) {
		this.esraScreeningRecurringReminderPeriodDays = esraScreeningRecurringReminderPeriodDays;
	}	
	
}
