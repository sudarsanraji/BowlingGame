package com.caweco.esra.entities.rest.general;

import java.util.ArrayList;

public class IntermediaryTreeModel extends Intermediary
{
	private ArrayList<IntermediaryTreeModel> intermediary = new ArrayList<IntermediaryTreeModel>();
	
	public IntermediaryTreeModel(Intermediary intermediary)
	{
		super();
		this.setAddress(intermediary.getAddress());
		this.setBvdId(intermediary.getBvdId());
		this.setName(intermediary.getName());
		this.setDirectPercentage(intermediary.getDirectPercentage());
		this.setTotalPercentage(intermediary.getTotalPercentage());
		this.setCountry(intermediary.getCountry());
	}
	
	public ArrayList<IntermediaryTreeModel> getIntermediary()
	{
		return this.intermediary;
	}
	
	public void setIntermediary(ArrayList<IntermediaryTreeModel> intermediary)
	{
		this.intermediary = intermediary;
	}
	
}