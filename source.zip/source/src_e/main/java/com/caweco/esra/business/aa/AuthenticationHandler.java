
package com.caweco.esra.business.aa;

import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.rest.ObjectMapperProvider;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.ldap.LdapClientGids;
import com.caweco.esra.business.ldap.LdapUtils;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.dao.access.AccessControlRuleDAO;
import com.caweco.esra.dao.access.ClientAssignmentRuleDAO;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.access.AccessControlRuleLdap;
import com.caweco.esra.entities.ldap.LdapAttributes;
import com.caweco.esra.entities.saml.SamlAttributes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.onelogin.saml2.http.HttpRequest;
import com.onelogin.saml2.servlet.ServletUtils;
import com.onelogin.saml2.settings.Saml2Settings;
import com.rapidclipse.framework.security.authorization.Subject;
import com.vaadin.flow.server.SynchronizedRequestHandler;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


/**
 * RequestHandler which handles SAML authentication response requests.
 * <p>
 * (Second part of a SAML authentication process. For first part, see {@link AuthenticationInitializer}.)
 * </p>
 */
public class AuthenticationHandler extends SynchronizedRequestHandler
{
	private static final long   serialVersionUID = 1L;
	private static final Logger LOG              = LoggerFactory.getLogger(AuthenticationHandler.class);
	private static ObjectMapper om = new ObjectMapper().registerModule(new JavaTimeModule());
	
	/* ************************************************************************** */
	
	
	@Override
	public boolean synchronizedHandleRequest(
		final VaadinSession session,
		final VaadinRequest request,
		final VaadinResponse response)
		throws IOException
	{
		
		final HttpServletRequest request1 = (HttpServletRequest) request;
		final HttpServletResponse response1 = (HttpServletResponse) response;
		
		final HttpRequest httpRequest = ServletUtils.makeHttpRequest(request1);
		final String samlResponseParameter = httpRequest.getParameter("SAMLResponse");
		
		AuthenticationHandler.LOG.debug("### AuthRequestHandler");
		
		// Is the Request an SAML Response?
		if (samlResponseParameter == null)
		{
			AuthenticationHandler.LOG.debug("# Skip here: Not for me. (No SAML Response)");
			
			// not for me, return
			// ["false" to proceed other handlers]
			return false;
		}
		
		AuthenticationHandler.LOG.info("### Processing SAML response ...");
		AuthenticationHandler.LOG.debug(samlResponseParameter);
		
		try
		{
			final Object samlRequestID = session.getAttribute("lastSamlRequestId");
			// Invalidate requestId
			session.setAttribute("lastSamlRequestId", UUID.randomUUID().toString());
			
			final Saml2Settings saml2Settings = ApplicationPropertyProvider.getSaml2Settings(null);
			final AuthExt auth = new AuthExt(saml2Settings, request1);
			
			auth.processResponse((String) samlRequestID, ApplicationPropertyProvider.isWithHttps());
			
			final boolean authenticated = auth.isAuthenticated();
			
			AuthenticationHandler.LOG.info(authenticated ? " ... authenticated" : " ... not authenticated");
			
			if (authenticated)
			{

				/**  *******************************
				 * Is Authenticated: Do Login
				 */
				
				
				/** *******************************
				 * Log errors first
				 * Continue even if there is an error at logging them.
				 */
				try {
					final List<String> errors = auth.getErrors();
					if (!errors.isEmpty())
					{
						AuthenticationHandler.LOG.warn("  " + StringUtils.join(errors, ", "));
						
						if (auth.isDebugActive())
						{
							final String errorReason = auth.getErrorReason();
							if (errorReason != null && !errorReason.isEmpty())
							{
								AuthenticationHandler.LOG.error("  " + auth.getErrorReason());
							}
						}
					}
				}
				catch (Exception e)
				{
					AuthenticationHandler.LOG.warn("Authenticator states that there are errors, but cannot print them out.");
				}
				
				
				/** *******************************
				 * Handle DEV Login
				 */
				if (ApplicationPropertyProvider.getAuthenticationEndpoint().equals("auth0")) {
					
					return handleDevLogin(auth, session, request, response1);
				}
				
				
				/** *******************************
				 * Handle Allianz (default) Login
				 */
				
				SamlAttributes attributesFromSAML = new SamlAttributes(auth.getAttributes());

				
				final String email = auth.getNameId();
				
				if (StringUtils.isNotBlank(email))
				{
					
					//// There is a email, so proceed:
					
					
					//// REINIT SESSION
					
					
					VaadinService.reinitializeSession(request);
					AuthenticationHandler.LOG.info(" ... change sessionID ...");
					
					
					//// SEARCH FOR USER
					
					
					final Optional<User> userO = UserDAO.find(email);
					
					
					//// GET LDAP DATA
					
					
					LdapAttributes attributes = new LdapAttributes(attributesFromSAML);
					
					LdapClientGids ldapClient = null;
					
					try
					{
						AuthenticationHandler.LOG.info(" ..# Get LDAP data ...");
						
						ldapClient = LdapUtils.getLdapClient();
						
						AuthenticationHandler.LOG.debug(" ... LDAP client ...");
						
						Optional<Map<String, String>> attributesFromLDAP = ldapClient.getUserInfos(email);
						
						AuthenticationHandler.LOG.debug(" ... fetched LDAP data ...");
						
						if (attributesFromLDAP.isPresent())
						{
							attributes.setLdapAttributes(attributesFromLDAP.get());
							
							AuthenticationHandler.LOG.info(" ... got user infos from LDAP ...");
						}
						else
						{
							AuthenticationHandler.LOG.warn("Got no user infos from LDAP!");
						}
						
						AuthenticationHandler.LOG.info(" ... LDAP done.");
					}
					catch (NamingException e)
					{
						AuthenticationHandler.LOG
							.error(" ! LDAP error: User exists, but it is not possible to get infos from LDAP", e);
//						response1.sendRedirect("dataconnectionerror");
//						return true;
					}
					catch (Exception e)
					{
						AuthenticationHandler.LOG
							.error(" ! LDAP error: User exists, but it is not possible to get infos from LDAP", e);
//						response1.sendRedirect("dataconnectionerror");
//						return true;
					}
					finally
					{
						if (ldapClient != null)
						{
							ldapClient.getCtx().close();
							AuthenticationHandler.LOG.info(" ... LDAP client closed.");
						}
					}
					
					
					//// Handle User and access of user to app/to client(s)
					
					boolean hasAccessByRule = AccessControlRuleDAO.hasAppAccessByLdapRule(attributes);
					
					if (userO.isPresent())
					{
						/*
						 *  Handle existing user
						 */
						
						AuthenticationHandler.LOG.info(" ..# Handle existing User...");
						
						User user = userO.get();
						user.setLastSamlAttributes(attributes);

						updateLdapAttributes(user.getEmailAddress(), attributes);
						
						
						
						AuthenticationHandler.LOG.info(" ... User data updated ...");
						
						ClientAssignmentRuleDAO.updateAutoAssignment(user, attributes, hasAccessByRule);
						makeUserAdmin(user);
						
						AuthenticationHandler.LOG.info(" ... updated User according to SAML/LDAP/config data ...");
						
						// User NEEDs at least one Client:
						
						if (!ClientDAO.findByUser(user).isEmpty() && user.getRoles(true).size() != 0 || user.isAppAdmin())
						{
							handleAttributesAndUpdateUser(session, user, attributes);
							logIn(session, user);
							
							AuthenticationHandler.LOG.info(
								"Done. User {} logged in. Changed SessionId and added user to session.",
								user.getEmailAddress());
							
							//// -> Continue below with "printSamlResponseAttributes"
							
						}
						else if (user.getRoles(true).size() == 0)
						{
							AuthenticationHandler.LOG.warn(
								"Done. User {} exists, is assigned to a client but has no roles and will be denied as a result",
								email);
							
							response1.sendRedirect("unauthorized");
							return true;
						}
						else
						{
							
							AuthenticationHandler.LOG.warn(
								"Done. User {} exists, but is neither assigned to a client nor a app admin",
								email);
							
							response1.sendRedirect("unauthorized");
							return true;
						}
					}
					
					
					else if (hasAccessByRule || isPredefindedAdmin(email))
					{
						/*
						 *  Handle unknown/new User with access by rule and/or is member "predefined admin"s
						 */
						
						AuthenticationHandler.LOG.info(" ..# Handle unknown User...");
						
						User user = UserDAO.getOrCreate(email);
						user.setLastSamlAttributes(attributes);
						this.updateLdapAttributes(user.getEmailAddress(), attributes);
						
						AuthenticationHandler.LOG.info(" ... User initialized ...");
						
						ClientAssignmentRuleDAO.updateAutoAssignment(user, attributes, hasAccessByRule);
						makeUserAdmin(user);
						
						AuthenticationHandler.LOG.info(" ... updated User according to SAML/LDAP/config data ...");
						
						if (!ClientDAO.findByUser(user).isEmpty() && user.getRoles(true).size() != 0 || user.isAppAdmin())
						{
							handleAttributesAndUpdateUser(session, user, attributes);
							logIn(session, user);
							
							AuthenticationHandler.LOG.info(
								"Done. New User {} logged in. Changed SessionId and added user to session.",
								user.getEmailAddress());
							
						//// -> Continue below with "printSamlResponseAttributes"
							
						}
						else if (user.getRoles(true).size() == 0)
						{
							AuthenticationHandler.LOG.warn(
								"Done. User {} exists, is assigned to a client but has no roles and will be denied as a result",
								email);
							
							response1.sendRedirect("unauthorized");
							return true;
						}
						else
						{
							AuthenticationHandler.LOG.warn(
								"Done. User {} exists, but is neither assigned to a client nor a app admin",
								email);
							
							response1.sendRedirect("unauthorized");
							return true;
						}
					}
					
					
					
					else
					{
						/*
						 * Handle unknown User with neither access by rule nor member of "predefined admin"s
						 */
						
						AuthenticationHandler.LOG.warn("Unauthorized! User {} does not have application access.", email);
						
						response1.sendRedirect("unauthorized");
						return true;
					}
					
					
					//// Continue after successful login
					
					// Hint: Errors at printing attributes must not change authentication result, which is here "OK"
					
					printSamlResponseAttributes(attributes, request);

					
					//// Handle direct links.
					
					// Hint: Errors at handling direct links must not change authentication result, which is here "OK"
					// See also "AuthenticationInitializer.authenticate(session, request1, response1);"

					try {
						Optional<String> fromSession = CurrentUtil.fromSession(session, "lastRequestURI");
						
						if (fromSession.isPresent())
						{
							AuthenticationHandler.LOG.debug("####### SEND REDIRECT TO \"{}\".", fromSession.get());
							
							CurrentUtil.toSession(session, "lastRequestURI", null);
							
							response1.sendRedirect(fromSession.get());
							return true;
						}
					}
					catch (Exception e)
					{
						AuthenticationHandler.LOG.warn("Error redirectioning to direct link", e);
					}
					
					
					//// User logged in. Proceed with other handler by returning "false"
					
					return false;

				}
				else
				{
					/*
					 * Email is null or empty
					 */
					AuthenticationHandler.LOG.warn("Unauthorized! User is authenticated, but no Email address was found.");
					
					session.setAttribute(Subject.class, null);
					session.setAttribute(User.class, null);
					
					response1.sendRedirect("loginfailed");
					return true;
				}
				
			}
			else
			{
				/*
				 * SAML states that User is NOT authenticated.
				 */
				AuthenticationHandler.LOG.info("Unauthenticated! Got a SAML response, but user is not authenticated");
				
				session.setAttribute(Subject.class, null);
				session.setAttribute(User.class, null);
				
				response1.sendRedirect("loginfailed");
				return true;
			}
		}
		catch (final Exception e)
		{

			AuthenticationHandler.LOG.error("Error at login process.", e);
			
			session.setAttribute(Subject.class, null);
			session.setAttribute(User.class, null);
			
			response1.sendRedirect("loginfailed");
			return true;
		}
	}
	

	/* ************************************************************************** */


	private void updateLdapAttributes(String emailAddress, LdapAttributes attributes) {
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/user/" + emailAddress + "/ldapAttributes");
		
		Response response = webTarget.request().post(Entity.entity(attributes, MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(response.toString());
	}

	
	/* ************************************************************************** */
	
	public static void handleAttributesAndUpdateUser(
		VaadinSession session,
		User user,
		SamlAttributes attributes)
	{
		handleAttributes(user, attributes);
		
		// isPredefindedAdmin(user);
		
		handleLastVisitInfos(session, user);
	}
	
	/* ************************************************************************** */
	
	public static void logIn(VaadinSession session, User user)
	{
		//// SET USER TO SESSION
		
		session.setAttribute(User.class, user);
		
		//// SET CLIENT
		
		// TODO
		
		//// UPDATE AUTHORIZATION
		
		Authorizer.updatePermissions(session, user);
	}
	
	/* ************************************************************************** */
	
	/**
	 * Checks if a user is in the Admin list. {@link ApplicationPropertyProvider#getAdmins()}. <br />
	 * Sets user's the marker flag ( {@link User#isAppAdmin()} ) if user is in the list, but not already marked.
	 * 
	 * @param user
	 */
	public static void makeUserAdmin(final User user)
	{
		final List<String> admins = ApplicationPropertyProvider.getAdmins();
		
		final Optional<String> isAppAdmin = admins.stream().filter(Objects::nonNull).filter(
			entry -> entry.equalsIgnoreCase(user.getEmailAddress())).findFirst();
		
		if (isAppAdmin.isPresent())
		{
			if (null!=user && !user.isAppAdmin())
			{
				user.setAppAdmin(true);
				
				RestClientESRADB client = RestUtil.getRestClient_ESRADB();
				WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldaprules");
				
				UserCreator.convertUserToMetadataDTO(user);
				
				Response response = webTarget.request().get();
				String responseBody = response.readEntity(String.class);
				
				JavaType type = om.getTypeFactory().constructCollectionType(Set.class, AccessControlRuleLdap.class);
				
				try {
					om.readValue(responseBody, type);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				AuthenticationHandler.LOG.debug("User {} is predefined admin. Permissions set.", user.toString());			}
		}
	}
	
	public static boolean isPredefindedAdmin(final String email)
	{
		final List<String> admins = ApplicationPropertyProvider.getAdmins();
		
		final Optional<String> isAppAdmin = admins.stream().filter(Objects::nonNull).filter(
			entry -> entry.equalsIgnoreCase(email)).findFirst();
		
		return isAppAdmin.isPresent();
	}
	
	/**
	 * - Updates "lastVisit" date and <br />
	 * - sets last visited client as current client (if available)
	 * 
	 * @param session
	 * @param user
	 */
	public static void handleLastVisitInfos(VaadinSession session, User user)
	{
		if(null!=user) {
		final Instant oldCurrentLogin = user.getCurrentLogin();
		user.setCurrentLogin(Instant.now());
		user.setLastLogin(oldCurrentLogin);
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
		
		UserMetadataDTO dto = UserCreator.convertUserToMetadataDTO(user);
		Response response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
		org.tinylog.Logger.tag("REST").info(response.toString());
		
		LOG.debug("User {} - Updated \"LastLogin value\"", user.toString());
		
		UUID lastVisitedClientId = user.getLastVisitedClientId();
		if (lastVisitedClientId != null)
		{
			Optional<Client> lastVisitedClient = ClientDAO.findById(lastVisitedClientId);
			
			if (lastVisitedClient.isPresent())
			{
				if (lastVisitedClient.get().getUserFull(true).keySet().contains(user))
				{
					session.setAttribute(Client.class, lastVisitedClient.get());
					LOG.debug(
							 "Set client {} for user {} to session.",
							    lastVisitedClient.get().getClientDescription(),
							    user.toString());
				}
				else
				{
					Set<Client> findByUser = ClientDAO.findByUser(user);
					if (!findByUser.isEmpty())
					{
						Client next = findByUser.iterator().next();
						
						session.setAttribute(Client.class, next);
						user.setLastVisitedClientId(next.getUuid());
						

					}
					else
					{
						user.setLastVisitedClientId(null);
						LOG.debug(
								"User {} - Resetted \"Last visited client\", as user is not assigned to client.",
							    user.toString());
					}
					
					client = RestUtil.getRestClient_ESRADB();
					webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
					dto = UserCreator.convertUserToMetadataDTO(user);
					response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
					org.tinylog.Logger.tag("REST").info(response.toString());
				}
			}
			else
			{
				Set<Client> findByUser = ClientDAO.findByUser(user);
				if (!findByUser.isEmpty())
				{
					Client next = findByUser.iterator().next();
					
					session.setAttribute(Client.class, next);
					user.setLastVisitedClientId(next.getUuid());
					
					client = RestUtil.getRestClient_ESRADB();
					webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
					dto = UserCreator.convertUserToMetadataDTO(user);
					response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
					org.tinylog.Logger.tag("REST").info(response.toString());
				}
			}
		}
		else
		{
			Set<Client> findByUser = ClientDAO.findByUser(user);
			if (!findByUser.isEmpty())
			{
				Client next = findByUser.iterator().next();
				
				session.setAttribute(Client.class, next);
				user.setLastVisitedClientId(next.getUuid());
				
				client = RestUtil.getRestClient_ESRADB();
				webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
				
				dto = UserCreator.convertUserToMetadataDTO(user);
				response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
				org.tinylog.Logger.tag("REST").info(response.toString());
			}
		}
	
		}
	}
	
	public static void handleAttributes(final User user, SamlAttributes attributes)
	{
		if (null!=user && attributes != null)
		{
			boolean store = false;
			final Optional<String> first = attributes.getGivenname();
			if (first.isPresent() && !StringUtils.equals(first.get(), user.getFirstname()))
			{
				user.setFirstname(first.get());
				store = true;
				AuthenticationHandler.LOG.debug("Updated User {} - Set \"FirstName\"", user.toString());
			}
			
			final Optional<String> last = attributes.getSurname();
			if (last.isPresent() && !StringUtils.equals(last.get(), user.getLastname()))
			{
				user.setLastname(last.get());
				store = true;
				AuthenticationHandler.LOG.debug("Updated User {} - Set \"LastName\"", user.toString());			}
			
			final Optional<String> department = attributes.getDepartment_ou();
			if (department.isPresent() && !StringUtils.equals(department.get(), user.getDepartment()))
			{
				user.setDepartment(department.get());
				store = true;
				AuthenticationHandler.LOG.debug("Updated User {} - Set \"Department\"", user.toString());
			}
			
			// TODO: HANDLE OTHER SAML ATTRIBUTES
			// e.g. update user's Roles if there is a mapping between values and Roles
			// or set SamlResponseAttributes to session
			
			if (store)
			{
				RestClientESRADB client = RestUtil.getRestClient_ESRADB();
				
				WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
				
				UserMetadataDTO dto = UserCreator.convertUserToMetadataDTO(user);
				Response response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
				org.tinylog.Logger.tag("REST").info(response.toString());
				
			}
		}
	}
	
	
	
	
	/* ************************************************************************** */
	
	private static void printSamlResponseAttributes(SamlAttributes r, VaadinRequest request)
	{
		try
		{
			LOG.debug("####### PathInfo-V after: " + request.getPathInfo());
			
			String attributesAsJsonString = JsonMapper.builder()
	                .disable(MapperFeature.USE_ANNOTATIONS) // Disable a feature
	                .build().writerWithDefaultPrettyPrinter().writeValueAsString(r.getAttributes());
			
			AuthenticationHandler.LOG.debug("SAML Response Attributes: {}", attributesAsJsonString);
		}
		catch (JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/* ************************************************************************** */
	
	
	private boolean handleDevLogin(AuthExt auth, VaadinSession session, VaadinRequest request, HttpServletResponse response1) throws IOException
	{
		String email = null;

		try  {

			// auth0 (mit google)
			
			final List<String> list = auth.getAttributes().get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress");
			email = list.stream().findFirst().orElse("");
			
			if (StringUtils.isNotBlank(email))
			{
				//// HANDLE USER
				
				final Optional<User> userO = UserDAO.find(email);
				
				if (userO.isPresent()) {
					
					VaadinService.reinitializeSession(request);
					AuthenticationHandler.LOG.info(" ... change sessionID ...");
					
					handleLastVisitInfos(session, userO.get());
					logIn(session, userO.get());
					
					AuthenticationHandler.LOG.info(
						"Done. User {} logged in. Changed SessionId and added user to session.",
						userO.get().getEmailAddress());
					return false;
				}
				
			}

			AuthenticationHandler.LOG.error("Error at login: User not found. [user=\"{}\"]", email);
			
			session.setAttribute(Subject.class, null);
			session.setAttribute(User.class, null);
			
			response1.sendRedirect("loginfailed");
			return true;

		}
		catch (Exception e)
		{
			AuthenticationHandler.LOG.error("Error at login [user=\"" + email + "\"]", e);
			
			session.setAttribute(Subject.class, null);
			session.setAttribute(User.class, null);
			
			response1.sendRedirect("loginfailed");
			return true;
		}
	}
	
}
