
package com.caweco.esra.entities.core;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.namematch.BvdMatch;
import com.caweco.esra.microstream.converters.GenericObjectKeyDeserializer;
import com.caweco.esra.microstream.converters.GenericObjectKeySerializer;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


public class SearchEntryCompany implements HasMatchDataCollection
{
	private Instant                   created   = Instant.now();
	private String                    createdBy;
	
	private CIResponse                item;
	private String                    comment   = "";
	
	/**
	 * Contains MatchData items for GsssMatch items from all CompanyGsssMatch items.
	 */
	@JsonSerialize(keyUsing = GenericObjectKeySerializer.class)
	@JsonDeserialize(keyUsing = GenericObjectKeyDeserializer.class)
	private Map<GsssMatch, MatchData> matchData = new HashMap<GsssMatch, MatchData>();
	
	private UUID                      id        = UUID.randomUUID();
	
	/**
	 * (2022-12-06 JM): 
	 * ID of the parent SearchEntryCompany. <br />
	 * Available if this entry was created by a Subsidiary Screening Task.<br />
	 * If set, no Subsidiary Screening of this entry is allowed.
	 */
	private UUID                      parentId;
	
	/**
	 * HINT: Uses "current" user. Ensure that a user is set in VaadinSession.
	 * 
	 * @param data
	 * @return a new SearchEntryCompany object
	 */
	public static SearchEntryCompany New(CIResponse data)
	{
		SearchEntryCompany searchEntryCompany = 
			New(data, CurrentUtil.getUser().getEmailAddress());
		return searchEntryCompany;
	}
	
	/**
	 * Creates a new SearchEntryCompany object.
	 * 
	 * @param data
	 * @param task
	 * @return a new SearchEntryCompany object
	 */
	public static SearchEntryCompany New(CIResponse data, SubsidiaryScreeningTaskF task)
	{
		SearchEntryCompany searchEntryCompany = new SearchEntryCompany(data);
		searchEntryCompany.setCreatedBy("Screeningtask " + task.getId().toString());
		searchEntryCompany.setParentId(task.getSearchEntryCompanyId());
		return searchEntryCompany;
	}
	
	
	/**
	 * Creates a new SearchEntryCompany object.
	 * @param data
	 * @param createdBy
	 * @return a new SearchEntryCompany object
	 */
	public static SearchEntryCompany New(CIResponse data, String createdBy)
	{
		SearchEntryCompany searchEntryCompany = new SearchEntryCompany(data);
		searchEntryCompany.setCreatedBy(createdBy);
		return searchEntryCompany;
	}
	
	public SearchEntryCompany()
	{
		//For Jackson
	}
	
	protected SearchEntryCompany(CIResponse data)
	{
		super();
		this.item = data;
	}
	
	public UUID getId()
	{
		return id;
	}

	public void setId(UUID id)
	{
		this.id = id;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public CIResponse getItem()
	{
		return this.item;
	}
	
	@Override
	public String getComment()
	{
		return this.comment;
	}
	
	@Override
	public SearchEntryCompany setComment(String comment)
	{
		this.comment = comment;
		return this;
	}
	
	@Override
	public Map<GsssMatch, MatchData> getMatchData()
	{
		return this.matchData;
	}
	
	@Override
	public SearchEntryCompany setMatchData(Map<GsssMatch, MatchData> matchData){
		this.matchData = matchData;
		return this;
	}
	
	/**
	 * ID of the parent SearchEntryCompany. <br />
	 * Available if this entry was created by a Subsidiary Screening Task.<br />
	 * If set, no Subsidiary Screening of this entry is allowed.
	 * @return the id of the parent SearchEntryCompany
	 */
	public UUID getParentId()
	{
		return parentId;
	}

	public void setParentId(UUID parentId)
	{
		this.parentId = parentId;
	}
	
	public boolean hasParent()
	{
		return parentId != null;
	}

	@Override
	public String toString() {
		String itemString = item != null ? item.toString() : "none";
		return "SearchEntryCompany [created=" + created + ", createdBy=" + createdBy + ", item=" + itemString + ", comment="
				+ comment + ", matchData=" + matchData + ", id=" + id + ", parentId=" + parentId + "]";
	}
}
