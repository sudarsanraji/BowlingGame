package com.caweco.esra.entities.rest.namematch;

import com.caweco.esra.business.properties.RestSettingsProvider;
import org.apache.commons.lang3.StringUtils;



/**
 * https://paas-cara-dev.apps.adp.allianz/api/v1/cara/rest/NameMatchService/
 * 
 * @author JA
 *
 */
public class NMSearch
{
	private String username = StringUtils.EMPTY;
	private String password = StringUtils.EMPTY;;
	private String system = StringUtils.EMPTY;;
	private String searchType = StringUtils.EMPTY;;
	private String sessionHandle = StringUtils.EMPTY;;
	private String nameToSearch = StringUtils.EMPTY;;
	private String nameType = StringUtils.EMPTY;;
	private String streetAddress1 = StringUtils.EMPTY;;
	private String streetAddress2 = StringUtils.EMPTY;;
	private String postCode = StringUtils.EMPTY;;
	private String city = StringUtils.EMPTY;;
	private String state = StringUtils.EMPTY;;
	private String country = StringUtils.EMPTY;;
	private String gender = StringUtils.EMPTY;;
	private String dateOfBirth = StringUtils.EMPTY;;
	private String idToSearch = StringUtils.EMPTY;;
	private String isin = StringUtils.EMPTY;;
	private String customField1 = StringUtils.EMPTY;;
	private String customField2 = StringUtils.EMPTY;;
	private String customField3 = StringUtils.EMPTY;;
	private String customField4 = StringUtils.EMPTY;;
	private String customField5 = StringUtils.EMPTY;;

	
	/**
	 * *******************
	 * Constructors ******
	 * *******************
	 */
	public NMSearch()
	{
		// Standard Constructor for Customization
	}
	
	/**
	 * Mandatory search Parameter
	 * 
	 * @param username
	 * @param password
	 * @param system
	 * @param searchType
	 * @param nameToSearch
	 * @param nameType
	 */
	public NMSearch(
		final String username,
		final String password,
		final String system,
		final String searchType,
		final String nameToSearch,
		final String nameType)
	{
		super();
		this.username = username;
		this.password = password;
		this.system = system;
		this.searchType = searchType;
		this.nameToSearch = nameToSearch;
		this.nameType = nameType;
		
		this.customField1 = RestSettingsProvider.DEFAULT_SEARCHDEFINITION_VALUE;
		this.customField2 = RestSettingsProvider.DEFAULT_BUSINESSUNIT_VALUE;
	}
	
	/**
	 * *******************
	 * getter/setter *****
	 * *******************
	 */
	
	public String getUsername()
	{
		return this.username;
	}
	
	public NMSearch setUsername(final String username) // NO_UCD - setter
	{
		this.username = username;
		return this;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public String getSystem()
	{
		return this.system;
	}
	
	public String getSearchType()
	{
		return this.searchType;
	}
	
	public String getSessionHandle()
	{
		return this.sessionHandle;
	}
	
	public String getNameToSearch()
	{
		return this.nameToSearch;
	}
	
	public String getNameType()
	{
		return this.nameType;
	}
	
	public String getStreetAddress1()
	{
		return this.streetAddress1;
	}
	
	public NMSearch setStreetAddress1(final String streetAddress1) // NO_UCD - setter
	{
		this.streetAddress1 = streetAddress1;
		return this;
	}
	
	public String getStreetAddress2()
	{
		return this.streetAddress2;
	}
	
	public NMSearch setStreetAddress2(final String streetAddress2) // NO_UCD - setter
	{
		this.streetAddress2 = streetAddress2;
		return this;
	}
	
	public String getPostCode()
	{
		return this.postCode;
	}
	
	public NMSearch setPostCode(final String postCode) // NO_UCD - setter
	{
		this.postCode = postCode;
		return this;
	}
	
	public String getCity()
	{
		return this.city;
	}
	
	public NMSearch setCity(final String city) // NO_UCD - setter
	{
		this.city = city;
		return this;
	}
	
	public String getState()
	{
		return this.state;
	}
	
	public NMSearch setState(final String state) // NO_UCD - setter
	{
		this.state = state;
		return this;
	}
	
	public String getCountry()
	{
		return this.country;
	}
	
	public NMSearch setCountry(final String country)
	{
		this.country = country;
		return this;
	}
	
	public String getGender()
	{
		return this.gender;
	}
	
	public String getDateOfBirth()
	{
		return this.dateOfBirth;
	}
	
	public String getIdToSearch()
	{
		return this.idToSearch;
	}
	
	public String getIsin()
	{
		return this.isin;
	}
	
	public String getCustomField1()
	{
		return this.customField1;
	}
	
	public NMSearch setCustomField1(final String customField1)
	{
		this.customField1 = customField1;
		return this;
	}
	
	public String getCustomField2()
	{
		return this.customField2;
	}
	
	public String getCustomField3()
	{
		return this.customField3;
	}
	
	public String getCustomField4()
	{
		return this.customField4;
	}
	
	public String getCustomField5()
	{
		return this.customField5;
	}
	
	@Override
	public String toString()
	{
		return "NMSearch [username="
			+ this.username
			+ ", password="
			+ this.password
			+ ", system="
			+ this.system
			+ ", searchType="
			+ this.searchType
			+ ", sessionHandle="
			+ this.sessionHandle
			+ ", nameToSearch="
			+ this.nameToSearch
			+ ", nameType="
			+ this.nameType
			+ ", streetAddress1="
			+ this.streetAddress1
			+ ", streetAddress2="
			+ this.streetAddress2
			+ ", postCode="
			+ this.postCode
			+ ", city="
			+ this.city
			+ ", state="
			+ this.state
			+ ", country="
			+ this.country
			+ ", gender="
			+ this.gender
			+ ", dateOfBirth="
			+ this.dateOfBirth
			+ ", idToSearch="
			+ this.idToSearch
			+ ", isin="
			+ this.isin
			+ ", customField1="
			+ this.customField1
			+ ", customField2="
			+ this.customField2
			+ ", customField3="
			+ this.customField3
			+ ", customField4="
			+ this.customField4
			+ ", customField5="
			+ this.customField5
			+ "]";
	}
}
