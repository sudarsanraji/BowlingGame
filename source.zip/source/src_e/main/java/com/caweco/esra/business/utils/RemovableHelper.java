package com.caweco.esra.business.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.removing.UsageInfoUser;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;
import com.caweco.esra.entities.core.Screening;

public class RemovableHelper
{
	public static final Logger LOG = LoggerFactory.getLogger(RemovableHelper.class);
	
	public static boolean isRemovableFromClient_Function(final Function it, final Client c)
	{
		if (c == null || it == null)
		{
			return false;
		}
		final boolean functionIsAssignedToAtLeastOneScreening = c.getScreenings().values().stream()
			.filter(scr -> Objects.equals(it, scr.getFunction()))
			.findFirst()
			.isPresent();
		
		LOG.debug("Function \"{}\" is {} deletable.", it.getName(), (functionIsAssignedToAtLeastOneScreening ? "NOT" : ""));
		
		return !functionIsAssignedToAtLeastOneScreening;
	}
	
	public static boolean isRemovableFromClient_LineOfBusiness(final LineOfBusiness it, final Client c)
	{
		if (c == null || it == null)
		{
			return false;
		}
		final boolean lobIsAssignedToAtLeastOneScreening = c.getScreenings().values().stream()
			.filter(scr -> Objects.equals(it, scr.getLineOfBusiness()))
			.findFirst()
			.isPresent();
		
		LOG.debug("LineOfBusiness \"{}\" is {} deletable.", it.getName(), (lobIsAssignedToAtLeastOneScreening ? "NOT" : ""));
		
		return !lobIsAssignedToAtLeastOneScreening;
	}
	
	
	public static boolean isRemovableFromClient_OE(final OE it, final Client c)
	{
		if (c == null || it == null)
		{
			return false;
		}
		final boolean oeIsAssignedToAtLeastOneScreening = c.getScreenings().values().stream()
			.filter(scr -> Objects.equals(it, scr
				.getOe()))
			.findFirst()
			.isPresent();
		
		LOG.debug("OE \"{}\" is {} deletable.", it.getName(), (oeIsAssignedToAtLeastOneScreening ? "NOT" : ""));
		
		return !oeIsAssignedToAtLeastOneScreening;
	}
	
	public static boolean isRemovableFromClient_Region(final OeRegion it, final Client c)
	{
		if (c == null || it == null)
		{
			return false;
		}
		
		final boolean regionIsAssignedToAtLeastOneOE = c.getOes(true).stream()
			.filter(oe -> Objects.equals(it, oe.getRegion()))
			.findFirst()
			.isPresent();
		
		LOG.debug("Region \"{}\" is {} deletable.", it.getName(), (regionIsAssignedToAtLeastOneOE ? "NOT" : ""));
		
		return !regionIsAssignedToAtLeastOneOE;
	}
	
	/**
	 * Evaluates the collected UsageInfoUser if user is NOT
	 * <ul>
	 * <li>a screening owner or</li>
	 * <li>a screening service user or</li>
	 * <li>a ESU user of a screening</li>
	 * </ul>
	 * in one of the clients.
	 * 
	 * @param infos the collected infos
	 * @return true if user object is not used (and therefore can be removed), false otherwise
	 * @see {@link UsageInfoUser#isScreeningUser()}
	 */
	public static boolean isFullyRemovable(final List<UsageInfoUser> infos)
	{
		final boolean isInUse = infos.stream().filter(UsageInfoUser::isScreeningUser).findFirst().isPresent();
		
		return !isInUse;
	}
	
	/* ******************************************************************************** */
	
	
	/**
	 * Collect Role's usages current Client.<br />
	 * It is assumed that the given Role belongs to the Client.
	 * 
	 * @param client
	 * @param role
	 * @return
	 */
	public static Set<User> getCurrentUsages(final Client client, final Role role)
	{
		if (client == null || role == null)
		{
			org.tinylog.Logger.tag("RemovableHelper").info("Collecting roles for 0 users");
			return new HashSet<>();
		}
		else
		{
			final var users = client.getUser();
			org.tinylog.Logger.tag("RemovableHelper").info("Collecting roles for {} users", users.size());
			// Collect roles from the storage server, as we might not be up to date
			UserDAO.getRoles(new ArrayList<>(users)).forEach((user, roles) -> user.setRoles(Optional.of(roles)));
			return users.stream().filter(u -> u.getRoles(false).contains(role)).collect(Collectors.toSet());
		}
	}
	
	/**
	 * Collect User's usages in all Clients.
	 * 
	 * @param user
	 * @param users
	 * @return
	 */
	public static List<UsageInfoUser> getUsages_inAllClients(final User user, final Map<Client, Set<User>> users)
	{
		final List<UsageInfoUser> result  = new ArrayList<>();
		
		users.forEach((c, u) -> {
			final UsageInfoUser usagesInClient = getUsagesInClient(c, user, u);
			if (usagesInClient != null)
			{
				result.add(usagesInClient);
			}
		});
		return result;
	}
	
	/**
	 * Collect User's usages in the given Client.
	 * 
	 * @param client
	 * @param user
	 * @return
	 */
	public static UsageInfoUser getUsagesInClient(final Client client,  final User user, final Set<User> users)
	{
		if (client == null || user == null)
		{
			return null;
		}
		
		final UsageInfoUser result = new UsageInfoUser(client, user, users);
		
		// Usage in Screenings
		for (final Screening screening : client.getScreenings().values())
		{
			if (Objects.equals(user, screening.getScreeningOwner()))
			{
				result.getUserIsOwner().add(screening);
			}
			if (Objects.equals(user, screening.getScreeningServiceUser()))
			{
				result.getUserIsServiceUser().add(screening);
			}
			if (Objects.equals(user, screening.getEsuWorker()))
			{
				result.getUserIsEsuWorker().add(screening);
			}
			
			if (screening.getPublicMessages(true).getFollower().contains(user))
			{
				result.getUserIsPublicMessageGroupFollower().add(screening);
			}
			
			final boolean isMemberOfAMessageGroup = screening.getMessageGroups(true).values()
				.stream()
				.filter(mg -> MessageGroupDAO.isMember(mg, user))
				.findFirst()
				.isPresent();
			if (isMemberOfAMessageGroup)
			{
				result.getUserIsMessageGroupMember().add(screening);
			}
		}
		
		return result;
	}
	
	
}
