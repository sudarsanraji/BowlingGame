package com.caweco.esra.dao;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.dto.BackupChannelDTO;
import com.caweco.esra.dto.creator.BackupChannelCreator;
import com.caweco.esra.entities.config.BackupChannel;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class BackupChannelDAO
{
	public static BackupChannel find(String name)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/maintenance/backupchannel/" + name);
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		BackupChannelDTO responseBody = response.readEntity(BackupChannelDTO.class);

		return BackupChannelCreator.convertDTOToBackupChannel(responseBody);
	}

	public static void update(BackupChannel ch) {
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/maintenance/backupchannel/" + ch.getName());
		
		Response response = webTarget.request().post(Entity.entity(BackupChannelCreator.convertBackupChannelToDTO(ch), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
}
