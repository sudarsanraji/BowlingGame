package com.caweco.esra.entities.config;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.caweco.esra.business.properties.RestSettingsProvider;


public class ConfigRestEndpoint
{
	public ConfigRestEndpoint()
	{
		
	}
	
	public static ConfigRestEndpoint getConfigBIH()
	{
		final ConfigRestEndpoint configBIH = new ConfigRestEndpoint("BIH", RestSettingsProvider.DEFAULT_REST_URL_BIH);
		configBIH.setEndpointPassword(RestSettingsProvider.DEFAULT_REST_PASSWORD_BIH);
		configBIH.setEndpointUsername(RestSettingsProvider.DEFAULT_REST_USERNAME_BIH);
		configBIH.setSystemName(RestSettingsProvider.DEFAULT_REST_SYSNAME_BIH);
		return configBIH;
	}
	
	public static ConfigRestEndpoint getConfigSEAWEB()
	{
		final ConfigRestEndpoint configSeaWeb =
			new ConfigRestEndpoint("SEAWEB", RestSettingsProvider.DEFAULT_REST_URL_SEAWEB);
		configSeaWeb.setEndpointPassword(RestSettingsProvider.DEFAULT_REST_PASSWORD_SEAWEB);
		configSeaWeb.setEndpointUsername(RestSettingsProvider.DEFAULT_REST_USERNAME_SEAWEB);
		return configSeaWeb;
	}
	
	public static ConfigRestEndpoint getConfigESRADB()
	{
		final ConfigRestEndpoint configSeaWeb =
			new ConfigRestEndpoint("ESRADB", RestSettingsProvider.DEFAULT_REST_URL_ESRADB);
		configSeaWeb.setEndpointPassword(RestSettingsProvider.DEFAULT_REST_PASSWORD_ESRADB);
		configSeaWeb.setEndpointUsername(RestSettingsProvider.DEFAULT_REST_USERNAME_ESRADB);
		return configSeaWeb;
	}
	
	
	private String						endpointIdentifier	= UUID.randomUUID().toString();
	private String						endpointRepresentation;
	private String						endpointUsername;
	private String						endpointPassword;
	private String						endpointBaseURL;
	private String						systemName;
	
	private final Map<String, String>	additional			= new HashMap<>();
	
	public ConfigRestEndpoint(final String endpointIdentifier, final String endpointBaseURL)
	{
		super();
		this.endpointIdentifier = endpointIdentifier;
		this.endpointRepresentation = endpointIdentifier;
		this.endpointBaseURL = endpointBaseURL;
	}
	
	public String getEndpointIdentifier()
	{
		return this.endpointIdentifier;
	}
	
	public void setEndpointIdentifier(final String endpointIdentifier)
	{
		this.endpointIdentifier = endpointIdentifier;
	}
	
	public String getEndpointRepresentation()
	{
		return this.endpointRepresentation;
	}
	
	public void setEndpointRepresentation(final String endpointRepresentation)
	{
		this.endpointRepresentation = endpointRepresentation;
	}
	
	public String getEndpointUsername()
	{
		return this.endpointUsername;
	}
	
	public void setEndpointUsername(final String username)
	{
		this.endpointUsername = username;
	}
	
	public String getEndpointPassword()
	{
		return this.endpointPassword;
	}
	
	public void setEndpointPassword(final String password)
	{
		this.endpointPassword = password;
	}
	
	public String getEndpointBaseURL()
	{
		return this.endpointBaseURL;
	}
	
	public void setEndpointBaseURL(final String baseURL)
	{
		this.endpointBaseURL = baseURL;
	}
	
	public String getSystemName()
	{
		return this.systemName;
	}
	
	public void setSystemName(final String systemName)
	{
		this.systemName = systemName;
	}
	
	public Map<String, String> getAdditional()
	{
		return new HashMap<String,String>(this.additional);
	}
	
}
