package com.caweco.esra.dao.access;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.collections4.Equator;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.AccessControlCompanyDTO;
import com.caweco.esra.dto.creator.AccessControlCompanyCreator;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.ldap.LdapOrg;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class AccessControlCompanyDAO
{
	private static ObjectMapper om = new ObjectMapper();
	
	public static Set<AccessControlCompany> findAll()
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcompaniesanddepartments");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(Set.class, AccessControlCompanyDTO.class);
		
		HashSet<AccessControlCompany> actualSet = new HashSet();
		
		
		try {
			HashSet<AccessControlCompanyDTO> returnedSet = om.readValue(responseBody, type);
			
			returnedSet.forEach(dto -> {
				actualSet.add(AccessControlCompanyCreator.convertDTOToAccessControlCompany(dto));
			});
			
			return actualSet;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static void insert(AccessControlCompany newItem)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcompaniesanddepartments");
		
		AccessControlCompanyDTO dto = AccessControlCompanyCreator.convertAccessControlToDTO(newItem);
		Response response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		try {
			om.readValue(responseBody, AccessControlCompanyDTO.class);
			Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
			+" added the company "  + newItem.getDisplayName());
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			Logger.tag("REST").error("AccessControlCompanyDAO.insert failed, data likely wasnt saved", e);
			e.printStackTrace();
		}
	}
	
	public static void delete(AccessControlCompany item)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcompaniesanddepartments/" + item.getCnId());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		try {
			om.readValue(responseBody, AccessControlCompanyDTO.class);
			Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
			+" removed the company "  + item.getDisplayName());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**************************************************************/
	
	public static void addChild(AccessControlCompany parent, LdapOrg child)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcompaniesanddepartments/" + parent.getCnId() + "/department");
		
		Response response = webTarget.request().post(Entity.entity(child, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		try {
			om.readValue(responseBody, AccessControlCompanyDTO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			Logger.tag("REST").error("AccessControlCompanyDAO.addChild failed, data likely wasnt saved", e);
			throw new RuntimeException(e);
		}
		
		parent.getAllowedDepartments().add(child);
		
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the department "  + child.getDisplayName() + " to the company " + parent.getDisplayName() );
	}
	
	public static void removeChild(AccessControlCompany parent, LdapOrg child)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcompaniesanddepartments/" + parent.getCnId() + "/department/" + child.getCnId());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		try {
			om.readValue(responseBody, AccessControlCompanyDTO.class);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		parent.getAllowedDepartments().remove(child);
		
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the department "  + child.getDisplayName() + " to the company " + parent.getDisplayName() );
	}
	
	/**************************************************************/
	
	public static Equator<LdapOrg> getEquator()
	{
		return new Equator<LdapOrg>()
		{
			
			@Override
			public boolean equate(LdapOrg o1, LdapOrg o2)
			{
				return o1.equalsNC(o2);
			}
			
			@Override
			public int hash(LdapOrg o)
			{
				return o.hashCode();
			}
		};
	}
}
