package com.caweco.esra.business.utils;

public class Triple<A, B, C>
{
	private final A first;
	private final B second;
	private final C third;

	public Triple(final A first, final B second, final C third)
	{
		this.first = first;
		this.second = second;
		this.third = third;
	}

	public A getFirst()
	{
		return this.first;
	}

	public B getSecond()
	{
		return this.second;
	}

	public C getThird()
	{
		return this.third;
	}
}
