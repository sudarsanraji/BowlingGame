package com.caweco.esra.entities.saml;

import java.util.Optional;


/**
 * Contains the saml attribute name and a "okValue".
 * <p>
 * If the "okValue" mets the attribute value of a SAML response this Criterion is fulfilled,
 * the {@link SamlAttributes} "fits".
 *
 */
public interface SamlAttributeCriterion
{
	String getAttributeName();
	
	String getOkValue();
	
	default boolean fit(SamlAttributes attr)
	{
		// No input -> Always false
		if(attr == null)
			return false;
		
		// No okValue -> Always true
		if(this.getOkValue() == null)
			return true;
		
		// Attribute not found -> Always false
		Optional<String> currentAttributeValue = attr.getAttributeFirstValue(this.getAttributeName());
		if(!currentAttributeValue.isPresent())
			return false;
		
		// Compare currentAttributeValue with okValue
		boolean equals = currentAttributeValue.get().equals(this.getOkValue());
		return equals;
	}
}
