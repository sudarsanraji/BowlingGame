package com.caweco.esra.dto;

import java.time.Instant;
import java.util.UUID;

import com.caweco.esra.entities.saml.SamlAttributes;

public class UserMetadataDTO {
	private String emailAddress;
	private String firstname;
	private String lastname;
	private String department;
	private boolean active;
	private boolean appAdmin;
	private Instant lastLogin;
	private Instant currentLogin;
	private UUID lastVisitedClientID;
	private SamlAttributes lastSamlAttributes;
	
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public boolean isAppAdmin() {
		return appAdmin;
	}
	public void setAppAdmin(boolean appAdmin) {
		this.appAdmin = appAdmin;
	}
	public Instant getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Instant lastLogin) {
		this.lastLogin = lastLogin;
	}
	public Instant getCurrentLogin() {
		return currentLogin;
	}
	public void setCurrentLogin(Instant currentLogin) {
		this.currentLogin = currentLogin;
	}
	public UUID getLastVisitedClientID() {
		return lastVisitedClientID;
	}
	public void setLastVisitedClientID(UUID lastVisitedClientID) {
		this.lastVisitedClientID = lastVisitedClientID;
	}
	public SamlAttributes getLastSamlAttributes() {
		return lastSamlAttributes;
	}
	public void setLastSamlAttributes(SamlAttributes lastSamlAttributes) {
		this.lastSamlAttributes = lastSamlAttributes;
	}
	
	
}
