
package com.caweco.esra.ui.part.watchlist.seawebimo;

import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.func.data.SeawebRedFlagCalculator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.ui.interfaces.HasResettableDataCommunicator;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.caweco.esra.ui.part.watchlist.common.NamedMarkerElement;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElement;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.function.SerializableBiConsumer;


public class ComplianceKeyElement extends Details
	implements WatchlistElement<ComplianceKeyElement>, HasResettableDataCommunicator
{
	protected PartWatchList                                       root;
	
	private SearchEntrySeaweb2Vessel                              item;
	ComplianceScreeningKeyData                                    complianceScreeningKey;
	private Integer                                               flagValue     = null;
	private Integer                                               flagValueOld  = null;
	private boolean                                               readOnly      = false;
	
	// TEMPORARY DATA
	private boolean                                               isInitialized = false;
	private Integer                                               flagValueForced;
	private SerializableBiConsumer<ComplianceKeyElement, Boolean> flagChangeListener;
	
	// UI
	private NamedMarkerElement                                    header;
	
	protected ComplianceKeyElement()
	{
		super();
		this.initUI();
		this.getElement().setAttribute("class", "screeningheader inner with-workaround-edge");
		
		this.header = NamedMarkerElement.getAs_WatchlistInnerDetailHeader().setNamedText("---");
		this.setSummary(this.header);
	}
	
	protected ComplianceKeyElement(ComplianceScreeningKeyData complianceScreeningKey)
	{
		this();
		this.complianceScreeningKey = complianceScreeningKey;
		this.header.setNamedText(complianceScreeningKey.getHumanReadable());
	}
	
	public ComplianceKeyElement(PartWatchList root, ComplianceScreeningKeyData complianceScreeningKey) {
		this(complianceScreeningKey);
		this.root = root;
	}
	
	
	@Override
	public Optional<PartWatchList> getWatchListRoot()
	{
		return Optional.ofNullable(root);
	}
	
	public ScreeningPageContext getContext() 
	{
		return getWatchListRoot().map(PartWatchList::getContext).orElse(null);
	}
	
	public Screening getScreening() 
	{
		return getWatchListRoot().map(PartWatchList::getScreening).orElse(null);
	}
	
	
	/**********************************************************/
	
	public ComplianceKeyElement setItem(SearchEntrySeaweb2Vessel item)
	{
		this.item = item;
		
		boolean value =
			SeawebRedFlagCalculator.hasRedFlag_Key(this.item, this.complianceScreeningKey);
		this.setValue(SanctionUtil.toFlag(value), false, false);
		
		return this;
	}
	
	public SearchEntrySeaweb2Vessel getItem()
	{
		return this.item;
	}
	
	public ComplianceScreeningKeyData getComplianceScreeningKey()
	{
		return this.complianceScreeningKey;
	}
	
	/**
	 * Event handler delegate method for the {@link Details}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void this_onOpenedChange(OpenedChangeEvent event)
	{
		if(event.isOpened() && !this.isInitialized)
		{
			this.initAndAddContent();
		}
	}
	
	private void initAndAddContent()
	{
		if(this.item != null && this.complianceScreeningKey != null)
		{
			Component element = SeawebElementProvider.getElement(this.complianceScreeningKey.getKey(), this.item);
			
			this.setContent(element);
			
			this.isInitialized = true;
		}
	}

	
	@Override
	public void setReadOnlyCustom(boolean readOnly)
	{
		this.readOnly = readOnly;
		// Nothing to do
	}
	
	protected boolean valueEquals(final Integer value1, final Integer value2)
	{
		return Objects.equals(value1, value2);
	}
	
	// from AbstractFieldSupport
	protected void setValue(final Integer newValue, final boolean fromInternal, final boolean fromClient)
	{
		if(fromClient && this.readOnly)
		{
			// TODO: reset UI to previous value
			// this.applyValue(flagValue);
			return;
		}
		
		final int currentValue    = this.getFlagValue();
		Integer       currentOldValue = this.flagValueOld;
		
		if(this.valueEquals(newValue, currentValue))
		{
			return;
		}
		
		this.flagValueOld = currentValue;
		this.flagValue    = newValue;
		
		if(!fromInternal)
		{
			try
			{
				if(this.header != null)
				{
					this.header.setMarked(this.flagValue);
				}
				
			}
			catch(final RuntimeException e)
			{
				this.flagValueOld = currentOldValue;
				this.flagValue    = currentValue;
				throw e;
			}
		}
		
		if(this.flagChangeListener != null)
		{
			this.flagChangeListener.accept(this, fromClient);
		}
	}
	
	@Override
	public void recalcFlag()
	{
		Integer flagValue = this.flagValueForced;
		
		// Recalc if not forced
		
		if(this.flagValueForced == null)
		{
			
			Boolean marked = false;
			if(this.item != null && this.complianceScreeningKey != null)
			{
				marked = SeawebRedFlagCalculator.hasRedFlag_Key(this.item,
					this.complianceScreeningKey);
			}
			
			flagValue = BooleanUtils.toIntegerObject(marked, 2, 0, 0);
		}
		
		this.setValue(flagValue, false, true);
	}
	
	@Override
	public int getFlagValue()
	{
		return this.flagValue == null ? -1 : this.flagValue;
	}
	
	@Override
	public int getFlagValueOld()
	{
		return this.flagValueOld == null ? -1 : this.flagValueOld;
	}
	
	public void setFlagForced(int flagValueForced)
	{
		this.flagValueForced = flagValueForced;
		
		this.recalcFlag();
	}
	
	@Override
	public void setFlagChangeListener(SerializableBiConsumer<ComplianceKeyElement, Boolean> flagChangeListener)
	{
		this.flagChangeListener = flagChangeListener;
		
	}
	
	@Override
	public void resetDataCommunicators()
	{
		if(this.isInitialized)
		{
			this.getContent().filter(Objects::nonNull)
				.filter(c -> c instanceof HasResettableDataCommunicator)
				.forEach(c -> ((HasResettableDataCommunicator)c).resetDataCommunicators());
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
		
		this.addOpenedChangeListener(this::this_onOpenedChange);
	} // </generated-code>

	@Override
	public String getName() {
		return item.getShipDetails().getShipName();
	}
	
}
