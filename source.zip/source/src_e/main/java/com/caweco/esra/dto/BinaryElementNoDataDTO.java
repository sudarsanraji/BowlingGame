package com.caweco.esra.dto;

import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;

public class BinaryElementNoDataDTO extends BinaryElement {

}
