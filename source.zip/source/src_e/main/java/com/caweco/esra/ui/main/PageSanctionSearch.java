
package com.caweco.esra.ui.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.rest.DataBackendHelper;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.core.FunctionDAO;
import com.caweco.esra.dao.core.LobDAO;
import com.caweco.esra.dao.core.OeDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.ui.data.provider.CustomFilterableDataProvider;
import com.caweco.esra.ui.esu.PageESUWorklist;
import com.caweco.esra.ui.main.helper.ScreeningSearchResult;
import com.caweco.esra.ui.main.helper.ScreeningTextSearchMultiResultItem2;
import com.caweco.esra.ui.main.renderer.RendererScreeningSearchResult;
import com.caweco.esra.ui.main.renderer.RendererScreeningSearchResultAction;
import com.caweco.esra.ui.sanctions.PageFinancialScreening;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.navigation.Navigation;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluatingComponentExtension;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluationStrategy;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.renderer.TextRenderer;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.dom.Style;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouterLink;


@PageTitle("ESRA Start & Search | ESRA")
@Route(value = "", layout = PageMain.class)
public class PageSanctionSearch extends VerticalLayout implements AfterNavigationObserver
{
	Main																		main;
	
	CustomFilterableDataProvider<ScreeningSearchResult<ScreeningMetadataBase>>	dp;
	
	boolean																		valuesChanged	= false;

	private RouterLink rlESUWorklist;
	private RouterLink rlNewScreening;
	
	public PageSanctionSearch()
	{
		//// UI
		
		super();
		this.initUI();
		
		UiHelper.image_addEmptyAltAttribute(this.image);
		
		this.main = new Main(
			this.divPlaceholder1,
			this.image,
			this.searchForm,
			this.objActions,
			this.divPlaceholder2,
			this.objFilterBar,
			this.gridSearchResults);
		this.main.setSizeFull();
		
		final Style mainElementStyle = this.main.getElement().getStyle();
		mainElementStyle.set("display", "flex");
		mainElementStyle.set("align-items", "stretch");
		mainElementStyle.set("flex-flow", "column");
		this.main.getElement().getClassList().add("withGridGap-s");
		
		this.divPlaceholder1.getElement().getStyle().set("flex-grow", "1");
		this.divPlaceholder2.getElement().getStyle().set("flex-grow", "1");
		this.gridSearchResults.getElement().getStyle().set("flex-grow", "7");
		this.add(this.main);
		
		this.initGrid();
		
		// Add "ENTER" shortcut and make it work for all child components of "searchForm"
		this.btnSearch.addClickShortcut(Key.ENTER).allowBrowserDefault().listenOn(
			this.searchForm).setEventPropagationAllowed(false);
		
		this.txtSearchTerm.focus();
		
		//// DATA
		
		this.switchAllOrOwnScreenings.setItems("all", "own");
		
		//Adding routerlink for navigation to ESU Worklist
		Button btnNewScreening = new Button("New Screening", VaadinIcon.PLUS.create());
		btnNewScreening.setWidthFull();
		rlNewScreening = new RouterLink();
		rlNewScreening.setRoute(PageFinancialScreening.class, "new");
		rlNewScreening.getElement().appendChild(btnNewScreening.getElement());
		objActions.add(rlNewScreening);
		this.objActions.setFlexGrow(1.0, rlNewScreening);
	
		
		//Adding routerlink for navigation to ESU Worklist
		Button btnESUWorklist = new Button("ESU Worklist", VaadinIcon.LIST.create());
 		btnESUWorklist.setWidthFull();
		rlESUWorklist = new RouterLink();
		rlESUWorklist.setRoute(PageESUWorklist.class);
		rlESUWorklist.getElement().appendChild(btnESUWorklist.getElement());
		objActions.add(rlESUWorklist);
		this.objActions.setFlexGrow(1.0, rlESUWorklist);
		
		Authorization.setSubjectEvaluatingComponentExtension(
			this.rlESUWorklist,
			SubjectEvaluatingComponentExtension.Builder.New().add(
				AuthorizationResources.ESUACCESS.resource(),
				SubjectEvaluationStrategy.VISIBLE).build());
	}
	
	public void forceRefresh()
	{
		this.dp.refreshAll();
	}
	
	@Override
	protected void onAttach(final AttachEvent attachEvent)
	{
		super.onAttach(attachEvent);
		
		final Client client = CurrentUtil.getClient();
		if(client != null)
		{
			final ListDataProvider<LineOfBusiness> dataProvider =
				DataProvider.ofCollection(LobDAO.getLineOfBusinesses(client));
			final ListDataProvider<Function> dataProviderFunction =
				DataProvider.ofCollection(FunctionDAO.findAll(client));
			final ListDataProvider<OE> dataProviderOffices = DataProvider.ofCollection(OeDAO.findAll(client));
			final ListDataProvider<ScreeningStatus> dataProviderProcessStatus =
				DataProvider.ofCollection(List.of(ScreeningStatus.values()));
			dataProvider.setSortOrder(LineOfBusiness::getName, SortDirection.ASCENDING);
			dataProviderFunction.setSortOrder(Function::getName, SortDirection.ASCENDING);
			dataProviderOffices.setSortOrder(OE::getName, SortDirection.ASCENDING);
			dataProviderProcessStatus.setSortOrder(ScreeningStatus::getStatus, SortDirection.ASCENDING);
			this.selectLob.setDataProvider(dataProvider);
			this.selectFunction.setDataProvider(dataProviderFunction);
			this.selectOffice.setDataProvider(dataProviderOffices);
			this.selectStatus.setDataProvider(dataProviderProcessStatus);
			
			this.dp = new CustomFilterableDataProvider<>(
				(d, q) ->
				{
					if(this.txtSearchTerm.isEmpty()
						&&
						this.selectLob.getValue() == null
						&&
						this.selectFunction.getValue() == null
						&&
						this.selectOffice.getValue() == null
						&&
						this.selectStatus.getValue() == null
						&& !this.valuesChanged)
					{
						return new ArrayList<ScreeningSearchResult<ScreeningMetadataBase>>().stream();
					}
					
					final Client c = CurrentUtil.getClient();
					final String clientId = c.getUuid().toString();
					
					final List<ScreeningMetadataBase> screenings = ScreeningDAO.getScreenings(clientId, d, q);
					
					return screenings.stream().map(base -> new ScreeningTextSearchMultiResultItem2(clientId, base));
				},
				
				qq ->
				{
					if(this.txtSearchTerm.isEmpty()
						&&
						this.selectLob.getValue() == null
						&&
						this.selectFunction.getValue() == null
						&&
						this.selectOffice.getValue() == null
						&&
						this.selectStatus.getValue() == null
						&& !this.valuesChanged)
					{
						return 0;
					}
					
					final Integer countScreenings = ScreeningDAO.countScreenings(CurrentUtil.getClient(), qq);
					return countScreenings;
				});
			
			this.dp.setOnSizeUpdate(size -> this.lblResult.setText(size + " results"));
			
			this.gridSearchResults.setDataProvider(this.dp);
			
			this.switchAllOrOwnScreenings.setValue("all");
		}
	}
	
	/*********************************************************/
	/** Lifecycle **/
	
	@Override
	public void afterNavigation(final AfterNavigationEvent event)
	{
		if(CurrentUtil.getClient() == null)
		{
			// Disable all actions
			this.searchForm.setEnabled(false);
			this.objActions.setEnabled(false);
			this.objFilterBar.setEnabled(false);
		}
		else
		{
			
			this.switchAllOrOwnScreenings.setVisible(true);
		}
		
		// Notificator.warn("Search has been temporarily disabled", 5000);
		
		// Check if search index is available yet, if not - block everything
		final boolean isAvailable = DataBackendHelper.isLuceneAvailable(CurrentUtil.getClient());
		if(!isAvailable)
		{
			Notificator.warn(
				"ESRA is still initalizing and as a result most features are not available yet. Please check back in a few minutes.",
				50000);
			
			this.rlESUWorklist.setVisible(false);
			this.rlNewScreening.setVisible(false);
			this.btnSearch.setEnabled(false);
			this.switchAllOrOwnScreenings.setReadOnly(true);
		}
		else
		{
			Authorization.evaluateComponents(this.rlESUWorklist);
			this.rlNewScreening.setVisible(true);
			this.btnSearch.setEnabled(true);
			this.switchAllOrOwnScreenings.setReadOnly(false);
		}
	}
	
	/*********************************************************/
	/** UI init **/
	
	private void initGrid()
	{
		//// Row sorting
		
		final Column<ScreeningSearchResult<ScreeningMetadataBase>> dateColumn =
			this.gridSearchResults.getColumnByKey("screeningDate");
		this.gridSearchResults.sort(GridSortOrder.desc(dateColumn).build());
		
	}
	
	/*********************************************************/
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridSearchResults}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridSearchResults_selectionChange(
		final SelectionEvent<Grid<ScreeningSearchResult<ScreeningMetadataBase>>, ScreeningSearchResult<ScreeningMetadataBase>> event)
	{
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSearch}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSearch_onClick(final ClickEvent<Button> event)
	{
		this.valuesChanged = true;
		this.executeSearch(event.isFromClient(), this.txtSearchTerm.getValue());
		// this.dp.refreshAll();
		// This triggers also the txtSearchTerm_valueChanged
	}
	
	private void executeSearch(final boolean isFromClient, final String currentSerachText)
	{
		this.dp.setLuceneSearchText(isFromClient, currentSerachText);
	}
	
	/**
	 * Event handler delegate method for the {@link RadioButtonGroup} {@link #switchAllOrOwnScreenings}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void switchAllOrOwnScreenings_valueChanged(
		final ComponentValueChangeEvent<RadioButtonGroup<String>, String> event)
	{
		if(event.isFromClient())
		{
			this.valuesChanged = true;
			
			if(event.getValue() != null && "own".equals(event.getValue()))
			{
				this.dp.addQueryParameter("s_isOwn", CurrentUtil.getUser().getEmailAddress());
			}
			else
			{
				this.dp.removeQueryParameter("s_isOwn");
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectLob}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectLob_valueChanged(final ComponentValueChangeEvent<ComboBox<LineOfBusiness>, LineOfBusiness> event)
	{
		if(event.isFromClient())
		{
			if(event.getValue() != null)
			{
				final Integer id = event.getValue().getId();
				this.dp.addPropertyFilter("lineOfBusiness", id);
				
			}
			else
			{
				this.dp.removePropertyFilter("lineOfBusiness");
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link TextField} {@link #txtSearchTerm}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtSearchTerm_valueChanged(final ComponentValueChangeEvent<TextField, String> event)
	{
		if(event.isFromClient())
		{
			final String currentSearchText = StringUtils.stripToNull(event.getValue());
			
			this.executeSearch(event.isFromClient(), currentSearchText);
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectFunction}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectFunction_valueChanged(final ComponentValueChangeEvent<ComboBox<Function>, Function> event)
	{
		if(event.isFromClient())
		{
			if(event.getValue() != null)
			{
				final Integer id = event.getValue().getId();
				this.dp.addPropertyFilter("function", id);
				
			}
			else
			{
				this.dp.removePropertyFilter("function");
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectOffice}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectOffice_valueChanged(final ComponentValueChangeEvent<ComboBox<OE>, OE> event)
	{
		if(event.isFromClient())
		{
			if(event.getValue() != null)
			{
				final Integer id = event.getValue().getId();
				this.dp.addPropertyFilter("oe", id);
				
			}
			else
			{
				this.dp.removePropertyFilter("oe");
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectStatus}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectStatus_valueChanged(
		final ComponentValueChangeEvent<ComboBox<ScreeningStatus>, ScreeningStatus> event)
	{
		
		if(event.isFromClient())
		{
			if(event.getValue() != null)
			{
				this.dp.addPropertyFilter("status", event.getValue());
				
			}
			else
			{
				this.dp.removePropertyFilter("status");
			}
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.divPlaceholder1 = new Div();
		this.image = new Image();
		this.searchForm = new HorizontalLayout();
		this.txtSearchTerm = new TextField();
		this.btnSearch = new Button();
		this.objActions = new HorizontalLayout();
		this.divPlaceholder2 = new Div();
		this.objFilterBar = new HorizontalLayout();
		this.objAllOrOwnFilter = new Div();
		this.lblOwn = new Label();
		this.switchAllOrOwnScreenings = new RadioButtonGroup<>();
		this.selectLob = new ComboBox<>();
		this.selectFunction = new ComboBox<>();
		this.selectOffice = new ComboBox<>();
		this.selectStatus = new ComboBox<>();
		this.lblResult = new Label();
		this.gridSearchResults = new Grid<>();
		
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.divPlaceholder1.setMaxHeight("50px");
		this.image.setSrc("frontend/images/ESRA_Logo.png");
		this.searchForm.setMaxWidth("1000px");
		this.txtSearchTerm.setClearButtonVisible(true);
		this.btnSearch.setText("Search");
		this.btnSearch.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSearch.setIcon(VaadinIcon.SEARCH.create());
		this.objActions.setMaxWidth("1000px");
		this.objActions.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.divPlaceholder2.setMaxHeight("50px");
		this.objFilterBar.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.lblOwn.setText("Screenings");
		this.lblOwn.getStyle().set("margin-right", ".5em");
		this.switchAllOrOwnScreenings.setRenderer(
			new TextRenderer<>(ItemLabelGeneratorFactory.NonNull(CaptionUtils::resolveCaption)));
		this.selectLob.setPlaceholder("Line of Business");
		this.selectLob.setMaxWidth("250px");
		this.selectLob.setClearButtonVisible(true);
		this.selectLob.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(LineOfBusiness::getName));
		this.selectFunction.setPlaceholder("Function");
		this.selectFunction.setMaxWidth("250px");
		this.selectFunction.setClearButtonVisible(true);
		this.selectFunction.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(Function::getName));
		this.selectOffice.setPlaceholder("Office");
		this.selectOffice.setMaxWidth("250px");
		this.selectOffice.setClearButtonVisible(true);
		this.selectOffice.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(OE::getName));
		this.selectStatus.setPlaceholder("Screening Status");
		this.selectStatus.setMaxWidth("250px");
		this.selectStatus.setClearButtonVisible(true);
		this.selectStatus.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(ScreeningStatus::getStatus));
		this.lblResult.setText("No results...");
		this.lblResult.getStyle().set("margin-left", "2em");
		this.gridSearchResults.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridSearchResults.getStyle().set("flex-basis", "0");
		this.gridSearchResults.addColumn(ScreeningSearchResult::getId).setKey("id").setHeader(
			CaptionUtils.resolveCaption(ScreeningSearchResult.class, "id")).setResizable(true).setSortable(
				true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(ScreeningSearchResult::getName).setKey("name").setHeader(
			CaptionUtils.resolveCaption(ScreeningSearchResult.class, "name")).setResizable(true).setSortable(true);
		this.gridSearchResults.addColumn(RenderedComponent.Renderer(RendererScreeningSearchResult::new)).setKey(
			"matches").setHeader("Matches").setResizable(true).setSortable(false);
		this.gridSearchResults.addColumn(ScreeningSearchResult::getScreeningDate).setKey("screeningDate").setHeader(
			CaptionUtils.resolveCaption(ScreeningSearchResult.class, "screeningDate")).setResizable(true).setSortable(
				true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningSearchResult::getLob).map(LineOfBusiness::getName).orElse(
				null)).setKey("lob.name").setHeader(
					CaptionUtils.resolveCaption(ScreeningSearchResult.class, "lob.name")).setResizable(true).setSortable(
						true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningSearchResult::getFunction).map(Function::getName).orElse(null)).setKey(
				"function.name").setHeader(
					CaptionUtils.resolveCaption(ScreeningSearchResult.class, "function.name")).setResizable(
						true).setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningSearchResult::getOe).map(OE::getName).orElse(null)).setKey(
				"oe.name").setHeader(CaptionUtils.resolveCaption(ScreeningSearchResult.class, "oe.name")).setResizable(
					true).setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningSearchResult::getStatus).map(ScreeningStatus::getStatus).orElse(
				null)).setKey("status.status").setHeader(
					CaptionUtils.resolveCaption(ScreeningSearchResult.class, "status.status")).setResizable(
						true).setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.addColumn(RenderedComponent.Renderer(RendererScreeningSearchResultAction::new)).setKey(
			"renderer").setSortable(false).setAutoWidth(true).setFlexGrow(0);
		this.gridSearchResults.setSelectionMode(Grid.SelectionMode.SINGLE);
		
		this.txtSearchTerm.setSizeUndefined();
		this.btnSearch.setSizeUndefined();
		this.searchForm.add(this.txtSearchTerm, this.btnSearch);
		this.searchForm.setFlexGrow(1.0, this.txtSearchTerm);
		this.lblOwn.setSizeUndefined();
		this.objAllOrOwnFilter.add(this.lblOwn, this.switchAllOrOwnScreenings);
		this.objAllOrOwnFilter.setSizeUndefined();
		this.selectLob.setSizeUndefined();
		this.selectFunction.setSizeUndefined();
		this.selectOffice.setSizeUndefined();
		this.selectStatus.setSizeUndefined();
		this.lblResult.setSizeUndefined();
		this.objFilterBar.add(
			this.objAllOrOwnFilter,
			this.selectLob,
			this.selectFunction,
			this.selectOffice,
			this.selectStatus,
			this.lblResult);
		this.objFilterBar.setFlexGrow(1.0, this.selectLob);
		this.objFilterBar.setFlexGrow(1.0, this.selectFunction);
		this.objFilterBar.setFlexGrow(1.0, this.selectOffice);
		this.objFilterBar.setFlexGrow(1.0, this.selectStatus);
		this.divPlaceholder1.setSizeUndefined();
		this.image.setWidth(null);
		this.image.setHeight("120px");
		this.searchForm.setWidth("80%");
		this.searchForm.setHeight(null);
		this.objActions.setWidth("80%");
		this.objActions.setHeight(null);
		this.divPlaceholder2.setSizeUndefined();
		this.objFilterBar.setSizeUndefined();
		this.gridSearchResults.setSizeUndefined();
		this.add(
			this.divPlaceholder1,
			this.image,
			this.searchForm,
			this.objActions,
			this.divPlaceholder2,
			this.objFilterBar,
			this.gridSearchResults);
		this.setFlexGrow(1.0, this.divPlaceholder1);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.image);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.searchForm);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.objActions);
		this.setFlexGrow(1.0, this.divPlaceholder2);
		this.setFlexGrow(7.0, this.gridSearchResults);
		this.setSizeFull();
		
		this.txtSearchTerm.addValueChangeListener(this::txtSearchTerm_valueChanged);
		this.btnSearch.addClickListener(this::btnSearch_onClick);
		this.switchAllOrOwnScreenings.addValueChangeListener(this::switchAllOrOwnScreenings_valueChanged);
		this.selectLob.addValueChangeListener(this::selectLob_valueChanged);
		this.selectFunction.addValueChangeListener(this::selectFunction_valueChanged);
		this.selectOffice.addValueChangeListener(this::selectOffice_valueChanged);
		this.selectStatus.addValueChangeListener(this::selectStatus_valueChanged);
		this.gridSearchResults.addSelectionListener(this::gridSearchResults_selectionChange);
	} // </generated-code>

	// <generated-code name="variables">
	private ComboBox<Function>									selectFunction;
	private Button												btnSearch;
	private Image												image;
	private HorizontalLayout									searchForm, objActions, objFilterBar;
	private Div													divPlaceholder1, divPlaceholder2, objAllOrOwnFilter;
	private Label												lblOwn, lblResult;
	private Grid<ScreeningSearchResult<ScreeningMetadataBase>>	gridSearchResults;
	private ComboBox<LineOfBusiness>							selectLob;
	private ComboBox<OE>										selectOffice;
	private TextField											txtSearchTerm;
	private RadioButtonGroup<String>							switchAllOrOwnScreenings;
	private ComboBox<ScreeningStatus>							selectStatus;
	// </generated-code>
	
}
