
package com.caweco.esra.subsidary.frontend;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.tinylog.Logger;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.common.usertask.UserTask;


public class SubsidiaryScreeningCachedTask implements UserTask
{

	AtomicBoolean            cancelTask        = new AtomicBoolean(false);
	AtomicReference<String>  cancelledNote     = new AtomicReference<>();
	AtomicReference<Instant> cancelRequestedAt = new AtomicReference<>();
	AtomicBoolean            cancelledOnError     = new AtomicBoolean(false);

	public static SubsidiaryScreeningCachedTask New(
		final User user,
		final UUID client,
		final Screening screening,
		final SearchEntryCompany company)
	{
		final SubsidiaryScreeningCachedTask subsidiaryScreening = new SubsidiaryScreeningCachedTask(
			user.getEmailAddress(), client, screening, company.getId(), company.getItem());
		return subsidiaryScreening;
	}

	protected final SubsidiaryScreeningTaskF wrapped;
	public CIResponse root_;

	protected SubsidiaryScreeningCachedTask(
		final String userId,
		final UUID clientId,
		final Screening screening,
		final UUID searchEntryCompanyId,
		final CIResponse root)
	{
		this.wrapped    = new SubsidiaryScreeningTaskF(userId, clientId,
			(screening != null ? screening.getScreeningID() : null), searchEntryCompanyId, root);
		this.root_ = root;
	}

	/**
	 * For standalone start
	 * 
	 * @return
	 */
	public SubsidiaryScreeningCachedTask start()
	{
		if(this.wrapped.getState() != SubsidiaryScreeningTaskState.RUNNING)
		{
			throw new UnsupportedOperationException("Not able to start Task with state " + this.wrapped.getState());
		}

		CompletableFuture.runAsync(SubsidiaryScreeningRunnable.New(this));

		return this;
	}

	public SubsidiaryScreeningTaskState getState()
	{
		return this.wrapped.getState();
	}

	@Override
	public UUID getId()
	{
		return this.wrapped.getId();
	}

	public String getUserId()
	{
		return this.wrapped.getCreatedBy();
	}

	public SubsidiaryScreeningTaskF getWrapped()
	{
		return this.wrapped;
	}

	@Override
	public Instant getCreated()
	{
		return this.wrapped.getCreated();
	}

	public UUID getClientId()
	{
		return this.wrapped.getClientId();
	}

	public UUID getScreeningId()
	{
		return this.wrapped.getScreeningId();
	}

	public UUID getSearchEntryCompanyId()
	{
		return this.wrapped.getSearchEntryCompanyId();
	}


	public void cancelTask(final String user)
	{
		cancelTaskC("Cancelled by " + user, false);
	}
	
	public void cancelTaskC(final String note, boolean byError)
	{
		Logger.error("TASK CANCELLATION REQUESTED! " + note);
		cancelledOnError.set(byError);
		this.cancelTask.set(false);
		this.cancelledNote.set(note);
		this.cancelRequestedAt.set(Instant.now());
	}

	@Override
	public String getUser()
	{
		return this.wrapped.getCreatedBy();
	}

	@Override
	public String getSummary()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Subsidiary Screening Task (Local)");
//		sb.append("Client: ").append(getClientId()).append("\\n");
//		sb.append("Screening: ").append(getScreeningId()).append("\\n");
//		sb.append("Company: ").append(this.wrapped.getRootCompanyName()).append(" / ").append(this.wrapped.getRootBvdId()).append("\\n");
		return sb.toString();
	}
}
