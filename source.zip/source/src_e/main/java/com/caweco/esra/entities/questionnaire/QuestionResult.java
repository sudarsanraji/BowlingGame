package com.caweco.esra.entities.questionnaire;

import java.util.Objects;

import com.rapidclipse.framework.server.resources.Caption;


public class QuestionResult
{
	
	private Question	question;
	private Answer		answer;
	private Boolean		completed	= false;
	
	@Caption("Question")
	public Question getQuestion()
	{
		return this.question;
	}
	
	public void setQuestion(final Question question)
	{
		this.question = question;
	}
	
	@Caption("Answer")
	public Answer getAnswer()
	{
		return this.answer;
	}
	
	public void setAnswer(final Answer answer)
	{
		this.answer = answer;
	}
	
	@Caption("Completed")
	public Boolean getCompleted()
	{
		return this.completed;
	}
	
	public void setCompleted(final Boolean completed)
	{
		this.completed = completed;
	}

	@Override
	public int hashCode() {
		return Objects.hash(question);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuestionResult other = (QuestionResult) obj;
		return Objects.equals(question, other.question);
	}

	
	
	
	
	
	
}
