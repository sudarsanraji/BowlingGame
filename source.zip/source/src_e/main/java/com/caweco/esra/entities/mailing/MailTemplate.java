package com.caweco.esra.entities.mailing;



/**
 * Contains text snippets for mail body and topic for a certain {@link MailType}.<br />
 * The text snippets may contain placeholder defined in {@link MailTypeConfig#getAvailablePlaceholder(MailType)}.
 *
 */
public class MailTemplate
{
	private String	header;
	private String	body;
	
	public String getHeader()
	{
		return this.header;
	}
	
	public void setHeader(String header)
	{
		this.header = header;
	}
	
	public String getBody()
	{
		return this.body;
	}
	
	public void setBody(String body)
	{
		this.body = body;
	}
}
