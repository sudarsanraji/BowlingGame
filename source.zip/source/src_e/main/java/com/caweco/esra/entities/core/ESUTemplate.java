package com.caweco.esra.entities.core;

public class ESUTemplate
{
	private int		id;
	private String	name;
	private String	content;
	private boolean	active	= true;
	private int		version	= 1;
	
	public ESUTemplate()
	{
		super();
	}
	
	
	
	public ESUTemplate(int id, String name, boolean active, int version, String content) {
		super();
		this.id = id;
		this.name = name;
		this.content = content;
		this.active = active;
		this.version = version;
	}



	public int getId()
	{
		return id;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	public int getVersion()
	{
		return version;
	}
	
	public void setVersion(int version)
	{
		this.version = version;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getContent()
	{
		return content;
	}
	
	public void setContent(String content)
	{
		this.content = content;
	}

	public boolean isActive()
	{
		return active;
	}
	
	public void setActive(boolean active)
	{
		this.active = active;
	}
}
