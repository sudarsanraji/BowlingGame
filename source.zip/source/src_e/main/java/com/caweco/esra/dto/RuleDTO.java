package com.caweco.esra.dto;

import java.util.HashSet;
import java.util.Set;

public class RuleDTO {
	private Set<ANDConditionDTO> ands = new HashSet<>();

	public Set<ANDConditionDTO> getAnds() {
		return ands;
	}

	public void setAnds(Set<ANDConditionDTO> ands) {
		this.ands = ands;
	}
	
	
}
