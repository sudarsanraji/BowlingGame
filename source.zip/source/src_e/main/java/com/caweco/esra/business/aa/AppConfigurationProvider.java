package com.caweco.esra.business.aa;

import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.User;
import com.rapidclipse.framework.security.authorization.AuthorizationConfiguration;
import com.rapidclipse.framework.security.authorization.AuthorizationConfigurationProvider;
import com.rapidclipse.framework.server.security.authorization.AuthorizationResource;


public class AppConfigurationProvider implements AuthorizationConfigurationProvider
{
	private static AppConfigurationProvider INSTANCE;
	
	public static AppConfigurationProvider getInstance()
	{
		if(AppConfigurationProvider.INSTANCE == null)
		{
			AppConfigurationProvider.INSTANCE = new AppConfigurationProvider();
		}
		
		return AppConfigurationProvider.INSTANCE;
	}
	
	private Authorizer provider;
	
	private AppConfigurationProvider()
	{
	}
	
	@Override
	public AuthorizationConfiguration provideConfiguration()
	{
		if(this.provider == null)
		{
			this.provider = new Authorizer(User.class, Role.class, AuthorizationResource.class);
		}
		
		return this.provider.provideConfiguration();
	}
}
