package com.caweco.esra.ui.beans;

import java.beans.Beans;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.messaging.MessagingMode;
import com.caweco.esra.business.func.messaging.MessagingUtil;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.splitlayout.SplitLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.textfield.TextArea;

public class PartEsuMessagingMain extends VerticalLayout
{
	private Screening item;
	private MessagingMode mode;

	//// GUI
	private final PartMessagesAll<Screening> objMessageViewer;
	private final PartMessageCategoryManager objMessageCategoryManager;

	public PartEsuMessagingMain()
	{
		super();
		this.initUI();

		// override
		this.taNewMessage.getStyle().set("height", "calc(100% - var(--lumo-space-xs)*2)");

		// Viewer
		this.objMessageViewer = new PartMessagesAll<>(this.item);
		this.splitLayout.addToPrimary(this.objMessageViewer);
		this.objMessageViewer.setEnabled(false);

		// Creator
		this.objMessageCreator.setEnabled(false);
		// Manager

		this.objMessageCategoryManager = new PartMessageCategoryManager().connect(this);
		this.div.add(this.objMessageCategoryManager);

		// Chooser
		if (!Beans.isDesignTime())
		{
			if (!AuthorizationUtil.isEsuUser())
			{
				this.tabPrivate.setVisible(false);
				this.tabPublic.setVisible(false);
			}
		}

		UiHelper.setAriaLabel(this.btnSaveMessage, Aria.get("Messaging_msg_save"));
	}

	public void setItem(final Screening item)
	{
		this.item = item;
		if (this.item == null)
		{
			// enable/disable
			this.objMessageCategoryChooser.setEnabled(false);
			this.objMessageViewer.setEnabled(false);
			this.objMessageCreator.setEnabled(false);
			this.objMessageCategoryManager.reset();

		}
		else
		{
			this.objMessageCategoryChooser.setEnabled(true);
			this.objMessageCategoryManager.handleItemChange();
			// TODO: check if user has Permission to see/edit messages

			//// Init with "Groups" tab
			this.toGroup(Optional.empty());
			//// select "Requestor" group if available
			this.objMessageCategoryManager.selectRequestorGroup();

		}
	}

	public Screening getItem()
	{
		return this.item;
	}

	public MessagingMode getMode()
	{
		return this.mode;
	}

	/**
	 * <b>This was changed to always show the groups tab.</b>
	 */
	public void backToPublic()
	{
		//(2022-10-27 MH): Non-ESU members may not see the public tab, so we're pointing this to the groups tab instead
		//(2023-02-07 MH): This was changed to always show the groups tab.
		this.objMessageCategoryChooser.setSelectedTab(this.tabGroups);
	}

	/**
	 * Go to "Group" tab and select group
	 * 
	 * @param group
	 */
	public void toGroup(final Optional<MessageGroup> group)
	{
		this.objMessageCategoryChooser.setSelectedTab(this.tabGroups);
		if (group.isPresent())
		{
			this.objMessageCategoryManager.selectGroup(group.get());
		}
	}

	public PartMessagesAll<Screening> getMessageViewer()
	{
		return this.objMessageViewer;
	}

	public VerticalLayout getNotAMemberLayout()
	{
		return this.vlNotAMember;
	}

	public Div getMessageCreator()
	{
		return this.objMessageCreator;
	}

	
	/**
	 * For direct access by link
	 *  
	 * @param group
	 */
	public void selectGroup(final String group)
	{
		final String groupClean = StringUtils.stripToNull(group);
		if (StringUtils.equalsIgnoreCase("pg", groupClean))
		{
			this.backToPublic();
		}
		else
		{
			try
			{
				final UUID groupID = UUID.fromString(groupClean);

				final Optional<MessageGroup> optional = Optional.of(MessageGroupDAO.findById(this.item, groupID));
				this.toGroup(optional);

			}
			catch (final Exception e)
			{
				Logger.warn("Cannot decode GroupID \"{}\".", groupClean);
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link Tabs}
	 * {@link #objMessageCategoryChooser}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void objMessageCategoryChooser_onSelectedChange(final SelectedChangeEvent event)
	{
		final Tab selectedTab = event.getSelectedTab();
		if (selectedTab == null)
		{
			this.mode = MessagingMode.UNSET;
		}
		else if (selectedTab == this.tabGroups)
		{
			this.mode = MessagingMode.GROUP;
		}
		else if (selectedTab == this.tabPublic)
		{
			this.mode = MessagingMode.PUBLIC;
		}
		else if (selectedTab == this.tabPrivate)
		{
			this.mode = MessagingMode.PRIVATE;
		}

		if (this.objMessageCategoryManager != null)
		{
			this.objMessageCategoryManager.handleModeChange();
		}
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSaveMessage}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSaveMessage_onClick(final ClickEvent<Button> event)
	{

		final String value = StringUtils.trimToNull(this.taNewMessage.getValue());

		if (value == null)
		{
			Notificator.error("Text is empty. Please insert some text!");
		}
		else
		{
			//// Create object
			final Message message = new Message(CurrentUtil.getUser()).setMessage(value);

			//// Update GUI
			this.objMessageCategoryManager.handleNewMessage(message);
			this.taNewMessage.setValue("");
		}
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnJoinGroup}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnJoinGroup_onClick(final ClickEvent<Button> event)
	{
		final var group = this.objMessageCategoryManager.getSelectedItem();
		if (group != null)
		{
			MessagingUtil.addUserToGroup(group, List.of(CurrentUtil.getUser()));
			this.objMessageCreator.setVisible(true);
			this.vlNotAMember.setVisible(false);
		}
		else
		{
			Notificator.error("No group has been selected!");
		}
	}

	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.lblHead = new Label();
		this.objMessageCategoryChooser = new Tabs();
		this.tabGroups = new Tab();
		this.tabPublic = new Tab();
		this.tabPrivate = new Tab();
		this.div = new Div();
		this.splitLayout = new SplitLayout();
		this.verticalLayout = new VerticalLayout();
		this.vlNotAMember = new VerticalLayout();
		this.label = new Label();
		this.btnJoinGroup = new Button();
		this.objMessageCreator = new Div();
		this.btnSaveMessage = new Button();
		this.taNewMessage = new TextArea();

		this.setSpacing(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.lblHead.setText("Communication");
		this.objMessageCategoryChooser.setClassName("custom1");
		this.objMessageCategoryChooser.getStyle().set("margin-bottom", "var(--lumo-space-s)");
		this.tabGroups.setFlexGrow(1.0);
		this.tabGroups.setClassName("menu");
		this.tabGroups.setLabel("My message groups");
		this.tabGroups.getStyle().set("flex-basis", "0");
		this.tabPublic.setFlexGrow(1.0);
		this.tabPublic.setClassName("menu");
		this.tabPublic.setLabel("ESU comments");
		this.tabPublic.getStyle().set("flex-basis", "0");
		this.tabPrivate.setFlexGrow(1.0);
		this.tabPrivate.setClassName("menu");
		this.tabPrivate.setLabel("My notes");
		this.tabPrivate.getStyle().set("flex-basis", "0");
		this.splitLayout.setOrientation(SplitLayout.Orientation.VERTICAL);
		this.verticalLayout.setMinWidth("100%");
		this.vlNotAMember.setVisible(false);
		this.label.setText("You're not part of this group yet, please join the group to send messages.");
		this.btnJoinGroup.setText("Join Group");
		this.objMessageCreator.getStyle().set("position", "relative");
		this.btnSaveMessage.getStyle().set("position", "absolute");
		this.btnSaveMessage.getStyle().set("right", "1em");
		this.btnSaveMessage.getStyle().set("bottom", "1em");
		this.btnSaveMessage.getStyle().set("z-index", "100");
		this.btnSaveMessage.setIcon(IronIcons.SAVE.create());
		this.taNewMessage.getStyle().set("height", "calc(100% - var(--lumo-space-xs)*2)");

		this.objMessageCategoryChooser.add(this.tabGroups, this.tabPublic, this.tabPrivate);
		this.label.setSizeUndefined();
		this.btnJoinGroup.setSizeUndefined();
		this.vlNotAMember.add(this.label, this.btnJoinGroup);
		this.vlNotAMember.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.vlNotAMember.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.btnJoinGroup);
		this.btnSaveMessage.setSizeUndefined();
		this.taNewMessage.setSizeFull();
		this.objMessageCreator.add(this.btnSaveMessage, this.taNewMessage);
		this.vlNotAMember.setSizeFull();
		this.objMessageCreator.setSizeFull();
		this.verticalLayout.add(this.vlNotAMember, this.objMessageCreator);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.vlNotAMember);
		this.splitLayout.addToSecondary(this.verticalLayout);
		this.splitLayout.setSplitterPosition(70.0);
		this.lblHead.setSizeUndefined();
		this.objMessageCategoryChooser.setWidthFull();
		this.objMessageCategoryChooser.setHeight(null);
		this.div.setWidthFull();
		this.div.setHeight(null);
		this.splitLayout.setSizeUndefined();
		this.add(this.lblHead, this.objMessageCategoryChooser, this.div, this.splitLayout);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.START, this.lblHead);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH, this.splitLayout);
		this.setFlexGrow(1.0, this.splitLayout);
		this.setSizeFull();

		this.objMessageCategoryChooser.setSelectedIndex(-1);

		this.objMessageCategoryChooser.addSelectedChangeListener(this::objMessageCategoryChooser_onSelectedChange);
		this.btnJoinGroup.addClickListener(this::btnJoinGroup_onClick);
		this.btnSaveMessage.addClickListener(this::btnSaveMessage_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button btnJoinGroup, btnSaveMessage;
	private SplitLayout splitLayout;
	private Tab tabGroups, tabPublic, tabPrivate;
	private TextArea taNewMessage;
	private VerticalLayout verticalLayout, vlNotAMember;
	private Label lblHead, label;
	private Div div, objMessageCreator;
	private Tabs objMessageCategoryChooser;
	// </generated-code>

}
