package com.caweco.esra.entities.esra.seaweb2;

import java.time.Instant;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import com.rapidclipse.framework.server.resources.Caption;

public class ComplianceScreeningKeyData
{
	private final Instant created     = Instant.now();
	
	boolean               active      = true;
	
	private String        key;
	private String        humanReadable;
	private String        description;
	
	private Set<Integer>  availableValues = new HashSet<>();
	private int           minValueForRed  = 2;
	
	private Instant       lastChanged;
	private String        lastChangedBy;
	
	
	public ComplianceScreeningKeyData()
	{
		super();
	}
	
	
	public boolean isActive()
	{
		return this.active;
	}
	
	
	public void setActive(final boolean active)
	{
		this.active = active;
	}
	
	
	public String getKey()
	{
		return this.key;
	}
	
	
	public void setKey(final String key)
	{
		this.key = key;
	}
	
	@Caption("Field Name")
	public String getHumanReadable()
	{
		return this.humanReadable;
	}
	
	
	public void setHumanReadable(final String humanReadable)
	{
		this.humanReadable = humanReadable;
	}
	
	public String getDescription()
	{
		return this.description;
	}


	public void setDescription(final String description)
	{
		this.description = description;
	}


	public Set<Integer> getAvailableValues()
	{
		return this.availableValues;
	}
	
	
	public void setAvailableValues(final Set<Integer> availableValues)
	{
		this.availableValues = availableValues;
	}
	
	
	public int getMinValueForRed()
	{
		return this.minValueForRed;
	}
	
	
	public void setMinValueForRed(final int minValueForRed)
	{
		this.minValueForRed = minValueForRed;
	}
	
	
	public Instant getLastChanged()
	{
		return this.lastChanged;
	}
	
	
	public void setLastChanged(final Instant lastChanged)
	{
		this.lastChanged = lastChanged;
	}
	
	
	public String getLastChangedBy()
	{
		return this.lastChangedBy;
	}
	
	
	public void setLastChangedBy(final String lastChangedBy)
	{
		this.lastChangedBy = lastChangedBy;
	}
	
	
	public Instant getCreated()
	{
		return this.created;
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.key);
	}

	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(this.getClass() != obj.getClass())
		{
			return false;
		}
		final ComplianceScreeningKeyData other = (ComplianceScreeningKeyData)obj;
		return Objects.equals(this.key, other.key);
	}
	
	
	
}
