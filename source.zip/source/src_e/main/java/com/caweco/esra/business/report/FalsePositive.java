package com.caweco.esra.business.report;

public class FalsePositive
{
	public static class Builder
	{
		private String name;
		private double hitscore;
		private String type;
		private String reason;
		private String factivalId;

		public Builder withName(final String name)
		{
			this.name = name;
			return this;
		}

		public Builder withHitscore(final double hitscore)
		{
			this.hitscore = hitscore;
			return this;
		}

		public Builder withType(final String type)
		{
			this.type = type;
			return this;
		}

		public Builder withReason(final String reason)
		{
			this.reason = reason;
			return this;
		}

		public Builder withFactivalId(final String factivalId)
		{
			this.factivalId = factivalId;
			return this;
		}

		public FalsePositive build()
		{
			return new FalsePositive(this.name, this.hitscore, this.type, this.reason, this.factivalId);
		}
	}

	private final String name;
	private final double hitscore;
	private final String type;
	private final String reason;
	private final String factivalId;

	public FalsePositive(
		final String name,
		final double hitscore,
		final String type,
		final String reason,
		final String factivalId
	)
	{
		this.name = name;
		this.hitscore = hitscore;
		this.type = type;
		this.reason = reason;
		this.factivalId = factivalId;
	}

	public String getName()
	{
		return this.name;
	}

	public double getHitscore()
	{
		return this.hitscore;
	}

	public String getType()
	{
		return this.type;
	}

	public String getReason()
	{
		return this.reason;
	}

	public String getFactivalId()
	{
		return this.factivalId;
	}
}
