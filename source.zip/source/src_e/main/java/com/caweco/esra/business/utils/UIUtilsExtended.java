package com.caweco.esra.business.utils;

import java.util.Objects;
import java.util.function.Function;

import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.Component;


public class UIUtilsExtended
{
	/**
	 * Basically the same functionality as {@link UIUtils#lookupComponentTree(Component, Class, Function)} <br />
	 * - with one difference: <br />
	 * Here, the <code>visitor</code> is <i>NOT</i> invoked for the given parent (the root) even it fits the
	 * <code>type</code> parameter.
	 * 
	 * @see UIUtils#lookupComponentTree(Component, Class, Function)
	 * @param <C>
	 * @param <T>
	 * @param parent
	 *            The root of the component tree to visit
	 * @param type
	 * @param visitor
	 * @return
	 */
	public static <C, T> T lookupComponentTree(
		final Component parent,
		final Class<C> type,
		final Function<C, T> visitor)
	{
		T value = null;
		
		if(value == null)
		{
			value = parent.getChildren().map(child -> UIUtils.lookupComponentTree(child, type, visitor)).filter(
				Objects::nonNull).findFirst().orElse(null);
		}
		
		return value;
	}
}
