package com.caweco.esra.dto;

import java.time.Instant;
import java.util.Map;

import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;
import com.caweco.esra.entities.rest.seaweb2.APSStatus_v2;
import com.caweco.esra.microstream.converters.GenericObjectKeyDeserializer;
import com.caweco.esra.microstream.converters.GenericObjectKeySerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class SearchEntrySeaweb2VesselDTO {
	private Instant created;
	private String createdBy;
	
	private APSShipDetail_v2 shipDetails;
	protected Integer shipCount;
	protected APSStatus_v2 apsStatus;
	
	private String entryComment;
	
	private String rating;
	private String ratingStatement;
	
	@JsonSerialize(keyUsing = GenericObjectKeySerializer.class)
	@JsonDeserialize(keyUsing = GenericObjectKeyDeserializer.class)
	private Map<String, Boolean> redFlagSettings_atFreeze;
	
	private String id;

	public Instant getCreated() {
		return this.created;
	}

	public void setCreated(final Instant created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}

	public APSShipDetail_v2 getShipDetails() {
		return this.shipDetails;
	}

	public void setShipDetails(final APSShipDetail_v2 shipDetails) {
		this.shipDetails = shipDetails;
	}

	public Integer getShipCount() {
		return this.shipCount;
	}

	public void setShipCount(final Integer shipCount) {
		this.shipCount = shipCount;
	}

	public APSStatus_v2 getApsStatus() {
		return this.apsStatus;
	}

	public void setApsStatus(final APSStatus_v2 apsStatus) {
		this.apsStatus = apsStatus;
	}

	public String getEntryComment() {
		return this.entryComment;
	}

	public void setEntryComment(final String entryComment) {
		this.entryComment = entryComment;
	}

	public String getRating() {
		return this.rating;
	}

	public void setRating(final String rating) {
		this.rating = rating;
	}

	public String getRatingStatement() {
		return this.ratingStatement;
	}

	public void setRatingStatement(final String ratingStatement) {
		this.ratingStatement = ratingStatement;
	}

	public Map<String, Boolean> getRedFlagSettings_atFreeze() {
		return this.redFlagSettings_atFreeze;
	}

	public void setRedFlagSettings_atFreeze(final Map<String, Boolean> redFlagSettings_atFreeze) {
		this.redFlagSettings_atFreeze = redFlagSettings_atFreeze;
	}

	public String getId() {
		return this.id;
	}

	public void setId(final String id) {
		this.id = id;
	}
	
	
}
