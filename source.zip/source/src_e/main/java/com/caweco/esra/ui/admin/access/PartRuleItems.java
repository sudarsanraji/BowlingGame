package com.caweco.esra.ui.admin.access;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.access.AccessControlCompanyDAO;
import com.caweco.esra.dao.access.AccessControlCountriesDAO;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.ldap.LdapOrg;
import com.caweco.esra.entities.saml.SamlCountry;
import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.caweco.esra.ui.dialogs.DialogContainer;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;


public class PartRuleItems extends VerticalLayout
{
	AccessControlCompany currentCompany;
	
	public PartRuleItems()
	{
		super();
		this.initUI();
		
		UiHelper.setAriaLabel(this.btnNewCompany, Aria.get("PageAccessControl_comp_add"));
		UiHelper.setAriaLabel(this.btnDeleteCompany, Aria.get("PageAccessControl_comp_remove"));
		UiHelper.setAriaLabel(this.btnNewDepartment, Aria.get("PageAccessControl_dep_add"));
		UiHelper.setAriaLabel(this.btnDeleteDepartment, Aria.get("PageAccessControl_dep_remove"));
		UiHelper.setAriaLabel(this.btnNewCountry, Aria.get("PageAccessControl_country_add"));
		UiHelper.setAriaLabel(this.btnDeleteCountry, Aria.get("PageAccessControl_country_remove"));
		
		//// Grid columns and sorting
		Column<AccessControlCompany> companyNameCol = this.gridCompany.addColumn(AccessControlCompany::getDisplayName)
			.setKey("displayName")
			.setSortable(true);
		this.gridCompany.sort(GridSortOrder.asc(companyNameCol).build());
		
		Column<LdapOrg> depNameColumn = this.gridDepartment.getColumnByKey("displayName");
		this.gridDepartment.sort(GridSortOrder.asc(depNameColumn).build());
		
		Column<SamlCountry> countryNameColumn = this.gridCountry.getColumnByKey("countryCode");
		this.gridCountry.sort(GridSortOrder.asc(countryNameColumn).build());
		
		//// Grid data
		this.gridCompany.setItems(AccessControlCompanyDAO.findAll());
		this.gridCountry.setItems(AccessControlCountriesDAO.findAll());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDeleteCompany}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDeleteCompany_onClick(ClickEvent<Button> event)
	{
		Optional<AccessControlCompany> firstSelectedItem = this.gridCompany.getSelectionModel().getFirstSelectedItem();
		if(firstSelectedItem.isPresent())
		{
			
			DialogConfirm.show(() ->
			{
				AccessControlCompanyDAO.delete(firstSelectedItem.get());
				
				Notificator.success("Removed company.");
				
				this.gridCompany.setItems(AccessControlCompanyDAO.findAll());
				this.gridDepartment.setItems(Collections.emptyList());
				// TODO: More UI Updates?
			},
				"Delete company \"" + firstSelectedItem.get().getRepresentation() + "\"?",
				"Deleting a company deletes also the Departments, but does not delete access- or Client-assignment rules!");
		}
		else
		{
			Notificator.error("No company selected.");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewCompany}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewCompany_onClick(ClickEvent<Button> event)
	{
		DialogNewLdapCompany.New()
			.setOnOk(dialog ->
			{
				this.gridCompany.setItems(AccessControlCompanyDAO.findAll());
				Notificator.success("New company saved!");
			})
			.open();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDeleteDepartment}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDeleteDepartment_onClick(ClickEvent<Button> event)
	{
		Optional<LdapOrg> firstSelectedItem = this.gridDepartment.getSelectionModel().getFirstSelectedItem();
		if(firstSelectedItem.isPresent())
		{
			if(this.currentCompany != null)
			{
				DialogConfirm.show(() ->
				{
					AccessControlCompanyDAO.removeChild(this.currentCompany, firstSelectedItem.get());
					
					Notificator.success("Removed company.");
				
					this.gridDepartment.setItems(this.currentCompany.getAllowedDepartments());
				},
					"Delete department \"" + firstSelectedItem.get().getDisplayName() + "\"?",
					"Deleting a department does not delete access- or Client-assignment rules!");
			}
			else
			{
				Notificator.error("Cannot obtain company for department.");
				Logger.error("Cannot obtain company for department \"{}\".", firstSelectedItem.get());
			}
		}
		else
		{
			Notificator.error("No department selected.");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewDepartment}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewDepartment_onClick(ClickEvent<Button> event)
	{
		if(this.currentCompany == null)
		{
			Notificator.error("No company selected.");
		}
		else
		{
			DialogNewLdapDepartment.New(this.currentCompany)
				.setOnOk(dialog ->
				{
					this.gridDepartment.setItems(this.currentCompany.getAllowedDepartments());
					Notificator.success("New department saved!");
				})
				.open();
			
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDeleteCountry}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDeleteCountry_onClick(ClickEvent<Button> event)
	{
		Optional<SamlCountry> firstSelectedItem = this.gridCountry.getSelectionModel().getFirstSelectedItem();
		if(firstSelectedItem.isPresent())
		{
			
			DialogConfirm.show(() ->
			{
				Set<SamlCountry> countries = AccessControlCountriesDAO.findAll();
				countries.remove(firstSelectedItem.get());
				
				AccessControlCountriesDAO.delete(firstSelectedItem.get());
				
				Notificator.success("Removed country.");
				
				this.gridCountry.setItems(countries);
			},
				"Delete country \"" + firstSelectedItem.get().getCountryName() + "\"?",
				"Deleting a country does not delete Client-assignment rules!");
		}
		else
		{
			Notificator.error("No country selected.");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewCountry}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewCountry_onClick(ClickEvent<Button> event)
	{
		DialogNewCountry dialogNewCountry = new DialogNewCountry();
		DialogContainer<DialogNewCountry> dialogContainer = new DialogContainer<>(dialogNewCountry);
		dialogContainer.onOk(dc ->
		{
			Set<SamlCountry> countries = AccessControlCountriesDAO.findAll();
			Notificator.success("Country added.");
			
			this.gridCountry.setItems(countries);
		});
		dialogContainer.open();
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCompany}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCompany_selectionChange(SelectionEvent<Grid<AccessControlCompany>, AccessControlCompany> event)
	{
		Optional<AccessControlCompany> firstSelectedItem = event.getFirstSelectedItem();
		this.currentCompany = firstSelectedItem.orElse(null);
		if (firstSelectedItem.isPresent())
		{
			this.gridDepartment.setItems(this.currentCompany.getAllowedDepartments());
		}
		else
		{
			this.gridDepartment.setItems(Collections.emptyList());
		}
		this.btnDeleteCompany.setEnabled(firstSelectedItem.isPresent());
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridDepartment}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridDepartment_selectionChange(SelectionEvent<Grid<LdapOrg>, LdapOrg> event)
	{
		Optional<LdapOrg> firstSelectedItem = event.getFirstSelectedItem();
		this.btnDeleteDepartment.setEnabled(firstSelectedItem.isPresent());
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridCountry}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridCountry_selectionChange(SelectionEvent<Grid<SamlCountry>, SamlCountry> event)
	{
		Optional<SamlCountry> firstSelectedItem = event.getFirstSelectedItem();
		this.btnDeleteCountry.setEnabled(firstSelectedItem.isPresent());
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.h3 = new H3();
		this.formCompany = new VerticalLayout();
		this.objActionsCompany = new HorizontalLayout();
		this.h5Company = new H4();
		this.btnDeleteCompany = new Button();
		this.btnNewCompany = new Button();
		this.gridCompany = new Grid<>(AccessControlCompany.class, false);
		this.formDepartment = new VerticalLayout();
		this.objActionsDepartment = new HorizontalLayout();
		this.h5Department = new H4();
		this.btnDeleteDepartment = new Button();
		this.btnNewDepartment = new Button();
		this.gridDepartment = new Grid<>(LdapOrg.class, false);
		this.hr = new Hr();
		this.formCountry = new VerticalLayout();
		this.objActionsCountry = new HorizontalLayout();
		this.h5Country = new H4();
		this.btnDeleteCountry = new Button();
		this.btnNewCountry = new Button();
		this.gridCountry = new Grid<>(SamlCountry.class, false);
		
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.h3.setClassName("esra");
		this.h3.setText("Items for Access- and Clientassignment rules");
		this.formCompany.setSpacing(false);
		this.formCompany.setPadding(false);
		this.formCompany.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.formCompany.getStyle().set("flex-basis", "0");
		this.objActionsCompany.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.h5Company.setClassName("esra");
		this.h5Company.setText("Company");
		this.btnDeleteCompany.setEnabled(false);
		this.btnDeleteCompany.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDeleteCompany.setIcon(VaadinIcon.TRASH.create());
		this.btnNewCompany.setIcon(VaadinIcon.PLUS.create());
		this.gridCompany.addThemeVariants(GridVariant.LUMO_COMPACT);
		this.gridCompany.getStyle().set("flex-basis", "0");
		this.gridCompany.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.formDepartment.setSpacing(false);
		this.formDepartment.setPadding(false);
		this.formDepartment.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.formDepartment.getStyle().set("flex-basis", "0");
		this.objActionsDepartment.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.h5Department.setClassName("esra");
		this.h5Department.setText("Departments of selected Company");
		this.btnDeleteDepartment.setEnabled(false);
		this.btnDeleteDepartment.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDeleteDepartment.setIcon(VaadinIcon.TRASH.create());
		this.btnNewDepartment.setIcon(VaadinIcon.PLUS.create());
		this.gridDepartment.addThemeVariants(GridVariant.LUMO_COMPACT);
		this.gridDepartment.getStyle().set("flex-basis", "0");
		this.gridDepartment.addColumn(LdapOrg::getDisplayName).setKey("displayName").setHeader("Department name")
			.setSortable(true);
		this.gridDepartment.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.formCountry.setSpacing(false);
		this.formCountry.setPadding(false);
		this.formCountry.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.formCountry.getStyle().set("flex-basis", "0");
		this.objActionsCountry.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.h5Country.setClassName("esra");
		this.h5Country.setText("Countries");
		this.btnDeleteCountry.setEnabled(false);
		this.btnDeleteCountry.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDeleteCountry.setIcon(VaadinIcon.TRASH.create());
		this.btnNewCountry.setIcon(VaadinIcon.PLUS.create());
		this.gridCountry.addThemeVariants(GridVariant.LUMO_COMPACT);
		this.gridCountry.getStyle().set("flex-basis", "0");
		this.gridCountry.addColumn(SamlCountry::getCountryCode).setKey("countryCode").setHeader("Country code").setResizable(true)
			.setSortable(true);
		this.gridCountry.addColumn(SamlCountry::getCountryName).setKey("countryName").setHeader("Country name").setResizable(true)
			.setSortable(true);
		this.gridCountry.setSelectionMode(Grid.SelectionMode.SINGLE);
		
		this.h5Company.setSizeUndefined();
		this.btnDeleteCompany.setSizeUndefined();
		this.btnNewCompany.setSizeUndefined();
		this.objActionsCompany.add(this.h5Company, this.btnDeleteCompany, this.btnNewCompany);
		this.objActionsCompany.setFlexGrow(1.0, this.h5Company);
		this.objActionsCompany.setSizeUndefined();
		this.gridCompany.setSizeUndefined();
		this.formCompany.add(this.objActionsCompany, this.gridCompany);
		this.formCompany.setFlexGrow(1.0, this.gridCompany);
		this.h5Department.setSizeUndefined();
		this.btnDeleteDepartment.setSizeUndefined();
		this.btnNewDepartment.setSizeUndefined();
		this.objActionsDepartment.add(this.h5Department, this.btnDeleteDepartment, this.btnNewDepartment);
		this.objActionsDepartment.setFlexGrow(1.0, this.h5Department);
		this.objActionsDepartment.setSizeUndefined();
		this.gridDepartment.setSizeUndefined();
		this.formDepartment.add(this.objActionsDepartment, this.gridDepartment);
		this.formDepartment.setFlexGrow(1.0, this.gridDepartment);
		this.h5Country.setSizeUndefined();
		this.btnDeleteCountry.setSizeUndefined();
		this.btnNewCountry.setSizeUndefined();
		this.objActionsCountry.add(this.h5Country, this.btnDeleteCountry, this.btnNewCountry);
		this.objActionsCountry.setFlexGrow(1.0, this.h5Country);
		this.objActionsCountry.setSizeUndefined();
		this.gridCountry.setSizeUndefined();
		this.formCountry.add(this.objActionsCountry, this.gridCountry);
		this.formCountry.setFlexGrow(1.0, this.gridCountry);
		this.h3.setSizeUndefined();
		this.formCompany.setSizeUndefined();
		this.formDepartment.setSizeUndefined();
		this.hr.setSizeUndefined();
		this.formCountry.setSizeUndefined();
		this.add(this.h3, this.formCompany, this.formDepartment, this.hr, this.formCountry);
		this.setFlexGrow(1.0, this.formCompany);
		this.setFlexGrow(1.0, this.formDepartment);
		this.setFlexGrow(1.0, this.formCountry);
		this.setSizeFull();
		
		this.btnDeleteCompany.addClickListener(this::btnDeleteCompany_onClick);
		this.btnNewCompany.addClickListener(this::btnNewCompany_onClick);
		this.gridCompany.addSelectionListener(this::gridCompany_selectionChange);
		this.btnDeleteDepartment.addClickListener(this::btnDeleteDepartment_onClick);
		this.btnNewDepartment.addClickListener(this::btnNewDepartment_onClick);
		this.gridDepartment.addSelectionListener(this::gridDepartment_selectionChange);
		this.btnDeleteCountry.addClickListener(this::btnDeleteCountry_onClick);
		this.btnNewCountry.addClickListener(this::btnNewCountry_onClick);
		this.gridCountry.addSelectionListener(this::gridCountry_selectionChange);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button                     btnDeleteCompany, btnNewCompany, btnDeleteDepartment, btnNewDepartment, btnDeleteCountry,
		btnNewCountry;
	private Grid<SamlCountry>          gridCountry;
	private Grid<AccessControlCompany> gridCompany;
	private VerticalLayout             formCompany, formDepartment, formCountry;
	private HorizontalLayout           objActionsCompany, objActionsDepartment, objActionsCountry;
	private H3                         h3;
	private Hr                         hr;
	private H4                         h5Company, h5Department, h5Country;
	private Grid<LdapOrg>              gridDepartment;
	// </generated-code>
	
}
