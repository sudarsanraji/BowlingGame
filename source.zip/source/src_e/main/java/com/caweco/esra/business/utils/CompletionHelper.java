
package com.caweco.esra.business.utils;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;


public class CompletionHelper
{
	public static <T> CompletionStage<List<T>> sequence(final List<CompletionStage<T>> stages)
	{
		// noinspection SuspiciousToArrayCall
		final CompletableFuture<Void> done =
			CompletableFuture.allOf(stages.toArray(new CompletableFuture[stages.size()]));
		
		return done.thenApply(v -> stages.stream()
			.map(CompletionStage::toCompletableFuture)
			.map(CompletableFuture::join)
			.collect(Collectors.<T>toList()));
	}
}
