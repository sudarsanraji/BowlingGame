package com.caweco.esra.business.func.data;

import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;


public class PresentationUtil
{
	public static String getRepresentation(final User it)
	{
		final String combined = Stream.of(it.getLastname(), it.getFirstname()).map(StringUtils::stripToNull).filter(
			Objects::nonNull).collect(Collectors.joining(", "));
		return combined != null ? combined : "[Not available/" + it.getEmailAddress() + "]";
	}
	
	public static String getRepresentation_ForPageHeader(final Screening it)
	{
		if (it == null)
		{
			return "";
		}
		
		StringBuilder sb = new StringBuilder();
		sb.append(it.getName());
		if (it.getOe() != null)
		{
			sb.append(" requested by ").append(it.getOe().getName());
		}
		if (it.getFunction() != null)
		{
			sb.append(" - ").append(it.getFunction().getName());
		}
		if (it.getLineOfBusiness() != null)
		{
			sb.append(" - ").append(it.getLineOfBusiness().getName());
		}
		if (it.getScreeningOwner() != null)
		{
			sb.append(" (").append(it.getScreeningOwner().getRepresentation()).append(")");
		}
		
		return sb.toString();
	}
	
	public static String getRepresentation_ForMailHeaderV1(final Screening it)
	{
		if (it == null)
		{
			return "";
		}
		
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		sb.append(it.getName() == null ? "" : it.getName());
		if (it.getOe() != null)
		{
			sb.append(" / ").append(it.getOe().getName());
		}
		if (it.getFunction() != null)
		{
			sb.append(" / ").append(it.getFunction().getName());
		}
		if (it.getLineOfBusiness() != null)
		{
			sb.append(" / ").append(it.getLineOfBusiness().getName());
		}
		sb.append("]");
		
		return sb.toString();
	}
	
	
	public static String getRepresentation_ForMainWatchlistHeader(final SearchEntrySeaweb2Vessel it)
	{
		
		if (it.getShipCount() > 0)
		{
			StringBuilder sb = new StringBuilder();
			sb.append(it.getShipDetails().getIHSLRorIMOShipNo());
			sb.append(" - ");
			sb.append(it.getShipDetails().getShipName());
			
			String flag = StringUtils.stripToNull(it.getShipDetails().getFlagName());
			String shipType = StringUtils.stripToNull(it.getShipDetails().getShiptypeLevel4());
			if (shipType != null)
			{
				sb.append(" - ").append(shipType);
			}
			if (flag != null)
			{
				sb.append(" - ").append(flag);
			}
			
			
			String representation = sb.toString();
			return representation;
		}
		else
		{
			String representation_notFound = it.getShipDetails().getIHSLRorIMOShipNo() + " - Not found";
			return representation_notFound;
		}
	}
}
