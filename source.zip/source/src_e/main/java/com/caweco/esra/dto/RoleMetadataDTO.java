package com.caweco.esra.dto;

import java.util.Set;

import com.caweco.esra.business.aa.AuthorizationResources;

public class RoleMetadataDTO {

	private String id;
	private String name;
	private String description;
	private Set<String> parentRoles;
	private Set<String> childRoles;
	private Set<AuthorizationResources> resources;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Set<String> getParentRoles() {
		return parentRoles;
	}
	public void setParentRoles(Set<String> parentRoles) {
		this.parentRoles = parentRoles;
	}
	public Set<String> getChildRoles() {
		return childRoles;
	}
	public void setChildRoles(Set<String> childRoles) {
		this.childRoles = childRoles;
	}
	public Set<AuthorizationResources> getResources() {
		return resources;
	}
	public void setResources(Set<AuthorizationResources> resources) {
		this.resources = resources;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
