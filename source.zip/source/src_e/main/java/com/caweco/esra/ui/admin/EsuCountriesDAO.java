package com.caweco.esra.ui.admin;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.entities.Client;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class EsuCountriesDAO {
	
	public static void removeCountry(Client client, String value) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		String replace = StringUtils.replace(value, "/", "#");
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/esuCountry/" + replace);
		
		Response response = webTarget.request().delete();
		System.out.println(response);
	}

	public static void addCountry(Client client, String value) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/esuCountry/");
		
		Response response = webTarget.request().post(Entity.entity(value, MediaType.APPLICATION_JSON));
		System.out.println(response);
	}
	
	
}
