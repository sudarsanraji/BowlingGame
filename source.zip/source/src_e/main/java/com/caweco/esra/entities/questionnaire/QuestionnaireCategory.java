package com.caweco.esra.entities.questionnaire;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.rapidclipse.framework.server.resources.Caption;


public enum QuestionnaireCategory
{
	TRADE_SANCTION("Trade Sanction"),
	BUSINESS_INFORMATION("Business Information");
	
	private String category;
	
	private QuestionnaireCategory(String category)
	{
		this.category = category;
	}
	
	@Caption("Category")
	public String getCategory()
	{
		return this.category;
	}
	
	public static Stream<QuestionnaireCategory> stream()
	{
		return Stream.of(QuestionnaireCategory.values());
	}
	
	public static List<QuestionnaireCategory> asList_byCategory()
	{
		return QuestionnaireCategory.stream()
			.sorted(Comparator.comparing(QuestionnaireCategory::getCategory, Comparator.naturalOrder()))
			.collect(Collectors.toList());
	}
}
