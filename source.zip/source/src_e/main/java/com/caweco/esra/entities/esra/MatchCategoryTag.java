package com.caweco.esra.entities.esra;

import java.util.Objects;

import com.caweco.esra.entities.rest.general.GsssMatch;
import com.rapidclipse.framework.server.resources.Caption;

/**
 * Configuration item for the representation and handling of items in {@link GsssMatch#getCategories()}.<br />
 * This configuration can be changes in backend and configures
 * <ul>
 * <li>how the category entries are handled (if category is a reason for a red flag)</ li><li>how the category is
 * painted in the UI (css colors)</li>
 * </ul>
 *
 */
public class MatchCategoryTag
{
	// Representation
	private String	tag;
	private String	color;
	private String	cssClass;
	
	// Data
	private int		weight	= 0;
	private String	searchString;
	private boolean	redFlag	= false;
	
	public MatchCategoryTag()
	{
		super();
	}
	
	public MatchCategoryTag(int weight, String tag, String searchString, String color, boolean redFlag)
	{
		super();
		this.weight = weight;
		this.tag = tag;
		this.searchString = searchString;
		this.color = color;
		this.redFlag = redFlag;
	}
	
	@Caption("Tag")
	public String getTag()
	{
		return this.tag;
	}
	
	public void setTag(String tag)
	{
		this.tag = tag;
	}
	
	@Caption("Css color")
	public String getColor()
	{
		return this.color;
	}
	
	public void setColor(String color)
	{
		this.color = color;
	}
	
	public String getCssClass()
	{
		return this.cssClass;
	}
	
	public void setCssClass(String cssClass)
	{
		this.cssClass = cssClass;
	}
	
	public String getSearchString()
	{
		return this.searchString;
	}
	
	public void setSearchString(String searchString)
	{
		this.searchString = searchString;
	}
	
	public boolean isRedFlag()
	{
		return this.redFlag;
	}
	
	public void setRedFlag(boolean redFlag)
	{
		this.redFlag = redFlag;
	}
	
	@Caption("Weight")
	public int getWeight()
	{
		return this.weight;
	}
	
	public void setWeight(int weight)
	{
		this.weight = weight;
	}

	@Override
	public int hashCode() {
		return Objects.hash(tag);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MatchCategoryTag other = (MatchCategoryTag) obj;
		return Objects.equals(tag, other.tag);
	}
	
	
}
