
package com.caweco.esra.dev.ui;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;

import org.tinylog.Logger;

import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.usernotifications.UserNotificationManager;
import com.caweco.esra.business.utils.ChronoUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.LineOfBusinessDAO;
import com.caweco.esra.dao.core.FunctionDAO;
import com.caweco.esra.dao.core.OeDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dev.mockup.MockDataProviderCompany;
import com.caweco.esra.dev.ui.subsidiaries.RendererTaskDuration;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyInfo;
import com.caweco.esra.subsidary.common.usernotifications.UserNotification;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningCachedTask;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;
import com.caweco.esra.subsidary.frontend.SubsidiaryTaskManager;
import com.rapidclipse.framework.server.data.renderer.CaptionRenderer;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.shared.Registration;


@AccessibleRule(appAdmin = true)
@PageTitle("DEV: Subsidiary Screening Measurements | ESRA")
@Route("checkSubsidiaries1")
@SuppressWarnings("ucd") // dev page
public class Check_Subsidiaries extends HorizontalLayout
{
	
	// Map<String, CIResponse> usableItems = new HashMap<>();
	Map<String, CIResponse> usableItems = new HashMap<>();
	
	Registration            reg;
	
	public Check_Subsidiaries()
	{
		super();
		this.initUI();
		
		this.grid
			.addColumn(v -> Optional.ofNullable(v).map(CIResponse::getCompanyInfoBvd)
				.map(CompanyInfo::getSubsidiaryData).map(sd -> sd.size()).orElse(0))
			.setKey("subSize").setHeader("No. of Subs").setResizable(true).setSortable(true).setFlexGrow(0);
	}
	
	@Override
	protected void onAttach(AttachEvent attachEvent)
	{
		super.onAttach(attachEvent);
		
		generateStatistics();
		grid.setItems(usableItems.values());
		
		grid2.setItems(SubsidiaryTaskManager.getCachedTasks());
	}
	
	private void generateStatistics()
	{
		Client client = CurrentUtil.getClient();
		
		// STAT1
		
		Div    div_c  = new Div();
		div_c.setText("Client: " + client.getClientDescription());
		objStatisticsC.add(div_c);
		
		int size_screenings = client.getScreenings().size();
		Div div_noOfScr     = new Div();
		div_noOfScr.setText("No. of Screenings: " + size_screenings);
		objStatisticsC.add(div_noOfScr);
		
//		usableItems = client.getScreenings().values().stream()
//			.flatMap(Check_Subsidiaries::helper_ScreeningToCIResponseStream)
//			.collect(Collectors.toMap(CIResponse::getCompanyBvdId, it -> it, (a, b) -> a));
		
		int size_validCompanyRequests = usableItems.size();
		Div div_noOfCompanInfos       = new Div();
		div_noOfCompanInfos.setText("No. of (valid) CompanyInfos: " + size_validCompanyRequests + " - NOT ACTIVATED");
		
		objStatisticsC.add(div_noOfCompanInfos);
		
		// STAT1
		
		Set<String> is1000 = new HashSet<>();
		Set<String> til50 = new HashSet<>();
		Set<String> til499 = new HashSet<>();
		Set<String> til999 = new HashSet<>();
		
		usableItems.values().forEach(it -> {
			try {
				int size = it.getCompanyInfoBvd().getSubsidiaryData().size();
				if (size == 1000) {
					is1000.add(it.getCompanyBvdId());
				}
				if (size < 51) {
					til50.add(it.getCompanyBvdId());
				}
				else if (size < 500) {
					til499.add(it.getCompanyBvdId());
				}
				else if (size < 1000) {
					til999.add(it.getCompanyBvdId());
				}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		});
		
		
		
		Div    div_50  = new Div();
		div_50.setText("<= 50: " + til50.size());
		objStatisticsC2.add(div_50);
		Div    div_499  = new Div();
		div_499.setText("< 500: " + til499.size());
		objStatisticsC2.add(div_499);
		Div    div_999  = new Div();
		div_999.setText("< 1000: " + til999.size());
		objStatisticsC2.add(div_999);
		Div    div_1000  = new Div();
		div_1000.setText("= 1000: " + is1000.size());
		objStatisticsC2.add(div_1000);
		
	}
	
	/**
	 * Screening to Stream of usable CIResponses (means: not null + data available)
	 * 
	 * @return
	 */
	static Stream<CIResponse> helper_ScreeningToCIResponseStream(/*Screening scr*/)
	{
//		if(scr != null && scr.getWatchlistCompanyEntries() != null && scr.getWatchlistCompanyEntries().get() != null)
//		{
//			return scr.getWatchlistCompanyEntries().get().stream()
//				.filter(Objects::nonNull).map(SearchEntryCompany::getItem)
//				.filter(Objects::nonNull)
//				.filter(it -> Objects.nonNull(it.getCompanyBvdId()))
//				.filter(it -> Objects.nonNull(it.getCompanyInfoBvd()));
//		}
		return Stream.empty();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #button}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void button_onClick(final ClickEvent<Button> event)
	{
		Set<CIResponse> selectedItems = grid.getSelectedItems();
		if(selectedItems != null && !selectedItems.isEmpty())
		{
			
//			Pair<Registration, Set<UUID>> newRun = SubsidiaryTaskManager
//				.newRuns(CurrentUtil.getUser().getEmailAddress(), selectedItems, this::onTaskUpdate);
//
//			
//			if(reg != null)
//			{
//				newRun.getLeft().remove();
//			}
//			else
//			{
//				reg = newRun.getLeft();
//			}
			Notificator.error("Disabled");
		}
	}
	
	public void onTaskUpdate()
	{
		Logger.debug("Task update event..");
		grid2.setItems(SubsidiaryTaskManager.getCachedTasks());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnRefresh}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnRefresh_onClick(final ClickEvent<Button> event)
	{
		grid2.setItems(SubsidiaryTaskManager.getCachedTasks());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnCreateScreening}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnCreateScreening_onClick(final ClickEvent<Button> event)
	{
		generateRandomScreenings(2);
//		newItems.stream().map(ScreeningMWrapper::Wrap).forEach(this.generated::add);
		
		Notificator.warn("Created 2 screenings");
	}
	
	
	public static List<Screening> generateRandomScreenings(final int number)
	{
		Client client = CurrentUtil.getClient();
		final List<Screening> res = new ArrayList<>(number);
		for(int i = 1; i <= number; i++)
		{
			final Screening  it                   = Screening.New(client.getUuid().toString(), CurrentUtil.getUser());
			
			List<SearchEntryCompany> secListNew = new ArrayList<>();
			for(int j = 1; j <= 3; j++) 
			{
				final String      generatedBvdId       = MockDataProviderCompany.generateRandomBvdId();
				final String      generatedCompanyName = MockDataProviderCompany.generateCompanyNameFor(generatedBvdId);
				final CIResponse generatedCIResponse  =
					MockDataProviderCompany.generateCIResponse(generatedBvdId, generatedCompanyName);
				secListNew.add(SearchEntryCompany.New(generatedCIResponse));
			}
			it.setWatchlistCompanyEntries(secListNew);
			
			it.setName("GENERATED " + ChronoUtil.formatInstant2(Instant.now()));
			it.setFunction(FunctionDAO.findAll(client).iterator().next());
			it.setLineOfBusiness(LineOfBusinessDAO.getLobs(client).iterator().next());
			it.setOe(OeDAO.findAll(client).iterator().next());
			res.add(it);
			
			ScreeningDAO.saveScreening(it, false);
			client.getScreenings().putIfAbsent(it.getScreeningID().toString(), it);
		}
		return res;
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSendNotification}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSendNotification_onClick(final ClickEvent<Button> event)
	{
		UserNotificationManager.send(new UserNotification()
		{
			String emailAddress = CurrentUtil.getUser().getEmailAddress();
			String id = UUID.randomUUID().toString();
			String msg = "Dummy Message " + UUID.randomUUID();
			Instant now = Instant.now();
			@Override
			public String getTargetUserId()
			{
				return emailAddress;
			}
			
			@Override
			public String getMessage()
			{
				return msg;
			}
			
			@Override
			public String getId()
			{
				return id;
			}
			
			@Override
			public Instant getCreated()
			{
				return now;
			}
		});
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSendTaskEmail}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSendTaskEmail_onClick(final ClickEvent<Button> event)
	{
	}

	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.objCompanies        = new VerticalLayout();
		this.objStatisticsC      = new HorizontalLayout();
		this.objTasksC2          = new HorizontalLayout();
		this.btnCreateScreening  = new Button();
		this.btnSendNotification = new Button();
		this.btnSendTaskEmail    = new Button();
		this.grid                = new Grid<>(CIResponse.class, false);
		this.objStatisticsC2     = new HorizontalLayout();
		this.objTasksC           = new HorizontalLayout();
		this.button              = new Button();
		this.objTasks            = new VerticalLayout();
		this.objStatisticsT      = new HorizontalLayout();
		this.grid2               = new Grid<>(SubsidiaryScreeningCachedTask.class, false);
		this.objStatisticsT2     = new HorizontalLayout();
		this.objActionsT         = new HorizontalLayout();
		this.btnRefresh          = new Button();
		
		this.btnCreateScreening.setText("Create Screening");
		this.btnCreateScreening.addThemeVariants(ButtonVariant.LUMO_SMALL);
		this.btnSendNotification.setText("Send UserNotification");
		this.btnSendNotification.addThemeVariants(ButtonVariant.LUMO_SMALL);
		this.btnSendTaskEmail.setEnabled(false);
		this.btnSendTaskEmail.setText("Send Email");
		this.btnSendTaskEmail.addThemeVariants(ButtonVariant.LUMO_SMALL);
		this.grid.addColumn(CIResponse::getCompanyBvdId).setKey("companyBvdId").setHeader("BvdID").setResizable(true)
			.setSortable(true);
		this.grid
			.addColumn(
				v -> Optional.ofNullable(v).map(CIResponse::getCompanyInfoBvd).map(CompanyInfo::getName).orElse(null))
			.setKey("companyInfoBvd.name").setHeader("Name").setResizable(true).setSortable(true);
		this.grid
			.addColumn(v -> Optional.ofNullable(v).map(CIResponse::getCompanyInfoBvd).map(CompanyInfo::getSubsidiaryData)
				.map(Map::isEmpty).orElse(null))
			.setKey("companyInfoBvd.subsidiaryData.empty").setHeader("EmptySubsidiaries?").setResizable(true)
			.setSortable(true).setFlexGrow(0);
		this.grid.setSelectionMode(Grid.SelectionMode.MULTI);
		this.button.setText("Screen selected");
		this.button.addThemeVariants(ButtonVariant.LUMO_SMALL);
		this.grid2.addColumn(new CaptionRenderer<>(SubsidiaryScreeningCachedTask::getId)).setKey("id").setHeader("TaskID")
			.setResizable(true).setSortable(true).setAutoWidth(true);
		this.grid2
			.addColumn(v -> Optional.ofNullable(v).map(SubsidiaryScreeningCachedTask::getWrapped)
				.map(SubsidiaryScreeningTaskF::getRootBvdId).orElse(null))
			.setKey("wrapped.rootBvdId").setHeader("RootBvdId").setResizable(true).setSortable(true).setAutoWidth(true);
		this.grid2.addColumn(new CaptionRenderer<>(SubsidiaryScreeningCachedTask::getState)).setKey("state")
			.setHeader("Task State").setResizable(true).setSortable(true).setAutoWidth(true);
		this.grid2.addColumn(SubsidiaryScreeningCachedTask::getCreated).setKey("created").setHeader("Task created")
			.setResizable(true).setSortable(true).setAutoWidth(true);
		this.grid2.addColumn(RenderedComponent.Renderer(RendererTaskDuration::new)).setKey("renderer")
			.setHeader("TaskDuration").setResizable(true).setSortable(false).setAutoWidth(true);
		this.grid2.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.btnRefresh.setText("Refresh Task list");
		this.btnRefresh.addThemeVariants(ButtonVariant.LUMO_SMALL);
		
		this.btnCreateScreening.setSizeUndefined();
		this.btnSendNotification.setSizeUndefined();
		this.btnSendTaskEmail.setSizeUndefined();
		this.objTasksC2.add(this.btnCreateScreening, this.btnSendNotification, this.btnSendTaskEmail);
		this.button.setSizeUndefined();
		this.objTasksC.add(this.button);
		this.objStatisticsC.setWidthFull();
		this.objStatisticsC.setHeight("100px");
		this.objTasksC2.setWidthFull();
		this.objTasksC2.setHeight("100px");
		this.grid.setSizeFull();
		this.objStatisticsC2.setWidthFull();
		this.objStatisticsC2.setHeight("100px");
		this.objTasksC.setWidthFull();
		this.objTasksC.setHeight("100px");
		this.objCompanies.add(this.objStatisticsC, this.objTasksC2, this.grid, this.objStatisticsC2, this.objTasksC);
		this.objCompanies.setFlexGrow(1.0, this.grid);
		this.btnRefresh.setSizeUndefined();
		this.objActionsT.add(this.btnRefresh);
		this.objStatisticsT.setWidthFull();
		this.objStatisticsT.setHeight("100px");
		this.grid2.setSizeFull();
		this.objStatisticsT2.setWidthFull();
		this.objStatisticsT2.setHeight("100px");
		this.objActionsT.setWidthFull();
		this.objActionsT.setHeight("100px");
		this.objTasks.add(this.objStatisticsT, this.grid2, this.objStatisticsT2, this.objActionsT);
		this.objTasks.setFlexGrow(1.0, this.grid2);
		this.objCompanies.setSizeFull();
		this.objTasks.setSizeFull();
		this.add(this.objCompanies, this.objTasks);
		this.setFlexGrow(3.0, this.objCompanies);
		this.setFlexGrow(2.0, this.objTasks);
		this.setSizeFull();
		
		this.btnCreateScreening.addClickListener(this::btnCreateScreening_onClick);
		this.btnSendNotification.addClickListener(this::btnSendNotification_onClick);
		this.btnSendTaskEmail.addClickListener(this::btnSendTaskEmail_onClick);
		this.button.addClickListener(this::button_onClick);
		this.btnRefresh.addClickListener(this::btnRefresh_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Grid<CIResponse>                    grid;
	private Grid<SubsidiaryScreeningCachedTask> grid2;
	private Button                              btnCreateScreening, btnSendNotification, btnSendTaskEmail, button,
		btnRefresh;
	private VerticalLayout                      objCompanies, objTasks;
	private HorizontalLayout                    objStatisticsC, objTasksC2, objStatisticsC2, objTasksC, objStatisticsT,
		objStatisticsT2, objActionsT;
	// </generated-code>
	
}
