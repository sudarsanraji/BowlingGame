package com.caweco.esra.business.report;

import java.io.InputStream;
import java.time.Instant;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

import com.caweco.esra.business.utils.AppResourceUtils;
import com.caweco.esra.business.utils.ChronoUtil;
import com.caweco.esra.business.utils.Wrapper;
import com.caweco.esra.entities.rest.general.Intermediaries;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.vaadin.flow.component.UI;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import one.microstream.X;

public final class ReportUtils
{
	public static JasperReport loadReport(final String name, final UI ui)
	{
		try
		{
			return JasperCompileManager.compileReport(
				AppResourceUtils.getInputStream(CLASS, REPORT_DIR + name + ".jrxml", ui)
			);
		}
		catch (final JRException e)
		{
			throw new RuntimeException(e);
		}
	}

	public static String formatInstant(final Instant i)
	{
		return ChronoUtil.formatInstant(i);
	}

	public static JasperPrint fillReport(
		final JasperReport report,
		final Map<String, Object> parameters,
		final Collection<?> datasource
	)
	{
		return fillReport(report, parameters, new JRBeanCollectionDataSource(datasource));
	}

	public static JasperPrint fillReport(
		final JasperReport report,
		final Map<String, Object> parameters,
		final JRBeanCollectionDataSource datasource
	)
	{
		try
		{
			return JasperFillManager.fillReport(report, parameters, datasource);
		}
		catch (final JRException e)
		{
			throw new RuntimeException(e);
		}
	}

	public static InputStream getImage(final String name, final UI ui)
	{
		return AppResourceUtils.getInputStream(CLASS, IMAGE_DIR + name, ui);
	}

	public static JRBeanCollectionDataSource createIntermediariesHelperDataSource( // NO_UCD - needed for JasperReports
		final Map<String, Intermediaries> intermediaries
	)
	{
		return new JRBeanCollectionDataSource(
			intermediaries.values()
				.stream()
				.map(i -> IntermediaryHelper.createIntermediaryTree(i.getIntermediaries()))
				.collect(Collectors.toList())
		);
	}

	public static JRBeanCollectionDataSource createStringWrapperDataSource(final Collection<String> strings) // NO_UCD - needed for JasperReports
	{
		return new JRBeanCollectionDataSource(strings.stream().map(Wrapper::new).collect(Collectors.toList()));
	}

	public static boolean containsGsssMatch(final Map<?, CompanyGsssMatch> matches) // NO_UCD - needed for JasperReports
	{
		return matches.values()
			.stream()
			.filter(X::isNotNull)
			.map(CompanyGsssMatch::getGsssMatchResults)
			.filter(X::isNotNull)
			.anyMatch(l -> !l.isEmpty());
	}

	private static final String REPORT_DIR = "/reports/screening/";
	private static final String IMAGE_DIR = "/images/";
	private static final Class<ReportUtils> CLASS = ReportUtils.class;

	private ReportUtils()
	{
		throw new UnsupportedOperationException();
	}
}
