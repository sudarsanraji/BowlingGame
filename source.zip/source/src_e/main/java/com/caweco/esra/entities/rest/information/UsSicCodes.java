package com.caweco.esra.entities.rest.information;

import java.util.HashMap;
import java.util.Map;


public class UsSicCodes
{
	private String				coreCode;
	private String				coreDescription;
	private Map<String, String>	primaryCodes	= new HashMap<>();
	private Map<String, String>	secondaryCodes	= new HashMap<>();
	
	public UsSicCodes()
	{
		// Empty Constructor for Framework
	}
	
	public String getCoreCode()
	{
		return this.coreCode;
	}
	
	public void setCoreCode(final String coreCode)
	{
		this.coreCode = coreCode;
	}
	
	public String getCoreDescription()
	{
		return this.coreDescription;
	}
	
	public void setCoreDescription(final String coreDescription)
	{
		this.coreDescription = coreDescription;
	}
	
	public Map<String, String> getPrimaryCodes()
	{
		return this.primaryCodes;
	}
	
	public void setPrimaryCodes(final Map<String, String> primaryCodes)
	{
		this.primaryCodes = primaryCodes;
	}
	
	public Map<String, String> getSecondaryCodes()
	{
		return this.secondaryCodes;
	}
	
	public void setSecondaryCodes(final Map<String, String> secondaryCodes)
	{
		this.secondaryCodes = secondaryCodes;
	}

	@Override
	public String toString() {
		return "UsSicCodes [coreCode=" + coreCode + ", coreDescription=" + coreDescription + ", primaryCodes="
				+ primaryCodes + ", secondaryCodes=" + secondaryCodes + "]";
	}
	
}
