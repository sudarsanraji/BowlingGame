
package com.caweco.esra.subsidary.frontend;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.business.usertask.UserTaskManager;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.vaadin.flow.shared.Registration;


public class SubsidiaryTaskManager
{
	// Necessary to keep track of running tasks e.g. to stop them if necessary.
	static ConcurrentHashMap<String, SubsidiaryScreeningCachedTask> CACHE = initCache();
	
	private static ConcurrentHashMap<String, SubsidiaryScreeningCachedTask> initCache()
	{
		final ConcurrentHashMap<String, SubsidiaryScreeningCachedTask> collect = new ConcurrentHashMap<String, SubsidiaryScreeningCachedTask>();
		return collect;
	}
	
	//// DATA Access
	
	public static Set<SubsidiaryScreeningCachedTask> getCachedTasks()
	{
		return new HashSet<>(SubsidiaryTaskManager.CACHE.values());
	}
	
	public static SubsidiaryScreeningCachedTask getCachedTask(final String screeningTaskId)
	{
		return SubsidiaryTaskManager.CACHE.get(screeningTaskId);
	}
	
	public static void interruptBeforeFinished(String taskId, String userId)
	{
		SubsidiaryScreeningCachedTask task = getCachedTask(taskId);
		if (task.getState() == SubsidiaryScreeningTaskState.RUNNING)
		{
			task.cancelTask(userId);
		}
	}
	
	//// Action starter
	
	public static Pair<Registration, UUID> newRun(
		final User user,
		final UUID client,
		final Screening screening,
		final SearchEntryCompany company,
		final Consumer<String> onTaskStateChange)
	{
		// Create
		final SubsidiaryScreeningCachedTask new1 = SubsidiaryScreeningCachedTask.New(user, client, screening, company);
		new1.getWrapped().setState(SubsidiaryScreeningTaskState.RUNNING);
		
		// To storage
		SubsidiaryTaskDAO.frontend_addRunningTask(new1.getWrapped());
		// To Cache
		SubsidiaryTaskManager.CACHE.put(new1.getId().toString(), new1);
		
		// listener
		final Registration registration = UserTaskManager.registerTaskStateListener(onTaskStateChange);
		
		// Start
		new1.start();
		
		return Pair.of(registration, new1.getId());
	}
	
}
