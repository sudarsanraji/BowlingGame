package com.caweco.esra.business.func.rest;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.namematch.NMResponse;
import com.caweco.esra.entities.rest.seaweb2.APSStatusBase_v2;
import com.caweco.esra.entities.rest.seaweb2.APSStatus_v2;

public class RestErrorHelper
{
	/**
	 * Returns the rest status message if this status message indicates an error.<br />
	 * Currently: if the status message starts with "201", "202" or "301". See also CARA REST docs for possible error
	 * messages.
	 * 
	 * @param response
	 * @return
	 */
	public static Optional<String> getError(NMResponse response)
	{
		String[] statusMessages = response.getStatusMessage();
		if (statusMessages == null || statusMessages.length == 0)
		{
			return Optional.empty();
		}
		
		String statusMessagesJoined = Stream.of(statusMessages).collect(Collectors.joining(", "));
		
		if (statusMessagesJoined.startsWith("201")
			|| statusMessagesJoined.startsWith("202")
			|| statusMessagesJoined
				.startsWith("203")
			|| statusMessagesJoined.startsWith("301"))
		{
			return Optional.of(statusMessagesJoined);
		}
		else
		{
			return Optional.empty();
		}
	}
	
	/**
	 * Returns the rest status message if this status message indicates an error.<br />
	 * Currently: if the status message starts with "201", "202" or "301". See also CARA REST docs for possible error
	 * messages.
	 * 
	 * @param response
	 * @return
	 */
	public static Optional<String> getError(CIResponse response)
	{
		String[] statusMessages = response.getStatusMessage();
		if (statusMessages == null || statusMessages.length == 0)
		{
			return Optional.empty();
		}
		
		String statusMessagesJoined = Stream.of(statusMessages).collect(Collectors.joining(", "));
		
		if (statusMessagesJoined.startsWith("201")
			|| statusMessagesJoined.startsWith("202")
			|| statusMessagesJoined
				.startsWith("203")
			|| statusMessagesJoined.startsWith("301"))
		{
			return Optional.of(statusMessagesJoined);
		}
		else
		{
			return Optional.empty();
		}
	}
	
	/**
	 * Returns the rest status message if this status message indicates an error.<br />
	 * Currently: if the status message starts with "201", "202" or "301". See also CARA REST docs for possible error
	 * messages.
	 * 
	 * @param hasStatus
	 * @return
	 */
	public static Optional<String> getError(APSStatusBase_v2 hasStatus)
	{
		APSStatus_v2 apsStatus = hasStatus.getAPSStatus();
		if (BooleanUtils.isTrue(apsStatus.isCompletedOK()))
		{
			return Optional.empty();
		}
		
		StringBuilder sb = new StringBuilder();
		String statusMessage = sb.append(apsStatus.getErrorMessage()).append("\n").append("Level: ")
			.append(apsStatus.getErrorLevel()).toString();
		
		return Optional.of(statusMessage);
	}
}
