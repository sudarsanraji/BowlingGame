package com.caweco.esra.dao.core;

import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Function;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class FunctionDAO
{
	public static Set<Function> findAll(Client parent)
	{
		return parent.getFunctions(true);
	}
	
	public static void insert(final Client parent, final Function it)
	{
		final Set<Function> holder = findAll(parent);
		holder.add(it);
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		String path = "/client/" + parent.getUuid().toString() + "/function/";
		
		WebTarget webTarget = client.getMethodTarget(path);
		
		Response response = webTarget.request().post(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the function "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	public static void update(final Client parent, final Function it)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		String path = "/client/" + parent.getUuid().toString() + "/function/" + it.getId();
		
		WebTarget webTarget = client.getMethodTarget(path);
		
		Response response = webTarget.request().put(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the function "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	public static boolean delete(final Client parent, final Function it)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		String path = "/client/" + parent.getUuid().toString() + "/function/" + it.getId();
		
		WebTarget webTarget = client.getMethodTarget(path);
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the function "  + it.getName() + " to the client : " +  parent.getClientDescription());	
		return true;
	}
	
	public static Set<Function> findAll()
	{
		return findAll(CurrentUtil.getClient());
	}
}
