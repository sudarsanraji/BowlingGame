
package com.caweco.esra.ui.part.watchlist;

import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.business.func.data.PresentationUtil;
import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.func.data.SeawebRedFlagCalculator;
import com.caweco.esra.business.report.ReportUtils;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.MatchRating;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;
import com.caweco.esra.ui.interfaces.HasResettableDataCommunicator;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.caweco.esra.ui.part.watchlist.common.BeanItemNotFound;
import com.caweco.esra.ui.part.watchlist.common.BeanWatchlistItemHeader;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElementType;
import com.caweco.esra.ui.part.watchlist.seawebimo.ComplianceKeyElement;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.function.SerializableBiConsumer;


public class WatchlistItemSeawebImoN2 extends Details
	implements RemovableWatchlistElement<WatchlistItemSeawebImoN2>, HasResettableDataCommunicator
{
	protected PartWatchList                                           root;
	
	// DATA
	private SearchEntrySeaweb2Vessel                                  item;
	private Integer                                                   flagValue     = null;
	private Integer                                                   flagValueOld  = null;
	private boolean                                                   readOnly      = false;
	
	// Listener
	private SerializableBiConsumer<WatchlistItemSeawebImoN2, Boolean> flagChangeListener;
	
	// TEMPORARY DATA
	private boolean                                                   isInitialized = false;
	
	Comparator<ComplianceKeyElement>                                  complianceKeyElementComparator;
	
	// UI
	private final BeanWatchlistItemHeader                             header;
	
	/**
	 * Just creates the header. Does <b>NOT</b> perform a "getShipByIMODetails" REST call!
	 * 
	 */
	protected WatchlistItemSeawebImoN2()
	{
		super();
		this.initUI();
		this.getElement().setAttribute("class", "screeningheader namematch with-workaround-edge");
		
		this.header = new BeanWatchlistItemHeader(WatchlistElementType.ESRA_WATCHLIST_ITEM, "IMO",
			"---")
				.withDetailButton(this::showDetails);
		this.setSummary(this.header);
		
		this.setOpened(false);
		
		final Comparator<ComplianceKeyElement> X =
			Comparator.comparing(it -> it.getFlagValue(), Comparator.reverseOrder());
		this.complianceKeyElementComparator = X
			.thenComparing(Comparator.comparing(it -> it.getComplianceScreeningKey().getHumanReadable()));
		
	}
	
	public WatchlistItemSeawebImoN2(final PartWatchList root)
	{
		this();
		this.root = root;
	}
	
	/***********************************************************/

	public ScreeningPageContext getContext() 
	{
		return this.getWatchListRoot().map(PartWatchList::getContext).orElse(null);
	}
	
	public Screening getScreening() 
	{
		return this.getWatchListRoot().map(PartWatchList::getScreening).orElse(null);
	}
	
	
	/***********************************************************/
	
	private void showDetails(final ClickEvent<Button> event)
	{
		final Dialog dialog = new Dialog(new DetailDialogSeawebImo(this.item.getShipDetails()));
		dialog.setWidth("1200px");
		dialog.setHeight("800px");
		
		dialog.open();
	}
	
	public WatchlistItemSeawebImoN2 setItem(final SearchEntrySeaweb2Vessel in)
	{
		this.item      = in;
		
		//// Update Header - DATA
		
		this.header.setDate(this.item.getCreated() != null ? ReportUtils.formatInstant(this.item.getCreated()) : "---");
		this.setComment(this.item.getEntryComment() != null ? this.item.getEntryComment() : "");
		
		final String representation = PresentationUtil.getRepresentation_ForMainWatchlistHeader(this.item);
		this.header.setName(representation);
		
		//// Update UI - MAIN FLAG
		
		final Client client = this.getContext().getClient();
		
		// Use "fromInternal" = true to prevent executing "flagChangeListener"
		this.setValue(SanctionUtil.toFlag(SeawebRedFlagCalculator.hasRedFlag(client, in)), true,
			false);
		
		return this;
	}
	
	public SearchEntrySeaweb2Vessel getItem()
	{
		return this.item;
	}
	
	/**
	 * Convenience method to get CompanyBvdId
	 * @return
	 */
	public Optional<String> getImoNumber() 
	{
		return Optional.ofNullable(this.item).map(SearchEntrySeaweb2Vessel::getShipDetails).map(APSShipDetail_v2::getIHSLRorIMOShipNo);
	}
	
	/**
	 * Applies pending changes to the {@link SearchEntrySeaweb2Vessel} and stores the changes.
	 * <p>
	 * (Only changes of the current {@link SearchEntrySeaweb2Vessel} item. If current item is new, this method does NOT
	 * apply it to the parent {@link Screening}! This is done in {@link PartWatchList#writeToScreening()})
	 * </p>
	 * 
	 * @return the ScreeningShipEntry.
	 */
	public SearchEntrySeaweb2Vessel getStoredItem()
	{
		//// Apply pending data
		this.item.setEntryComment(this.getComment());
		this.item.setRating(MatchRating.TRUE_FINDING.name());
		
		return this.item;
	}
	
	public String getComment()
	{
		return this.header.getComment();
	}
	
	public WatchlistItemSeawebImoN2 setComment(final String comment)
	{
		this.header.setComment(comment);
		return this;
	}
	
	/***********************************************************/
	// as WatchlistElement
	
	@Override
	public void removeSelfFromWatchlist()
	{
		final PartWatchList watchlist = UIUtils.getNextParent(this, PartWatchList.class);
		if(watchlist != null)
		{
			watchlist.removeItemS(this);
		}
	}
	
	@Override
	public Optional<PartWatchList> getWatchListRoot()
	{
		return Optional.ofNullable(this.root);
	}


	@Override
	public void setReadOnlyCustom(final boolean readOnly)
	{
		if (this.readOnly != readOnly)
		{
			this.readOnly = readOnly;
			
			// Header
			if (this.readOnly) 
			{
				this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
			}
			else 
			{
				this.header.setType(WatchlistElementType.ESRA_WATCHLIST_ITEM);
			}
			
			// Content
		}
	}
	
	@Override
	public void asEsuPart()
	{
		this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
	}
	
	@Override
	public int getFlagValue()
	{
		return this.flagValue == null ? -1 : this.flagValue;
	}
	
	@Override
	public int getFlagValueOld()
	{
		return this.flagValueOld == null ? -1 : this.flagValueOld;
	}
	
	@Override
	public void setFlagChangeListener(final SerializableBiConsumer<WatchlistItemSeawebImoN2, Boolean> flagChangeListener)
	{
		this.flagChangeListener = flagChangeListener;
	}
	
	@Override
	public void recalcFlag()
	{
		// Calculate "marked" flag (boolean)
		Boolean calculatedMarkedValue = false;
		if(this.item != null)
		{
			final Client client = this.getContext().getClient();
			calculatedMarkedValue = SanctionUtil.isMarked_internal(client, this.item);
		}
		
		// Map to "flagValue" (integer) for UI representation
		final Integer flagValue = BooleanUtils.toIntegerObject(calculatedMarkedValue, 2, 0, 0);
		
		this.setValue(flagValue, false, true);
	}
	
	/***********************************************************/
	
	protected boolean valueEquals(final Integer value1, final Integer value2)
	{
		return Objects.equals(value1, value2);
	}
	
	/**
	 * Similar to AbstractFieldSupport
	 * 
	 * @param newValue
	 * @param fromInternal
	 *            Set to true to prevent calling FlagChangeListener.
	 * @param fromClient
	 *            If "FromClient" is true, changing Value is only possible if not readOnly.
	 */
	protected void setValue(final Integer newValue, final boolean fromInternal, final boolean fromClient)
	{
		if(fromClient && this.readOnly)
		{
			// TODO: reset UI to previous value
			// this.applyValue(flagValue);
			return;
		}
		
		final int currentValue    = this.getFlagValue();
		final Integer currentOldValue = this.flagValueOld;
		
		//// Has value changed?
		if(this.valueEquals(newValue, currentValue))
		{
			return;
		}
		
		//// Value HAS changed:
		
		this.flagValueOld = currentValue;
		this.flagValue    = newValue;
		
		try
		{
			if(this.header != null)
			{
				this.header.setMarked(this.flagValue);
			}
			
		}
		catch(final RuntimeException e)
		{
			this.flagValueOld = currentOldValue;
			this.flagValue    = currentValue;
			throw e;
		}
		
		if(!fromInternal)
		{
			if(this.flagChangeListener != null)
			{
				this.flagChangeListener.accept(this, fromClient);
			}
		}
	}

	/*********************************************************************/
	
	/**
	 * Event handler delegate method for the {@link Details}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void this_onOpenedChange(final OpenedChangeEvent event)
	{
		if(event.isOpened() && !this.isInitialized)
		{
			this.initAndAddContent();
		}
	}
	
	/**
	 * Create and attach content UI Components
	 */
	private void initAndAddContent()
	{
		if(this.item != null)
		{
			
			if(this.item.getShipCount() > 0)
			{
				final Client client = this.getContext().getClient();
				
				// Add ComplianceKeyElement entry for each ComplianceScreeningKeyData
				
				client.getSeaweb2ScreeningKeyConfig(false).stream()
					.map(it -> new ComplianceKeyElement(this.root, it).setItem(this.item))
					.sorted(
						this.complianceKeyElementComparator)
					.forEach(this::addContent);
			}
			else
			{
				final BeanItemNotFound notFoundComponent = new BeanItemNotFound().setMessage("No vessel found.")
					.setPrefix(this.item.getShipDetails().getIHSLRorIMOShipNo());
				this.setContent(notFoundComponent);
			}
			
			this.isInitialized = true;
			
			// Apply readOnly to new child component(s) if necessary
			// see setReadOnlyCustom
			if (this.readOnly) 
			{
				// Content
				// Not needed here
			}
		}
	}
	
	/*********************************************************************/
	
	@Override
	public void resetDataCommunicators()
	{
		if(this.isInitialized)
		{
			this.getContent().filter(Objects::nonNull)
				.filter(c -> c instanceof HasResettableDataCommunicator)
				.forEach(c -> ((HasResettableDataCommunicator)c).resetDataCommunicators());
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.objNoItemFound = new FlexLayout();
		this.iconNoResults  = new Icon(VaadinIcon.EXCLAMATION_CIRCLE);
		this.lblNoResults   = new Label();
		
		this.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
		this.objNoItemFound.getStyle().set("flex-direction", "column");
		this.objNoItemFound.getStyle().set("gap", ".5em");
		this.iconNoResults.setVisible(false);
		this.lblNoResults.setText("No results found");
		this.lblNoResults.setVisible(false);
		this.lblNoResults.getStyle().set("font-weight", "bold");
		
		this.lblNoResults.setSizeUndefined();
		this.objNoItemFound.add(this.iconNoResults, this.lblNoResults);
		this.objNoItemFound.setSizeUndefined();
		this.setContent(this.objNoItemFound);
		
		this.addOpenedChangeListener(this::this_onOpenedChange);
	} // </generated-code>
	
	// <generated-code name="variables">
	private FlexLayout objNoItemFound;
	private Label      lblNoResults;
	private Icon       iconNoResults;
	// </generated-code>

	@Override
	public String getName() {
		return this.item.getShipDetails().getShipName() != null ? this.item.getShipDetails().getShipName() : this.item.getShipDetails().getIHSLRorIMOShipNo();
	}
	
}
