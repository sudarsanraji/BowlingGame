
package com.caweco.esra.subsidary.common.event;

public class ScreeningBlockingChangeEvent
{
	
	public static ScreeningBlockingChangeEvent New(String id, boolean blocked)
	{
		return new ScreeningBlockingChangeEvent(id, blocked);
	}
	
	public final String  screeningId;
	public final boolean blocked;
	
	protected ScreeningBlockingChangeEvent(String id, boolean blocked)
	{
		this.screeningId = id;
		this.blocked     = blocked;
	}
}
