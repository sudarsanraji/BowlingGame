package com.caweco.esra.ui.admin;

import java.util.Collection;
import java.util.HashSet;
import java.util.concurrent.Callable;
import java.util.Set;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.RemovableHelper;
import com.caweco.esra.dao.EsuTagsDAO;
import com.caweco.esra.dao.LineOfBusinessDAO;
import com.caweco.esra.dao.WatchlistStatementDAO;
import com.caweco.esra.dao.core.FunctionDAO;
import com.caweco.esra.dao.core.OeRegionDAO;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OeRegion;
import com.caweco.esra.ui.admin.parts.PartEsraTag;
import com.caweco.esra.ui.admin.parts.PartOEForm;
import com.caweco.esra.ui.admin.parts.PartSeawebComplianceKey;
import com.caweco.esra.ui.beans.PartComboBoxValueForm;
import com.caweco.esra.ui.beans.PartSimpleValueForm;
import com.caweco.esra.ui.beans.PartStringValueForm;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;


@AccessibleRule(AuthorizationResources.CLIENTADMINCOMMON)
@PageTitle("Backend: Selectable Data | ESRA")

@Route(value = "selectabledata", layout = AdminBackendContainer.class)
public class PageComboBoxData extends VerticalLayout
{
	public static String CONTENT_HEIGHT = "40vh";
	/**
	 * 
	 */
	public PageComboBoxData()
	{
		super();
		this.initUI();
		
		
		final PartSimpleValueForm<OeRegion> pOeR = new PartSimpleValueForm<>(
			OeRegion::New,
			OeRegion::setName,
			OeRegion::getName,
			"Office Regions",
			CurrentUtil.getClient().getOeRegions(true),
			object -> OeRegionDAO.update(CurrentUtil.getClient(), object),
			object -> OeRegionDAO.delete(CurrentUtil.getClient(), object),
			object -> OeRegionDAO.insert(CurrentUtil.getClient(), object));
		pOeR.withDeleteButton()
			.withDeletableRule(RemovableHelper::isRemovableFromClient_Region, CurrentUtil.getClient());
		pOeR.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(pOeR);
		
		final PartOEForm pOEForm = new PartOEForm(CurrentUtil.getClient().getOes(true), "Offices");
		pOEForm
			.withDeleteButton()
			.withDeletableRule(RemovableHelper::isRemovableFromClient_OE, CurrentUtil.getClient());
		pOEForm.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(pOEForm);
		
		pOeR.setOnItemsetChange(pOEForm::refreshRegions);
		
		Callable<Collection<LineOfBusiness>> returnLoBMethod = () -> {
			return CurrentUtil.getClient().getLobs(true);
		};
		
		final PartComboBoxValueForm<LineOfBusiness> partLOB = new PartComboBoxValueForm<LineOfBusiness>(
			CurrentUtil.getClient().getLobs(true),
			LineOfBusiness.class,
			"Line of Business",
			(element) -> {
				LineOfBusinessDAO.saveExistingLob(element, CurrentUtil.getClient().getUuid().toString());
			},
			(element) -> {
				LineOfBusinessDAO.saveNewLob(element, CurrentUtil.getClient().getUuid().toString());
			},
			(element) -> {
				LineOfBusinessDAO.deleteExistingLob(element, CurrentUtil.getClient().getUuid().toString());
			},
			returnLoBMethod);
		partLOB
			.withDeleteButton()
			.withDeletableRule(RemovableHelper::isRemovableFromClient_LineOfBusiness, CurrentUtil.getClient());
		partLOB.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partLOB);
		
		Callable<Collection<Function>> returnMethod = () -> {
			return CurrentUtil.getClient().getFunctions(true);
		};
		
		final PartComboBoxValueForm<Function> partFunction = new PartComboBoxValueForm<>(CurrentUtil.getClient().getFunctions(true),
			Function.class, "Functions",
			function -> FunctionDAO.update(CurrentUtil.getClient(), function),
			function -> FunctionDAO.insert(CurrentUtil.getClient(), function),
			function -> FunctionDAO.delete(CurrentUtil.getClient(), function),
			returnMethod);
		partFunction
			.withDeleteButton()
			.withDeletableRule(RemovableHelper::isRemovableFromClient_Function, CurrentUtil.getClient());
		partFunction.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partFunction);
		
		
		final PartStringValueForm partWatchlist = new PartStringValueForm(CurrentUtil.getClient().getMatchRatingStatements(true),
			"Watchlist statements",
			(value) -> WatchlistStatementDAO.removeStatement(CurrentUtil.getClient(), value),
			(value) -> WatchlistStatementDAO.addStatement(CurrentUtil.getClient(), value));
		partWatchlist.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partWatchlist);
		
		final PartStringValueForm partEsuTags = new PartStringValueForm(CurrentUtil.getClient().getEsuTags(true),
				"ESU Tags",
				(value) -> EsuTagsDAO.removeTag(CurrentUtil.getClient(), value),
				(value) -> EsuTagsDAO.addTag(CurrentUtil.getClient(), value));
		partEsuTags.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partEsuTags);
		
		final PartStringValueForm partEsuCountries = new PartStringValueForm(CurrentUtil.getClient().getEsuCountries(true),
			"Referral reason",
			(value) -> EsuCountriesDAO.removeCountry(CurrentUtil.getClient(), value),
			(value) -> EsuCountriesDAO.addCountry(CurrentUtil.getClient(), value));
		partEsuCountries.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partEsuCountries);
		
		final PartStringValueForm partPrcCountries = new PartStringValueForm(CurrentUtil.getClient().getPrcCountries(true),
			"PRC Countries",
			(value) -> PrcCountriesDAO.removeCountry(CurrentUtil.getClient(), value),
			(value) -> PrcCountriesDAO.addCountry(CurrentUtil.getClient(), value));
		partPrcCountries.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partPrcCountries);
		
		final PartEsraTag partEsraTags = new PartEsraTag("ESRA Tags").setItems(CurrentUtil.getClient().getMatchCategoryTags(true));
		partEsraTags.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partEsraTags);
		
		final PartSeawebComplianceKey partSeaweb2ComplianceKeyConfig = new PartSeawebComplianceKey()
			.setItems(CurrentUtil.getClient().getSeaweb2ScreeningKeyConfig(true));
		partSeaweb2ComplianceKeyConfig.setHeight(CONTENT_HEIGHT);
		this.flexLayout.add(partSeaweb2ComplianceKeyConfig);
		
		
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.flexLayout = new FlexLayout();
		
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.getStyle().set("overflow-x", "hidden");
		this.getStyle().set("overflow-y", "auto");
		this.flexLayout.setClassName("withGridGap-l");
		this.flexLayout.setFlexWrap(FlexLayout.FlexWrap.WRAP);
		
		this.flexLayout.setSizeUndefined();
		this.add(this.flexLayout);
		this.setFlexGrow(1.0, this.flexLayout);
		this.setSizeFull();
	} // </generated-code>
	
	// <generated-code name="variables">
	private FlexLayout flexLayout;
	// </generated-code>
	
}
