package com.caweco.esra.entities.access;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

import com.caweco.esra.entities.ldap.LdapOrg;
import com.caweco.esra.entities.meta.HasRepresentation;


public class AccessControlRuleLdap implements HasRepresentation
{
	public AccessControlRuleLdap()
	{
		
	}
	
	private Instant	created	= Instant.now();
	private AccessControlCompany company;
	private LdapOrg                    department;
	private UUID id;
	
	public AccessControlRuleLdap(AccessControlCompany company)
	{
		super();
		Objects.requireNonNull(company);
		this.company = company;
	}
	
	public AccessControlRuleLdap(AccessControlCompany company, LdapOrg department)
	{
		super();
		Objects.requireNonNull(company);
		Objects.requireNonNull(department);
		this.company = company;
		this.department = department;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public AccessControlCompany getCompany()
	{
		return this.company;
	}
	
	public LdapOrg getDepartment()
	{
		return this.department;
	}
	
	@Override
	public String getRepresentation()
	{
		return this.department == null
			? this.company.getDisplayName()
			: this.company.getDisplayName() + " - " + this.department.getDisplayName();
	}
	
	public boolean mayFitSameSamlAttributeSet(AccessControlRuleLdap other)
	{
		if(this == other)
			return true;
		if(other == null)
			return false;
		
		if (!this.company.equalsNC(other.company))
		{
			return false;
		}
		
		// If samlDepartment is "null" the rule is valid for ALL departments
		// -> "this" and "other" only differ if both departments are set and are not the same.
		
		if (this.department != null
			&& other.department != null
			&& !this.department.equalsNC(other.department))
		{
			return false;
		}
		
		return true;
	}
	
	@Override
	public int hashCode()
	{
		final int prime  = 31;
		int       result = 1;
		result = prime * result + ((this.company == null) ? 0 : this.company.hashCode());
		result = prime * result + ((this.department == null) ? 0 : this.department.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (this.getClass() != obj.getClass())
			return false;
		AccessControlRuleLdap other = (AccessControlRuleLdap) obj;
		if (this.company == null)
		{
			if (other.company != null)
				return false;
		}
		else if (!this.company.equals(other.company))
			return false;
		if (this.department == null)
		{
			if (other.department != null)
				return false;
		}
		else if (!this.department.equals(other.department))
			return false;
		return true;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}
	
	
}
