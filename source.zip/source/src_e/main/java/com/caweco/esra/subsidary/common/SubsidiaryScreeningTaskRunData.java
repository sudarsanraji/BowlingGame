package com.caweco.esra.subsidary.common;

import java.time.Instant;

// Usage: Frontend, Backend & as DTO
public class SubsidiaryScreeningTaskRunData
{
	public Instant runStart;
	public Instant runEnd;
	/**
	 * Message if Run was cancelled, e.g. due to an Error
	 */
	public String cancelledNote;
}
