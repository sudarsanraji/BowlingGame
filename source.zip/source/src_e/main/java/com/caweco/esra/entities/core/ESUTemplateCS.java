package com.caweco.esra.entities.core;

import java.util.Objects;
import java.util.Optional;

import com.caweco.esra.dao.esu.ESUTemplateDAO;
import com.caweco.esra.dto.ESUTemplateMetadataDTO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.ui.interfaces.HasActiveState;
import com.rapidclipse.framework.server.resources.Caption;


public class ESUTemplateCS implements HasActiveState {

	private ESUTemplateMetadataDTO meta;
	private Optional<String>	content = null;
	
	
	public ESUTemplateCS(ESUTemplateMetadataDTO meta) {
		super();
		Objects.requireNonNull(meta);
		this.meta = meta;
	}
	
	public ESUTemplateCS(ESUTemplateMetadataDTO meta, Optional<String>	content) {
		this(meta);
		this.content = content;
	}
	
	public void updateMetadata(ESUTemplateMetadataDTO meta)
	{
		Objects.requireNonNull(meta);
		this.meta = meta;
	}


	@Caption("ID")
	public int getId()
	{
		return meta.getId();
	}
	
	
	@Caption("Vers.")
	public int getVersion()
	{
		return meta.getVersion();
	}
	
	public void setVersion(int version)
	{
		meta.setVersion(version);
	}
	
	@Caption("Name")
	public String getName()
	{
		return meta.getName();
	}
	
	public void setName(String name)
	{
		meta.setName(name);
	}
	
	@Caption("Content")
	public String getContent(Client client, boolean force)
	{
		if (content == null || force) {
			// fetch content
			content = Optional.ofNullable(ESUTemplateDAO.getEsuTemplateContent(client, getId()));
			return content.orElse("");
		}

		return content.orElse("");
	}
	
	public Optional<String> getContentRaw()
	{
		return content;
	}
	
	public void setContent(String htmlContent) {
		content = Optional.ofNullable(htmlContent);
	}	
	
	@Caption("Active")
	@Override
	public boolean isActive()
	{
		return meta.isActive();
	}
	
	@Override
	public void setActive(boolean active)
	{
		meta.setActive(active);
	}


	
}
