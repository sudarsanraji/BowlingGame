package com.caweco.esra.business.func.rest;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.config.ConfigRestEndpoint;

import jakarta.ws.rs.client.WebTarget;


public class RestClientSeaWeb2
{
	private final WebTarget    webTarget;
	private final ConcurrentHashMap<String, WebTarget> registry = new ConcurrentHashMap<>();
	

	public RestClientSeaWeb2(final ConfigRestEndpoint esraRestConfiguration)
	{
		this.webTarget = RestClientBuilder.getClientSeaweb(esraRestConfiguration).target(esraRestConfiguration.getEndpointBaseURL());
	}
	
	public WebTarget getMethodTarget(final String methodName)
	{
		if (StringUtils.isBlank(methodName))
		{
			return this.webTarget;
		}
		
		return this.registry.computeIfAbsent(methodName, path -> this.webTarget.path(path));
	}
	
	
	public WebTarget getWebTarget()
	{
		return this.webTarget;
	}

	
	/*******************************************************************/
}
