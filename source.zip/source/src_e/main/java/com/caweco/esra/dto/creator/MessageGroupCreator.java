package com.caweco.esra.dto.creator;

import java.util.UUID;

import com.caweco.esra.dao.messaging.MessageGroupMetadataDTO;
import com.caweco.esra.dto.MessageGroupCreateDTO;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.messaging.MessageGroup;

public class MessageGroupCreator {
	public static MessageGroupMetadataDTO convertGroupToMetadataDTO(MessageGroup group) {
		MessageGroupMetadataDTO dto = new MessageGroupMetadataDTO();
		dto.setActive(group.isActive());
		dto.setCreated(group.getCreated());
		dto.setCreatedBy(group.getCreatedBy());
		dto.setId(group.getId().toString());
		dto.setName(group.getName());
		
		return dto;
	}
	
	public static MessageGroupCreateDTO convertGroupToCreatorDTO(MessageGroup group, User creator) {
		MessageGroupCreateDTO dto = new MessageGroupCreateDTO();
		dto.setActive(group.isActive());
		dto.setCreated(group.getCreated());
		dto.setCreatedBy(group.getCreatedBy());
		dto.setId(group.getId().toString());
		dto.setName(group.getName());
		dto.setCreator(UserCreator.convertUserToMetadataDTO(creator));
		return dto;
	}
	
	public static MessageGroup convertMetadataDTOToGroup(MessageGroupMetadataDTO dto)
	{
		MessageGroup group = new MessageGroup();
		group.setId(UUID.fromString(dto.getId()));
		group.setCreated(dto.getCreated());
		group.setCreatedBy(dto.getCreatedBy());
		group.setName(dto.getName());
		group.setActive(dto.isActive());
		return group;
	}
}
