package com.caweco.esra.dev.mockup;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.stream.Stream;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.ObjectMapperProvider;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.namematch.NMResponse;


public class MockupDataprovider
{
	
	public static NMResponse getNameMatch_(final String searchFor, final String nameType, final String country)
	{
		try
		{
			
			if (searchFor.startsWith("long"))
			{
				Thread.sleep(1000l);
			}
			
			Optional<String> res = MockupDataprovider.getNameSearchFromFile(nameType, searchFor);
			if (res.isPresent())
			{
				return new ObjectMapperProvider().getContext(String.class)
					.readValue(
						res.get(),
						NMResponse.class);
			}
			
			// SPECIAL RESULTS IF NOT FOUND
			
			else if (searchFor.startsWith("error"))
			{
				String[] split = searchFor.split("\\s", 2);
				String errorPart = split[0];
				String quest = split.length > 1 ? split[1] : split[0];
				NMResponse response = new ObjectMapperProvider().getContext(String.class)
					.readValue(MockupDataprovider.getNameSearchFromFile("special", errorPart).get(), NMResponse.class);
				response.setNameToSearch(quest);
				return response;
			}
			else if (searchFor.startsWith("empty"))
			{
				NMResponse response = new ObjectMapperProvider().getContext(String.class)
					.readValue(MockupDataprovider.getNameSearchFromFile("special", "empty").get(), NMResponse.class);
				response.setNameToSearch(searchFor.substring(5));
				return response;
			}
			
			
			// DEFAULT/FALLBACK IF NOT FOUND
			
			else if (nameType.equals("1"))
			{
				return new ObjectMapperProvider().getContext(String.class)
					.readValue(
						MockupDataprovider.getNameSearchFromFile(nameType, "sulzer_ag")
							.get(),
						NMResponse.class);
			}
			else if (nameType.equals("2"))
			{
				return new ObjectMapperProvider().getContext(String.class)
					.readValue(
						MockupDataprovider.getNameSearchFromFile(nameType, "kim_jong_un")
							.get(),
						NMResponse.class);
			}
			else if (nameType.equals("3"))
			{
				return new ObjectMapperProvider().getContext(String.class)
					.readValue(
						MockupDataprovider.getNameSearchFromFile(nameType,
							"sulzer_ag")
							.get(),
						NMResponse.class);
			}
			else if (nameType.equals("4"))
			{
				return new ObjectMapperProvider().getContext(String.class)
					.readValue(
						MockupDataprovider.getNameSearchFromFile(nameType, "ep_Sif")
							.get(),
						NMResponse.class);
			}
			
		}
		catch (Exception e)
		{
			throw new RuntimeException("No mockdata available.", e);
		}
		
		throw new RuntimeException("No mockdata available.");
	}
	
	public static CIResponse getCompanyInfo_(final String bvdid)
	{
		try
		{
			Thread.sleep(2000l);
			
			Optional<String> res = getCompanyInfoFromFile(bvdid);
			
			if (res.isPresent())
			{
				CIResponse result = new ObjectMapperProvider().getContext(String.class)
					.readValue(
						res.get(),
						CIResponse.class);
				return result;
			}
			else if (bvdid.startsWith("default"))
			{
				// DEFAULT/FALLBACK IF NOT FOUND
				
				CIResponse resultErsatz = new ObjectMapperProvider().getContext(String.class)
					.readValue(
						getCompanyInfoFromFile("DE7330267200").get(),
						CIResponse.class);
				return resultErsatz;
			}
			else {
				return MockDataProviderCompany.getOrGenerateCompanyInfoFor(bvdid);
			}
		}
		catch (Exception e)
		{
			throw new RuntimeException("No mockdata available.", e);
		}
	}
	
	////////////////
	//// Json string from file
	
	public static Optional<String> getCompanyInfoFromFile(final String bvdid)
	{
		return getMockupFileContent("cis_" + bvdid + ".json");
	}
	
	public static Optional<String> getNameSearchFromFile(String nameType, final String searchstring)
	{
		return getMockupFileContent("nm_" + nameType + "_" + searchstring + ".json");
	}
	
	public static Optional<String> getMockupFileContent(final String filename)
	{
		try
		{
			final Path filepath = Paths.get(ApplicationPropertyProvider.getMockdataDirectory())
				.resolve(escapeStringAsFilename(filename));
			
			if (Files.exists(filepath))
			{
				final StringBuilder sb = new StringBuilder();
				try (Stream<String> stream = Files.lines(filepath, StandardCharsets.UTF_8))
				{
					stream.forEach(s -> sb.append(s).append("\n"));
					return Optional.of(sb.toString());
				}
				catch (final IOException e)
				{
					Logger.error("Could not read file. - " + e.getMessage());
					return Optional.empty();
				}
			}
			else
			{
				Logger.error("File \"{}\" does not exist. - ", filepath.toString());
				return Optional.empty();
			}
			
		}
		catch (InvalidPathException e)
		{
			Logger.error(e);
			return Optional.empty();
		}
	}
	
	public static String escapeStringAsFilename(final String inputName)
	{
		final String encoded = inputName.replaceAll("[^a-zA-Z0-9-_\\.]", "_");
		// Truncate the string.
		final int end = Math.min(encoded.length(), 124);
		return encoded.substring(0, end);
	}
}
