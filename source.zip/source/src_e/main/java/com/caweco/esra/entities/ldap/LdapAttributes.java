package com.caweco.esra.entities.ldap;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.caweco.esra.business.ldap.LdapField;
import com.caweco.esra.entities.saml.SamlAttributes;

/**
 * Wrapper for attributes of a LDAP response of the ESRA LDAP endpoint.
 * <p>
 * Following LDAP fields are used to obtain the available attributes:
 * <ul>
 * <li>LdapField.MAIL - Mail</li>
 * <li>LdapField.C - Country</li>
 * <li>LdapField.GIVENNAME - Givenname</li>
 * <li>LdapField.SN - Surname</li>
 * <li>LdapField.ALLIANZ_OECOMPANYID - Company</li>
 * <li>LdapField.ALLIANZ_ORGID - Department</li>
 * </ul>
 * </p>
 */
public class LdapAttributes extends SamlAttributes
{
	private Map<String, String> ldapAttributes = new HashMap<>();
	
	public LdapAttributes()
	{
		super();
		/*needed for Jackson*/
	}
	
	public LdapAttributes(final SamlAttributes samlAttributes)
	{
		super(samlAttributes.getAttributes());
	}
	
	public Map<String, String> getLdapAttributes()
	{
		return new HashMap<String, String>(ldapAttributes);	
	}
	
	public void setLdapAttributes(final Map<String, String> ldapAttributes)
	{
		this.ldapAttributes = ldapAttributes;
	}
	
	
	/* *************************************************************** */
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#MAIL}
	 */
	@Override
	public Optional<String> getMail()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.MAIL.getLdapKey()));
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#C}
	 */
	@Override
	public Optional<String> getCountry()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.C.getLdapKey()));
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#GIVENNAME}
	 */
	@Override
	public Optional<String> getGivenname()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.GIVENNAME.getLdapKey()));
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#SN}
	 */
	@Override
	public Optional<String> getSurname()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.SN.getLdapKey()));
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#ALLIANZ_OECOMPANYID}<br />
	 * Thats the full LDAP path of the user's company.
	 */
	@Override
	public Optional<String> getCompany()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.ALLIANZ_OECOMPANYID.getLdapKey()));
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#ALLIANZ_ORGID}<br />
	 * Thats the full LDAP path of the user's department.
	 */
	@Override
	public Optional<String> getDepartment()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.ALLIANZ_ORGID.getLdapKey()));
	}
	
	/**
	 * Does not return a value.
	 */
	@Override
	public Optional<String> getDivision()
	{
		return Optional.empty();
	}
	
	/**
	 * Returns the LDAP attribute for key {@link LdapField#DEPARTMENTNUMBER}<br />
	 * Thats the human readable name of the user's department.
	 */
	@Override
	public Optional<String> getDepartment_ou()
	{
		return Optional.ofNullable(this.ldapAttributes.get(LdapField.DEPARTMENTNUMBER.getLdapKey()));
	}
	
	/**
	 * Does not return a value.
	 */
	@Override
	public Optional<String> getOrganizationName()
	{
		return Optional.empty();
	}
}
