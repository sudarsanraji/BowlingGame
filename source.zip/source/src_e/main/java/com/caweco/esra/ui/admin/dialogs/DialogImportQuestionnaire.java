package com.caweco.esra.ui.admin.dialogs;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.tinylog.Logger;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.dao.questionnaire.QuestionnaireDAO;
import com.caweco.esra.dto.QuestionDTO;
import com.caweco.esra.dto.QuestionnaireExportDTO;
import com.caweco.esra.dto.creator.RuleCreator;
import com.caweco.esra.entities.questionnaire.DateChooserQuestion;
import com.caweco.esra.entities.questionnaire.DurationChooserQuestion;
import com.caweco.esra.entities.questionnaire.FreeTextQuestion;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.Rule;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;
import com.caweco.esra.ui.dialogs.DialogBigMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;

public class DialogImportQuestionnaire extends Dialog {
	
	ObjectMapper om = new ObjectMapper();
	Runnable onSuccessfulImport;
	
	MemoryBuffer memoryBuffer = new MemoryBuffer();
	

	/**
	 * 
	 */
	public DialogImportQuestionnaire() {
		super();
		this.initUI();
		
		this.upload.setReceiver(this.memoryBuffer);
		

		this.upload.addSucceededListener(event -> {
			final InputStream    fileData = this.memoryBuffer.getInputStream();
			
			try {
				String data = new String(fileData.readAllBytes(), StandardCharsets.UTF_8);
				
				QuestionnaireExportDTO dto = om.readValue(data, QuestionnaireExportDTO.class);
				
				List<Question> failedRules = new ArrayList<>();
				HashMap<Integer, Integer> legacyQuestionnaireIDs = new HashMap<>();
				
				
				//Import logic begins here
				
				final Questionnaire q = new Questionnaire();
				
				q.setDescription(dto.getDescription());
				q.setActive(dto.getActive());
				q.setCategory(dto.getCategory());
				q.setVersion(dto.getVersion() + 1);
				q.setQuestionnaireID(QuestionnaireDAO.getNextQuestionnaireID());
				q.setQuestions(new ArrayList<>());
				
				for (final QuestionCategory cat : dto.getCategories())
				{
					q.getCategories().add(new QuestionCategory(cat));
				}
				
				// First add all the questions without the rules
				for (final QuestionDTO question : dto.getQuestions())
				{
					if (question.getCategory() == null) {
						Logger.error("## Potential data consistency problem during import process: Question \"{}\" (ID: {}) has no Category! Corrupt data expected, excluding Question as a result",
							question.getQuestionTest(),
							question.getId());
						continue;
					}
					else if (!q.getCategories().contains(question.getCategory()))
					{
						Logger.error("## Potential data consistency problem during import process: Category \"{}\" of Question \"{}\" (ID: {}) does not exist! Corrupt data expected, excluding Question as a result",
							question.getCategory().getCategory(),
							question.getQuestionTest(),
							question.getId()
							);
						continue;
					}

					
					Question newQ;
						
					switch (question.getQuestionType()) {
						case FREETEXT:
							newQ = new FreeTextQuestion();
							break;
						case DATE:
							newQ = new DateChooserQuestion();
							break;
						case DURATION:
							newQ = new DurationChooserQuestion();
							break;
						case MULTI:
							newQ = new MultiOptionQuestion();
							((MultiOptionQuestion) newQ).setValues(question.getValues());
							break;
						case SINGLE:
							newQ = new SingleOptionQuestion();
							((SingleOptionQuestion) newQ).setValues(question.getValues());
							break;
						default:
							newQ = new Question();
							break;
					}
					
					newQ.setActive(question.getActive());
					newQ.setCategory(question.getCategory());
					newQ.setHelperText(question.getHelperText());
					newQ.setId(QuestionDAO.getNextQuestionID(q.getQuestions(false)));
					newQ.setInstructionText(question.getInstructionText());
					newQ.setQuestionText(question.getQuestionTest());

					newQ.setStandard(question.getStandard());
					
					if(question.getRule() != null)
					{
						Rule potentialRule = RuleCreator.createRuleBasedOnImport(q, question.getRule(), q.getQuestions(false), question, legacyQuestionnaireIDs);
						
						if(potentialRule != null)
						{
							newQ.setRule(potentialRule);						
						}
						else
						{
							failedRules.add(newQ);
						}
					}
					
					q.getQuestions(false).add(newQ);
					legacyQuestionnaireIDs.put(newQ.getId(), question.getId());
				}
				
				if(!failedRules.isEmpty())
				{
					StringBuilder questionListBuilder = new StringBuilder();

					failedRules.forEach(failedQuestion -> {
						questionListBuilder.append("\n- " + failedQuestion.getQuestionText() + " (ID: " + failedQuestion.getId() + ")");
					});
					
					DialogBigMessage ruleErrorDialog = DialogBigMessage.New().withTopic("Error occured")
					.withContent("Some rules failed to import and we've aborted the questionnaire import as a result. Please double check if the data for the following Questions is correct:" + questionListBuilder.toString())
					.withColor("red").go();
					
					this.close();
					
					((Dialog) ruleErrorDialog).addOpenedChangeListener(openChangeEvent -> {
						if(!openChangeEvent.isOpened())
						{
							this.onSuccessfulImport.run();
						}
					});
				}
				else
				{
					QuestionnaireDAO.insertWithAllQuestions(q);
					this.close();
					Notificator.success("Import successful!");
					this.onSuccessfulImport.run();
				}
				


			} catch (Exception e) {
				DialogBigMessage.New().withTopic("Error occured")
				.withContent("A error occured during the import. Please double check the data you've entered.")
				.withColor("red").go();
				
				e.printStackTrace();
				this.close();
			}
		});
		
	}
	
	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.verticalLayout = new VerticalLayout();
		this.label = new Label();
		this.upload = new Upload();
	
		this.label.setText("Please upload questionnaires here:");
	
		this.label.setSizeUndefined();
		this.upload.setSizeUndefined();
		this.verticalLayout.add(this.label, this.upload);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.upload);
		this.verticalLayout.setSizeFull();
		this.add(this.verticalLayout);
		this.setSizeUndefined();
	} // </generated-code>

	// <generated-code name="variables">
	private Upload upload;
	private VerticalLayout verticalLayout;
	private Label label;
	// </generated-code>

	public void setOnImport(Runnable listener) {
		this.onSuccessfulImport = listener;
	}

}
