package com.caweco.esra.business.report;

import java.util.ArrayList;
import java.util.List;

public class TocItem
{
	private final String display;
	private final String link;
	private final List<TocSubItem> subitems = new ArrayList<>();
	
	public TocItem(final String display)
	{
		this(display, null);
	}

	public TocItem(final String display, final String link)
	{
		this.display = display;
		this.link = link;
	}

	public String getDisplay()
	{
		return this.display;
	}

	public String getLink()
	{
		return this.link;
	}

	public List<TocSubItem> getSubitems()
	{
		return new ArrayList<>(this.subitems);
	}
}
