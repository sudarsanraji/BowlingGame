package com.caweco.esra.ui.questionnaire.parts;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.QuestionnaireUtils;
import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.DateChooserQuestion;
import com.caweco.esra.entities.questionnaire.DurationChooserQuestion;
import com.caweco.esra.entities.questionnaire.FreeTextQuestion;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionResult;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;
import com.caweco.esra.entities.questionnaire.Rule;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;
import com.caweco.esra.ui.questionnaire.QuestionContainer;
import com.caweco.esra.ui.questionnaire.RuleValidator;
import com.caweco.esra.ui.questionnaire.beans.BeanDateChooserQuestionTemplate;
import com.caweco.esra.ui.questionnaire.beans.BeanDurationChooserQuestionTemplate;
import com.caweco.esra.ui.questionnaire.beans.BeanFreeTextQuestionTemplate;
import com.caweco.esra.ui.questionnaire.beans.BeanMultiChooserQuestionTemplate;
import com.caweco.esra.ui.questionnaire.beans.BeanSingleOptionQuestionTemplate;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;


public class PartFillinCategory extends VerticalLayout
{
	PartQuestionnaireOverview parent;
	
	private Boolean		isFirstQuestion	= true;
	private final QuestionCategory questionCategory;
	
	
	public PartFillinCategory(final PartQuestionnaireOverview parent, final QuestionCategory cat, final QuestionnaireResult result,
		final Map<QuestionCategory, List<Question>> groupedQuestions, final List<Question> allQuestions)
	{
		super();
		this.initUI();
		this.questionCategory = cat;
		this.parent = parent;
		
		groupedQuestions.get(cat).forEach(qu ->
		{
			final Optional<QuestionResult> qresults = QuestionnaireUtils.getQuestionResult_forQuestion(result, qu);
			
			QuestionResult questionResult;
			
			if(!qresults.isPresent())
			{
				questionResult = new QuestionResult();
				questionResult.setQuestion(qu);
			}
			else
			{
				questionResult = qresults.get();
			}
			
			if(qu instanceof FreeTextQuestion)
			{
				final BeanFreeTextQuestionTemplate freeText =
					new BeanFreeTextQuestionTemplate(this, result, questionResult);
				if(!questionResult.getCompleted())
				{
					freeText.setEnabled(this.isFirstQuestion);
				}
				freeText.setVisible(qu.getRule() == null);
				this.add(freeText);
			}
			else if(qu instanceof DateChooserQuestion)
			{
				final BeanDateChooserQuestionTemplate dateChooser =
					new BeanDateChooserQuestionTemplate(this, result, questionResult);
				if(!questionResult.getCompleted())
				{
					dateChooser.setEnabled(this.isFirstQuestion);
				}
				dateChooser.setVisible(qu.getRule() == null);
				this.add(dateChooser);
			}
			else if(qu instanceof DurationChooserQuestion)
			{
				final BeanDurationChooserQuestionTemplate durationChooser =
					new BeanDurationChooserQuestionTemplate(this, result, questionResult);
				if(!questionResult.getCompleted())
				{
					durationChooser.setEnabled(this.isFirstQuestion);
				}
				durationChooser.setVisible(qu.getRule() == null);
				this.add(durationChooser);
			}
			else if(qu instanceof SingleOptionQuestion)
			{
				final BeanSingleOptionQuestionTemplate singleValue =
					new BeanSingleOptionQuestionTemplate(this, result, questionResult);
				if(!questionResult.getCompleted())
				{
					singleValue.setEnabled(this.isFirstQuestion);
				}
				singleValue.setVisible(qu.getRule() == null);
				this.add(singleValue);
			}
			else if(qu instanceof MultiOptionQuestion)
			{
				final BeanMultiChooserQuestionTemplate multiValue =
					new BeanMultiChooserQuestionTemplate(this, result, questionResult);
				if(!questionResult.getCompleted())
				{
					multiValue.setEnabled(this.isFirstQuestion);
				}
				multiValue.setVisible(qu.getRule() == null);
				this.add(multiValue);
			}
			
			this.isFirstQuestion = false;
		});
		
		this.validateQuestionRules(result, allQuestions);
		
		this.enableFirstValidQuestion();
	}
	
	public PartQuestionnaireOverview getParent_logical()
	{
		return this.parent;
	}
	
	public void enableFirstValidQuestion()
	{
		
		final List<Component> questionContainerChildren = this.getChildren().filter(Objects::nonNull)
			.filter(c -> c instanceof QuestionContainer).collect(Collectors.toList());
		for (final Component comp : questionContainerChildren)
		{
			// Must be visible
			if (comp.isVisible())
			{
				// Must not be completed
				final QuestionResult res = ((QuestionContainer) comp).getQuestionResult();
				if (res == null || BooleanUtils.isFalse(res.getCompleted()))
				{
					((VerticalLayout) comp).setEnabled(true);
					break;
				}
			}
		}
	}
	
	public void enableNextValidQuestion(final VerticalLayout child, final boolean enabled)
	{
		boolean isNext = false;
		
		final List<Component> children = this.getChildren().collect(Collectors.toList());
		for (final Component comp : children)
		{
			if(isNext)
			{
				if(comp.isVisible())
				{
					((VerticalLayout)comp).setEnabled(true);
					break;
				}
			}
			
			if(comp.equals(child))
			{
				isNext = enabled;
			}
		}
	}
	
	/**
	 * Checks if one of the <b>visible</b> questions has rule that relies on the changed value
	 * 
	 * @param changed
	 * @return
	 */
	public boolean hasFilledQuestionWithRule(final ChooseableValues changed)
	{
		for(final Component c : this.getChildren().collect(Collectors.toSet()))
		{
			
			final Question question = ((QuestionContainer) c).getQuestion();
			final Rule     rule     = question.getRule();
			
			if (rule != null)
			{
				final boolean hasCondition_BasedOnQuestionValue = RuleValidator
					.hasCondition_BasedOnQuestionValue(rule, changed);
				if (hasCondition_BasedOnQuestionValue)
				{
					return true;
				}
			}
		}
		return false;
	}
	
	public void validateQuestionRules(final QuestionnaireResult result)
	{
		this.validateQuestionRules(result, QuestionDAO.getQuestions(
			result.getQuestionnaire().getQuestionnaireID().toString(),
			CurrentUtil.getClient().getUuid().toString()));
	}
	
	public void validateQuestionRules(final QuestionnaireResult result, final List<Question> allQuestions)
	{
		// TODO: Prevent save if Screening FROZEN as last defense
		
		this.getChildren().forEach(child ->
		{
			if(((QuestionContainer)child).getQuestion().getRule() != null)
			{
				final RuleValidator ruleValidator =
					new RuleValidator(((QuestionContainer)child).getQuestion().getRule(), result);
				final boolean isValid = ruleValidator.validateRule(allQuestions);
				child.setVisible(isValid);
				
				if(!isValid)
				{
					result.getResults().remove(((QuestionContainer)child).getQuestionResult());
					((QuestionContainer)child).resetAnswer();
					//ScreeningDAO.saveScreening(this.parent.getParent_logical().getScreening());
					
					//ScreeningDAO.updateLastChange(this.parent.getParent_logical().getScreening());
				}
				
				((VerticalLayout)child).setEnabled(true);
			}
		});
	}
	
	/**
	 * Evaluates if all visible QuestionContainer of this {@link QuestionCategory} are completed.
	 * 
	 * @return
	 */
	public Boolean getQuestionCategoryProgress()
	{
		for(final Component comp : this.getChildren().collect(Collectors.toList()))
		{
			if(comp.isVisible())
			{
				if(!((QuestionContainer)comp).getQuestionResult().getCompleted())
				{
					return false;
				}
			}
		}
		return true;
	}
	
	public QuestionCategory getQuestionCategory()
	{
		return this.questionCategory;
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.setWidth("70%");
		this.setHeightFull();
	} // </generated-code>
	
}
