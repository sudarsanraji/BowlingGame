package com.caweco.esra.entities.core;

import java.util.Objects;

import com.caweco.esra.ui.interfaces.ComboBoxValue;
import com.rapidclipse.framework.server.resources.Caption;


public class OE implements ComboBoxValue
{
	private Integer		id;
	private String		name;
	private boolean		active;
	
	private OeRegion	region;
	
	public OE()
	{
		super();
	}
	
	@Override
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Caption("Office")
	@Override
	public String getName()
	{
		return this.name;
	}
	
	@Override
	public Integer getId()
	{
		return this.id;
	}
	
	@Override
	public void setId(Integer id)
	{
		this.id = id;
	}
	
	@Override
	public void setActive(Boolean active)
	{
		this.active = active;
	}
	
	@Override
	public Boolean getActive()
	{
		return this.active;
	}
	
	@Caption("Region")
	public OeRegion getRegion()
	{
		return this.region;
	}
	
	public OE setRegion(OeRegion region)
	{
		this.region = region;
		return this;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OE other = (OE) obj;
		return Objects.equals(id, other.id);
	}
	
	
	
	
}
