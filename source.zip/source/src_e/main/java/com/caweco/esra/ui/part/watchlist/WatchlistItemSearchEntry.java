
package com.caweco.esra.ui.part.watchlist;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.report.ReportUtils;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryGsss;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.ui.interfaces.HasResettableDataCommunicator;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.caweco.esra.ui.part.watchlist.common.BeanWatchlistItemHeader;
import com.caweco.esra.ui.part.watchlist.common.GsssMatchContainer;
import com.caweco.esra.ui.part.watchlist.common.GsssMatchManager;
import com.caweco.esra.ui.part.watchlist.common.MatchDataSetChangeEventMD;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElementType;
import com.caweco.esra.ui.sanctions.bean.SearchType;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.function.SerializableBiConsumer;
import com.vaadin.flow.shared.Registration;


public class WatchlistItemSearchEntry extends Details
	implements RemovableWatchlistElement<WatchlistItemSearchEntry>, HasResettableDataCommunicator,
	GsssMatchManager<GsssMatch, MatchData>
{
	protected PartWatchList                                               root;
	
	// Data / Dataprovider
	private SearchEntryGsss                                               item;
	private Integer                                                       flagValue     = null;
	private Integer                                                       flagValueOld  = null;
	private boolean                                                       readOnly      = false;
	
	// Listener
	private SerializableBiConsumer<WatchlistItemSearchEntry, Boolean> flagChangeListener;
	
	// TEMPORARY DATA
	private boolean                                                       isInitialized = false;
	
	// UI
	private final BeanWatchlistItemHeader                                 header;
	private GsssMatchContainer                                            contentElement;
	
	public WatchlistItemSearchEntry(final PartWatchList root, final SearchType searchType)
	{
		super();
		this.root = root;
		this.initUI();
		
		this.getElement().setAttribute("class", "screeningheader namematch with-workaround-edge");
		
		this.header =
			new BeanWatchlistItemHeader(WatchlistElementType.ESRA_WATCHLIST_ITEM, searchType.getName(), "---");
		this.setSummary(this.header);
		
		this.setOpened(false);
	}
	
	/***********************************************************/
	
	public Screening getScreening()
	{
		return this.getWatchListRoot().map(PartWatchList::getScreening).orElse(null);
	}
	
	/***********************************************************/
	
	public WatchlistItemSearchEntry setItem(final SearchEntryGsss item)
	{
		this.item = item;
		
		this.header.setName(this.getContentLabel());
		this.header.setDate(this.item.getCreated() != null ? ReportUtils.formatInstant(this.item.getCreated()) : "---");
		
		this.setComment(item.getComment() != null ? item.getComment() : "");
		
		// Add Child components
		this.initAndAddContent();
		
		//// Update UI - MAIN FLAG
		
		final Client client = this.getContext().getClient();
		final Integer flag   = SanctionUtil.toFlag(SanctionUtil.isMarked(client, this.item));
		
		// Use "fromInternal" = true to prevent executing "flagChangeListener"
		this.setValue(flag, false, false);
		
		return this;
	}
	
	public SearchEntryGsss getItem()
	{
		return this.item;
	}
	
	/**
	 * Applies pending changes to the {@link SearchEntryGsss} and stores the changes.
	 * <p>
	 * (Only the "inner" changes. Does NOT apply a new SearchEntryGsss to the screening! This is done in
	 * {@link PartWatchList#writeToScreening()})
	 * </p>
	 * 
	 * @return the SearchEntryGsss.
	 */
	public SearchEntryGsss getStoredItem()
	{
		//// Apply pending data
		this.item.setComment(this.getComment());
		
		return this.item;
	}
	
	public SearchType getSearchType()
	{
		return this.item.getSearchtype();
	}
	
	public String getComment()
	{
		return this.header.getComment();
	}
	
	public WatchlistItemSearchEntry setComment(final String comment)
	{
		this.header.setComment(comment);
		return this;
	}
	
	/***********************************************************/
	// as WatchlistElement
	
	@Override
	public void removeSelfFromWatchlist()
	{
		final PartWatchList watchlist = UIUtils.getNextParent(this, PartWatchList.class);
		if(watchlist != null)
		{
			watchlist.removeItemSE(this);
		}
	}
	
	@Override
	public Optional<PartWatchList> getWatchListRoot()
	{
		return Optional.ofNullable(this.root);
	}
	
	@Override
	public void setReadOnlyCustom(final boolean readOnly)
	{
		if(this.readOnly != readOnly)
		{
			this.readOnly = readOnly;
			
			// Header & Content
			if(this.readOnly)
			{
				// Header
				this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
				// Content
				if(this.contentElement != null)
				{
					this.contentElement.setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
				}
			}
			else
			{
				// Header
				this.header.setType(WatchlistElementType.ESRA_WATCHLIST_SUBITEM);
				// Content
				if(this.contentElement != null)
				{
					this.contentElement.setType(WatchlistElementType.ESRA_WATCHLIST_SUBITEM);
				}
			}
		}
	}
	
	@Override
	public void asEsuPart()
	{
		// Header
		this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
		// Content
		if(this.contentElement != null)
		{
			this.contentElement.setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
		}
	}
	
	@Override
	public int getFlagValue()
	{
		return this.flagValue == null ? -1 : this.flagValue;
	}
	
	@Override
	public int getFlagValueOld()
	{
		return this.flagValueOld == null ? -1 : this.flagValueOld;
	}
	
	@Override
	public void
		setFlagChangeListener(final SerializableBiConsumer<WatchlistItemSearchEntry, Boolean> flagChangeListener)
	{
		this.flagChangeListener = flagChangeListener;
	}
	
	@Override
	public void recalcFlag()
	{
		// Calculate "marked" flag (boolean)
		final Client        client                = this.getContext().getClient();
		final Boolean calculatedMarkedValue = SanctionUtil.isMarked(client, this.item, this.getMatchDataMap(), false);
		
		// Map to "flagValue" (integer) for UI representation
		final Integer           flagValue             = SanctionUtil.toFlag(calculatedMarkedValue);
		
		this.setValue(flagValue, false, true);
	}
	
	/***********************************************************/
	
	protected boolean valueEquals(final Integer value1, final Integer value2)
	{
		return Objects.equals(value1, value2);
	}
	
	/**
	 * Similar to AbstractFieldSupport
	 * 
	 * @param newValue
	 * @param fromInternal
	 *            Set to true to prevent calling FlagChangeListener.
	 * @param fromClient
	 *            If "FromClient" is true, changing Value is only possible if not readOnly.
	 */
	protected void setValue(final Integer newValue, final boolean fromInternal, final boolean fromClient)
	{
		if(fromClient && this.readOnly)
		{
			// TODO: reset UI to previous value
			// this.applyValue(flagValue);
			return;
		}
		
		final int currentValue    = this.getFlagValue();
		final Integer currentOldValue = this.flagValueOld;
		
		if(this.valueEquals(newValue, currentValue))
		{
			return;
		}
		
		this.flagValueOld = currentValue;
		this.flagValue    = newValue;
		
		try
		{
			if(this.header != null)
			{
				this.header.setMarked(this.flagValue);
			}
			
		}
		catch(final RuntimeException e)
		{
			this.flagValueOld = currentOldValue;
			this.flagValue    = currentValue;
			throw e;
		}
		
		if(!fromInternal)
		{
			if(this.flagChangeListener != null)
			{
				this.flagChangeListener.accept(this, fromClient);
			}
		}
	}
	
	/*********************************************************************/
	
	private void initAndAddContent()
	{
		if(this.item != null)
		{
			this.contentElement = new GsssMatchContainer(this);
			this.setContent(this.contentElement);
			
			this.isInitialized = true;
			
			// Apply readOnly to new child component(s) if necessary
			// see setReadOnlyCustom
			if(this.readOnly)
			{
				// Content
				this.contentElement.setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
			}
		}
	}
	
	/*********************************************************************/
	
	@Override
	public void resetDataCommunicators()
	{
		if(this.isInitialized)
		{
			this.getContent().filter(Objects::nonNull)
				.filter(c -> c instanceof HasResettableDataCommunicator)
				.forEach(c -> ((HasResettableDataCommunicator)c).resetDataCommunicators());
		}
	}
	
	/*********************************************************************/
	// as GsssMatchManager
	
	@Override
	public ScreeningPageContext getContext()
	{
		return this.getWatchListRoot().map(PartWatchList::getContext).orElse(null);
	}
	
	@Override
	public String getContentLabel()
	{
		return this.item.getResponse_nameToSearch();
	}
	
	@Override
	public List<GsssMatch> getMatches()
	{
		return this.item.getGsssMatchResults();
	}
	
	@Override
	public Map<GsssMatch, MatchData> getMatchDataMap()
	{
		return this.item.getMatchData();
	}
	
	@Override
	public MatchData getMatchDataFor(final GsssMatch match)
	{
		if(match != null && this.getMatches().contains(match))
		{
			final MatchData existingMatchData = this.getMatchDataMap().get(match);
			if(existingMatchData != null)
			{
				return existingMatchData;
			}
			else
			{
				final MatchData newMatchData = new MatchData();
				this.getMatchDataMap().put(match, newMatchData);
				return newMatchData;
			}
		}
		return null;
	}
	
	@Override
	public void onRatingChange(final boolean isFromClient, final GsssMatch match)
	{
		this.recalcFlag();
	}
	
	@Override
	public void notifyMatchDataChange(final boolean isFromClient, final GsssMatch match, final MatchData matchData, final boolean isNew)
	{
		if(match != null && this.getMatches().contains(match))
		{	
			this.getMatchDataMap().put(match, matchData);
			// Notify Listener
			final MatchDataSetChangeEventMD ev           =
				this.createMatchDataSetChangeEvent(this, isFromClient, match, matchData, isNew);
			ComponentUtil.fireEvent(this, ev);
		}
	}
	
//	@Override
//	public void doRatingChange(boolean isFromClient, GsssMatch match, MatchRating newRating)
//	{
//		MatchRating newRating_ = newRating != null ? newRating : MatchRating.UNKNOWN;
//		
//		MatchData   matchData  = getMatchDataFor(match);
//		
//		if(!Objects.equals(matchData.getRating(), newRating_.name()))
//		{
//			matchData.setRating(newRating_.name());
//			
//			// Notify Listener
//			MatchDataSetChangeEventMD ev = createMatchDataSetChangeEvent(this, isFromClient, match, matchData, false);
//			ComponentUtil.fireEvent(this, ev);
//			
//			// Update UI
//			onRatingChange(isFromClient, match);
//		}
//	}
	
	@Override
	public Registration addMatchDataSetChangeListener(final ComponentEventListener<MatchDataSetChangeEventMD> listener)
	{
		return this.addListener(MatchDataSetChangeEventMD.class, listener);
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
	} // </generated-code>

	@Override
	public String getName() {
		return this.item.getResponse_nameToSearch();
	}
	
}
