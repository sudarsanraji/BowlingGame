package com.caweco.esra.ui.interfaces;

public interface HasActiveState
{
	public boolean isActive();

	public void setActive(boolean active);
}
