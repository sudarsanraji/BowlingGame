package com.caweco.esra.business.utils;

public final class IntUtils {
	/**
	 * Finds the first occurrence of a digit, and stops when another letter is
	 * found. <b>Note:</b> Does not account for negative integers.
	 */
	public static int parseIntFromStringWithChars(final String s) {
		final int start = StringUtils.indexOfFirstMatch(s, Character::isDigit);

		if (start == -1) {
			throw new IllegalArgumentException("'" + s + "' does not contain a parseable Integer!");
		}

		final int end = StringUtils.indexOfFirstMatch(s.substring(start), c -> !Character.isDigit(c));

		// If -1 is returned, we couldn't find an end, which means the int goes until
		// the end of the string
		if (end == -1) {
			return Integer.parseInt(s.substring(start));
		} else {
			return Integer.parseInt(s.substring(start, end + start));
		}
	}

	private IntUtils() {
		throw new UnsupportedOperationException();
	}
}
