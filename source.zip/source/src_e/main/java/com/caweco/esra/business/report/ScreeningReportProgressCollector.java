package com.caweco.esra.business.report;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ScreeningReportProgressCollector {
	private static class State {
		int processed;
		int total;

		State() {
		}

		State(final int processed, final int total) {
			this.processed = processed;
			this.total = total;
		}

		public void add(final State other) {
			this.processed += other.processed;
			this.total += other.total;
		}
	}

	private final MonitoringDataSource.Listener listener;

	private final Map<Collection<?>, State> states = new HashMap<>();

	public ScreeningReportProgressCollector(final MonitoringDataSource.Listener listener) {
		this.listener = listener;
	}

	public MonitoringDataSource createDataSource(final Collection<?> c) {
		final MonitoringDataSource.Listener monitor = (processed, total) -> {
			final State state = this.states.get(c);
			state.processed = processed;
			state.total = total + 2;
			this.triggerListener();
		};

		states.put(c, new State(0, c.size() + 2));

		return new MonitoringDataSource(c, monitor);
	}

	private void triggerListener() {
		final State stateSum = states.values().stream().collect(State::new, State::add, State::add);
		this.listener.consume(stateSum.processed, stateSum.total);
	}
}
