
package com.caweco.esra.entities.core;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.applog.ChangeEntry;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;
import com.caweco.esra.ui.dialogs.DialogBigMessage;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;
import com.rapidclipse.framework.server.resources.Caption;
import com.vaadin.flow.component.UI;

/**
 * Frontend Representation. No need to preserve old data.
 *
 */
public class Screening implements HasMessages
{
	public static final Logger LOG        = LoggerFactory.getLogger(Screening.class);
	
	public static Screening New(final String clientId, final User user)
	{
		Objects.requireNonNull(user);

		final Screening screening = new Screening(clientId);

		screening.setScreeningOwner(user);
		screening.setScreeningServiceUser(user);
		screening.setWatchlistCompanyEntries(new ArrayList<>());
		screening.setWatchlistSearchEntriesGsss(new ArrayList<>());
		screening.setVesselsSeaWeb(new ArrayList<>());

		screening.setCreatedBy(user.getEmailAddress());

		return screening;
	}

	private final String frontendData_clientId;
	private boolean frontendData_existsInBackend = false;

	private UUID screeningID = UUID.randomUUID();
	private LocalDate screeningDate = LocalDate.now();
	private Optional<LocalDate> screeningEsuDate = Optional.empty();
	private Optional<LocalDate> screeningPublishDate = Optional.empty();

	private User screeningOwner;
	private User screeningServiceUser;

	private String name;
	private LineOfBusiness lineOfBusiness;
	private OE oe;
	private Function function;

	//// Infos

	private ScreeningStatus status = ScreeningStatus.IN_PROGRESS;

	private Monitoring latestMonitoring;
	/**
	 * Fetch when needed
	 */
	private Optional<List<SearchEntryCompany>> newWatchlistCompanyEntries = Optional.empty();
	/**
	 * Fetch when needed
	 */
	private Optional<List<SearchEntryGsss>> newWatchlistSearchEntriesGsss = Optional.empty();
	/**
	 * Fetch when needed
	 */
	private Optional<List<SearchEntrySeaweb2Vessel>> newVesselsSeaWeb = Optional.empty();

	//// TS SCREENING DATA

	/**
	 * Fetch when needed
	 */
	private Optional<QuestionnaireResult> tradeSanctionResult = Optional.empty();

	//// BUSINESS DATA

	/**
	 * Fetch when needed
	 */
	private Optional<QuestionnaireResult> businessInformationResult = Optional.empty();

	//// ESU DATA
	private User esuWorker;

	/**
	 * MAybe change to "Fetch when needed." May be a lot of data
	 */
	private String ESUTemplateResult;

	private Set<String> esuTags = new HashSet<>();
	private Set<String> esuCountries = new HashSet<>();
	private Set<String> prcCountries = new HashSet<>();

	//// MESSGAING DATA
	private Optional<MessageGroup> esuMessagesPublic = Optional.empty();

	private Optional<Map<UUID, MessageGroup>> esuMessageGroups = Optional.empty();

	/**
	 * Fetch when needed per user
	 */
	private final Map<String, List<Message>> esuMessagesPrivate = new HashMap<>();

	//// FILES

	/**
	 * Fetch when needed
	 */
	private Optional<List<BinaryElement>> files = Optional.empty();

	//// Timestamps & Infos

	private Instant created = Instant.now();
	private String createdBy;

	private Instant lastChanged = Instant.now();
	private String lastChangedBy;

	/**
	 * Fetch when needed
	 */
	private Optional<List<ChangeEntry>> notableChanges = Optional.empty();

	private boolean archived = false;

	/*************************************************************/

	public Screening(final String clientId)
	{
		super();
		Objects.requireNonNull(clientId);
		this.frontendData_clientId = clientId;
	}

	/** Meta information *****************************************/

	public Instant getCreated()
	{
		return this.created;
	}

	public void setCreated(final Instant created)
	{
		this.created = created;
	}

	public String getCreatedBy()
	{
		return this.createdBy;
	}

	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}

	public Instant getLastChanged()
	{
		return this.lastChanged;
	}

	public void setLastChanged(final Instant lastChanged)
	{
		this.lastChanged = lastChanged;
	}

	public String getLastChangedBy()
	{
		return this.lastChangedBy;
	}

	public void setLastChangedBy(final String lastChangedBy)
	{
		this.lastChangedBy = lastChangedBy;
	}

	public void updateLastChanged(final User changedBy)
	{
		this.lastChanged = Instant.now();
		this.lastChangedBy = changedBy.getEmailAddress();
	}

	@Caption("Process Date")
	public LocalDate getScreeningDate()
	{
		return this.screeningDate;
	}

	public void setScreeningDate(final LocalDate screeningDate)
	{
		this.screeningDate = screeningDate;
	}

	public List<ChangeEntry> getNotableChanges(final boolean forceUpdate)
	{
		if (this.notableChanges.isPresent() && !forceUpdate)
		{
			return this.notableChanges.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.notableChanges.isPresent())
			{
				this.notableChanges = Optional.of(new ArrayList<>());
			}
			return this.notableChanges.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.notableChanges = ScreeningDAO.getNotableChanges(this);

			return this.notableChanges.orElse(null);
		}
	}

	public void setNotableChanges(final List<ChangeEntry> changes)
	{
		this.notableChanges = Optional.of(changes);
	}

	/** Common ***************************************************/

	@Caption("Process ID")
	public UUID getScreeningID()
	{
		return this.screeningID;
	}

	public void setScreeningID(final UUID screeningID)
	{
		this.screeningID = screeningID;
	}

	@Caption("Name of Process")
	public String getName()
	{
		return this.name;
	}

	public void setName(final String name)
	{
		this.name = name;
	}

	@Caption("Status")
	public ScreeningStatus getStatus()
	{
		return this.status;
	}

	public void setStatus(final ScreeningStatus status)
	{
		this.status = status;
	}

	public List<BinaryElement> getFiles(final boolean forceUpdate)
	{
		if (this.files.isPresent() && !forceUpdate)
		{
			return this.files.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.files.isPresent())
			{
				this.files = Optional.of(new ArrayList<>());
			}
			return this.files.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.files = ScreeningDAO.getFiles(this);

			return this.files.get();
		}
	}

	@Caption("Line Of Business")
	public LineOfBusiness getLineOfBusiness()
	{
		return this.lineOfBusiness;
	}

	public void setLineOfBusiness(final LineOfBusiness lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}

	@Caption("Office")
	public OE getOe()
	{
		return this.oe;
	}

	public void setOe(final OE oe)
	{
		this.oe = oe;
	}

	@Caption("Function")
	public Function getFunction()
	{
		return this.function;
	}

	public void setFunction(final Function function)
	{
		this.function = function;
	}

	@Caption("Owner")
	public User getScreeningOwner()
	{
		return this.screeningOwner;
	}

	public void setScreeningOwner(final User screeningOwner)
	{
		this.screeningOwner = screeningOwner;
	}

	@Caption("Owner")
	public User getScreeningServiceUser()
	{
		return this.screeningServiceUser;
	}

	public void setScreeningServiceUser(final User screeningServiceUser)
	{
		this.screeningServiceUser = screeningServiceUser;
	}

	/** Financial Sanctions **************************************/

	public List<SearchEntryGsss> getWatchlistSearchEntriesGsss(final boolean forceUpdate)
	{
		if (this.newWatchlistSearchEntriesGsss.isPresent() && !forceUpdate)
		{
			return this.newWatchlistSearchEntriesGsss.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.newWatchlistSearchEntriesGsss.isPresent())
			{
				this.files = Optional.of(new ArrayList<>());
			}
			return this.newWatchlistSearchEntriesGsss.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.newWatchlistSearchEntriesGsss = ScreeningDAO.getWatchlistSearchEntriesGsss(this);

			return this.newWatchlistSearchEntriesGsss.get();
		}
	}

	public void setWatchlistSearchEntriesGsss(final List<SearchEntryGsss> watchlistSearchEntriesGsss)
	{
		
		//Check for IPPP-2646
		if(this.newWatchlistSearchEntriesGsss.isPresent() && this.newWatchlistSearchEntriesGsss.get().size() > watchlistSearchEntriesGsss.size() && this.status.equals(ScreeningStatus.REVIEW_REQUESTED)) {
			LOG.error("Something tried to clear the list of GSSS entries while screening was REVIEW_REQUESTED, Stacktrace printed below. Screening ID: {}", this.screeningID.toString());
			LOG.error(Arrays.toString(Thread.currentThread().getStackTrace()).replace( ',', '\n' ));
			
			if(UI.getCurrent() != null)
			{
				UI.getCurrent().access(() -> {
					
					DialogBigMessage dbm = DialogBigMessage.New().withTopic("An issue occured!").withContent("An issue occured with your screening. To prevent data inconsistency and further issues, please re-open the screening on the homepage. You may also report this error message to the ESRA Helpdesk, with a list of steps you did shortly before recieving this message.")
							.withWidth("500px").withColor("red");
					dbm.open();
				});
			}
			
			return;
		}
		
		this.newWatchlistSearchEntriesGsss = Optional.of(watchlistSearchEntriesGsss);
	}

	public List<SearchEntryCompany> getWatchlistCompanyEntries(final boolean forceUpdate)
	{
		if (this.newWatchlistCompanyEntries.isPresent() && !forceUpdate)
		{
			return this.newWatchlistCompanyEntries.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.newWatchlistCompanyEntries.isPresent())
			{
				this.files = Optional.of(new ArrayList<>());
			}
			return this.newWatchlistCompanyEntries.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.newWatchlistCompanyEntries = ScreeningDAO.getWatchlistCompanyEntries(this);

			return this.newWatchlistCompanyEntries.get();
		}
	}

	public void setWatchlistCompanyEntries(final List<SearchEntryCompany> watchlistCompanyEntries)
	{
		
		
		//Check for IPPP-2646
		if(this.newWatchlistCompanyEntries.isPresent() && this.newWatchlistCompanyEntries.get().size() > watchlistCompanyEntries.size() && this.status.equals(ScreeningStatus.REVIEW_REQUESTED)) {
			LOG.error("Something tried to clear the list of company entries while screening was REVIEW_REQUESTED, Stacktrace printed below. Screening ID: {}", this.screeningID.toString());
			LOG.error(Arrays.toString(Thread.currentThread().getStackTrace()).replace( ',', '\n' ));
			
			if(UI.getCurrent() != null)
			{
				UI.getCurrent().access(() -> {
					
					DialogBigMessage dbm = DialogBigMessage.New().withTopic("An issue occured!").withContent("An issue occured with your screening. To prevent data inconsistency and further issues, please re-open the screening on the homepage. You may also report this error message to the ESRA Helpdesk, with a list of steps you did shortly before recieving this message.")
							.withWidth("500px").withColor("red");
					dbm.open();
				});
			}
			
			
			return;
		}
		
		this.newWatchlistCompanyEntries = Optional.of(watchlistCompanyEntries);
	}

	public List<SearchEntrySeaweb2Vessel> getVesselsSeaWeb(final boolean forceUpdate)
	{
		if (this.newVesselsSeaWeb.isPresent() && !forceUpdate)
		{
			return this.newVesselsSeaWeb.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.newVesselsSeaWeb.isPresent())
			{
				this.files = Optional.of(new ArrayList<>());
			}
			return this.newVesselsSeaWeb.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.newVesselsSeaWeb = ScreeningDAO.getVesselsSeaWeb(this);

			return this.newVesselsSeaWeb.get();
		}
	}

	public void setVesselsSeaWeb(final List<SearchEntrySeaweb2Vessel> vesselsSeaWeb)
	{
		
		//Check for IPPP-2646
		if(this.newVesselsSeaWeb.isPresent() && this.newVesselsSeaWeb.get().size() > vesselsSeaWeb.size() && this.status.equals(ScreeningStatus.REVIEW_REQUESTED)) {
			LOG.error("Something tried to clear the list of vessels while screening was REVIEW_REQUESTED, Stacktrace printed below. Screening ID: {}", this.screeningID.toString());
			LOG.error(Arrays.toString(Thread.currentThread().getStackTrace()).replace( ',', '\n' ));
			
			if(UI.getCurrent() != null)
			{
				UI.getCurrent().access(() -> {
					
					DialogBigMessage dbm = DialogBigMessage.New().withTopic("An issue occured!").withContent("An issue occured with your screening. To prevent data inconsistency and further issues, please re-open the screening on the homepage. You may also report this error message to the ESRA Helpdesk, with a list of steps you did shortly before recieving this message.")
							.withWidth("500px").withColor("red");
					dbm.open();
				});
			}
			
			return;
		}
		this.newVesselsSeaWeb = Optional.of(vesselsSeaWeb);
	}

	/** Monitoring ***********************************************/

	public Monitoring getMonitoring()
	{
		return this.latestMonitoring;
	}

	public void setMonitoring(final Monitoring latestMonitoring)
	{
		this.latestMonitoring = latestMonitoring;
	}

	/** Trade sanction *******************************************/

	public QuestionnaireResult getTradeSanctionResult()
	{
		return this.getTradeSanctionResult(true);
	}

	@Caption("Trade Sanction Result")
	public QuestionnaireResult getTradeSanctionResult(final boolean forceUpdate)
	{
		if (this.tradeSanctionResult.isPresent() && !forceUpdate)
		{
			return this.tradeSanctionResult.get();
		}
		else if (!this.frontendData_existsInBackend)
		{
			// ignore "force" here: Screening does not exist in Backend
			if (!this.tradeSanctionResult.isPresent())
			{
				this.tradeSanctionResult = Optional.of(new QuestionnaireResult());
			}
			return this.tradeSanctionResult.get();
		}
		else
		{
			// "exists in backend" & either "force" or not yet fetched
			this.tradeSanctionResult = ScreeningDAO.getTradeSanctionResult(this);

			return this.tradeSanctionResult.orElse(null);
		}
	}

	public void setTradeSanctionResult(final QuestionnaireResult tradeSanctionResult)
	{
		this.tradeSanctionResult = Optional.of(tradeSanctionResult);
	}

	/** Business Information *************************************/

	@Caption("Business Information Result")
	public QuestionnaireResult getBusinessInformationResult(final boolean forceUpdate)
	{
//	}
		if(this.businessInformationResult.isPresent() && !forceUpdate)
		{
			return this.businessInformationResult.get();
		}
		else if(!this.frontendData_existsInBackend)
		{
			if(this.businessInformationResult.isEmpty())
			{
				this.businessInformationResult = Optional.of(new QuestionnaireResult());
			}
			return this.businessInformationResult.get();
		}
		else
		{
			this.businessInformationResult = ScreeningDAO.getBusinessInformationResult(this);
			return this.businessInformationResult.orElse(null);
		}
	}

	public void setBusinessInformationResult(final QuestionnaireResult businessInformationResult)
	{
		this.businessInformationResult = Optional.of(businessInformationResult);
	}

	/** ESU ******************************************************/

	@Caption("ESU Worker")
	public User getEsuWorker()
	{
		return this.esuWorker;
	}

	public void setEsuWorker(final User esuWorker)
	{
		this.esuWorker = esuWorker;
	}

	@Caption("Assessment")
	public String getESUTemplateResult()
	{
		return this.ESUTemplateResult;
	}

	public void setESUTemplateResult(final String eSUTemplateResult)
	{
		this.ESUTemplateResult = eSUTemplateResult;
	}

	@Override
	public MessageGroup getPublicMessages(final boolean forceUpdate)
	{
		if (this.esuMessagesPublic.isPresent() && !forceUpdate)
		{
			return this.esuMessagesPublic.get();
		}
		else
		{
			final Optional<MessageGroup> serverResult = MessageGroupDAO.getPublicChannel(this);

			if (serverResult.isPresent())
			{
				this.esuMessagesPublic = serverResult;
			}

			return this.esuMessagesPublic.get();
		}

	}

	@Override
	public Map<String, List<Message>> getPrivateMessages()
	{
		return  this.esuMessagesPrivate;
	}

	@Override
	public List<Message> getPrivateMessages(final User user)
	{
		if (user != null && user.getEmailAddress() != null)
		{
			return this.getPrivateMessages().get(user.getEmailAddress());
		}
		return null;
	}

	public Set<String> getEsuTags()
	{
		return this.esuTags == null ? new HashSet<>() : this.esuTags;
	}

	public void setEsuTags(final Set<String> esuTags)
	{
		this.esuTags = esuTags;
	}

	public Set<String> getEsuCountries()
	{
		return this.esuCountries == null ? new HashSet<>() : this.esuCountries;
	}

	public void setPrcCountries(final Set<String> prcCountries)
	{
		this.prcCountries = prcCountries;
	}

	public Set<String> getPrcCountries()
	{
		return this.prcCountries == null ? new HashSet<>() : this.prcCountries;
	}

	public void setEsuCountries(final Set<String> esuCountries)
	{
		this.esuCountries = esuCountries;
	}

	@Override
	public Object getMessagesParent()
	{
		// TODO Auto-generated method stub
		return this;
	}

	// New Message Groups
	@Override
	public Map<UUID, MessageGroup> getMessageGroups(final boolean forceUpdate)
	{
		if (this.esuMessageGroups.isPresent() && !forceUpdate)
		{
			return this.esuMessageGroups.get();
		}
		else
		{
			final Optional<List<MessageGroup>> serverResult = MessageGroupDAO.getChannelsOfScreening(this);

			if (serverResult.isPresent())
			{
				final Map<UUID, MessageGroup> groupMap = new HashMap<>();

				serverResult.get().forEach(group ->
				{
					groupMap.put(group.getId(), group);
				});

				this.esuMessageGroups = Optional.of(groupMap);
			}

			return this.esuMessageGroups.get();
		}
	}

	public boolean isArchived()
	{
		return this.archived;
	}

	public void setArchived(final boolean archived)
	{
		this.archived = archived;
	}

	public String getClientId()
	{
		return this.frontendData_clientId;
	}

	public boolean existsInBackend()
	{
		return this.frontendData_existsInBackend;
	}

	public void setExistsInBackend(final boolean frontendData_existsInBackend)
	{
		this.frontendData_existsInBackend = frontendData_existsInBackend;
	}

	public Optional<LocalDate> getScreeningEsuDate()
	{
		return this.screeningEsuDate != null ? this.screeningEsuDate : Optional.empty();
	}
	
	public Optional<LocalDate> getScreeningPublishDate()
	{
		return this.screeningPublishDate != null ? this.screeningPublishDate : Optional.empty();
	}

	public void setScreeningEsuDate(final Optional<LocalDate> screeningEsuDate)
	{
		this.screeningEsuDate = screeningEsuDate;
	}
	
	public void setScreeningPublishDate(final Optional<LocalDate> screeningPublishDate)
	{
		this.screeningPublishDate = screeningPublishDate;
	}

}
