
package com.caweco.esra.entities;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.commons.collections4.SetUtils;

import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.LineOfBusinessDAO;
import com.caweco.esra.dao.RoleDAO;
import com.caweco.esra.dao.esu.ESUTemplateDAO;
import com.caweco.esra.entities.access.ClientAssignmentRuleLdap;
import com.caweco.esra.entities.access.HasClientAssignmentInfo;
import com.caweco.esra.entities.config.EsraClientConfiguration;
import com.caweco.esra.entities.config.ManualClientUserAssignment;
import com.caweco.esra.entities.core.ESUTemplateCS;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.esra.MatchCategoryTag;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.entities.mailing.MailTemplate;
import com.caweco.esra.entities.mailing.MailType;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.rapidclipse.framework.server.resources.Caption;

import one.microstream.reference.Lazy;


public class Client
{
	private UUID                                            uuid                      = UUID.randomUUID();
	private String                                          clientDescription;
	
	private Optional<Set<Role>>                             roles                     = Optional.empty();
	private Optional<Set<Questionnaire>>                    questionnaires            = Optional.empty();
	
	// Available Values for Select/ComboBoxes/Mails
	
	private Optional<Set<ESUTemplateCS>>                    esuTemplates              = Optional.empty();
	private Optional<Set<String>>                           esuTags                   = Optional.empty();
	private Optional<Set<String>>                           esuCountries              = Optional.empty();
	private Optional<Set<String>>                           prcCountries              = Optional.empty();
	
	private Optional<Set<OE>>                               oes                       = Optional.empty();
	private Optional<Set<Function>>                         functions                 = Optional.empty();
	private Optional<Set<LineOfBusiness>>                   lobs                      = Optional.empty();
	private Optional<Set<OeRegion>>                         oeRegions                 = Optional.empty();
	
	private Map<MailType, MailTemplate>                     mailTemplates             = new HashMap<>();
	private Optional<Set<String>>                           matchRatingStatements     = Optional.empty();
	private Optional<List<MatchCategoryTag>>                matchCategoryTags         = Optional.empty();
	
	//// Config
	private EsraClientConfiguration                         clientConfiguration       = new EsraClientConfiguration();
	
	private Optional<Map<User, ManualClientUserAssignment>> clientUser                = Optional.empty();
	
	private Optional<Set<ComplianceScreeningKeyData>>       seaweb2ScreeningKeyConfig = Optional.empty();
		
	private final ConcurrentHashMap<String, Screening>      screeningsConcurrentMap   = new ConcurrentHashMap<>();
	
	public Client()
	{
		super();
	}
	
	public Set<OE> getOes(final boolean forceUpdate)
	{
		if(this.oes.isPresent() && !forceUpdate)
		{
			return this.oes.get();
		}
		else
		{
			this.oes = Optional.of(ClientDAO.getOe(this));
			return this.oes.get();
		}
	}
	
	public void setOes(final Set<OE> oes)
	{
		this.oes = Optional.of(oes);
	}
	
	public Set<OeRegion> getOeRegions(final boolean forceUpdate)
	{
		if(this.oeRegions.isPresent() && !forceUpdate)
		{
			return this.oeRegions.get();
		}
		else
		{
			this.oeRegions = Optional.of(ClientDAO.getOeRegions(this));
			return this.oeRegions.get();
		}
	}
	
	public void setOeRegions(final Set<OeRegion> oeRegions)
	{
		this.oeRegions = Optional.of(oeRegions);
	}
	
	public Set<Function> getFunctions(final boolean forceUpdate)
	{
		if(this.functions.isPresent() && !forceUpdate)
		{
			return this.functions.get();
		}
		else
		{
			this.functions = Optional.of(ClientDAO.getFunctions(this));
			return this.functions.get();
		}
	}
	
	public void setFunctions(final Set<Function> functions)
	{
		this.functions = Optional.of(functions);
	}
	
	public Set<LineOfBusiness> getLobs(final boolean forceUpdate)
	{
		if(this.lobs.isPresent() && !forceUpdate)
		{
			return this.lobs.get();
		}
		else
		{
			this.lobs = Optional.of(LineOfBusinessDAO.getLobs(this));
			return this.lobs.get();
		}
	}
	
	public void setLobs(final Set<LineOfBusiness> lobs)
	{
		this.lobs = Optional.of(lobs);
	}
	
	public Set<ESUTemplateCS> getEsuTemplates(final boolean forceUpdate)
	{
		if(this.esuTemplates.isPresent() && !forceUpdate)
		{
			return this.esuTemplates.get();
		}
		else
		{
			this.esuTemplates = Optional.of(ESUTemplateDAO.getAll(this));
			return this.esuTemplates.get();
		}
	}
	
	public Optional<Set<ESUTemplateCS>> getEsuTemplatesRaw()
	{
		return this.esuTemplates;
	}
	
	public Set<String> getEsuTags(final boolean forceUpdate)
	{
		if(this.esuTags.isPresent() && !forceUpdate)
		{
			return this.esuTags.get();
		}
		else
		{
			this.esuTags = Optional.of(ClientDAO.getESUTags(this));
			return this.esuTags.get();
		}
	}
	
	public void setEsuTags(final Set<String> esuTags)
	{
		this.esuTags = Optional.of(esuTags);
	}
	
	public Set<String> getEsuCountries(final boolean forceUpdate)
	{
		if(this.esuCountries.isPresent() && !forceUpdate)
		{
			return this.esuCountries.get();
		}
		else
		{
			this.esuCountries = Optional.of(ClientDAO.getESUCountries(this));
			return this.esuCountries.get();
		}
	}
	
	public void setEsuCountries(final Set<String> esuCountries)
	{
		this.esuCountries = Optional.of(esuCountries);
	}
	
	public Set<String> getPrcCountries(final boolean forceUpdate)
	{
		if(this.prcCountries.isPresent() && !forceUpdate)
		{
			return this.prcCountries.get();
		}
		else
		{
			this.prcCountries = Optional.of(ClientDAO.getPRCCountries(this));
			return this.prcCountries.get();
		}
	}
	
	public void setPrcCountries(final Set<String> prcCountries)
	{
		this.prcCountries = Optional.of(prcCountries);
	}
	
	public ConcurrentHashMap<String, Screening> getScreenings()
	{
		return this.screeningsConcurrentMap;
	}
	
	/**
	 * DO NOT USE: CURRENTLY UNSUPPORTED
	 * 
	 * @param screenings
	 */
	public void setScreenings(final ConcurrentHashMap<String, Screening> screenings)
	{
		throw new UnsupportedOperationException();
		// this.screeningsConcurrentMap = screenings;
	}
	
	public Set<Questionnaire> getQuestionnaires(final boolean forceUpdate)
	{
		if(this.questionnaires.isPresent() && !forceUpdate)
		{
			return this.questionnaires.get();
		}
		else
		{
			this.questionnaires = Optional.of(ClientDAO.getQuestionnaires(this));
			return this.questionnaires.get();
		}
	}
	
	public void setQuestionnaires(final Set<Questionnaire> questionnaires)
	{
		this.questionnaires = Optional.of(questionnaires);
	}
	
	@Caption("ID")
	public UUID getUuid()
	{
		return this.uuid;
	}
	
	public void setUuid(final UUID uuid)
	{
		this.uuid = uuid;
	}
	
	@Caption("Name")
	public String getClientDescription()
	{
		return this.clientDescription;
	}
	
	public void setClientDescription(final String clientDescription)
	{
		this.clientDescription = clientDescription;
	}
	
	public EsraClientConfiguration getClientConfiguration()
	{
		return this.clientConfiguration;
	}
	
	public void setClientConfiguration(final EsraClientConfiguration clientConfiguration)
	{
		this.clientConfiguration = clientConfiguration;
	}
	
	public Map<MailType, MailTemplate> getMailTemplates()
	{
		return this.mailTemplates;
	}
	
	public void setMailTemplates(final Map<MailType, MailTemplate> mailTemplates)
	{
		this.mailTemplates = mailTemplates;
	}
	
	public Set<String> getMatchRatingStatements(final boolean forceUpdate)
	{
		if(this.matchRatingStatements.isPresent() && !forceUpdate)
		{
			return this.matchRatingStatements.get();
		}
		else
		{
			this.matchRatingStatements = Optional.of(ClientDAO.getMatchRatingStatements(this));
			return this.matchRatingStatements.get();
		}
	}
	
	public void setMatchRatingStatements(final Set<String> matchRatingStatements)
	{
		this.matchRatingStatements = Optional.of(matchRatingStatements);
	}
	
	public List<MatchCategoryTag> getMatchCategoryTags(final boolean forceUpdate)
	{
		if(this.matchCategoryTags.isPresent() && !forceUpdate)
		{
			return this.matchCategoryTags.get();
		}
		else
		{
			this.matchCategoryTags = Optional.of(ClientDAO.getMatchRatingCategories(this));
			return this.matchCategoryTags.get();
		}
	}
	
	public void setMatchCategoryTags(final List<MatchCategoryTag> matchCategoryTags)
	{
		this.matchCategoryTags = Optional.of(matchCategoryTags);
	}
	
	/**
	 * Returns the client's user as a unmodifiable Set.
	 * 
	 * @return
	 */
	public Set<User> getUser()
	{
		return SetUtils.unmodifiableSet(this.getUserFull(true).keySet());
	}
	
	/**
	 * Returns the client's user and assignment infos.
	 * 
	 * @return
	 */
	public Map<User, ManualClientUserAssignment> getUserFull(final Boolean forceUpdate)
	{
		if(this.clientUser.isPresent() && !forceUpdate)
		{
			return this.clientUser.get();
		}
		else
		{
			this.clientUser = Optional.of(ClientDAO.getUserFull(this));
			return this.clientUser.get();
		}
		
	}
	
	public Set<Role> getRoles(final boolean forceUpdate)
	{
		if(this.roles.isPresent() && !forceUpdate)
		{
			return this.roles.get();
		}
		else
		{
			this.roles = Optional.of(RoleDAO.findAll(this));
			return this.roles.get();
		}
	}
	
	public void setRoles(final Set<Role> roles)
	{
		this.roles = Optional.of(roles);
	}
	
	
	public Set<ComplianceScreeningKeyData> getSeaweb2ScreeningKeyConfig(final boolean forceUpdate)
	{
		if(this.seaweb2ScreeningKeyConfig.isPresent() && !forceUpdate)
		{
			return this.seaweb2ScreeningKeyConfig.get();
		}
		else
		{
			this.seaweb2ScreeningKeyConfig = Optional.of(ClientDAO.getSeaweb2ScreeningKeyConfig(this));
			return this.seaweb2ScreeningKeyConfig.get();
		}
	}
	
	public void setSeaweb2ScreeningKeyConfig(final Set<ComplianceScreeningKeyData> seaweb2ScreeningKeyConfig)
	{
		this.seaweb2ScreeningKeyConfig = Optional.of(seaweb2ScreeningKeyConfig);
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(this.uuid);
	}
	
	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(this.getClass() != obj.getClass())
		{
			return false;
		}
		final Client other = (Client)obj;
		return Objects.equals(this.uuid, other.uuid);
	}
	
}
