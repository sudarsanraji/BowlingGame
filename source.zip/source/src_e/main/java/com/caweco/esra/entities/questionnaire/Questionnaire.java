package com.caweco.esra.entities.questionnaire;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.ui.interfaces.HasActiveState;
import com.rapidclipse.framework.server.resources.Caption;


public class Questionnaire implements HasActiveState
{
	private Integer					questionnaireID;
	private String					description;
	private List<QuestionCategory>	categories		= new ArrayList<>();
	private Optional<List<Question>> questions		= Optional.empty();
	private Boolean					active			= true;
	private QuestionnaireCategory	category;
	private int						version			= 1;
	

	
	@Caption("Category")
	public QuestionnaireCategory getCategory()
	{
		return this.category;
	}
	
	public void setCategory(final QuestionnaireCategory category)
	{
		this.category = category;
	}
	
	public List<QuestionCategory> getCategories()
	{
		return this.categories;
	}
	
	public void setCategories(final List<QuestionCategory> categories)
	{
		this.categories = categories;
	}
	

	
	@Caption("Active")
	public Boolean getActive()
	{
		return this.active;
	}
	
	@Caption("ID")
	public Integer getQuestionnaireID()
	{
		return this.questionnaireID;
	}
	
	public void setQuestionnaireID(final Integer questionnaireID)
	{
		this.questionnaireID = questionnaireID;
	}
	
	@Caption("Description")
	public String getDescription()
	{
		return this.description;
	}
	
	public void setDescription(final String description)
	{
		this.description = description;
	}
	
	@Caption("Questions")
	public List<Question> getQuestions(final boolean forceUpdate)
	{
		if(this.questions.isPresent() && !forceUpdate)
		{
			return this.questions.get();
		}
		else
		{
			final List<Question> questions = QuestionDAO.getQuestions(this, CurrentUtil.getClient());
			
			this.questions = Optional.of(questions);
			return this.questions.get();
		}
	}
	
	public void setQuestions(final List<Question> questions)
	{
		this.questions = Optional.of(questions);
	}
	
	@Caption("Vers.")
	public int getVersion()
	{
		return this.version;
	}
	
	public void setVersion(final int version)
	{
		this.version = version;
	}
	
	@Override
	public boolean isActive()
	{
		return BooleanUtils.isTrue(this.active);
	}
	
	@Override
	public void setActive(final boolean active)
	{
		this.active = active;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.questionnaireID);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (this.getClass() != obj.getClass())
		{
			return false;
		}
		final Questionnaire other = (Questionnaire) obj;
		return Objects.equals(this.questionnaireID, other.questionnaireID);
	}
	
	
}
