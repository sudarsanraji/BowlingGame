package com.caweco.esra.entities.access;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.ldap.LdapAttributes;
import com.caweco.esra.entities.ldap.LdapOrg;
import com.caweco.esra.entities.meta.HasRepresentation;
import com.caweco.esra.entities.saml.SamlAttributes;
import com.caweco.esra.entities.saml.SamlCountry;


/**
 * Used to check if a user's {@link LdapAttributes} fit to this rule.<br />
 * If LdapAttributes fits user is assigned to "clientToAssignTo" automatically.
 * <p>
 * There are three criterias:
 * <ul>
 * <li>the company - must be set</li>
 * <li>a {@link SamlCountry} - may be unset. "unset" means ALL countries</li>
 * <li>a department - may be unset. "unset" means ALL departments</li>
 * </ul>
 *
 */
public class ClientAssignmentRuleLdap implements HasRepresentation, HasClientAssignmentInfo
{
	private UUID uuid;
	private final Instant              created = Instant.now();
	private final AccessControlCompany company;
	private SamlCountry                samlCountry;
	private LdapOrg                    department;
	
	private Client               clientToAssignTo;
	private Set<Role>            rolesToAssign;
	
	public ClientAssignmentRuleLdap(Client client, AccessControlCompany company)
	{
		super();
		Objects.requireNonNull(client);
		Objects.requireNonNull(company);
		this.clientToAssignTo = client;
		this.company = company;
		
	}
	
	public ClientAssignmentRuleLdap(Client client, AccessControlCompany company, LdapOrg department)
	{
		super();
		Objects.requireNonNull(client);
		Objects.requireNonNull(company);
		Objects.requireNonNull(department);
		this.clientToAssignTo = client;
		this.company = company;
		this.department = department;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public AccessControlCompany getCompany()
	{
		return this.company;
	}
	
	public LdapOrg getDepartment()
	{
		return this.department;
	}
	
	public SamlCountry getSamlCountry()
	{
		return this.samlCountry;
	}
	
	public void setSamlCountry(SamlCountry samlCountry)
	{
		this.samlCountry = samlCountry;
	}
	
	@Override
	public String getRepresentation()
	{
		StringBuilder sb = new StringBuilder(this.company.getDisplayName());
		
		if (this.samlCountry != null)
			sb.append(" - ").append(this.samlCountry.getCountryName());
		else
			sb.append(" - ").append("all countries");
		
		if (this.department != null)
			sb.append(" - ").append(this.department.getDisplayName());
		else
			sb.append(" - ").append("all departments");
		
		return sb.toString();
	}
	
	@Override
	public Client getClientToAssignTo()
	{
		return this.clientToAssignTo;
	}
	
	public void setClientToAssignTo(Client clientToAssignTo)
	{
		this.clientToAssignTo = clientToAssignTo;
	}
	
	public Set<Role> getRolesToAssign()
	{
		return this.rolesToAssign;
	}
	
	public void setRolesToAssign(Set<Role> rolesToAssign)
	{
		this.rolesToAssign = rolesToAssign;
	}
	
	/**
	 * Also for {@link LdapAttributes}
	 */
	@Override
	public boolean fit(SamlAttributes attr)
	{
		// No input -> Always false
		if (attr == null)
			return false;
		
		//// Check Company
		
		Optional<String> currentCompany = attr.getCompany();
		
		// Attribute not found -> Always false
		if (!currentCompany.isPresent())
			return false;
		
		// AttributeValue is not correct -> false
		if (!currentCompany.get().equals(this.company.getDistinguishedName()))
			return false;
		
		//// Company is OK here, so proceed with Country
		
		//// Check Country
		
		// If Country is defined in rule, country must fit -> if fits proceed with Department, otherwise return false (as all
		// rules must fit);
		if (this.getSamlCountry() != null)
		{
			boolean fitCountry = this.samlCountry.fit(attr);
			if (!fitCountry)
				return false;
		}
		
		//// Company is OK here, and Country is also OK or not set, so proceed with Department
		//// Check Department
		
		// No Department defined in this rule -> true
		if (this.getDepartment() == null)
			return true;
		
		// Compare "Attribute for department" to "departmentName"
		Optional<String> currentDepartment = attr.getDepartment();
		if (!currentDepartment.isPresent())
			return false;
		return currentDepartment.get().equals(this.department.getDistinguishedName());
		
	}
	
	
	public boolean mayFitSameAttributeSet(ClientAssignmentRuleLdap other)
	{
		if (this == other)
			return true;
		if (other == null)
			return false;
		
		if (!this.company.equalsNC(other.company))
		{
			return false;
		}
		
		// If samlCountry is "null" the rule is valid for ALL countries
		// -> "this" and "other" only differ if both countries are set and are not the same.
		
		if (this.samlCountry != null && other.samlCountry != null && !this.samlCountry.equals(other.samlCountry))
		{
			return false;
		}
		
		// If samlDepartment is "null" the rule is valid for ALL departments
		// -> "this" and "other" only differ if both departments are set and are not the same.
		
		if (this.department != null
			&& other.department != null
			&& !this.department.equalsNC(other.department))
		{
			return false;
		}
		
		return true;
	}
	
	@Override
	public int hashCode()
	{
		final int prime  = 31;
		int       result = 1;
		result = prime * result + ((this.company == null) ? 0 : this.company.hashCode());
		result = prime * result + ((this.department == null) ? 0 : this.department.hashCode());
		result = prime * result + ((this.samlCountry == null) ? 0 : this.samlCountry.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (this.getClass() != obj.getClass())
			return false;
		ClientAssignmentRuleLdap other = (ClientAssignmentRuleLdap) obj;
		if (this.company == null)
		{
			if (other.company != null)
				return false;
		}
		else if (!this.company.equals(other.company))
			return false;
		if (this.department == null)
		{
			if (other.department != null)
				return false;
		}
		else if (!this.department.equals(other.department))
			return false;
		if (this.samlCountry == null)
		{
			if (other.samlCountry != null)
				return false;
		}
		else if (!this.samlCountry.equals(other.samlCountry))
			return false;
		return true;
	}

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
	
	
	
//	@Override
//	public int hashCode()
//	{
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((this.samlCompany == null) ? 0 : this.samlCompany.hashCode());
//		result = prime * result + ((this.samlCountry == null) ? 0 : this.samlCountry.hashCode());
//		result = prime * result + ((this.samlDepartment == null) ? 0 : this.samlDepartment.hashCode());
//		return result;
//	}
//	
//	@Override
//	public boolean equals(Object obj)
//	{
//		if(this == obj)
//			return true;
//		if(obj == null)
//			return false;
//		if(this.getClass() != obj.getClass())
//			return false;
//		ClientAssignmentRuleLdap other = (ClientAssignmentRuleLdap)obj;
//		if(this.samlCompany == null)
//		{
//			if(other.samlCompany != null)
//				return false;
//		}
//		else if(!this.samlCompany.equals(other.samlCompany))
//			return false;
//		if(this.samlCountry == null)
//		{
//			if(other.samlCountry != null)
//				return false;
//		}
//		else if(!this.samlCountry.equals(other.samlCountry))
//			return false;
//		if(this.samlDepartment == null)
//		{
//			if(other.samlDepartment != null)
//				return false;
//		}
//		else if(!this.samlDepartment.equals(other.samlDepartment))
//			return false;
//		return true;
//	}
}
