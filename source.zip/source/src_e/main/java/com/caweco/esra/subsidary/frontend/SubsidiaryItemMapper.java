
package com.caweco.esra.subsidary.frontend;

import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskDTO;

public class SubsidiaryItemMapper
{
	public static SubsidiaryScreeningTaskF convert(SubsidiaryScreeningTaskDTO it)
	{
		
		if(it == null)
			return null;
		
		return new SubsidiaryScreeningTaskF(
			it.getId(),
			it.getCreated(),
			it.getCreatedBy(),
			
			it.getClientId(),
			it.getScreeningId(),
			it.getSearchEntryCompanyId(),
			
			it.getRootBvdId(),
			it.getRootCompanyName(),
			it.getState(),
			
			it.isResultDataAvailableInBackend(),
			it.isThisIsFromBackend(),
			it.getRunData(),
			
			it.getResultTree(),
			it.getResultData(), // is null when DTO is from backend
			it.getAppliedData());
	}
	
	/**
	 * HINT: Does NOT fetch "resultData" from backend to write it to DTO to send it back to backend.
	 * @param it
	 * @return
	 */
	public static SubsidiaryScreeningTaskDTO convertToDTO(SubsidiaryScreeningTaskF it)
	{
		
		if(it == null)
			return null;
		
		return new SubsidiaryScreeningTaskDTO(
			it.getId(),
			it.getCreated(),
			it.getCreatedBy(),
			
			it.getClientId(),
			it.getScreeningId(),
			it.getSearchEntryCompanyId(),
			
			it.getRootBvdId(),
			it.getRootCompanyName(),
			it.getState(),
			
			it.resultDataAvailableInBackend,
			it.thisIsFromBackend,
			it.getRunData(),
			
			it.getResultTree(),
			it.getResultData(false),
			it.getAppliedData());
	}
}
