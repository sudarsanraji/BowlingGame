package com.caweco.esra.ui.beans;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.function.Supplier;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.entities.Client;
import com.caweco.esra.ui.interfaces.ComboBoxValue;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.InputEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializableBiFunction;
import com.vaadin.flow.function.SerializableConsumer;


public class PartComboBoxValueForm<T extends ComboBoxValue> extends VerticalLayout
{
	
	private T                                          item;
	private Collection<T>                        items;
	private final Class<T>					clazz;
	
	private SerializableBiFunction<T, Client, Boolean> deletableRule;
	private SerializableConsumer<T> saveExistingMethod;
	private SerializableConsumer<T> deleteExistingMethod;
	private SerializableConsumer<T> saveNewMethod;
	private Client                                     client;
	private Callable<Collection<T>> refreshMethod;
	
	/**
	 *
	 */
	@SuppressWarnings("unchecked")
	public PartComboBoxValueForm(
		final Collection<T> items,
		final Class<T> clazz,
		final String name,
		final SerializableConsumer<T> saveExistingMethod,
		final SerializableConsumer<T> saveNewMethod,
		final SerializableConsumer<T> deleteExistingMethod,
		final Callable<Collection<T>> refreshMethod
		)
	{
		super();
		this.clazz = clazz;
		this.items = items;
		this.saveExistingMethod = saveExistingMethod;
		this.saveNewMethod = saveNewMethod;
		this.deleteExistingMethod = deleteExistingMethod;
		this.refreshMethod = refreshMethod;
		this.initUI();
		Column<ComboBoxValue> nameColumn = this.grid.getColumnByKey("name");
		this.grid.sort(GridSortOrder.asc(nameColumn).build());
		
		this.lblType.setText(name);
		
		this.grid.setItems((Collection<ComboBoxValue>)items);
		
		this.setNewItemToForm();
		
		UiHelper.setAriaLabel(this.btnNew, Aria.get("Values_add"));
		UiHelper.setAriaLabel(this.btnDelete, Aria.get("Values_remove"));
		UiHelper.setAriaLabel(this.btnSave, Aria.get("Values_save"));
	}
	

	public PartComboBoxValueForm<T> withDeleteButton()
	{
		this.btnDelete.setVisible(true);
		return this;
	}
	
	public PartComboBoxValueForm<T> withDeletableRule(SerializableBiFunction<T, Client, Boolean> deletableRule, Client client)
	{
		this.deletableRule = deletableRule;
		this.client = client;
		return this;
	}
	
	
	/*********************************************************/
	
	
	protected boolean evalSaveEnabled()
	{
		String value = StringUtils.stripToEmpty(this.txtName.getValue());
		boolean no1 = (value.length() >= 3);
		return no1;
	}
	
	protected void setNewItemToForm()
	{
		try
		{
			T item = this.clazz.getDeclaredConstructor().newInstance();
			this.setItemToForm(item, true);
		}
		catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void setItemToForm(T item, boolean isNew)
	{
		this.item = item;
		this.binder.readBean(this.item);
		this.btnSave.setEnabled(this.evalSaveEnabled());
		if (!isNew && this.deletableRule != null && this.client != null)
		{
			Boolean isDeletable = this.deletableRule.apply(this.item, this.client);
			this.btnDelete.setEnabled(BooleanUtils.isTrue(isDeletable));
		}
		else
		{
			this.btnDelete.setEnabled(!isNew);
		}
		this.txtName.focus();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		try
		{
			this.binder.writeBean(this.item);
			
			if(this.items.contains(this.item))
			{
				this.saveExistingMethod.accept(this.item);
				this.items = (Collection<T>) this.refreshMethod.call();
				this.grid.setItems((Collection<ComboBoxValue>) this.items);
				this.grid.getDataProvider().refreshItem(this.item);
			}
			else
			{
				
				this.items.add(this.item);
				this.saveNewMethod.accept(this.item);
				this.items = (Collection<T>) this.refreshMethod.call();
				this.grid.setItems((Collection<ComboBoxValue>) this.items);
				this.grid.getDataProvider().refreshAll();
			}
			
			this.setNewItemToForm();
		}
		catch (final Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	@SuppressWarnings("unchecked")
	private void grid_selectionChange(SelectionEvent<Grid<ComboBoxValue>, ComboBoxValue> event)
	{
		Optional<ComboBoxValue> selected = event.getFirstSelectedItem();
		if (selected.isPresent())
		{
			this.setItemToForm((T) selected.get(), false);
		}
		else
		{
			this.setNewItemToForm();
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNew_onClick(final ClickEvent<Button> event)
	{
		this.setNewItemToForm();
	}
	
	/**
	 * Event handler delegate method for the {@link TextField} {@link #txtName}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtName_onInput(final InputEvent event)
	{
		this.btnSave.setEnabled(this.evalSaveEnabled());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDelete_onClick(ClickEvent<Button> event)
	{
		this.grid.getSelectionModel().getFirstSelectedItem().ifPresent(it ->
		{
			this.items.remove(it);
			this.deleteExistingMethod.accept(this.item);
			
			this.grid.getDataProvider().refreshAll();
			this.grid.deselectAll();
			
			this.setNewItemToForm();
		});
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout2 = new HorizontalLayout();
		this.lblType = new Label();
		this.btnDelete = new Button();
		this.btnNew = new Button();
		this.grid = new Grid<>(ComboBoxValue.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.txtName = new TextField();
		this.btnSave = new Button();
		this.binder = new Binder<>();
		
		this.setSpacing(false);
		this.setMaxHeight("500px");
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout2.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.lblType.setText("Label");
		this.btnDelete.setEnabled(false);
		this.btnDelete.setVisible(false);
		this.btnDelete.setIcon(VaadinIcon.TRASH.create());
		this.btnNew.setIcon(VaadinIcon.PLUS.create());
		this.grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT, GridVariant.LUMO_WRAP_CELL_CONTENT);
		this.grid.getStyle().set("flex-basis", "0");
		this.grid.addColumn(ComboBoxValue::getId).setKey("id").setHeader(CaptionUtils.resolveCaption(ComboBoxValue.class, "id"))
			.setSortable(true).setAutoWidth(true).setFlexGrow(0);
		this.grid.addColumn(ComboBoxValue::getName).setKey("name")
			.setHeader(CaptionUtils.resolveCaption(ComboBoxValue.class, "name"))
			.setSortable(true);
		this.grid.addColumn(ComboBoxValue::getActive).setKey("active")
			.setHeader(CaptionUtils.resolveCaption(ComboBoxValue.class, "active")).setSortable(true).setAutoWidth(true)
			.setFlexGrow(0);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.horizontalLayout.setSpacing(false);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.label.setText("Value");
		this.label.getStyle().set("margin-right", "10px");
		this.txtName.setValueChangeTimeout(0);
		this.txtName.setValueChangeMode(ValueChangeMode.TIMEOUT);
		this.btnSave.setEnabled(false);
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		
		this.binder.forField(this.txtName).withNullRepresentation("").bind(ComboBoxValue::getName, ComboBoxValue::setName);
		
		this.lblType.setWidthFull();
		this.lblType.setHeight(null);
		this.btnDelete.setSizeUndefined();
		this.btnNew.setSizeUndefined();
		this.horizontalLayout2.add(this.lblType, this.btnDelete, this.btnNew);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblType);
		this.label.setSizeUndefined();
		this.txtName.setWidthFull();
		this.txtName.setHeight(null);
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.label, this.txtName, this.btnSave);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.END, this.btnSave);
		this.horizontalLayout2.setSizeUndefined();
		this.grid.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.horizontalLayout2, this.grid, this.horizontalLayout);
		this.setFlexGrow(1.0, this.grid);
		this.setWidth("350px");
		this.setHeight(null);
		
		this.btnDelete.addClickListener(this::btnDelete_onClick);
		this.btnNew.addClickListener(this::btnNew_onClick);
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.txtName.addInputListener(this::txtName_onInput);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Binder<ComboBoxValue> binder;
	private Button                btnDelete, btnNew, btnSave;
	private HorizontalLayout      horizontalLayout2, horizontalLayout;
	private Label                 lblType, label;
	private Grid<ComboBoxValue>   grid;
	private TextField             txtName;
	// </generated-code>
	
}
