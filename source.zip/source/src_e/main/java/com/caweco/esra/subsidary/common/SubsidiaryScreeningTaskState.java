
package com.caweco.esra.subsidary.common;

public enum SubsidiaryScreeningTaskState
{
	/**
	 * Initial State. By default replaced before registering Task in backend
	 * at creating and starting of the task with RUNNING.<br />
	 * Task can have this state after lost heartbeat or app restart.<br />
	 * <b>Blocks screening.</b>
	 */
	CREATED_WAITING,

	/**
	 * Data fetching and processing is in progress.<br />
	 * <b>Blocks screening.</b>
	 */
	RUNNING,

	/**
	 * Data fetching and processing stopped with an error<br />
	 *
	 */
	DONE_ERROR,

	/**
	 * Data fetching and processing done successfully.<br />
	 * User input needed before applying data to Screening.<br />
	 * <b>Blocks screening.</b>
	 */
	DONE_OK,

	/**
	 * Skipped by user or otherwise.<br />
	 *
	 */
	DONE_SKIPPED,

	/**
	 * Data fetching and processing done successfully.<br />
	 * Data also applied to screening. (By user or automatically)<br />
	 *
	 */
	APPLIED,

	/**
	 * Data fetched and applied to screening, but a new Task was started for same screening/company.<br />
	 * Item here just for documentation.
	 */
	APPLIED_REPLACED;
	
	public boolean isBlocking()
	{
		switch(this)
		{
			case CREATED_WAITING:
			case RUNNING:
			case DONE_OK:
				return true;
			default:
				return false;
		}
	}
	
	public boolean isDone()
	{
		switch(this)
		{
			case CREATED_WAITING:
			case RUNNING:
				return false;
			default:
				return true;
		}
	}
	
}
