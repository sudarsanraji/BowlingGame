
package com.caweco.esra;

import org.tinylog.Logger;

import com.rapidclipse.framework.server.RapServletService;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinSession;


/**
 * Servlet error handler, prints stacktraces by default.
 */
@SuppressWarnings("ucd") // required for RC
public class LogExtension implements RapServletService.Extension
{
	@Override
	public void sessionCreated(
		final RapServletService service,
		final VaadinSession session,
		final VaadinRequest request)
	{
		session.setErrorHandler(event ->
		{
			
			// event.getThrowable().printStackTrace();
			Logger.error(event.getThrowable());
		});
	}
}
