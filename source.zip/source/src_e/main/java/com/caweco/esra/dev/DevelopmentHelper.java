package com.caweco.esra.dev;

import java.util.Objects;
import java.util.Optional;

import org.tinylog.Logger;

import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.entities.config.ConfigMailServer;


public class DevelopmentHelper
{
	//////////
	//// MAILING
	
	public static boolean useDevData_MailServer()
	{
		return Optional.ofNullable(ApplicationPropertyProvider.prop.getProperty("flag.usedevdata.mailserver")).filter(
			v -> Objects.equals(v, "true")).isPresent();
	}
	
	public static ConfigMailServer getDevData_Mailsettings()
	{
		
		// final ConfigMailServer devMailServer = new ConfigMailServer();
		// devMailServer.setSmtpPort("25");
		// devMailServer.setSmtpUsername("smtpsender@xdev-software.de");
		// devMailServer.setSmtpSenderEmailAddress("smtpsender@xdev-software.de");
		// devMailServer.setSmtpServerURL("xdevsoftware-de01b.mail.protection.outlook.com");
		// return devMailServer;
		
		final ConfigMailServer mailSettingsItem = new ConfigMailServer();
		mailSettingsItem.setSmtpServerURL("smtp.gmail.com");
		mailSettingsItem.setSmtpPort("465");
		mailSettingsItem.setSsh(true);
		mailSettingsItem.setSmtpUsername("jo.me.rcdebug@gmail.com");
		mailSettingsItem.setSmtpSenderEmailAddress("jo.me.rcdebug@gmail.com");
		mailSettingsItem.setSmtpPassword("qCpDjd!8oaM61#PtJp$F");
		
		Logger.warn("USE DEV MAILSETTINGS!!");
		return mailSettingsItem;
		
	}
	
}
