
package com.caweco.esra.business.func.rest;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import com.caweco.esra.entities.config.ConfigRestEndpoint;

import jakarta.ws.rs.client.WebTarget;


public class RestClientESRADB
{
	
	private final WebTarget                            webTarget;
	private final ConcurrentHashMap<String, WebTarget> registry              = new ConcurrentHashMap<>();
	final ConfigRestEndpoint                           esraRestConfiguration = ConfigRestEndpoint.getConfigESRADB();
	
	public RestClientESRADB()
	{
		this.webTarget = RestClientBuilder.getClientESRADB()
			.target(esraRestConfiguration.getEndpointBaseURL());
		
		HttpAuthenticationFeature authFeature = HttpAuthenticationFeature.basic("iGJHahzkB2NHf4XdapxrJ3EmJurb9LTi2Jwp9LU4wEPzDjsuDkpHr6cbmmYdFBfR", "YZr4rw3o9MmCcrwzrs3tWMVZYHXxgfZiUymt4C3KepuKhacEtzTEo8vyZxaxiR6D");
		
		this.webTarget.register(authFeature);
	}
	
	public WebTarget getMethodTarget(final String methodName)
	{
		if(StringUtils.isBlank(methodName))
		{
			return this.webTarget;
		}
		
		return this.registry.computeIfAbsent(methodName, path -> this.webTarget.path(path));
	}
	
	public WebTarget getWebTarget()
	{
		return this.webTarget;
	}
	
}
