package com.caweco.esra.business.utils;

/**
 * Creates a pointer to a pointer. This is usually useless, but for jasper we
 * use this so we can create a list of strings as a data source. Normally that
 * wouldn't work as we have to access a field as a value. So when using this we
 * can use the actual String as the value.
 */
public class Wrapper<T> {
	private final T value;

	public Wrapper(final T value) {
		this.value = value;
	}

	public T getValue() {
		return value;
	}
}
