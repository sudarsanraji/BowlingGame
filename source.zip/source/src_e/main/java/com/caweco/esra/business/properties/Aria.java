package com.caweco.esra.business.properties;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class Aria
{
	protected Aria()
	{
	}
	
	public static String              ARIA_LABEL_UNDEFINED    = "Aria text is undefined. Please report this to your admin!";
	public static Map<String, String> ariaLabelTextCollection = new ConcurrentHashMap<String, String>();
	
	/**
	 * Returns the string value for given key, or an empty {@link Optional} otherwise.
	 * 
	 * @param key
	 * @return
	 */
	public static Optional<String> getText(String key)
	{
		if (ariaLabelTextCollection == null || ariaLabelTextCollection.isEmpty())
		{
			ariaLabelTextCollection = new Aria().init();
		}
		return Optional.ofNullable(ariaLabelTextCollection.get(key));
	}
	
	/**
	 * Returns the string value for given key, or {@link Aria#ARIA_LABEL_UNDEFINED} otherwise
	 * 
	 * @param key
	 * @return
	 */
	public static String get(String key)
	{
		return getText(key).orElse(ARIA_LABEL_UNDEFINED);
	}
	
	public Map<String, String> init()
	{
		Map<String, String> map = new ConcurrentHashMap<String, String>();
		
		// Common - QuillEditor
		map.put("QuillEditor_setTextType", "Set text type");
		map.put("QuillEditor_toggleBold", "Bold");
		map.put("QuillEditor_toggleItalic", "Italic");
		map.put("QuillEditor_toggleUnderline", "Underlined");
		map.put("QuillEditor_addLink", "Add Link");
		map.put("QuillEditor_Ordered", "Ordered");
		map.put("QuillEditor_Bullet", "Bullet");
		map.put("QuillEditor_textColor", "Text Color");
		map.put("QuillEditor_textBackgroundColor", "Background Color");
		map.put("QuillEditor_delete", "Delete text");
		
		// Common - FilterComponent
		map.put("FilterComponent_addFilter", "Add Filter");
		map.put("FilterComponent_removeFilter", "Remove Filter");
		
		
		// Common - ESUTag
		map.put("ESUTag_remove", "Remove");
		
		// Common - MarkerRedFlag
		map.put("FindingMarker_SR_SR", "Sanctions Risk");
		map.put("FindingMarker_SR_PSR", "Potential Sanctions Risk");
		map.put("FindingMarker_SR_none", "No Sanctions Risk");
		map.put("FindingMarker_SR_unknown", "Unknown / Not finished");
		
		// Common - FileboxItem
		map.put("FileboxItem_remove", "Remove file");
		
		// PartAppHeader
		map.put("AppHeader_toStartPage", "Go to start page");
		map.put("AppHeader_settings", "Settings");
		map.put("AppHeader_logout", "Logout");
		map.put("AppHeader_changeClient", "Change Client");
		
		map.put("AppHeader_showNotifications", "Show Notifications");
		map.put("AppHeader_showTasks", "Show Tasks");
		
		// ContainerCreateScreening
		map.put("ContainerCreateScreening_nav", "Screening navigation");
		
		// PageSanctionSearch
		map.put("PageSanctionSearch_filter_onlyown_all", "Show all assigned Screenings.");
		
		map.put("PageSanctionSearch_item_edit", "Edit");
		map.put("PageSanctionSearch_item_pdfSummary", "Show PDF Summary");
		
		// PageSanctionScreening
		map.put("PageSanctionScreening_toggleWatchlistOpen", "Open or Close all watchlist items");
		// PageSanctionScreening -> BeanWatchlistItemHeader
		map.put("PageSanctionScreening_finding_info", "Show detailed information");
		map.put("PageSanctionScreening_finding_remove", "Remove from list");
		
		map.put("PageSanctionScreening_finding_subsidiary_start", "Start Subsidiary Screening");
		map.put("PageSanctionScreening_finding_subsidiary_pending", "Pending Subsidiary Screening");
		map.put("PageSanctionScreening_finding_subsidiary_show", "Show tree");
		
		// PageSanctionScreening -> RendererWatchlistItemActions
		map.put("PageSanctionScreening_finding_singleitem_info", "Show detailed information");
		map.put("PageSanctionScreening_setRatingStatement", "Set rating statement");
		map.put("PageSanctionScreening_setRating", "Set finding rating");
		
		// PageEsuAssessment -> PartEsuText
		map.put("PageEsuAssessment_addText", "Add text block");
		
		// PageEsuAssessment -> PartMessagingMain
		map.put("Messaging_msg_save", "Save");
		// PageEsuAssessment -> PartMessageSingle
		map.put("Messaging_msg_delete", "Delete");
		// PageEsuAssessment -> PartMessageCategoryManager
		map.put("Messaging_newGroup", "New Group");
		map.put("Messaging_addGroupUser", "Add User");
		map.put("Messaging_leaveGroup", "Leave Group");
		map.put("Messaging_editGroup", "Edit Group");
		map.put("Messaging_deleteGroup", "Delete Group");
		
		// PageESUWorklist -> GenColScreeningGrid
		map.put("PageEsuWorklist_item_edit", "");
		map.put("PageEsuWorklist_item_pdfSummary", "Show PDF Summary");
		map.put("PageEsuWorklist_item_reviewer", "Change Reviewer");
		// PageESUWorklist -> RendererFavButton
		map.put("PageEsuWorklist_item_favorite", "Toggle favorite");
		
		// Backend - PageAccessControl -> PartRuleItems
		map.put("PageAccessControl_comp_add", "Add new company entry");
		map.put("PageAccessControl_comp_remove", "Remove company");
		map.put("PageAccessControl_dep_add", "Add new department entry");
		map.put("PageAccessControl_dep_remove", "Remove department");
		map.put("PageAccessControl_country_add", "Add new country entry");
		map.put("PageAccessControl_country_remove", "Remove country");
		// Backend - PageAccessControl -> DialogNewLdapCompany
		map.put("PageAccessControl_comp_search", "Search");
		// Backend - PageAccessControl -> DialogNewLdapDepartment
		map.put("PageAccessControl_dep_search", "Search");
		// Backend - PageAccessControl -> PartRulesLdap
		map.put("PageAccessControl_ar_add", "Add access rule");
		map.put("PageAccessControl_ar_remove", "Remove access rule");
		map.put("PageAccessControl_car_add", "Add client assignmenmt rule");
		map.put("PageAccessControl_car_remove", "Remove client assignmenmt rule");
		
		// Backend - PageBackup -> RendererS3ElementAction
		map.put("PageBackup_remove", "Delete Backup");
		
		// Backend - PageAllUser -> RendererUserBackendActions
		map.put("PageAllUser_delete", "Delete User");
		
		// Backend - PageUserRoles -> RendererRoleBackendActions
		map.put("PageUserRoles_delete", "Delete Group");
		
		// Backend - PageComboBoxData
		// -> PartSimpleValueForm, PartOEForm, PartComboBoxValueForm, PartStringValueForm, PartEsraTag
		map.put("Values_add", "Add");
		map.put("Values_remove", "Delete");
		map.put("Values_save", "Save");
		// Backend - PageComboBoxData -> RendererEsraTagAction
		map.put("Values_esraTag_edit", "Edit");
		// Backend - PageComboBoxData -> ColorPicker
		map.put("Values_esraTag_color", "Choose Color");
		// Backend - PageComboBoxData -> RendererSeawebComplianceKeyAction
		map.put("Values_seawebComplianceKey_edit", "Edit");
		
		// Backend - PageQuestionnaireOverview -> GenColQuestionnaireGrid
		map.put("Quest_item_edit", "Edit Questionnaire");
		map.put("Quest_item_clone", "Clone Questionnaire");
		map.put("Quest_item_remove", "Delete Questionnaire");
		// Backend - PageQuestionnaireOverview -> GenColCategoryGrid
		map.put("Quest_category_remove", "Delete Question Category");
		// Backend - PageQuestionnaireOverview -> GenColQuestionGrid
		map.put("Quest_question_edit", "Edit Question");
		map.put("Quest_question_remove", "Delete Question");
		// Backend - PageQuestionnaireOverview -> BeanRuleComponent
		map.put("Quest_questionRule_AND_add", "Add AND Condition");
		map.put("Quest_questionRule_remove", "Delete Condition");
		// Backend - PageQuestionnaireOverview -> BeanRuleComponent
		map.put("Quest_questionRule_OR_add", "Add OR Condition");
		
		// Backend - PageTemplateOverview -> GenColESUTemplate
		map.put("EsuTemplate_item_edit", "Edit Template");
		map.put("EsuTemplate_item_clone", "Clone Template");
		map.put("EsuTemplate_item_remove", "Delete Template");
		
		
		return map;
	}
	
	
}
