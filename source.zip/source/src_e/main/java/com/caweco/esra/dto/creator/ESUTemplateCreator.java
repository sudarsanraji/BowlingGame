package com.caweco.esra.dto.creator;


import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.ESUTemplate;
import com.caweco.esra.entities.core.ESUTemplateCS;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.caweco.esra.dto.ESUTemplateMetadataDTO;

public class ESUTemplateCreator {
	
	public static ESUTemplate convert(Client client, ESUTemplateCS it) {
		if (it.getId() == -1) {
			return new ESUTemplate(
					it.getId(),
					it.getName(), 
					it.isActive(), 
					it.getVersion(), 
					it.getContentRaw() != null ? it.getContentRaw().orElse("") : "");
		}
		else {
			return new ESUTemplate(
					it.getId(),
					it.getName(), 
					it.isActive(), 
					it.getVersion(), 
					it.getContent(client, false));
		}
	}
	
	
	public static ESUTemplateCS convert(ESUTemplateMetadataDTO it) {
		return new ESUTemplateCS(it);
	}
	
	public static Set<ESUTemplate> convertCollection(Client client, Optional<Set<ESUTemplateCS>> optional) {
		
		if (optional.isPresent()) {
			return optional.get().stream().map(cs -> convert(client, cs)).collect(Collectors.toSet());
		}
		else return new HashSet<>(0);
	}
	
}
