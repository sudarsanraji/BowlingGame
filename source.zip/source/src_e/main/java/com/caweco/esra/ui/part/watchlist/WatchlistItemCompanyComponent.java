
package com.caweco.esra.ui.part.watchlist;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.business.report.ReportUtils;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.ui.interfaces.HasResettableDataCommunicator;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.caweco.esra.ui.part.watchlist.common.BeanWatchlistItemHeader;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElementType;
import com.caweco.esra.ui.part.watchlist.company.PartWatchlistItemCompanyGsssMatch;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.caweco.esra.ui.sanctions.parts.companydeatils.DialogCompanyDetails;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.function.SerializableBiConsumer;


public class WatchlistItemCompanyComponent extends Details
	implements RemovableWatchlistElement<WatchlistItemCompanyComponent>, HasResettableDataCommunicator
{
	private final Logger logger = LoggerFactory.getLogger(WatchlistItemCompanyComponent.class);
	
	protected PartWatchList                                                  root;
	
	// Data / Dataprovider
	protected SearchEntryCompany                                             item;
	protected Integer                                                        flagValue     = null;
	protected Integer                                                        flagValueOld  = null;
	protected boolean                                                        readOnly      = false;
	
	// Listener
	protected SerializableBiConsumer<WatchlistItemCompanyComponent, Boolean> flagChangeListener;
	
	// TEMPORARY DATA
	protected boolean                                                        isInitialized = false;
	
	// UI
	protected BeanWatchlistItemHeader                                        header;
	
	// Parent UI Wrapper
	protected WatchlistItemCompanyWrapper                                    parentWrapperComponent;
	
	/**
	 * Just creates the header. Does <b>NOT</b> perform a CompanyInfo REST call!
	 * 
	 * @param root
	 */
	public WatchlistItemCompanyComponent(final PartWatchList root)
	{
		super();
		this.root = root;
		this.initUI();
		
		this.getElement().setAttribute("class", "screeningheader with-workaround-edge");
		
		this.header = new BeanWatchlistItemHeader(
			WatchlistElementType.ESRA_WATCHLIST_ITEM,
			"Organization",
			"---")
				.withDetailButton(this::showDetails);
		this.setSummary(this.header);
		
		this.setOpened(false);
	}
	
	/***********************************************************/
	
	public ScreeningPageContext getContext()
	{
		return this.getWatchListRoot().map(PartWatchList::getContext).orElse(null);
	}
	
	public Screening getScreening()
	{
		return this.getWatchListRoot().map(PartWatchList::getScreening).orElse(null);
	}
	
	public WatchlistItemCompanyComponent setParentWrapper(final WatchlistItemCompanyWrapper parentWrapperComponent)
	{
		this.parentWrapperComponent = parentWrapperComponent;
		return this;
	}
	
	public WatchlistItemCompanyWrapper getParentWrapper()
	{
		return this.parentWrapperComponent;
	}
	
	/***********************************************************/
	
	protected void showDetails(final ClickEvent<Button> event)
	{
		final Dialog dialog = new Dialog(new DialogCompanyDetails(this.item.getItem()));
		dialog.setWidth("1200px");
		dialog.setHeight("800px");
		
		dialog.open();
	}
	
	/**
	 * Applies the {@link GsssMatch} items from the given {@link CIResponse}.
	 * 
	 * @param in
	 *            the CIResponse item
	 * @return
	 */
	public WatchlistItemCompanyComponent setItem(final SearchEntryCompany in)
	{
		this.item = in;
		
		//// Update Header - DATA
		
		this.header.setName(in.getItem().getCompanyInfoBvd() != null ? in.getItem().getCompanyInfoBvd().getName()
			: "<screening not available, try later again>");
		this.header.setDate(this.item.getCreated() != null ? ReportUtils.formatInstant(this.item.getCreated()) : "---");
		
		if(in.hasParent())
		{
			this.header.setTypePrefixText("Subsidiary");
		}
		else
		{
			
			// (2023-06-29) ESRA-626/ESRA-638
			// Disable temporarily.
			
			// this.header.withSubsidiaryScreening(in);
		}
		
		//// Update UI - MAIN FLAG
		
		// TODO X
		
		if(in.getItem().getCompanyInfoBvd() != null)
		{
			final Boolean marked = SanctionUtil.isMarked(this.getContext().getClient(), this.item);
			final Integer flag = SanctionUtil.toFlag(marked);			
			this.setValue(flag, true, false);
		}
		else
		{
			SanctionUtil.toFlag(null);
			this.setValue(null, true, false);
		}
		
		
		// Use "fromInternal" = true to prevent executing "flagChangeListener"
		// i changed this
		
		
		return this;
	}
	
	public SearchEntryCompany getItem()
	{
		return this.item;
	}
	
	/**
	 * Convenience method to get CompanyBvdId
	 * @return
	 */
	public Optional<String> getCompanyBvdId() 
	{
		return Optional.ofNullable(this.item).map(SearchEntryCompany::getItem).map(CIResponse::getCompanyBvdId);
	}
	
	/**
	 * Applies pending changes to the {@link SearchEntryCompany} and stores the changes.
	 * <p>
	 * (Only the "inner" changes. Does NOT apply a new SearchEntryCompany to the screening! This is done in
	 * {@link PartWatchList#writeToScreening()})
	 * </p>
	 * 
	 * @return the SearchEntryGsss.
	 */
	public SearchEntryCompany getStoredItem()
	{
		//// Apply pending data
		this.item.setComment(this.getComment());
		
		if(this.isInitialized)
		{
			final Map<GsssMatch, MatchData> matchData = this.collectMatchesAndPendingMatchData();
			this.item.setMatchData(matchData);
		}
		
		return this.item;
	}
	
	public String getComment()
	{
		return this.header.getComment();
	}
	
	public WatchlistItemCompanyComponent setComment(final String comment)
	{
		this.header.setComment(comment);
		return this;
	}
	
	/***********************************************************/
	// as WatchlistElement
	
	@Override
	public void removeSelfFromWatchlist()
	{
		if(this.parentWrapperComponent.isMainItem(this) && this.parentWrapperComponent.hasChildItems())
		{
			// This item is a parent and has children..
			Notificator.error("Cannot remove: This Company has Subsidiaries.");
		}
		else
		{
			// This item is either a parent without children or a child..
			this.getWatchListRoot().ifPresent(wl -> wl.removeItemCN(this));
		}
	}
	
	@Override
	public Optional<PartWatchList> getWatchListRoot()
	{
		return Optional.ofNullable(this.root);
	}
	
	@Override
	public void setReadOnlyCustom(final boolean readOnly)
	{
		if(this.readOnly != readOnly)
		{
			this.readOnly = readOnly;
			
			// Header
			if(this.readOnly)
			{
				this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
			}
			else
			{
				this.header.setType(WatchlistElementType.ESRA_WATCHLIST_ITEM);
			}
			
			// Content
			UIUtils.lookupComponentTree(this, PartWatchlistItemCompanyGsssMatch.class, c -> {
				c.setReadOnlyCustom(readOnly);
				return null;
			});
		}
	}
	
	@Override
	public void asEsuPart()
	{
		// Header
		this.header.setType(WatchlistElementType.ESU_WATCHLIST_ITEM);
			
		// Content
		UIUtils.lookupComponentTree(this, PartWatchlistItemCompanyGsssMatch.class, c -> {
			c.asEsuPart();
			return null;
		});

	}
	
	@Override
	public int getFlagValue()
	{
		return this.flagValue == null ? -1 : this.flagValue;
	}
	
	@Override
	public int getFlagValueOld()
	{
		return this.flagValueOld == null ? -1 : this.flagValueOld;
	}
	
	@Override
	public void setFlagChangeListener(
		final SerializableBiConsumer<WatchlistItemCompanyComponent, Boolean> flagChangeListener)
	{
		this.flagChangeListener = flagChangeListener;
	}
	
	@Override
	public void recalcFlag()
	{
		// Calculate "marked" flag (boolean)
		// Hint: Get and use pending "ratings" (Do NOT use the map from the screening!)
		final Map<GsssMatch, MatchData> matchData             = this.collectMatchesAndPendingMatchData();
		final Client                          client                = this.getContext().getClient();
		final Boolean                         calculatedMarkedValue = SanctionUtil.isMarked(client, this.item, matchData);
		
		// Map to "flagValue" (integer) for UI representation
		final int                             flagValue             = SanctionUtil.toFlag(calculatedMarkedValue);
		
		this.setValue(flagValue, false, true);
	}
	
	/**
	 * Collect MatchData from child "PartWatchlistItemCompanyGsssMatch" items.<br />
	 * Represents the CURRENT STATE, not the state in storage!
	 * 
	 * @return
	 */
	protected Map<GsssMatch, MatchData> collectMatchesAndPendingMatchData()
	{
		
		final Map<GsssMatch, MatchData> allMatchData_New = new HashMap<>();
		
		//I'M THE PROBLEM YOU'RE LOOKING FOR
		UIUtils.lookupComponentTree(this, PartWatchlistItemCompanyGsssMatch.class, c -> {
			allMatchData_New.putAll(c.getMatchDataMap());
			return null;
		});
		
		return allMatchData_New;
	}
	
	/***********************************************************/
	
	protected boolean valueEquals(final Integer value1, final Integer value2)
	{
		return Objects.equals(value1, value2);
	}
	
	/**
	 * Similar to AbstractFieldSupport
	 * 
	 * @param newValue
	 * @param fromInternal
	 *            Set to true to prevent calling FlagChangeListener.
	 * @param fromClient
	 *            If "FromClient" is true, changing Value is only possible if not readOnly.
	 */
	protected void setValue(final Integer newValue, final boolean fromInternal, final boolean fromClient)
	{
		if(fromClient && this.readOnly)
		{
			// TODO: reset UI to previous value
			// this.applyValue(flagValue);
			return;
		}
		
		final int currentValue    = this.getFlagValue();
		final Integer currentOldValue = this.flagValueOld;
		
		//// Has value changed?
		if(this.valueEquals(newValue, currentValue))
		{
			return;
		}
		
		//// Value HAS changed:
		
		this.flagValueOld = currentValue;
		this.flagValue    = newValue;
		
		try
		{
			if(this.header != null)
			{
				this.header.setMarked(this.flagValue);
				System.out.println(" COMP ITEM " + this.item.getItem().getCompanyBvdId() + " -> FlagValue: " + this.flagValue);
			}
		}
		catch(final RuntimeException e)
		{
			this.flagValueOld = currentOldValue;
			this.flagValue    = currentValue;
			throw e;
		}
		
		if(!fromInternal)
		{
			if(this.flagChangeListener != null)
			{
				this.flagChangeListener.accept(this, fromClient);
			}
		}
	}
	
	/*********************************************************************/
	
	/**
	 * Event handler delegate method for the {@link Details}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	protected void this_onOpenedChange(final OpenedChangeEvent event)
	{
		if(event.isOpened() && !this.isInitialized)
		{
			this.initAndAddContent();
		}
	}
	
	/**
	 * Create and attach content UI Components
	 */
	protected void initAndAddContent()
	{
		if(this.item != null)
		{
			final Map<GsssMatch, MatchData> allMatchData = this.item.getMatchData();
			
			//// Company Profile
			
			if(this.item.getItem().getCompanyGsssMatchResults() != null)
			{
				final CompanyGsssMatch                        cgs_item              =
					this.item.getItem().getCompanyGsssMatchResults();
				
				final PartWatchlistItemCompanyGsssMatch companyProfileElement =
					new PartWatchlistItemCompanyGsssMatch(this, "Company profile")
						.setItem(cgs_item, allMatchData);
				
				companyProfileElement.setFlagChangeListener((i, fromClient) -> {
					if(fromClient)
					{
						this.recalcFlag();
					}
				});
				
				this.setContent(companyProfileElement);
			}
			
			//// GlobalUltimateOwner
			
			if(this.item.getItem().getGuoGsssMatchResults() != null)
			{
				final CompanyGsssMatch                        cgs_item   = this.item.getItem().getGuoGsssMatchResults();
				
				final PartWatchlistItemCompanyGsssMatch guoElement =
					new PartWatchlistItemCompanyGsssMatch(this, "Global Ultimate Owner")
						.setItem(cgs_item, allMatchData);
				
				guoElement.setFlagChangeListener((i, fromClient) -> {
					if(fromClient)
					{
						this.recalcFlag();
					}
				});
				
				this.addContent(guoElement);
			}
			
			//// Beneficial Owner
			
			if(this.item.getItem().getBenOwnGsssMatchResults() != null)
			{
				this.item.getItem().getBenOwnGsssMatchResults().forEach((k, v) -> {
					final PartWatchlistItemCompanyGsssMatch it =
						new PartWatchlistItemCompanyGsssMatch(this, "Beneficial Owner")
							.setItem(v, allMatchData);
					
					it.setFlagChangeListener((i, fromClient) -> {
						if(fromClient)
						{
							this.recalcFlag();
						}
					});
					
					this.addContent(it);
				});
			}
			
			//// Intermediaries
			
			if(this.item.getItem().getInterGsssMatchResults() != null)
			{
				
				final TreeMap<String, CompanyGsssMatch> sortedMap = new TreeMap<>();
				if(this.item.getItem().getInterGsssMatchResults() != null)
				{
					sortedMap.putAll(this.item.getItem().getInterGsssMatchResults());
				}
				
				sortedMap.forEach((k, v) -> {
					final PartWatchlistItemCompanyGsssMatch it =
						new PartWatchlistItemCompanyGsssMatch(this, "Intermediary")
							.setItem(v, allMatchData);
					
					it.setFlagChangeListener((i, fromClient) -> {
						if(fromClient)
						{
							this.recalcFlag();
						}
					});
					
					this.addContent(it);
				});
			}
			
			this.isInitialized = true;
			
			// Apply readOnly to new child component(s) if necessary
			// see setReadOnlyCustom
			if(this.readOnly)
			{
				// Content
				UIUtils.lookupComponentTree(this, PartWatchlistItemCompanyGsssMatch.class, c -> {
					c.setReadOnlyCustom(this.readOnly);
					return null;
				});
			}
			
			if (this.root.isEsuPart())
			{
				// Content
				UIUtils.lookupComponentTree(this, PartWatchlistItemCompanyGsssMatch.class, c -> {
					c.asEsuPart();
					return null;
				});
			}
		}
	}
	
	/*********************************************************************/
	
	@Override
	public void resetDataCommunicators()
	{
		if(this.isInitialized)
		{
			this.getContent().filter(Objects::nonNull)
				.filter(c -> c instanceof HasResettableDataCommunicator)
				.forEach(c -> ((HasResettableDataCommunicator)c).resetDataCommunicators());
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
		
		this.addOpenedChangeListener(this::this_onOpenedChange);
	} // </generated-code>

	@Override
	public String getName() {
		if(this.item.getItem().getCompanyInfoBvd() == null) {
			return "";
		}else {
		return this.item.getItem().getCompanyInfoBvd().getName();
		}
	}
}
