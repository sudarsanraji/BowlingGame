package com.caweco.esra.ui.data.provider;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.func.rest.data.QueryDescription;
import com.rapidclipse.framework.server.data.filter.Filter;
import com.rapidclipse.framework.server.data.provider.FilterableDataProvider;
import com.vaadin.flow.data.provider.AbstractBackEndDataProvider;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.shared.Registration;


public class CustomFilterableDataProvider<T> extends AbstractBackEndDataProvider<T, Void>
	implements FilterableDataProvider<T, Void>, QueryDescription
{
	
	private static final long					serialVersionUID	= -1328100913598416968L;
	
	private String								luceneSearchText, propertySearchText;
	private String[]							propertySearchFields;
	private Function<String, Optional<String>>	luceneSearchTextAdapter, propertySearchTextAdapter;
	private HashMap<String, Object>				propertyQueryParams	= new HashMap<>();
	private HashMap<String, String>				queryParams			= new HashMap<>();
	
	private Consumer<Integer>					onSizeUpdate;
	
	public CustomFilterableDataProvider(FetchCallback<T> fetchCallback, CountCallback<T> countCallback)
	{
		super();
		this.fetchCallback = fetchCallback;
		this.countCallback = countCallback;
		
	}
	
	@Override
	public void setFilter(Filter filter)
	{
		// RapidClipse Framework Filter used by FilterComponent not supported..
	}
	
	/**
	 * Currently a property cannot be added multiple times with different values.
	 * If there was previously a mapping for the property, the old value is replaced.
	 * 
	 * @param property
	 *            a property path starting from the base bean type
	 * @param value
	 * @return
	 */
	public Registration addPropertyFilter(String property, Object value)
	{
		Object old = propertyQueryParams.put(property, value);
		if(!Objects.equals(value, old))
		{
			refreshAll();
		}
		return () -> this.removePropertyFilter(property);
	}
	
	public void removePropertyFilter(String property)
	{
		Object removed = propertyQueryParams.remove(property);
		if(removed != null)
		{
			refreshAll();
		}
	}
	
	public Registration addQueryParameter(String property, String value)
	{
		String old = queryParams.put(property, value);
		if(!Objects.equals(value, old))
		{
			refreshAll();
		}
		return () -> this.removeQueryParameter(property);
	}
	
	public void removeQueryParameter(String property)
	{
		String removed = queryParams.remove(property);
		if(removed != null)
		{
			refreshAll();
		}
	}
	
	public void setLuceneSearchText(String text)
	{
		setLuceneSearchText(true, text);
	}
	
	public void setLuceneSearchText(boolean refresh, String text)
	{
		String text_ = StringUtils.stripToNull(text);
		if(luceneSearchTextAdapter != null)
		{
			Optional<String> result = luceneSearchTextAdapter.apply(text_);
			if(result != null)
			{
				applyLuceneSearchText(refresh, result.get());
			}
			else
			{
				// skip
			}
		}
		else
		{
			applyLuceneSearchText(refresh, text_);
		}
	}
	
	protected void applyLuceneSearchText(boolean refresh, String text)
	{
		if(!StringUtils.equalsIgnoreCase(this.luceneSearchText, text))
		{
			this.luceneSearchText = text;
			if(refresh)
				refreshAll();
		}
	}
	
	public void setPropertySearchText(String text)
	{
		setPropertySearchText(true, text);
	}
	
	public void setPropertySearchText(boolean refresh, String text)
	{
		String text_ = StringUtils.stripToNull(text);
		if(propertySearchTextAdapter != null)
		{
			Optional<String> result = propertySearchTextAdapter.apply(text_);
			if(result != null)
			{
				applyPropertySearchText(refresh, result.get());
			}
			else
			{
				// skip
			}
		}
		else
		{
			applyPropertySearchText(refresh, text_);
		}
	}
	
	protected void applyPropertySearchText(boolean refresh, String text)
	{
		if(!StringUtils.equalsIgnoreCase(this.propertySearchText, text))
		{
			this.propertySearchText = text;
			if(refresh)
				refreshAll();
		}
	}
	
	public void setPropertySearchFields(String... field)
	{
		this.propertySearchFields = field;
		refreshAll();
	}
	
	@Override
	public boolean isInMemory()
	{
		return false;
	}
	
	@Override
	protected Stream<T> fetchFromBackEnd(Query<T, Void> query)
	{
		return fetchCallback.fetch(this, query);
	}
	
	@Override
	protected int sizeInBackEnd(Query<T, Void> query)
	{
		int count = countCallback.count(this);
		System.out.println("sizeInBackEnd:" + count);
		try
		{
			if(onSizeUpdate != null)
			{
				onSizeUpdate.accept(count);
			}
		}
		catch(Exception e)
		{
			// TODO: handle exception
		}
		return count;
	}
	
	@FunctionalInterface
	public interface FetchCallback<T> extends Serializable
	{
		/**
		 * Fetches a stream of items based on a query.
		 * 
		 * @param desc
		 *            the query description that defines which items to fetch
		 * @return a stream of items
		 */
		Stream<T> fetch(QueryDescription desc, Query<T, ?> query);
	}
	
	@FunctionalInterface
	public interface CountCallback<T> extends Serializable
	{
		/**
		 * Counts the number of available items based on a query.
		 *
		 * @param desc
		 *            the query that defines which items to count
		 * @return the number of available items
		 */
		int count(QueryDescription desc);
	}
	
	private final FetchCallback<T>	fetchCallback;
	private final CountCallback<T>	countCallback;
	
	@Override
	public String getLuceneSearchText()
	{
		return luceneSearchText;
	}
	
	@Override
	public String getPropertySearchText()
	{
		return propertySearchText;
	}
	
	@Override
	public String[] getPropertySearchFields()
	{
		return propertySearchFields;
	}
	
	@Override
	public HashMap<String, Object> getPropertyQueryParams()
	{
		return propertyQueryParams;
	}
	
	@Override
	public HashMap<String, String> getQueryParams()
	{
		return queryParams;
	}
	
	public void setOnSizeUpdate(Consumer<Integer> onSizeUpdate)
	{
		this.onSizeUpdate = onSizeUpdate;
	}
}
