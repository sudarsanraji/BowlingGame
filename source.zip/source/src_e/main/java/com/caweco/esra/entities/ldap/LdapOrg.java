package com.caweco.esra.entities.ldap;

import java.util.Objects;

import com.caweco.esra.entities.meta.HasRepresentation;

/**
 * A object which represents an LDAP organization object. It can be a main/root-organization as well as a
 * sub-organization.<br />
 * From the LDAP point of view it represents a object in the "OU=orgs" part of the tree.
 */
public class LdapOrg implements LdapItem, HasRepresentation
{
	public LdapOrg()
	{
		
	}
	
	private String displayName;
	// ldap cn value
	private String cnId;
	// Full ldap path of the item
	private String distinguishedName;
	
	public LdapOrg(String distinguishedName, String displayName)
	{
		super();
		Objects.requireNonNull(distinguishedName);
		this.distinguishedName = distinguishedName;
		this.displayName = displayName;
		
	}
	
	public String getDisplayName()
	{
		return this.displayName;
	}
	
	public void setDisplayName(String displayName)
	{
		this.displayName = displayName;
	}
	
	public String getCnId()
	{
		return this.cnId;
	}
	
	public void setCnId(String cnId)
	{
		this.cnId = cnId;
	}
	
	/**
	 * The full LDAP path for this item.
	 */
	@Override
	public String getDistinguishedName()
	{
		return this.distinguishedName;
	}
	
	@Override
	public void setDistinguishedName(String distinguishedName)
	{
		this.distinguishedName = distinguishedName;
	}
	
	@Override
	public int hashCode()
	{
		final int prime  = 31;
		int       result = 1;
		result = prime * result + ((this.distinguishedName == null) ? 0 : this.distinguishedName.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (this.getClass() != obj.getClass())
			return false;
		LdapOrg other = (LdapOrg) obj;
		if (this.distinguishedName == null)
		{
			if (other.distinguishedName != null)
				return false;
		}
		else if (!this.distinguishedName.equals(other.distinguishedName))
			return false;
		return true;
	}
	
	
	public boolean equalsNC(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof LdapOrg))
		{
			return false;
		}
		LdapOrg other = (LdapOrg) obj;
		if (this.distinguishedName == null)
		{
			if (other.distinguishedName != null)
				return false;
		}
		else if (!this.distinguishedName.equals(other.distinguishedName))
			return false;
		return true;
	}
	
	@Override
	public String getRepresentation()
	{
		return this.getDisplayName();
	}
	
}
