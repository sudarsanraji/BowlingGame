
package com.caweco.esra.subsidary.common;

public enum SubNodeState
{
	/**
	 * Initial state
	 */
	CREATED_WAITING,
	/**
	 * In progress
	 */
	IN_PROGRESS,
	/**
	 * Fetching data done.
	 */
	FETCHED,
	/**
	 * Fetching data and processing children done.
	 */
	PROCESSING_DONE,
	/**
	 * Data error at fetching data or no connection at all.
	 */
	DATA_ERROR,
	/**
	 * Skipped by user of due to an data error of another node.
	 */
	SKIPPED,
	/**
	 * No further processing.
	 */
	STOP_THRESHOLD,
	/**
	 * No further processing.
	 */
	STOP_MAXLEVEL,
	/**
	 * No further processing.
	 */
	STOP_MAXSUBSIDIARIES,
	/**
	 * No further processing.
	 */
	STOP_UNKNOWN_SHARE;

}
