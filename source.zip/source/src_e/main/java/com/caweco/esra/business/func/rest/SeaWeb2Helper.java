
package com.caweco.esra.business.func.rest;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import com.caweco.esra.business.func.rest.seaweb.GetShipsByIHSLRorIMONumbersAllv2;

/**
 * Helper for processing search text for Seaweb2 rest calls.
 *
 */
public class SeaWeb2Helper
{
	/**
	 * Valid IMO numbers (also) match this pattern.
	 */
	public static Pattern IMO_PATTERN = Pattern.compile("\\d{7}");
	
	/**
	 * Pattern for splitting search text strings to extract imo numbers
	 */
	public static String SEARCHTEXT_SPLIT_PATTERN = "[\\p{Space},;]";
	
	/*********************************************************************/
	
	/**
	 * Joins items into a single String separated by ",".
	 *
	 * @param in
	 * @return
	 */
	public static String processSearchtext_Step2_Join(final List<String> in)
	{
		final String joined = in.stream().collect(Collectors.joining(","));
		return joined;
	}
	
	/**
	 * Break input list into batches of size {@link GetShipsByIHSLRorIMONumbersAllv2#MAX_IMONUMBER_COUNT}
	 *
	 * @param in
	 * @return
	 */
	public static List<List<String>> processSearchtext_Step2_Grouping(final List<String> in)
	{
		final List<List<String>> partition =
			ListUtils.partition(in, GetShipsByIHSLRorIMONumbersAllv2.MAX_IMONUMBER_COUNT);
		return partition;
	}
	

	
	/**
	 * Splits "searchtext" by {@link SeaWeb2Helper#SEARCHTEXT_SPLIT_PATTERN}, <br />
	 * checks if the parts matches the {@link SeaWeb2Helper#IMO_PATTERN}<br />
	 * and divides them by validity in two lists: 
	 * <ul><li>Key "true": Valid IMO numbers</li>
	 * <li>Key "false": Invalid parts</li></ul>
	 * @param searchtext
	 * @return
	 */
	public static Map<Boolean, List<String>> processSearchtext_Step1_SplitAndPartition(final String searchtext)
	{
		final Map<Boolean, List<String>> parted =
			Stream.of((searchtext == null ? "" : searchtext).split(SeaWeb2Helper.SEARCHTEXT_SPLIT_PATTERN))
				.filter(StringUtils::isNotBlank)
				.collect(Collectors.partitioningBy(SeaWeb2Helper::mayBeImoNumber));
		
		return parted;
	}

	/*********************************************************************/
	
	/**
	 * Check if input matches {@link SeawebHelper#IMO_PATTERN}.
	 *
	 * @param imo
	 * @return
	 */
	public static boolean mayBeImoNumber(final String imo)
	{
		return SeaWeb2Helper.IMO_PATTERN.matcher(imo).matches();
	}
	
}
