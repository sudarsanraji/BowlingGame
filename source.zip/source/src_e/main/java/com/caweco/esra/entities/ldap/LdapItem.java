package com.caweco.esra.entities.ldap;

/**
 * A object which represents a LDAP object, defined by an (full) LDAP path (= the distinguishedName);
 */
public interface LdapItem
{
	public String getDistinguishedName();
	
	public void setDistinguishedName(String distinguishedName);
}
