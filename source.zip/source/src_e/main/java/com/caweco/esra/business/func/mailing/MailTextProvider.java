package com.caweco.esra.business.func.mailing;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;

import com.caweco.esra.business.func.data.PresentationUtil;
import com.caweco.esra.business.func.link.DirectLinkBuilderv2;
import com.caweco.esra.business.properties.ESRABaseSettingsProvider;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.mailing.MailTemplate;
import com.caweco.esra.entities.mailing.MailType;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;


/**
 * Provides methods to prepare value maps for placeholder replacement regarding of the different {@link MailType}s.
 * <p>
 * Provides also methods to get Mail parts (body, header) and replace placeholder within these parts.
 * </p>
 *
 */
public class MailTextProvider
{
	////////////
	//// Text elements
	
	public static String getEmailBody(final MailTemplate template, final Map<String, String> parameter)
	{
		return StringSubstitutor.replace(template.getBody(), parameter);
	}
	
	public static String getEmailTopic(final MailTemplate template, final Map<String, String> parameter)
	{
		return StringSubstitutor.replace(template.getHeader(), parameter);
	}
	
	////////////
	//// Property map
	
	public static Map<String, String> prepareMap_newSubsidiaryScreeningFinishedMsg(Screening screening, SubsidiaryScreeningTaskF task)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(screening));
		root.put("requestor", "Subsidiary Screening Owner");
		

		if (task.getState() == SubsidiaryScreeningTaskState.APPLIED) {
			root.put("state", "SUCCESS");
			root.put("successOrNot", "successfully");
		}
		else if (task.getState() == SubsidiaryScreeningTaskState.DONE_OK) {
			root.put("state", "SUCCESS, waiting for user");
			root.put("successOrNot", "");
		}
		else if (task.getState() == SubsidiaryScreeningTaskState.DONE_SKIPPED) {
			root.put("state", "FAILED - skipped by user");
			root.put("successOrNot", "");
		}
		else if (task.getState() == SubsidiaryScreeningTaskState.DONE_ERROR) {
			root.put("state", "FAILED");
			root.put("successOrNot", "");
		}
		else {
			throw new RuntimeException("Trying to send email for state " + task.getState().name());
		}
		
		root.put("screeningName", screening.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLinkToScreening("screening", screening.getScreeningID().toString()));
		root.put("companyName", task.getRootBvdId() + " / " + task.getRootCompanyName());

		root.put("personalNoteFromSender", "");
		
		return root;
	}

	
	public static Map<String, String> prepareMap_newGroupMessage(Screening r, MessageGroup g)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageEsuAssessment_toGroup(r, g));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("groupName", g.getName());
		
		return root;
	}
	
	public static Map<String, String> prepareMap_newPublicMessage(final Screening r)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageEsuAssessment_toPublic(r));
		root.put("screeningID", r.getScreeningID().toString());
		
		return root;
	}
	
	public static Map<String, String> prepareMap_GroupInvitation(final Screening r, final MessageGroup g, final String inviter)
	{
		
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageEsuAssessment_toGroup(r, g));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("groupName", g.getName());
		root.put("senderName", inviter);
		return root;
	}
	
	/**
	 * Usage: for MailType.REVIEW_FINISHED and MailType.SCREENING_NEEDS_UPDATE as they have same placeholders.
	 * <br />
	 * See also {@link MailTypeConfig#getAvailablePlaceholder(MailType)}
	 * 
	 * @param r
	 * @return
	 */
	public static Map<String, String> prepareMap_reviewFinished(final Screening r, final String sender)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageEsuAssessment_toScreening(r));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("lob", r.getLineOfBusiness().getName());
		root.put("oe", r.getOe().getName());
		root.put("requestor", r.getScreeningOwner().getRepresentation());
		root.put("reviewer", sender);
		return root;
	}
	
	public static Map<String, String> prepareMap_screeningOwnerChanged(final Screening r, final String sender, final String additionalNotificationFromUser)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageSanctionScreening_toScreening(r));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("requestor", r.getScreeningOwner().getRepresentation());
		root.put("senderName", sender);
		
		// Currently not necessary for non-html mails
		// Encode.forHtmlContent(additionalNotificationFromUser);
		
		final String additionalNotificationFromUserTrimmed = StringUtils.trimToNull(additionalNotificationFromUser);
		root.put("personalNoteFromSender",
			additionalNotificationFromUserTrimmed == null ? "" : "\n" + additionalNotificationFromUserTrimmed + "\n");
		
		return root;
	}
	
	public static Map<String, String> prepareMap_screeningOwnerTakeover(final Screening r, final String sender, final User previousOwner)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageSanctionScreening_toScreening(r));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("requestor", previousOwner.getRepresentation());
		root.put("senderName", sender);
		
		return root;
	}
	
	public static Map<String, String> prepareMap_screeningServiceUserChanged(final Screening r, final String sender, final String additionalNotificationFromUser)
	{
		final Map<String, String> root = new HashMap<>();
		root.put("appName", ESRABaseSettingsProvider.APPNAME);
		root.put("headerExtension1", PresentationUtil.getRepresentation_ForMailHeaderV1(r));
		root.put("screeningName", r.getName());
		root.put("screeningLink", DirectLinkBuilderv2.getLink_PageSanctionScreening_toScreening(r));
		root.put("screeningID", r.getScreeningID().toString());
		root.put("requestor", r.getScreeningServiceUser().getRepresentation());
		root.put("senderName", sender);
		
		// Currently not necessary for non-html mails
		// Encode.forHtmlContent(additionalNotificationFromUser);
		
		final String additionalNotificationFromUserTrimmed = StringUtils.trimToNull(additionalNotificationFromUser);
		root.put("personalNoteFromSender",
			additionalNotificationFromUserTrimmed == null ? "" : "\n" + additionalNotificationFromUserTrimmed + "\n");
		
		
		return root;
	}
	
}
