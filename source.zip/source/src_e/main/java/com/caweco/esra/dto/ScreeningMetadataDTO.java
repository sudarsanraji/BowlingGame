package com.caweco.esra.dto;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Set;

import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.Monitoring;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ScreeningMetadataDTO {
	private String parentID;
	private String screeningID;
	private LocalDate screeningDate;
	private LocalDate screeningEsuDate;
	private LocalDate screeningPublishDate;
	
	private UserMetadataNoAttributesDTO screeningOwner;
	
	@JsonProperty("screeningServiceUser")
	private UserMetadataNoAttributesDTO screeningService;
	private String name;
	private LineOfBusiness lineOfBusiness;
	private OE oe;
	private Function function;
	private ScreeningStatus status;

	private Monitoring latestMonitoring;
	private UserMetadataNoAttributesDTO esuWorker;
	private String ESUTemplateResult;
	private Set<String> esuTags;
	private Set<String> esuCountries;
	private Set<String> prcCountries;
	
	private Instant created;
	private String createdBy;
	
	private Instant lastChanged;
	private String lastChangedBy;
	private Boolean archived;
	
	public String getScreeningID() {
		return this.screeningID;
	}
	public void setScreeningID(final String screeningID) {
		this.screeningID = screeningID;
	}
	public LocalDate getScreeningDate() {
		return this.screeningDate;
	}
	public void setScreeningDate(final LocalDate screeningDate) {
		this.screeningDate = screeningDate;
	}

	public String getName() {
		return this.name;
	}
	public void setName(final String name) {
		this.name = name;
	}
	public LineOfBusiness getLineOfBusiness() {
		return this.lineOfBusiness;
	}
	public void setLineOfBusiness(final LineOfBusiness lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	public OE getOe() {
		return this.oe;
	}
	public void setOe(final OE oe) {
		this.oe = oe;
	}
	public Function getFunction() {
		return this.function;
	}
	public void setFunction(final Function function) {
		this.function = function;
	}
	public ScreeningStatus getStatus() {
		return this.status;
	}
	public void setStatus(final ScreeningStatus status) {
		this.status = status;
	}
	public Monitoring getLatestMonitoring() {
		return this.latestMonitoring;
	}
	public void setLatestMonitoring(final Monitoring latestMonitoring) {
		this.latestMonitoring = latestMonitoring;
	}
	public UserMetadataNoAttributesDTO getEsuWorker() {
		return this.esuWorker;
	}
	public void setEsuWorker(final UserMetadataNoAttributesDTO esuWorker) {
		this.esuWorker = esuWorker;
	}
	public String getESUTemplateResult() {
		return this.ESUTemplateResult;
	}
	public void setESUTemplateResult(final String eSUTemplateResult) {
		this.ESUTemplateResult = eSUTemplateResult;
	}
	public Set<String> getEsuTags() {
		return this.esuTags;
	}
	public void setEsuTags(final Set<String> esuTags) {
		this.esuTags = esuTags;
	}
	public Set<String> getEsuCountries() {
		return this.esuCountries;
	}
	public void setEsuCountries(final Set<String> esuCountries) {
		this.esuCountries = esuCountries;
	}
	public Instant getCreated() {
		return this.created;
	}
	public void setCreated(final Instant created) {
		this.created = created;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}
	public Instant getLastChanged() {
		return this.lastChanged;
	}
	public void setLastChanged(final Instant lastChanged) {
		this.lastChanged = lastChanged;
	}
	public String getLastChangedBy() {
		return this.lastChangedBy;
	}
	public void setLastChangedBy(final String lastChangedBy) {
		this.lastChangedBy = lastChangedBy;
	}
	public String getParentID() {
		return this.parentID;
	}
	public void setParentID(final String parentID) {
		this.parentID = parentID;
	}
	public UserMetadataNoAttributesDTO getScreeningOwner() {
		return this.screeningOwner;
	}
	public void setScreeningOwner(final UserMetadataNoAttributesDTO screeningOwner) {
		this.screeningOwner = screeningOwner;
	}
	public UserMetadataNoAttributesDTO getScreeningService() {
		return this.screeningService;
	}
	public void setScreeningService(final UserMetadataNoAttributesDTO screeningService) {
		this.screeningService = screeningService;
	}
	public boolean isArchived()
	{
		return this.archived;
	}
	public void setArchived(final Boolean archived)
	{
		this.archived = archived;
	}
	public Set<String> getPrcCountries()
	{
		return prcCountries;
	}
	public void setPrcCountries(Set<String> prcCountries)
	{
		this.prcCountries = prcCountries;
	}
	
	public LocalDate getScreeningEsuDate() {
		return screeningEsuDate;
	}
	public void setScreeningEsuDate(LocalDate screeningEsuDate) {
		this.screeningEsuDate = screeningEsuDate;
	}
	
	public LocalDate getScreeningPublishDate() {
		return screeningPublishDate;
	}
	public void setScreeningPublishDate(LocalDate screeningPublishDate) {
		this.screeningPublishDate = screeningPublishDate;
	}
	
}
