package com.caweco.esra.entities.meta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class TableString
{
    String text;
    
    public TableString(String text)
    {
        super();
        this.text = text;
    }
    
    public String getText()
    {
        return this.text;
    }
    
    public static Collection<TableString> toTableStringList(Collection<String> collection)
    {
    	Collection<TableString> tableStringList = new ArrayList<TableString>();
    	
    	collection.forEach(str -> {
    		tableStringList.add(new TableString(str));
    	});
    	
    	return tableStringList;
    }
    
    public static Collection<String> toStringList(Collection<TableString> collection)
    {
    	Collection<String> stringList = new ArrayList<String>();
    	
    	collection.forEach(str -> {
    		stringList.add(str.getText());
    	});
    	
    	return stringList;
    }
    
    public static Set<String> toStringSet(Collection<TableString> collection)
    {
    	Set<String> stringList = new HashSet<String>();
    	
    	collection.forEach(str -> {
    		stringList.add(str.getText());
    	});
    	
    	return stringList;
    }

	@Override
	public String toString() {
		return text;
	}
    
    
}
