package com.caweco.esra.business.func.common;

import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.Notification.Position;
import com.vaadin.flow.component.notification.NotificationVariant;


public class Notificator
{
	private Notificator()
	{
	}
	
	public static final int DEFAULT_DURATION = 5000;
	public static final Position DEFAULT_POSITION = Position.BOTTOM_START;
	
	public static Notification info(final String text)
	{
		return Notification.show(text, Notificator.DEFAULT_DURATION, Notificator.DEFAULT_POSITION);
	}
	
	public static Notification warn(final String text)
	{
		final Notification notification = Notificator.getWarn(text);
		notification.open();
		return notification;
	}
	
	public static Notification warn(final String text, final int duration, Position position)
	{
		final Notification notification = Notificator.getWarn(text, duration, position);
		notification.open();
		return notification;
	}
	
	public static Notification warn(final String text, final int duration)
	{
		final Notification notification = Notificator.getWarn(text, duration);
		notification.open();
		return notification;
	}
	
	public static Notification error(final String text)
	{
		final Notification notification = Notificator.getError(text);
		notification.open();
		return notification;
	}
	
	public static Notification success(final String text)
	{
		final Notification notification = Notificator.getSuccess(text);
		notification.open();
		return notification;
	}
	
	public static Notification getWarn(final String text)
	{
		final Notification notification =
			new Notification(text, Notificator.DEFAULT_DURATION, Notificator.DEFAULT_POSITION);
		notification.addThemeVariants(NotificationVariant.LUMO_PRIMARY);
		return notification;
	}
	
	public static Notification getWarn(final String text, final int duration)
	{
		final Notification notification =
			new Notification(text, duration, Notificator.DEFAULT_POSITION);
		notification.addThemeVariants(NotificationVariant.LUMO_PRIMARY);
		return notification;
	}
	
	public static Notification getWarn(final String text, final int duration, Position position)
	{
		final Notification notification =
			new Notification(text, duration, position);
		notification.addThemeVariants(NotificationVariant.LUMO_PRIMARY);
		return notification;
	}
	
	public static Notification getError(final String text)
	{
		final Notification notification =
			new Notification(text, Notificator.DEFAULT_DURATION, Notificator.DEFAULT_POSITION);
		notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
		return notification;
	}
	
	public static Notification getSuccess(final String text)
	{
		final Notification notification =
			new Notification(text, Notificator.DEFAULT_DURATION, Notificator.DEFAULT_POSITION);
		notification.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
		return notification;
	}
	
	//// Special
}
