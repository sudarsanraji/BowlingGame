package com.caweco.esra.business.func.mailing;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.config.ConfigMailServer;


/**
 * Temporarily collected Data for Mails.
 * Do not persist this, use {@link EmailTemplate} for persistence.
 *
 */
public interface MailData
{
	
	String getSubjectText();
	
	String getBodyText();
	
	boolean isHtmlFormatted();
	
	String getSender();
	
	Collection<String> getRecipients();
	
	Collection<String> getRecipientsCC();
	
	Collection<String> getRecipientsBCC();
	
	public static MailData.Default New(String body, String topic)
	{
		MailData.Default md = new MailData.Default();
		md.setBodyText(body).setSubjectText(topic);
		return md;
	}
	
	public static class Default implements MailData
	{
		private String		subjectText;
		private String		bodyText;
		private boolean		htmlFormatted	= false;
		
		private String		sender;
		private Set<String>	recipients		= new HashSet<>();
		private Set<String>	recipientsCC	= new HashSet<>();
		private Set<String>	recipientsBCC	= new HashSet<>();
		
		ConfigMailServer	serverSettings;
		
		@Override
		public String getSubjectText()
		{
			return this.subjectText;
		}
		
		public MailData.Default setSubjectText(final String subjectText)
		{
			this.subjectText = subjectText;
			return this;
		}
		
		@Override
		public String getBodyText()
		{
			return this.bodyText;
		}
		
		public MailData.Default setBodyText(final String bodyText)
		{
			this.bodyText = bodyText;
			return this;
		}
		
		@Override
		public boolean isHtmlFormatted()
		{
			return this.htmlFormatted;
		}
		
		@Override
		public String getSender()
		{
			return this.sender;
		}
		
		public MailData.Default setSender(final String sender) // NO_UCD - setter
		{
			this.sender = sender;
			return this;
		}
		
		@Override
		public Set<String> getRecipients()
		{
			return this.recipients;
		}
		
//		public MailData.Default setRecipients(final Set<String> recipients)
//		{
//			this.recipients = recipients;
//			return this;
//		}
		
		public MailData.Default addRecipient(final String recipient)
		{
			this.recipients.add(recipient);
			return this;
		}
		
		@Override
		public Set<String> getRecipientsCC()
		{
			return this.recipientsCC;
		}
		
		public MailData.Default setRecipientsCC(final Set<String> recipientsCC) // NO_UCD - setter
		{
			this.recipientsCC = recipientsCC;
			return this;
		}
		
		@Override
		public Set<String> getRecipientsBCC()
		{
			return this.recipientsBCC;
		}
		
		public MailData.Default setRecipientsBCC(final Set<String> recipientsBCC)
		{
			this.recipientsBCC = recipientsBCC;
			return this;
		}
		
		public ConfigMailServer getServerSettings()
		{
			return this.serverSettings;
		}
		
		public MailData.Default setServerSettings(final ConfigMailServer serverSettings) // NO_UCD - setter
		{
			this.serverSettings = serverSettings;
			return this;
		}
		
	}
}
