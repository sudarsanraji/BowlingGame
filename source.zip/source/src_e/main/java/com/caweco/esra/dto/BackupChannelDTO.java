package com.caweco.esra.dto;

public class BackupChannelDTO {

	private String name;
	private String folderName;
	private Integer maxFolderCount;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public Integer getMaxFolderCount() {
		return maxFolderCount;
	}
	public void setMaxFolderCount(Integer maxFolderCount) {
		this.maxFolderCount = maxFolderCount;
	}
	
	
}
