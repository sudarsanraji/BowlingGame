package com.caweco.esra.ui.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.messaging.MessageGroupHelper;
import com.caweco.esra.business.func.messaging.MessagingMode;
import com.caweco.esra.business.func.messaging.MessagingUtil;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dao.messaging.MessageDAO;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.dao.messaging.MessageGroupService;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.ui.beans.selection.PartUserSelect;
import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.caweco.esra.ui.dialogs.DialogContentImpl;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.selection.SelectionEvent;


@SuppressWarnings("serial")
public class PartMessageCategoryManager extends VerticalLayout
{
	private PartEsuMessagingMain   parent;
	private MessagingMode          mode;
	private Grid<MessageGroup>     gridMessageGroup;
	
	ListDataProvider<MessageGroup> dp;
	
	public PartMessageCategoryManager()
	{
		super();
		this.initUI();
		
		this.gridMessageGroup = new Grid<MessageGroup>();
		this.gridMessageGroup.addColumn(MessageGroup::getName);
		this.gridMessageGroup.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.gridMessageGroup.addSelectionListener(this::gridGroups_selectionChange);
		this.gridMessageGroup.setMaxHeight("80px");
		this.gridGroups.add(this.gridMessageGroup);
		
		UiHelper.setAriaLabel(this.btnNewGroup, Aria.get("Messaging_newGroup"));
		UiHelper.setAriaLabel(this.btnGroupLeave, Aria.get("Messaging_leaveGroup"));
		UiHelper.setAriaLabel(this.btnGroupManageUser, Aria.get("Messaging_addGroupUser"));
		UiHelper.setAriaLabel(this.btnGroupEdit, Aria.get("Messaging_editGroup"));
		UiHelper.setAriaLabel(this.btnGroupDelete, Aria.get("Messaging_deleteGroup"));
	}
	
	public PartMessageCategoryManager connect(PartEsuMessagingMain parent)
	{
		this.parent = parent;
		return this;
	}
	
	/////////////
	//// Public
	/////////////

	/**
	 * For direct access by link
	 *  
	 * @param group
	 */
	public void selectGroup(MessageGroup group)
	{
		if (group == null)
		{
			return;
		}
		
		if (this.dp == null)
		{
			return;
		}
		
		if (this.mode != MessagingMode.GROUP)
		{
			return;
		}
		
		// Dataprovider contains MessageGroups of User. If "group" is not in this collection, user is not assigned to "group".
		if (this.dp.getItems().contains(group))
		{
			this.gridMessageGroup.asSingleSelect().setValue(group);
		}
		
	}
	
	public void selectRequestorGroup()
	{
		if (this.dp == null)
		{
			return;
		}
		
		Optional<MessageGroup> requestorGroup = MessageGroupHelper.getRequestorGroup(this.dp.getItems());
		
		// Dataprovider contains MessageGroups of User. If "group" is not in this collection, user is not assigned to "group".
		if (requestorGroup.isPresent())
		{
			this.gridMessageGroup.asSingleSelect().setValue(requestorGroup.get());
		}
	}
	
	public void handleItemChange()
	{
		this.reset();
		this.refreshCbGroups(false);
		
		if (this.parent.getItem() != null)
		{
			this.objPublicMode.setEnabled(true);
			this.objGroupMode.setEnabled(true);
		}
		else
		{
			this.objPublicMode.setEnabled(false);
			this.objGroupMode.setEnabled(false);
		}
	}
	
	
	/**
	 * Called when changing selected tab
	 */
	public void handleModeChange()
	{
		MessagingMode newMode = this.parent.getMode();
		
		if (newMode == null)
			newMode = MessagingMode.UNSET;
		
		if (this.mode != newMode)
		{
			this.mode = newMode;
			
			switch (this.mode)
			{
			case PRIVATE:
				
				this.objPublicMode.setVisible(false);
				this.objGroupMode.setVisible(false);
				
				this.prepareExternalComponents(this.parent.getItem() != null, true);
				
				if (this.parent.getItem() != null)
				{
					this.handlePrivateMessages(this.parent.getItem());
				}
				break;
			case GROUP:
				
				this.objPublicMode.setVisible(false);
				this.objGroupMode.setVisible(true);
				
				// Default: disabled/clean, until a group was selected.
				this.prepareExternalComponents(false, true);
				
				// Does a lot: resets or refreshes Groups for comboBox: depends if parent item is null or not.
				// if available, sets the previous value to cb.
				this.refreshCbGroups(true);
				
				break;
			case PUBLIC:
				
				this.objPublicMode.setVisible(true);
				this.objGroupMode.setVisible(false);
				
				this.prepareExternalComponents(this.parent.getItem() != null, true);
				
				if (this.parent.getItem() != null)
				{
					this.handlePublicMessages(this.parent.getItem());
				}
				
				break;
			default:
				
				this.objPublicMode.setVisible(false);
				this.objGroupMode.setVisible(false);
				
				this.prepareExternalComponents(false, true);
				
				break;
			}
		}
	}
	
	public void handleNewMessage(Message message)
	{
		
		//// Save and notify user
		switch (this.mode)
		{
		case PRIVATE:
			MessageDAO.savePrivateMessage(this.parent.getItem(), message, CurrentUtil.getUser());
			
			break;
		case GROUP:
			MessageGroup selectedGroup = this.gridMessageGroup.asSingleSelect().getValue();
			
			MessageDAO.saveGroupMessage(message, selectedGroup);
			
			// notify subscribed members
			MessagingUtil.sendMail_newGroupMessage(CurrentUtil.getUser(), this.parent.getItem(), selectedGroup);
			
			break;
		case PUBLIC:
			MessageDAO.savePublicMessage(this.parent.getItem().getPublicMessages(true), message);
			
			// notify followers
			MessagingUtil.sendMail_newPublicMessage(CurrentUtil.getUser(), this.parent.getItem());
			
			break;
		default:
			// should not happen!!
			break;
		}
		
		//// Update GUI
		// Happens by broadcast for Group messages & Public Messages. But not for private notes..
		if (MessagingMode.PRIVATE == this.mode)
		{
			this.parent.getMessageViewer().handleNewEntry(message, null);
		}
	}
	
	/**
	 * <p>
	 * Resets the component. <br />
	 * Removes data and resets settings to initial state.
	 * </p>
	 */
	public void reset()
	{
		//// Reset Data
		ListDataProvider<MessageGroup> dp = DataProvider.ofCollection(new ArrayList<>());
		
		
		this.gridMessageGroup.setDataProvider(dp);
		
		//// Reset GUI
		
		this.objPublicMode.setVisible(false);
		this.objGroupMode.setVisible(false);
		this.resetGroup();
		this.resetPublic();
		
		this.prepareExternalComponents(false, true);
	}
	
	/////////////
	//// INTERNAL
	/////////////
	
	/**
	 * Called when selected Group was changed.<br />
	 * Refreshes Messages list by calling backend. Sets the list to comboBox.<br />
	 * 
	 * @param group
	 */
	protected void handleGroupChange(
		final MessageGroup group)
	{
		
		//// CLEANUP
		this.resetGroup();
		
		if (group != null)
		{
			this.prepareExternalComponents(true,group.getMembers(true).containsKey(CurrentUtil.getUser()));
			
			//// Buttons
			this.objActionsGroup.setVisible(true);
			
			User user = CurrentUtil.getUser();
			
			
			this.btnGroupDelete.setVisible(Objects.equals(group.getCreatedBy(), user.getEmailAddress()));
			
			this.btnGroupManageUser.setVisible(group.getAdmins(true).contains(user));
			this.btnGroupLeave.setVisible(true);
			boolean isTheOnlyAdmin = group.getAdmins(false).contains(user) && group.getAdmins(false).size() == 1;
			if (isTheOnlyAdmin)
			{
				this.btnGroupLeave.setEnabled(false);
				this.btnGroupLeave.getElement().setAttribute("title", "You are the only admin of this group.");
			}
			
			//// MESSAGES
			
			// Fetch from Backend
			List<Message> messages = group.getMessages(true);
			
			this.showMessages(messages, false, group, null);
		}
	}
	
	/**
	 * Called when "Public Messages" tab selected.<br />
	 * Refreshes Messages list by calling backend.
	 * 
	 * @param hasMessages a Screening
	 */
	protected void handlePublicMessages(Screening hasMessages)
	{
		// Fetch from Backend
		MessageGroup publicMessageGroup = hasMessages.getPublicMessages(true);
		
		//// CLEANUP
		this.resetPublic();
		
		//// Buttons
		boolean isFollower = publicMessageGroup.getFollower().contains(CurrentUtil.getUser());
		this.chbSendNotificationPublic.setValue(isFollower);
		
		//// MESSAGES
		this.showMessages(new ArrayList<>(publicMessageGroup.getMessages(true)), false, publicMessageGroup, hasMessages);
	}
	
	/**
	 * Called when "Private Messages" tab selected.<br />
	 * Refreshes Messages list by calling backend.
	 * 
	 * @param hasMessages a Screening
	 */
	protected void handlePrivateMessages(Screening hasMessages)
	{
		// (2023-07-06) Moved fetching from #handleModeChange() to here
		
		// Fetch from Backend
		List<Message> privateMessages = MessageGroupService.getOrCreateMyNotes(hasMessages, CurrentUtil.getUser());
		
		//// MESSAGES
		this.showMessages(privateMessages, true, null, hasMessages);
	}
	
	private void prepareExternalComponents(boolean enable, boolean isMember)
	{
		if (this.parent.getMessageViewer() != null)
		{
			this.parent.getMessageViewer().reset();
			this.parent.getMessageViewer().setEnabled(enable);
		}
		
		if (this.parent.getMessageCreator() != null)
		{
			this.parent.getMessageCreator().setEnabled(enable);
			this.parent.getNotAMemberLayout().setVisible(!isMember);
			this.parent.getMessageCreator().setVisible(isMember);
		}
	}
	
	private void resetGroup()
	{
		this.btnGroupDelete.setVisible(true);
		this.btnGroupEdit.setVisible(true);
		this.btnGroupManageUser.setVisible(true);
		this.btnGroupLeave.setVisible(true);
		this.objActionsGroup.setVisible(false);
	}
	
	private void resetPublic()
	{
		this.chbSendNotificationPublic.setVisible(true);
		this.chbSendNotificationPublic.setValue(false);
	}
	
	/**
	 * Refreshes MessageGroup list by calling backend. Sets the list to comboBox.<br />
	 * If available, sets the previous value to comboBox.
	 * 
	 * @param setToPreviousValue
	 * @return
	 */
	private MessageGroup refreshCbGroups(boolean setToPreviousValue)
	{
		MessageGroup       value         = this.gridMessageGroup.asSingleSelect().getValue();
		
		List<MessageGroup> messageGroups = new ArrayList<MessageGroup>();
		if (this.parent.getItem() != null)
		{
			// (2022-11-09 MH): ESU Users can view all groups by default
			if (AuthorizationUtil.isEsuUser())
			{
				messageGroups.addAll(MessageGroupDAO.findAll(this.parent.getItem()).values());
			}
			else
			{
				messageGroups.addAll(MessageGroupDAO.findByUser(this.parent.getItem(), CurrentUtil.getUser()));
			}
		}
		this.dp = DataProvider.ofCollection(messageGroups);
		this.dp.setSortOrder(MessageGroup::getName, SortDirection.ASCENDING);
		this.gridMessageGroup.setDataProvider(this.dp);
		
		if (setToPreviousValue && value != null)
		{
			this.gridMessageGroup.asSingleSelect().setValue(value);
		}
		
		return value;
	}
	
	
	/**
	 * Show messages in UI. <br />
	 * "group" parameter <b>not</b> necessary for private messages, "screening" parameter <b>only</b> necessary for private
	 * messages
	 * 
	 * @param messages
	 * @param withDeleteButton
	 * @param group            parameter <b>not</b> necessary for private messages
	 * @param screening        parameter <b>only</b> necessary for private messages
	 */
	protected void showMessages(List<Message> messages, boolean withDeleteButton, MessageGroup group, Screening screening)
	{
		if (this.parent.getMessageViewer() != null)
		{
			this.parent.getMessageViewer().setItems(messages, withDeleteButton, group, screening);
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewGroup}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewGroup_onClick(ClickEvent<Button> event)
	{
		final TextField g = new TextField();
		g.setWidthFull();
		
		DialogContentImpl.New(g).setTextHeader("Name of the new group").setOnOk(c ->
		{
			String newGroupName = StringUtils.stripToNull(c.getValue());
			if (newGroupName != null)
			{
				
				//// Save the new Group
				MessageGroup newMessageGroup = new MessageGroup(CurrentUtil.getUser(), newGroupName);
				
				MessageGroupDAO.insertScreeningMessageGroup(this.parent.getItem(), newMessageGroup, new ArrayList<>());
				
				//// Set the new Group to GUI
				this.refreshCbGroups(false);
				this.gridMessageGroup.asSingleSelect().setValue(newMessageGroup);
			}
			else
			{
				Notificator.error("Name must not be empty");
			}
		}).setWidth("400px").show();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnGroupLeave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnGroupLeave_onClick(ClickEvent<Button> event)
	{
		/*
		 * Leave Group
		 */
		MessageGroup group = this.gridMessageGroup.asSingleSelect().getValue();
		//// Push user out of the group
		MessageGroupDAO.removeMember(group, CurrentUtil.getUser());
		MessageGroupDAO.removeAdmin(group, CurrentUtil.getUser());
		
		//// Say parent it should update
		this.parent.backToPublic();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnGroupManageUser}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnGroupManageUser_onClick(ClickEvent<Button> event)
	{
		/*
		 * Add user to group
		 */
		MessageGroup         group              = this.gridMessageGroup.asSingleSelect().getValue();
		Set<User>            originalMemberList = group.getMembers(true).keySet();
		
		// Get ALL user
		Set<User>            availableUser      = UserDAO.findAll();
		
		final PartUserSelect g                  = new PartUserSelect().setItems(availableUser, originalMemberList);
		DialogContentImpl.New(g).setOnOk(c ->
		{
			Set<User> newMemberList = new HashSet<>(c.getSelectedItems());
			// Ensure that Admins remain in user list
			newMemberList.addAll(group.getAdmins(true));
			
			Collection<User> userToRemove = CollectionUtils.subtract(originalMemberList, newMemberList);
			Collection<User> userToAdd    = CollectionUtils.subtract(newMemberList, originalMemberList);
			
			userToRemove.removeAll(group.getAdmins(false)); // To be sure
			
			Map<User, Boolean> members = group.getMembers(true);
			
			if (!userToRemove.isEmpty())
			{
				userToRemove.forEach(u ->
				{
					members.remove(u);
				});
				
				
				MessageGroupDAO.removeMembers(group, userToRemove);
			}
			
			if (!userToAdd.isEmpty())
			{
				MessagingUtil.inviteUser(this.parent.getItem(), group, userToAdd, false);
			}
		}).setWidth("800px").setHeight("400px")
			.setTextHeader("Select user")
			.show();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnGroupEdit}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnGroupEdit_onClick(ClickEvent<Button> event)
	{
		/*
		 * Edit Group settings
		 */
		PartMessageGroupDetails content = new PartMessageGroupDetails(this.gridMessageGroup.asSingleSelect().getValue());
		
		DialogContentImpl.New(content).setTextHeader("Edit group").setOnOk(c ->
		{
			MessageGroup changedGroup = content.getChangedGroup();
			this.gridMessageGroup.getDataProvider().refreshItem(changedGroup);
			MessageGroupDAO.update(changedGroup);
			
		}).show();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnGroupDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnGroupDelete_onClick(ClickEvent<Button> event)
	{
		/*
		 * Delete Group
		 */
		MessageGroup group = this.gridMessageGroup.asSingleSelect().getValue();
		DialogConfirm.show(() ->
		{
			//// Delete Group
			
			ScreeningDAO.deleteMessagingGroup(parent.getItem(), group);
			
			//// Say parent it should update
			this.parent.backToPublic();
			
		}, null, "Delete Group \"" + group.getName() + "\"?");
	}
	
	/**
	 * Event handler delegate method for the {@link Checkbox} {@link #chbSendNotificationPublic}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void chbSendNotificationPublic_valueChanged(ComponentValueChangeEvent<Checkbox, Boolean> event)
	{
		/*
		 * Toggle "Follow"/"Subscribe" state.
		 */
		if (event.isFromClient())
		{
			Set<User> follower    = this.parent.getItem().getPublicMessages(true).getFollower();
			boolean   wasFollower = follower.contains(CurrentUtil.getUser());
			
			boolean   follow      = BooleanUtils.isTrue(event.getValue());
			
			if (wasFollower != follow)
			{
				if (follow)
				{
					follower.add(CurrentUtil.getUser());
					ScreeningDAO.followPublicMessages(CurrentUtil.getUser(), CurrentUtil.getClient().getUuid()
						.toString(), ((Screening) this.parent.getItem().getMessagesParent()).getScreeningID().toString());
				}
				else
				{
					follower.remove(CurrentUtil.getUser());
					
					ScreeningDAO.unfollowPublicMessages(CurrentUtil.getUser(), CurrentUtil.getClient().getUuid()
						.toString(), ((Screening) this.parent.getItem().getMessagesParent()).getScreeningID().toString());
					
				}
			}
			else
			{
				// Not changed..
			}
		}
	}
	
	/**
	 * Event handler method for the {@link Grid} {@link #gridMessageGroup}.
	 */
	private void gridGroups_selectionChange(final SelectionEvent<Grid<MessageGroup>, MessageGroup> event)
	{
		MessageGroup group = event.getSource().asSingleSelect().getValue();
		this.handleGroupChange(group);
	}
	
	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.objGroupMode = new Div();
		this.divCustomGroupChooser = new VerticalLayout();
		this.lblSelectGroup = new Label();
		this.gridGroups = new Div();
		this.btnNewGroup = new Button();
		this.objActionsGroup = new HorizontalLayout();
		this.btnGroupLeave = new Button();
		this.btnGroupManageUser = new Button();
		this.btnGroupEdit = new Button();
		this.btnGroupDelete = new Button();
		this.hr2 = new Hr();
		this.objPublicMode = new Div();
		this.objActionsPublic = new HorizontalLayout();
		this.chbSendNotificationPublic = new Checkbox();
		this.hr3 = new Hr();
		
		this.setSpacing(false);
		this.setPadding(false);
		this.objGroupMode.setEnabled(false);
		this.objGroupMode.setVisible(false);
		this.divCustomGroupChooser.setSpacing(false);
		this.lblSelectGroup.setText("Select group:");
		this.lblSelectGroup.getStyle().set("margin-right", "2em");
		this.gridGroups.setMaxHeight("80px");
		this.btnNewGroup.setText("New Group");
		this.btnNewGroup.setIcon(VaadinIcon.PLUS.create());
		this.objActionsGroup.setSpacing(false);
		this.objActionsGroup.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.btnGroupLeave.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnGroupLeave.setIcon(VaadinIcon.SIGN_OUT.create());
		this.btnGroupManageUser.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnGroupManageUser.setIcon(VaadinIcon.USERS.create());
		this.btnGroupEdit.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnGroupEdit.setIcon(VaadinIcon.COGS.create());
		this.btnGroupDelete.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnGroupDelete.setIcon(VaadinIcon.TRASH.create());
		this.objPublicMode.setEnabled(false);
		this.objPublicMode.setVisible(false);
		this.objActionsPublic.setSpacing(false);
		this.chbSendNotificationPublic.setLabel("Send notification");
		
		this.lblSelectGroup.setSizeUndefined();
		this.gridGroups.setWidthFull();
		this.gridGroups.setHeight("150px");
		this.btnNewGroup.setWidthFull();
		this.btnNewGroup.setHeight(null);
		this.divCustomGroupChooser.add(this.lblSelectGroup, this.gridGroups, this.btnNewGroup);
		this.divCustomGroupChooser.setFlexGrow(1.0, this.gridGroups);
		this.btnGroupLeave.setSizeUndefined();
		this.btnGroupManageUser.setSizeUndefined();
		this.btnGroupEdit.setSizeUndefined();
		this.btnGroupDelete.setSizeUndefined();
		this.objActionsGroup.add(this.btnGroupLeave, this.btnGroupManageUser, this.btnGroupEdit, this.btnGroupDelete);
		this.divCustomGroupChooser.setSizeUndefined();
		this.objActionsGroup.setSizeUndefined();
		this.hr2.setSizeUndefined();
		this.objGroupMode.add(this.divCustomGroupChooser, this.objActionsGroup, this.hr2);
		this.objActionsPublic.setSizeUndefined();
		this.chbSendNotificationPublic.setSizeUndefined();
		this.hr3.setSizeUndefined();
		this.objPublicMode.add(this.objActionsPublic, this.chbSendNotificationPublic, this.hr3);
		this.objGroupMode.setWidthFull();
		this.objGroupMode.setHeight(null);
		this.objPublicMode.setWidthFull();
		this.objPublicMode.setHeight(null);
		this.add(this.objGroupMode, this.objPublicMode);
		this.setSizeUndefined();
		
		this.btnNewGroup.addClickListener(this::btnNewGroup_onClick);
		this.btnGroupLeave.addClickListener(this::btnGroupLeave_onClick);
		this.btnGroupManageUser.addClickListener(this::btnGroupManageUser_onClick);
		this.btnGroupEdit.addClickListener(this::btnGroupEdit_onClick);
		this.btnGroupDelete.addClickListener(this::btnGroupDelete_onClick);
		this.chbSendNotificationPublic.addValueChangeListener(this::chbSendNotificationPublic_valueChanged);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Checkbox         chbSendNotificationPublic;
	private Button           btnNewGroup, btnGroupLeave, btnGroupManageUser, btnGroupEdit, btnGroupDelete;
	private VerticalLayout   divCustomGroupChooser;
	private HorizontalLayout objActionsGroup, objActionsPublic;
	private Div              objGroupMode, gridGroups, objPublicMode;
	private Label            lblSelectGroup;
	private Hr               hr2, hr3;
	// </generated-code>
	
	public MessageGroup getSelectedItem()
	{
		return this.gridMessageGroup.asSingleSelect().getValue();
	}
	
}
