package com.caweco.esra.entities.rest.general;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import com.caweco.esra.entities.rest.namematch.Roles;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(value = { "hitScoreNormalized" })
public class GsssMatch
{
	@JsonProperty("hitScore")
	private double						hitScore;
	@JsonProperty("name")
	private String						name;
	@JsonProperty("aliases")
	private Map<String, String>			aliases			= new HashMap<>();
	@JsonProperty("gender")
	private String						gender;
	@JsonProperty("addresses")
	private Map<String, String>			addresses		= new HashMap<>();
	@JsonProperty("dateOfBirth")
	private Map<String, String>			dateOfBirth		= new HashMap<>();
	@JsonProperty("deceasedDate")
	private String						deceasedDate;
	@JsonProperty("placeOfBirth")
	private Map<String, String>			placeOfBirth	= new HashMap<>();
	@JsonProperty("citizenshipAndResidency")
	private String						citizenshipAndResidency;
	@JsonProperty("identification")
	private Map<String, Identification>	identification	= new HashMap<>();
	@JsonProperty("factivaEntryID")
	private String						factivaEntryID;
	@JsonProperty("internalEsraID")
	private String						internalEsraID = UUID.randomUUID().toString();
	@JsonProperty("categories")
	private Map<String, String>			categories		= new HashMap<>();
	@JsonProperty("sanctionsReferences")
	private String						sanctionsReferences;
	@JsonProperty("sanctionsIds")
	private String						sanctionsIds;
	@JsonProperty("pepRoles")
	private Roles						pepRoles;
	@JsonProperty("linkedProfiles")
	private Map<String, Profile>		linkedProfiles	= new HashMap<>();
	@JsonProperty("profileNotes")
	private String						profileNotes;
	@JsonProperty("sources")
	private String						sources;
	

	@Override
	public int hashCode() {
		return Objects.hash(factivaEntryID, internalEsraID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GsssMatch other = (GsssMatch) obj;
		return Objects.equals(factivaEntryID, other.factivaEntryID)
				&& Objects.equals(internalEsraID, other.internalEsraID);
	}
	
	

	public GsssMatch()
	{
		// empty Constructor for Framework
	}
	
	public double getHitScore()
	{
		return this.hitScore;
	}
	
	public void setHitScore(final double hitScore)
	{
		this.hitScore = hitScore;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public Map<String, String> getAliases()
	{
		return this.aliases;
	}
	
	public void setAliases(final Map<String, String> aliases)
	{
		this.aliases = aliases;
	}
	
	public String getGender()
	{
		return this.gender;
	}
	
	public void setGender(final String gender)
	{
		this.gender = gender;
	}
	
	public Map<String, String> getAddresses()
	{
		return this.addresses;
	}
	
	public void setAddresses(final Map<String, String> addresses)
	{
		this.addresses = addresses;
	}
	
	public Map<String, String> getDateOfBirth()
	{
		return this.dateOfBirth;
	}
	
	public void setDateOfBirth(final Map<String, String> dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getDeceasedDate()
	{
		return this.deceasedDate;
	}
	
	public void setDeceasedDate(final String deceasedDate)
	{
		this.deceasedDate = deceasedDate;
	}
	
	public Map<String, String> getPlaceOfBirth()
	{
		return this.placeOfBirth;
	}
	
	public void setPlaceOfBirth(final Map<String, String> placeOfBirth)
	{
		this.placeOfBirth = placeOfBirth;
	}
	
	public String getCitizenshipAndResidency()
	{
		return this.citizenshipAndResidency;
	}
	
	public void setCitizenshipAndResidency(final String citizenshipAndResidency)
	{
		this.citizenshipAndResidency = citizenshipAndResidency;
	}
	
	public Map<String, Identification> getIdentification()
	{
		return this.identification;
	}
	
	public void setIdentification(final Map<String, Identification> identification)
	{
		this.identification = identification;
	}
	
	public String getFactivaEntryID()
	{
		return this.factivaEntryID;
	}
	
	public void setFactivaEntryID(final String factivaEntryID)
	{
		this.factivaEntryID = factivaEntryID;
	}
	
	public Map<String, String> getCategories()
	{
		return this.categories;
	}
	
	public void setCategories(final Map<String, String> categories)
	{
		this.categories = categories;
	}
	
	public String getSanctionsReferences()
	{
		return this.sanctionsReferences;
	}
	
	public void setSanctionsReferences(final String sanctionsReferences)
	{
		this.sanctionsReferences = sanctionsReferences;
	}
	
	public String getSanctionsIds()
	{
		return this.sanctionsIds;
	}
	
	public void setSanctionsIds(final String sanctionsIds)
	{
		this.sanctionsIds = sanctionsIds;
	}
	
	public Roles getPepRoles()
	{
		return this.pepRoles;
	}
	
	public void setPepRoles(final Roles pepRoles)
	{
		this.pepRoles = pepRoles;
	}
	
	public Map<String, Profile> getLinkedProfiles()
	{
		return this.linkedProfiles;
	}
	
	public void setLinkedProfiles(final Map<String, Profile> linkedProfiles)
	{
		this.linkedProfiles = linkedProfiles;
	}
	
	public String getProfileNotes()
	{
		return this.profileNotes;
	}
	
	public void setProfileNotes(final String profileNotes)
	{
		this.profileNotes = profileNotes;
	}
	
	public String getSources()
	{
		return this.sources;
	}
	
	public void setSources(final String sources)
	{
		this.sources = sources;
	}
	
	@JsonIgnore
	public double getHitScoreNormalized()
	{
		return Math.round(this.hitScore * 100 / 120);
	}

	public String getInternalEsraID() {
		return internalEsraID;
	}

	public void setInternalEsraID(String internalEsraID) {
		this.internalEsraID = internalEsraID;
	}

	
	
	
	
}
