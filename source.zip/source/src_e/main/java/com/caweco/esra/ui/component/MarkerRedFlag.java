package com.caweco.esra.ui.component;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;


public class MarkerRedFlag extends Div
{
	/**
	 * For details see entries:
	 * <ul>
	 * <li>{@link Type#ICON_WL}</li>
	 * <li>{@link Type#ICON_Q}</li>
	 * <li>{@link Type#TEXT_Q}</li>
	 * <li>{@link Type#TEXT}</li>
	 * </ul>
	 */
	public static enum Type
	{
		/**
		 * Display Icons and sets color depending on specific rules:
		 * <ul>
		 * <li>intValue == null or intValue < 0 -> gray</li>
		 * <li>intValue = 0 -> green</li>
		 * <li>intValue = 1 -> yellow</li>
		 * <li>intValue > 1 -> red</li>
		 * </ul>
		 */
		ICON_WL,
		/**
		 * Display Icons and sets color depending on specific rules:
		 * <ul>
		 * <li>intValue == null -> gray</li>
		 * <li>intValue > 0 -> red</li>
		 * <li>intValue <= 0 -> green</li>
		 * </ul>
		 */
		ICON_Q,
		/**
		 * Display intValue as text and sets color depending on rules:
		 * <ul>
		 * <li>intValue == null -> gray</li>
		 * <li>intValue > 0 -> red</li>
		 * <li>intValue <= 0 -> green</li>
		 * </ul>
		 */
		TEXT_Q,
		/**
		 * Display textual value. Does not change Color.
		 */
		TEXT;
	}
	
	public static enum Color
	{
		GRAY,
		RED,
		GREEN,
		YELLOW;
	}
	
	private Type    type = Type.ICON_WL;
	private Integer intValue;
	private String  stringValue;
	private String  color;
	
	public MarkerRedFlag()
	{
		super();
		this.setClassName("esra-wl-tag");
		this.setSizeUndefined();
	}
	
	
	public Type getType()
	{
		return this.type;
	}
	
	public MarkerRedFlag setType(Type type)
	{
		this.type = type == null ? Type.ICON_WL : type;
		this.update_();
		return this;
	}
	
	public Integer getValue()
	{
		return this.intValue;
	}
	
	public void setValue(Integer value)
	{
		this.setValue(null, value);
	}
	
	protected void setValue(Type type, Integer value)
	{
		this.intValue = value;
		this.stringValue = value == null ? null : value.toString();
		
		if (type == null)
		{
			this.setType(this.getType());
		}
		else
		{
			this.setType(type);
		}
	}
	
	public String getStringValue()
	{
		return this.stringValue;
	}
	
	/**
	 * Sets "value" as content and {@link Type} to {@link Type#TEXT}
	 * 
	 * @param value
	 */
	protected void setStringValue(String value) // NO_UCD - setter
	{
		this.stringValue = StringUtils.stripToEmpty(value);
		this.intValue = null;
		
		this.setType(Type.TEXT);
	}
	
//	public void setStringValue(String value, String color)
//	{
//		this.setStringValue(value);
//		this.setColor(color);
//	}
	
//	public void setStringValue(String value, MarkerRedFlag.Color color)
//	{
//		this.setStringValue(value);
//		this.setColor(color);
//	}
//	
	/**
	 * Sets "value" and {@link Type} to {@link Type#ICON_WL}.
	 * 
	 * <p>
	 * Reason: It is not possible to get exact integer value from boolean in other type configurations!
	 * </p>
	 * 
	 * @param value
	 */
	public void setBooleanValue(Boolean value)
	{
		Integer integerObject = BooleanUtils.toIntegerObject(value, 2, 0, null);
		this.setValue(Type.ICON_WL, integerObject);
	}
	
	
	public String getColor()
	{
		return this.color;
	}
	
//	public void setColor(String color)
//	{
//		String colorCleaned = Optional.ofNullable(color)
//			.filter(col -> (CssHelper.isValidCssHexColor(col) || CssHelper.isValidCssColorKeyword(col)))
//			.orElse(Color.GRAY.name());
//		this.setColor_(colorCleaned);
//	}
	
	public void setColor(MarkerRedFlag.Color color)
	{
		this.setColor_(color == null ? Color.GRAY.name() : color.name());
		this.setAriaLabel_(color == null ? Color.GRAY : color);
	}
	
	/* ******************************************************************************* */
	
	protected void update_()
	{
		this.removeAll();
		
		if (Type.ICON_WL == this.type)
		{
			
			if (this.intValue == null || this.intValue < 0)
			{
				// No icon
				this.add(VaadinIcon.WARNING.create());
				this.setColor(Color.GRAY);
			}
			else if (this.intValue == 0)
			{
				this.add(VaadinIcon.CHECK_CIRCLE_O.create());
				this.setColor(Color.GREEN);
			}
			else if (this.intValue == 1)
			{
				this.add(VaadinIcon.EXCLAMATION_CIRCLE_O.create());
				this.setColor(Color.YELLOW);
			}
			else
			{
				this.add(VaadinIcon.EXCLAMATION_CIRCLE_O.create());
				this.setColor(Color.RED);
				
			}
			
		}
		else if (Type.ICON_Q == this.type)
		{
			
			if (this.intValue == null)
			{
				// No icon
				this.setColor(Color.GRAY);
			}
			else if (this.intValue > 0)
			{
				this.add(VaadinIcon.EXCLAMATION_CIRCLE_O.create());
				this.setColor(Color.RED);
			}
			else
			{
				this.add(VaadinIcon.CHECK_CIRCLE_O.create());
				this.setColor(Color.GREEN);
			}
			
		}
		else if (Type.TEXT_Q == this.type)
		{
			this.add(new Span(this.stringValue));
			
			if (this.intValue == null)
			{
				this.setColor(Color.GRAY);
			}
			else if (this.intValue > 0)
			{
				this.setColor(Color.RED);
			}
			else
			{
				this.setColor(Color.GREEN);
			}
		}
		else if (Type.TEXT == this.type)
		{
			this.add(new Span(this.stringValue));
		}
	}
	


	protected void setColor_(String cleanColor)
	{
		this.color = cleanColor;
		this.getStyle().set("background-color", this.color);
	}
	
	
	protected void setAriaLabel_(MarkerRedFlag.Color color)
	{
		if (color == Color.GREEN)
		{
			UiHelper.setAriaLabel(this, Aria.get("FindingMarker_SR_None"));
		}
		else if (color == Color.YELLOW)
		{
			UiHelper.setAriaLabel(this, Aria.get("FindingMarker_SR_PSR"));
		}
		else if (color == Color.RED)
		{
			UiHelper.setAriaLabel(this, Aria.get("FindingMarker_SR_SR"));
		}
		else
		{
			UiHelper.setAriaLabel(this, Aria.get("FindingMarker_SR_Unknown"));
		}
	}
}
