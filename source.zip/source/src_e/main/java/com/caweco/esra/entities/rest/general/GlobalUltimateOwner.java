package com.caweco.esra.entities.rest.general;

import com.caweco.esra.entities.rest.monitoring.BvdInfoTypeB;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonSerialize(as = BvdInfoTypeB.class)
public class GlobalUltimateOwner implements BvdInfoTypeB
{
	private String	name;
	private String	bvdId;
	private String	type;
	private String	city;
	private String	countryIso;
	private String	leiNumber;
	private String	directPercentage;
	private String	totalPercentage;
	
	public GlobalUltimateOwner()
	{
		// Empty Constructor for Framework
	}
	
	@Override
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	@Override
	public String getBvdId()
	{
		return this.bvdId;
	}
	
	public void setBvdId(final String bvdId)
	{
		this.bvdId = bvdId;
	}
	
	public String getType()
	{
		return this.type;
	}
	
	public void setType(final String type)
	{
		this.type = type;
	}
	
	@Override
	public String getCity()
	{
		return this.city;
	}
	
	public void setCity(final String city)
	{
		this.city = city;
	}
	
	@Override
	public String getCountryIso()
	{
		return this.countryIso;
	}
	
	public void setCountryIso(final String countryIso)
	{
		this.countryIso = countryIso;
	}
	
	public String getLeiNumber()
	{
		return this.leiNumber;
	}
	
	public void setLeiNumber(final String leiNumber)
	{
		this.leiNumber = leiNumber;
	}
	
	public String getDirectPercentage()
	{
		return this.directPercentage;
	}
	
	public void setDirectPercentage(final String directPercentage)
	{
		this.directPercentage = directPercentage;
	}
	
	public String getTotalPercentage()
	{
		return this.totalPercentage;
	}
	
	public void setTotalPercentage(final String totalPercentage)
	{
		this.totalPercentage = totalPercentage;
	}

	@Override
	public String toString() {
		return "GlobalUltimateOwner [name=" + name + ", bvdId=" + bvdId + ", type=" + type + ", city=" + city
				+ ", countryIso=" + countryIso + ", leiNumber=" + leiNumber + ", directPercentage=" + directPercentage
				+ ", totalPercentage=" + totalPercentage + "]";
	}
	
}
