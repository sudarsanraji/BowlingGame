package com.caweco.esra.ui.component;

import java.util.function.Consumer;

import com.caweco.esra.business.utils.UiHelper;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;

@Tag("esra-tagbox-item")
public class TagItem extends Div
{
	protected Consumer<TagItem> onDeleteClick;
	private Label             label;
	private Button            btn;
	
	public TagItem(String text)
	{
		super();
		this.label = this.createLabel();
		this.setTagText(text);
		this.btn = this.createButton();
		this.add(this.label, this.btn);
	}
	
	public TagItem()
	{
		super();
		this.label = this.createLabel();
		this.btn = this.createButton();
		this.add(this.label, this.btn);
	}
	
	public TagItem setTagText(String text)
	{
		this.label.setText(text);
		return this;
	}
	
	public TagItem setButtonAria(String ariaText)
	{
		UiHelper.setAriaLabel(this.btn, ariaText);
		return this;
	}
	
	public TagItem onDelete(Consumer<TagItem> onDeleteClick)
	{
		this.onDeleteClick = onDeleteClick;
		return this;
	}
	
	protected Label createLabel()
	{
		final Label label = new Label();
		return label;
	}
	
	protected Button createButton()
	{
		Button btn0 = new Button();
		btn0.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		btn0.setIcon(VaadinIcon.CLOSE_CIRCLE_O.create());
		btn0.addClickListener(event ->
		{
			if (this.onDeleteClick != null)
			{
				this.onDeleteClick.accept(this);
			}
		});
		return btn0;
	}
	
}
