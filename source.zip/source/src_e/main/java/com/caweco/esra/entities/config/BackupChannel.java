package com.caweco.esra.entities.config;

import java.time.Instant;
import java.util.function.Function;
import java.util.function.Supplier;


public class BackupChannel
{
	
	String						name;
	String						folderName;
	Supplier<String>			childFolderNameGenerator;
	Function<String, Instant>	childFolderNameParser;
	Integer						maxFolderCount;
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getFolderName()
	{
		return this.folderName;
	}
	
	public void setFolderName(String folderName)
	{
		this.folderName = folderName;
	}
	
	public Supplier<String> getChildFolderNameGenerator()
	{
		return this.childFolderNameGenerator;
	}
	
	public void setChildFolderNameGenerator(Supplier<String> childFolderNameGenerator)
	{
		this.childFolderNameGenerator = childFolderNameGenerator;
	}
	
	public Function<String, Instant> getChildFolderNameParser()
	{
		return this.childFolderNameParser;
	}
	
	public void setChildFolderNameParser(Function<String, Instant> childFolderNameParser)
	{
		this.childFolderNameParser = childFolderNameParser;
	}
	
	public Integer getMaxFolderCount()
	{
		return this.maxFolderCount;
	}
	
	public void setMaxFolderCount(Integer maxFolderCount)
	{
		this.maxFolderCount = maxFolderCount;
	}
}
