package com.caweco.esra.business.func.rest;

import com.caweco.esra.entities.Client;

import jakarta.ws.rs.client.WebTarget;

public class DataBackendHelper 
{
	public static String TEMPLATE_CHECK_LUCENE = "/lucene/{clientUuid}";
	
	public static Boolean isLuceneAvailable(Client client) {
		
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TEMPLATE_CHECK_LUCENE)
				.resolveTemplate("clientUuid", client.getUuid().toString());
		
		return webTarget.request().get(Boolean.class);
	}
}
