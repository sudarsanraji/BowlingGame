package com.caweco.esra.dto;

public class ScreeningMetadataEsuBase extends ScreeningMetadataBase {
	private int unreadMessages;
	private String esuWorker;

	public int getUnreadMessages() {
		return unreadMessages;
	}

	public void setUnreadMessages(int unreadMessages) {
		this.unreadMessages = unreadMessages;
	}
	
	public String getEsuWorker() {
		return esuWorker;
	}

	public void setEsuWorker(String esuWorker) {
		this.esuWorker = esuWorker;
	}
}
