package com.caweco.esra.entities.rest.general;

import java.util.Objects;

public class Identification
{
	private String	idValue;
	private String	idType;
	private String	idCountry;
	
	public Identification()
	{
		// empty Constructor for Framework
	}
	
	public String getIdValue()
	{
		return this.idValue;
	}
	
	public void setIdValue(final String idValue)
	{
		this.idValue = idValue;
	}
	
	public String getIdType()
	{
		return this.idType;
	}
	
	public void setIdType(final String idType)
	{
		this.idType = idType;
	}
	
	public String getIdCountry()
	{
		return this.idCountry;
	}
	
	public void setIdCountry(final String idCountry)
	{
		this.idCountry = idCountry;
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.idCountry, this.idType, this.idValue);
	}

	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(this.getClass() != obj.getClass())
		{
			return false;
		}
		final Identification other = (Identification)obj;
		return Objects.equals(this.idCountry, other.idCountry)
			&& Objects.equals(this.idType, other.idType)
			&& Objects.equals(this.idValue, other.idValue);
	}
	
	
}
