package com.caweco.esra.business.func.data;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.esra.MatchCategoryTag;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;


public class DataExtractorGsss
{
	/**
	 * Collects all {@link CompanyGsssMatch} entries of a {@link CIResponse} in a Stream:
	 * <ul>
	 * <li>the Company Profile</li>
	 * <li>the Global Ultimate Owner</li>
	 * <li>all Beneficial Owner</li>
	 * <li>all Intermediaries</li>
	 * </ul>
	 * 
	 * @param in
	 * @return
	 */
	public static Stream<CompanyGsssMatch> getCompanyGsssMatches(CIResponse in)
	{
		if (in == null)
		{
			return Stream.empty();
		}
		//// Company Profile, GlobalUltimateOwner
		Stream<CompanyGsssMatch> stream1                       = Stream
			.of(in.getCompanyGsssMatchResults(), in.getGuoGsssMatchResults());
		
		//// Beneficial Owner, Intermediaries
		Stream<CompanyGsssMatch> stream2                       = Stream
			.of(in.getBenOwnGsssMatchResults(), in.getInterGsssMatchResults()).filter(Objects::nonNull)
			.map(Map::values).flatMap(Collection::stream);
		
		Stream<CompanyGsssMatch>    companyGsssMatchesOfScreening = Stream.concat(stream1, stream2)
			.filter(Objects::nonNull);
		return companyGsssMatchesOfScreening;
	}
	
	/**
	 * Maps category strings from {@link GsssMatch#getCategories()} to {@link MatchCategoryTag} objects. <br />
	 * Uses {@link DataExtractorGsss#getCategoryAsObjects(Client, String)}.
	 * 
	 * @param c  the client
	 * @param in the GsssMatch item
	 * @return
	 */
	public static List<MatchCategoryTag> getCategoriesAsObjects(Client c, GsssMatch in)
	{
		if (in.getCategories() == null || in.getCategories().isEmpty())
		{
			return Collections.emptyList();
		}
		
		// @formatter:off
		
		Collection<String> categoryValues = in.getCategories().values();
		
		List<MatchCategoryTag> categoryObjects =
			categoryValues.stream()
			.map(v -> getCategoryAsObject(c, v))
			.filter(Objects::nonNull)
			.sorted(Comparator.comparing(MatchCategoryTag::getWeight, Comparator.reverseOrder()))
			.collect(Collectors.toList());
		
		// @formatter:on
		
		return categoryObjects;
	}
	
	/**
	 * Maps a single category entry to a {@link MatchCategoryTag} object. <br />
	 * If "cat" is nut null and not empty, but not found: returns a new dummy MatchCategoryTag with no redFlag.
	 * 
	 * @param c
	 * @param cat
	 * @return
	 */
	public static MatchCategoryTag getCategoryAsObject(Client c, String cat)
	{
		if (cat == null || cat.isEmpty() || c == null)
		{
			return null;
		}
		else
		{
			
			Optional<MatchCategoryTag> tag = c.getMatchCategoryTags(false).stream()
				.filter(mct ->
				{
					boolean contains = cat.contains(mct.getSearchString());
			
						// TODO: REMOVE DEV CODE
			
//							System.out.println("\"" + cat + "\" contains \"" + mct.getSearchString() + "\": " + contains);
//							
//							System.out.println(Hex.encodeHex(cat.getBytes(StandardCharsets.UTF_8)));
//							System.out.println(Hex.encodeHex(mct.getSearchString().getBytes(StandardCharsets.UTF_8)));
//							
//							String encodedString =
//								StringUtils.toEncodedString(cat.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
//							String encodedString2 = StringUtils.toEncodedString(
//								mct.getSearchString().getBytes(StandardCharsets.UTF_8),
//								StandardCharsets.UTF_8);
//							
//							boolean contains2 = StringUtils.containsIgnoreCase(encodedString, encodedString2);
//							System.out.println("\"" + cat + "\" containsIC \"" + mct.getSearchString() + "\": " + contains2);
					
					return contains;
				})
				.findFirst();
			
			return tag.orElse(new MatchCategoryTag(0, cat, null, "gray", false));
		}
	}
	
	public static MatchCategoryTag getCategoryObject(Client c, String cat)
	{
		if (cat == null || cat.isEmpty() || c == null)
		{
			return null;
		}
		else
		{
			
			MatchCategoryTag tag = c.getMatchCategoryTags(false).stream()
				.filter(mct -> cat.contains(mct.getSearchString()))
				.findFirst().orElse(null);
			
			return tag;
		}
	}
	
}
