package com.caweco.esra.dao;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.dto.creator.ScreeningFilterCreator;
import com.caweco.esra.entities.esu.ScreeningFilter;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class PersonalFilterDAO {

	public static void savePersonalFilter(ScreeningFilter filter, String userEmail, String clientId) {
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/user/" + userEmail + "/screeningFilter/" + clientId);
		
		Response response = webTarget.request().put(Entity.entity(ScreeningFilterCreator.convertScreeningFilterToDTO(filter), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}

}
