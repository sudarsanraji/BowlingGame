package com.caweco.esra.ui.esu;

import com.caweco.esra.entities.meta.HasRepresentation;


public enum EsuView implements HasRepresentation
{
	ALL_ESU("All"),
	INBOX("Inbox"),
	FAVOURITES("Favourites");
	
	String representation;
	
	EsuView(String representation)
	{
		this.representation = representation;
	}
	
	@Override
	public String getRepresentation()
	{
		return this.representation;
	}
}
