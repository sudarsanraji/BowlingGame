package com.caweco.esra.ui.admin.parts;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.reporting.UARReportBuilderThread;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ManualClientUserAssignment;
import com.caweco.esra.ui.admin.parts.renderer.RendererUserBackendActions;
import com.caweco.esra.ui.interfaces.HasRefreshableGrid;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.GridFilterSubjectFactory;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.formlayout.FormLayout.FormItem;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.function.SerializableSupplier;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.server.VaadinSession;

/**
 * Add/Edit user - ALL client / Single client depending on {@link Mode}. Default is {@link Mode#CLIENT}
 *
 */
public class PartUserForm extends VerticalLayout implements HasRefreshableGrid
{
	
	public enum Mode
	{
		ALL, CLIENT;
	}
	
	public static final Logger      LOG                        = LoggerFactory.getLogger(PartUserForm.class);
	private Anchor downloadLink;
	
    private ExecutorService executorService;

	private User                    user;
	
	private boolean                 allUserMode                = false;
	SerializableSupplier<Set<User>> allUserModeUserSupplier    = UserDAO::findAll;
	SerializableSupplier<Set<User>> clientUserModeUserSupplier = () -> CurrentUtil.getClient().getUser();
	Comparator<User>                userComparator             = Comparator
		.comparing(User::getLastname, Comparator.nullsFirst(String.CASE_INSENSITIVE_ORDER));
	
	
	public PartUserForm()
	{
		this(Mode.CLIENT);
	}
	/**
	 * Called when the component is attached to the UI.
	 * This method is part of the component lifecycle and is invoked automatically.
	 *
	 * @param attachEvent the event that contains information about the attach operation
	 */
	@Override
	protected void onAttach(AttachEvent attachEvent) {
	    super.onAttach(attachEvent);
	    if (this.allUserMode) {
	        restoreDownloadLink();
	    }
	}
	/**
	 * Restores the download link from the session and updates the UI components accordingly.
	 * This method checks if a previously generated download link is stored in the session
	 * and re-establishes it in the UI if available.
	 */
	private void restoreDownloadLink() {
	    VaadinSession session = VaadinSession.getCurrent();
	    if (session != null) {
	        StreamResource storedResource = (StreamResource) session.getAttribute("downloadResource");
	        if (storedResource != null) {
	            String filename = storedResource.getName();
	            setupDownloadLink(storedResource, filename);
	        }
	    }
	}
	
	public PartUserForm(final Mode mode)
	{
		super();
		this.initUI();
		this.allUserMode = mode == null ? false : Mode.ALL == mode;
		
		if (this.allUserMode)
		{
            this.button.setVisible(true);
			this.binder.forField(this.checkAppAdmin).bind(User::isAppAdmin, User::setAppAdmin);
			
			final Map<Client, Set<User>> users = ClientDAO.findAll()
				.stream()
				.collect(Collectors.toMap(Function.identity(), Client::getUser, (a,b) -> a));
			
			this.getGrid().addColumn(RenderedComponent.Renderer(() -> new RendererUserBackendActions(
				this, users)))
				.setResizable(true)
				.setSortable(false)
				.setAutoWidth(true)
				.setFlexGrow(0);
		}
		else
		{
			this.checkAppAdmin.setVisible(false);
			this.getGrid().removeColumnByKey("appAdmin");
			this.button.setVisible(false);
		}
		
		this.refreshGridData();
	}
	
	@Override
	public void refreshGridData()
	{
		final Set<User>  users       = this.allUserMode ? this.allUserModeUserSupplier.get() : this.clientUserModeUserSupplier.get();
		final List<User> usersSorted = users.stream().sorted(this.userComparator).collect(Collectors.toList());
		
		this.getGrid().setItems(usersSorted);
		this.filterComponent.connectWith(this.getGrid());
		
	}
	
	protected void setCurrentUser(final User u)
	{
		this.user = u;
		
		this.binder.readBean(this.user);
		
		this.userForm.setEnabled(this.user != null);
		this.btnSave.setEnabled(this.user != null);

		this.txtEmailAddress.setReadOnly(u != null && u.getEmailAddress() != null);
		
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void grid_selectionChange(final SelectionEvent<Grid<User>, User> event)
	{
		final Optional<User> firstSelectedItem = event.getFirstSelectedItem();
			
		this.setCurrentUser(firstSelectedItem.orElse(null));
	}
	
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewUser}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewUser_onClick(final ClickEvent<Button> event)
	{
		this.getGrid().deselectAll();
		
		this.setCurrentUser(new User());
	}

	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		try
		{
			final boolean isNewUser = this.user.getEmailAddress() == null;
			
			this.binder.writeBean(this.user);
			
			if (isNewUser)
			{
				if (UserDAO.find(this.user.getEmailAddress()).isPresent())
				{
					Notificator.error("Validation failed: Email already exist!");
					return;
				}
				else
				{
					UserDAO.insert(this.user);
					
					if (!this.allUserMode)
					{
						ClientDAO.addUser(CurrentUtil.getClient(), this.user, ManualClientUserAssignment
							.New(CurrentUtil.getUser().getEmailAddress()));
					}
				}
				
				
				this.refreshGridData();
				this.getGrid().select(this.user);
				
			}
			else
			{
				UserDAO.update(this.user);
				this.getGrid().getDataProvider().refreshItem(this.user);
			}
			
			this.txtEmailAddress.setReadOnly(true);
		}
		catch (final ValidationException e)
		{
			LOG.debug("Error validation user.", e);
			Notificator.error("Validation failed: " + e.getMessage());
		}
		
	}
	
	public void addSelListener(final SelectionListener<Grid<User>, User> selListener)
	{
		this.getGrid().addSelectionListener(selListener);
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #button}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	 public void button_onClick(final ClickEvent<Button> event) {
	        prepareUIForReportGeneration();
	        UI currentUI = UI.getCurrent();
	        this.executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
	        executorService.submit(() -> {
	            UARReportBuilderThread reportThread = new UARReportBuilderThread(currentUI, this);
	            reportThread.start();
	        });
	        executorService.shutdown();
	    }
    /**
     * Prepares the user interface for report generation by updating UI elements.
     */
    private void prepareUIForReportGeneration() {
        if (getDownloadLink() != null) {
            getHorizontalLayout().remove(getDownloadLink());
        }
        getProgressBar().setVisible(true);
        getProgressBar().setIndeterminate(true);
        getProgressBar().setWidth("150px");
        getProgressBar().setHeight("10px");
        getLabel().setVisible(true);
        getHorizontalLayout().add(getLabel());
    }
    
    /**
     * Sets up the download link for the generated report and updates the UI components accordingly.
     *
     * @param resource the {@link StreamResource} representing the downloadable report file
     * @param filename the name of the file to be downloaded
     */
	public void setupDownloadLink(StreamResource resource, String filename) {
	    getProgressBar().setVisible(false);
	    Anchor downloadLink = new Anchor(resource, "Download UAR Report " + filename);
	    downloadLink.getElement().setAttribute("download", true);
	    setDownloadLink(downloadLink);
	    getHorizontalLayout().add(getDownloadLink());
	    getHorizontalLayout().setVisible(true);
	    getLabel().setVisible(false);
	    LOG.info("Report built and added to UI.");
		LOG.info(CurrentUtil.getUser().getFirstname() + " " + CurrentUtil.getUser().getLastname()
						+ " with roles " + CommonUtil.getLogString(CurrentUtil.getUser())
						+ " created the report " + filename + " from the admin page ");
	}
    public Grid<User> getGrid() {
		return grid;
	}

	public void setGrid(Grid<User> grid) {
		this.grid = grid;
	}

	public ProgressBar getProgressBar() {
		return progressBar;
	}

	public void setProgressBar(ProgressBar progressBar) {
		this.progressBar = progressBar;
	}

	public Anchor getDownloadLink() {
		return downloadLink;
	}

	public void setDownloadLink(Anchor downloadLink) {
		this.downloadLink = downloadLink;
	}

	public HorizontalLayout getHorizontalLayout() {
		return horizontalLayout;
	}

	public void setHorizontalLayout(HorizontalLayout horizontalLayout) {
		this.horizontalLayout = horizontalLayout;
	}

	public Label getLabel() {
		return label;
	}

	public void setLabel(Label label) {
		this.label = label;
	}
    	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.filterComponent = new FilterComponent();
		this.grid = new Grid<>(User.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.btnNewUser = new Button();
		this.btnSave = new Button();
		this.button = new Button();
		this.progressBar = new ProgressBar();
		this.label = new Label();
		this.userForm = new FormLayout();
		this.formItem = new FormItem();
		this.lblEmailAddress = new Label();
		this.txtEmailAddress = new TextField();
		this.formItem2 = new FormItem();
		this.lblLastname = new Label();
		this.txtLastname = new TextField();
		this.formItem3 = new FormItem();
		this.lblFirstname = new Label();
		this.txtFirstname = new TextField();
		this.formItem4 = new FormItem();
		this.lblDepartment = new Label();
		this.horizontalLayout2 = new HorizontalLayout();
		this.txtDepartment = new TextField();
		this.formItem5 = new FormItem();
		this.checkActive = new Checkbox();
		this.formItem6 = new FormItem();
		this.checkAppAdmin = new Checkbox();
		this.binder = new Binder<>();
	
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT,
				GridVariant.LUMO_WRAP_CELL_CONTENT);
		this.grid.getStyle().set("flex-basis", "0");
		this.grid.addColumn(User::getLastname).setKey("lastname")
				.setHeader(CaptionUtils.resolveCaption(User.class, "lastname")).setResizable(true).setSortable(true);
		this.grid.addColumn(User::getFirstname).setKey("firstname")
				.setHeader(CaptionUtils.resolveCaption(User.class, "firstname")).setResizable(true).setSortable(true);
		this.grid.addColumn(User::getEmailAddress).setKey("emailAddress")
				.setHeader(CaptionUtils.resolveCaption(User.class, "emailAddress")).setResizable(true).setSortable(true);
		this.grid.addColumn(User::getDepartment).setKey("department")
				.setHeader(CaptionUtils.resolveCaption(User.class, "department")).setResizable(true).setSortable(true);
		this.grid.addColumn(User::isAppAdmin).setKey("appAdmin")
				.setHeader(CaptionUtils.resolveCaption(User.class, "appAdmin")).setResizable(true).setSortable(true)
				.setComparator(Comparator.comparing(User::isAppAdmin)).setAutoWidth(true).setFlexGrow(0);
		this.grid.addColumn(User::isActive).setKey("active").setHeader(CaptionUtils.resolveCaption(User.class, "active"))
				.setResizable(true).setSortable(true).setComparator(Comparator.comparing(User::isActive)).setAutoWidth(true)
				.setFlexGrow(0);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.btnNewUser.setText("New User");
		this.btnNewUser.setIcon(VaadinIcon.PLUS.create());
		this.btnSave.setEnabled(false);
		this.btnSave.setText("Save");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		this.button.setText("Generate UAR Report");
		this.button.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.progressBar.setClassName("slow1");
		this.progressBar.setVisible(false);
		this.label.setText("This operation may take some time");
		this.label.setVisible(false);
		this.userForm.setEnabled(false);
		this.userForm
				.setResponsiveSteps(new FormLayout.ResponsiveStep("0px", 2, FormLayout.ResponsiveStep.LabelsPosition.TOP));
		this.lblEmailAddress.setText("Email");
		this.txtEmailAddress.setReadOnly(true);
		this.lblLastname.setText("Lastname");
		this.lblFirstname.setText("Firstname");
		this.lblDepartment.setText("Department");
		this.checkActive.setLabel("Active");
		this.checkAppAdmin.setLabel("Application Admin");
	
		this.binder.forField(this.txtEmailAddress).asRequired().withNullRepresentation("").bind(User::getEmailAddress,
				User::setEmailAddress);
		this.binder.forField(this.txtLastname).asRequired().withNullRepresentation("").bind(User::getLastname,
				User::setLastname);
		this.binder.forField(this.txtFirstname).withNullRepresentation("").bind(User::getFirstname, User::setFirstname);
		this.binder.forField(this.txtDepartment).withNullRepresentation("").bind(User::getDepartment, User::setDepartment);
		this.binder.forField(this.checkActive).bind(User::isActive, User::setActive);
	
		this.filterComponent.connectWith(this.grid.getDataProvider());
		this.filterComponent.setFilterSubject(GridFilterSubjectFactory.CreateFilterSubject(this.grid,
				Arrays.asList("firstname", "lastname", "emailAddress"),
				Arrays.asList("firstname", "lastname", "emailAddress", "active")));
	
		this.btnNewUser.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.button.setSizeUndefined();
		this.progressBar.setSizeUndefined();
		this.horizontalLayout.add(this.btnNewUser, this.btnSave, this.button, this.progressBar);
		this.lblEmailAddress.setSizeUndefined();
		this.lblEmailAddress.getElement().setAttribute("slot", "label");
		this.txtEmailAddress.setWidthFull();
		this.txtEmailAddress.setHeight(null);
		this.formItem.add(this.lblEmailAddress, this.txtEmailAddress);
		this.lblLastname.setSizeUndefined();
		this.lblLastname.getElement().setAttribute("slot", "label");
		this.txtLastname.setWidthFull();
		this.txtLastname.setHeight(null);
		this.formItem2.add(this.lblLastname, this.txtLastname);
		this.lblFirstname.setSizeUndefined();
		this.lblFirstname.getElement().setAttribute("slot", "label");
		this.txtFirstname.setWidthFull();
		this.txtFirstname.setHeight(null);
		this.formItem3.add(this.lblFirstname, this.txtFirstname);
		this.txtDepartment.setWidthFull();
		this.txtDepartment.setHeight(null);
		this.horizontalLayout2.add(this.txtDepartment);
		this.lblDepartment.setSizeUndefined();
		this.lblDepartment.getElement().setAttribute("slot", "label");
		this.horizontalLayout2.setWidthFull();
		this.horizontalLayout2.setHeight(null);
		this.formItem4.add(this.lblDepartment, this.horizontalLayout2);
		this.checkActive.setSizeUndefined();
		this.formItem5.add(this.checkActive);
		this.checkAppAdmin.setSizeUndefined();
		this.formItem6.add(this.checkAppAdmin);
		this.userForm.add(this.formItem, this.formItem2, this.formItem3, this.formItem4, this.formItem5, this.formItem6);
		this.filterComponent.setWidthFull();
		this.filterComponent.setHeight(null);
		this.grid.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.label.setSizeUndefined();
		this.userForm.setSizeUndefined();
		this.add(this.filterComponent, this.grid, this.horizontalLayout, this.label, this.userForm);
		this.setFlexGrow(1.0, this.grid);
		this.setSizeFull();
	
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.btnNewUser.addClickListener(this::btnNewUser_onClick);
		this.btnSave.addClickListener(this::btnSave_onClick);
		this.button.addClickListener(this::button_onClick);
	} // </generated-code>

	

	// <generated-code name="variables">
	private FormLayout userForm;
	private Checkbox checkActive, checkAppAdmin;
	private Button btnNewUser, btnSave, button;
	private ProgressBar progressBar;
	private Grid<User> grid;
	private HorizontalLayout horizontalLayout, horizontalLayout2;
	private Label label, lblEmailAddress, lblLastname, lblFirstname, lblDepartment;
	private FilterComponent filterComponent;
	private Binder<User> binder;
	private TextField txtEmailAddress, txtLastname, txtFirstname, txtDepartment;
	private FormItem formItem, formItem2, formItem3, formItem4, formItem5, formItem6;
	// </generated-code>
	
	
}
