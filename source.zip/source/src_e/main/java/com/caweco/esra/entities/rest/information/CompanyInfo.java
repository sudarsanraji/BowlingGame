package com.caweco.esra.entities.rest.information;

import java.util.HashMap;
import java.util.Map;

import com.caweco.esra.entities.rest.general.BeneficialOwner;
import com.caweco.esra.entities.rest.general.GlobalUltimateOwner;
import com.caweco.esra.entities.rest.general.Intermediaries;
import com.caweco.esra.entities.rest.general.ShareHolder;
import com.caweco.esra.entities.rest.general.Subsidiary;
import com.caweco.esra.entities.rest.general.UltimateBeneficiaries;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.rapidclipse.framework.server.resources.Caption;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyInfo
{
	private String								name;
	private String								address;
	private String								postCode;
	private String								city;
	private String								country;
	private String								countryIsoCode;
	private String								stateProvince;
	private String								telephone;
	private String								faxNumber;
	private String								website;
	private String								email;
	private String								vatNumber;
	private String								nationalIdNumber;
	private String								isinNumber;
	private String								leiNumber;
	private String								tradeDescriptionEn;
	private String								tradeDescriptionOl;
	private String								productsAndServices;
	private String								bvdMajorSector;
	private NaceCodes							naceRev2Codes;
	private UsSicCodes							usSicCodes;
	private Map<String, BeneficialOwner>		beneficialOwners			= new HashMap<>();
	private Map<String, UltimateBeneficiaries>	otherUltimateBeneficiaries	= new HashMap<>();
	private Map<String, Intermediaries>			boIntermediaries			= new HashMap<>();
	private Map<String, Intermediaries>			oubIntermediaries			= new HashMap<>();
	private GlobalUltimateOwner					globalUltimateOwner;
	// CARA v4
	private Map<String, ShareHolder>			shareHoldersData			= new HashMap<>();
	// CARA v5
	private Map<String, Subsidiary>				subsidiaryData				= new HashMap<>();
	
	public CompanyInfo()
	{
		// Empty Constructor for Framework
	}
	
	@Caption("Name")
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	@Caption("Address")
	public String getAddress()
	{
		return this.address;
	}
	
	public void setAddress(final String address)
	{
		this.address = address;
	}
	
	@Caption("Postcode")
	public String getPostCode()
	{
		return this.postCode;
	}
	
	public void setPostCode(final String postCode)
	{
		this.postCode = postCode;
	}
	
	@Caption("City")
	public String getCity()
	{
		return this.city;
	}
	
	public void setCity(final String city)
	{
		this.city = city;
	}
	
	@Caption("Country")
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(final String country)
	{
		this.country = country;
	}
	
	@Caption("Country ISO")
	public String getCountryIsoCode()
	{
		return this.countryIsoCode;
	}
	
	public void setCountryIsoCode(final String countryIsoCode)
	{
		this.countryIsoCode = countryIsoCode;
	}
	
	@Caption("State")
	public String getStateProvince()
	{
		return this.stateProvince;
	}
	
	public void setStateProvince(final String stateProvince)
	{
		this.stateProvince = stateProvince;
	}
	
	@Caption("Phone")
	public String getTelephone()
	{
		return this.telephone;
	}
	
	public void setTelephone(final String telephone)
	{
		this.telephone = telephone;
	}
	
	@Caption("FAX")
	public String getFaxNumber()
	{
		return this.faxNumber;
	}
	
	public void setFaxNumber(final String faxNumber)
	{
		this.faxNumber = faxNumber;
	}
	
	@Caption("Website")
	public String getWebsite()
	{
		return this.website;
	}
	
	public void setWebsite(final String website)
	{
		this.website = website;
	}
	
	@Caption("EMail")
	public String getEmail()
	{
		return this.email;
	}
	
	public void setEmail(final String email)
	{
		this.email = email;
	}
	
	@Caption("Vat Number")
	public String getVatNumber()
	{
		return this.vatNumber;
	}
	
	public void setVatNumber(final String vatNumber)
	{
		this.vatNumber = vatNumber;
	}
	
	@Caption("National Id Number")
	public String getNationalIdNumber()
	{
		return this.nationalIdNumber;
	}
	
	public void setNationalIdNumber(final String nationalIdNumber)
	{
		this.nationalIdNumber = nationalIdNumber;
	}
	
	@Caption("ISIN Number")
	public String getIsinNumber()
	{
		return this.isinNumber;
	}
	
	public void setIsinNumber(final String isinNumber)
	{
		this.isinNumber = isinNumber;
	}
	
	@Caption("LEI Number")
	public String getLeiNumber()
	{
		return this.leiNumber;
	}
	
	public void setLeiNumber(final String leiNumber)
	{
		this.leiNumber = leiNumber;
	}
	
	@Caption("Trade Description EN")
	public String getTradeDescriptionEn()
	{
		return this.tradeDescriptionEn;
	}
	
	public void setTradeDescriptionEn(final String tradeDescriptionEn)
	{
		this.tradeDescriptionEn = tradeDescriptionEn;
	}
	
	@Caption("Trade Description OL")
	public String getTradeDescriptionOl()
	{
		return this.tradeDescriptionOl;
	}
	
	public void setTradeDescriptionOl(final String tradeDescriptionOl)
	{
		this.tradeDescriptionOl = tradeDescriptionOl;
	}
	
	@Caption("Products / Services")
	public String getProductsAndServices()
	{
		return this.productsAndServices;
	}
	
	public void setProductsAndServices(final String productsAndServices)
	{
		this.productsAndServices = productsAndServices;
	}
	
	@Caption("BVD Major Sector")
	public String getBvdMajorSector()
	{
		return this.bvdMajorSector;
	}
	
	public void setBvdMajorSector(final String bvdMajorSector)
	{
		this.bvdMajorSector = bvdMajorSector;
	}
	
	@Caption("NACE Rev.2")
	public NaceCodes getNaceRev2Codes()
	{
		return this.naceRev2Codes;
	}
	
	public void setNaceRev2Codes(final NaceCodes naceRev2Codes)
	{
		this.naceRev2Codes = naceRev2Codes;
	}
	
	@Caption("US SIC")
	public UsSicCodes getUsSicCodes()
	{
		return this.usSicCodes;
	}
	
	public void setUsSicCodes(final UsSicCodes usSicCodes)
	{
		this.usSicCodes = usSicCodes;
	}
	
	@Caption("Beneficial Owners")
	public Map<String, BeneficialOwner> getBeneficialOwners()
	{
		return this.beneficialOwners;
	}
	
	public void setBeneficialOwners(final Map<String, BeneficialOwner> beneficialOwners)
	{
		this.beneficialOwners = beneficialOwners;
	}
	
	@Caption("Ultimate Beneficiaries")
	public Map<String, UltimateBeneficiaries> getOtherUltimateBeneficiaries()
	{
		return this.otherUltimateBeneficiaries;
	}
	
	public void setOtherUltimateBeneficiaries(final Map<String, UltimateBeneficiaries> otherUltimateBeneficiaries)
	{
		this.otherUltimateBeneficiaries = otherUltimateBeneficiaries;
	}
	
	@Caption("Bo Intermediaries")
	public Map<String, Intermediaries> getBoIntermediaries()
	{
		return this.boIntermediaries;
	}
	
	public void setBoIntermediaries(final Map<String, Intermediaries> boIntermediaries)
	{
		this.boIntermediaries = boIntermediaries;
	}
	
	@Caption("Oub Intermediaries")
	public Map<String, Intermediaries> getOubIntermediaries()
	{
		return this.oubIntermediaries;
	}
	
	public void setOubIntermediaries(final Map<String, Intermediaries> oubIntermediaries)
	{
		this.oubIntermediaries = oubIntermediaries;
	}
	
	@Caption("Global Ultimate Owner")
	public GlobalUltimateOwner getGlobalUltimateOwner()
	{
		return this.globalUltimateOwner;
	}
	
	public void setGlobalUltimateOwner(final GlobalUltimateOwner globalUltimateOwner)
	{
		this.globalUltimateOwner = globalUltimateOwner;
	}
	
	@Caption("Shareholder")
	public Map<String, ShareHolder> getShareHoldersData()
	{
		return this.shareHoldersData;
	}
	
	public void setShareHoldersData(Map<String, ShareHolder> shareHoldersData)
	{
		this.shareHoldersData = shareHoldersData;
	}
	
	@Caption("Subsidiaries")
	public Map<String, Subsidiary> getSubsidiaryData()
	{
		return this.subsidiaryData;
	}
	
	public void setSubsidiaryData(Map<String, Subsidiary> subsidiaryData)
	{
		this.subsidiaryData = subsidiaryData;
	}

	@Override
	public String toString() {
		String naceRev2CodesString = naceRev2Codes != null ? naceRev2Codes.toString()
				: "none";
		String usSicCodesString = usSicCodes != null ? usSicCodes.toString()
				: "none";
		String globalUltimateOwnerString = globalUltimateOwner != null ? globalUltimateOwner.toString()
				: "none";
		
		return "CompanyInfo [name=" + name + ", address=" + address + ", postCode=" + postCode + ", city=" + city
				+ ", country=" + country + ", countryIsoCode=" + countryIsoCode + ", stateProvince=" + stateProvince
				+ ", telephone=" + telephone + ", faxNumber=" + faxNumber + ", website=" + website + ", email=" + email
				+ ", vatNumber=" + vatNumber + ", nationalIdNumber=" + nationalIdNumber + ", isinNumber=" + isinNumber
				+ ", leiNumber=" + leiNumber + ", tradeDescriptionEn=" + tradeDescriptionEn + ", tradeDescriptionOl="
				+ tradeDescriptionOl + ", productsAndServices=" + productsAndServices + ", bvdMajorSector="
				+ bvdMajorSector + ", naceRev2Codes=" + naceRev2CodesString + ", usSicCodes=" + usSicCodesString
				+ ", beneficialOwners=" + beneficialOwners + ", otherUltimateBeneficiaries="
				+ otherUltimateBeneficiaries + ", boIntermediaries=" + boIntermediaries + ", oubIntermediaries="
				+ oubIntermediaries + ", globalUltimateOwner=" + globalUltimateOwnerString + ", shareHoldersData="
				+ shareHoldersData + ", subsidiaryData=" + subsidiaryData + "]";
	}
	
	
	
}
