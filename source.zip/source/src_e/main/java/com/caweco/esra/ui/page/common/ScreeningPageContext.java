package com.caweco.esra.ui.page.common;

import java.util.Optional;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Screening;

public class ScreeningPageContext extends PageContext
{
	public static ScreeningPageContext New(Client client, Screening screening) //NO_UCD
	{
		ScreeningPageContext c = new ScreeningPageContext();
		c.client = client;
		c.screening = screening;
		return c;
	}
	
	protected Screening screening;

	public Optional<Screening> getScreening()
	{
		return Optional.ofNullable(screening);
	}
	public void setScreening(Screening screening)
	{
		this.screening = screening;
	}
}
