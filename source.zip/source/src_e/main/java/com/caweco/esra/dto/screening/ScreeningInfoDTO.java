package com.caweco.esra.dto.screening;

import com.caweco.esra.dto.ClientMetadataDTO;
import com.caweco.esra.dto.ScreeningMetadataDTO;

public class ScreeningInfoDTO
{
	public ClientMetadataDTO client;
	public ScreeningMetadataDTO screening;
}
