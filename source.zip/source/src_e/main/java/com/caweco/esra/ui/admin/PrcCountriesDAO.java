package com.caweco.esra.ui.admin;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.entities.Client;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class PrcCountriesDAO {
	
	public static void removeCountry(final Client client, final String value) {
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/prcCountry/" + value);
		
		final Response response = webTarget.request().delete();
		System.out.println(response);
	}

	public static void addCountry(final Client client, final String value) {
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/prcCountry/");
		
		final Response response = webTarget.request().post(Entity.entity(value, MediaType.APPLICATION_JSON));
		System.out.println(response);
	}
	
	
}
