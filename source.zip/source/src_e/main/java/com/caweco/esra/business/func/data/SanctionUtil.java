package com.caweco.esra.business.func.data;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.config.EsraClientConfiguration;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.core.MatchRating;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.core.SearchEntryGsss;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.esra.MatchCategoryTag;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.ui.sanctions.PageBusinessInformation;
import com.caweco.esra.ui.sanctions.PageFinancialScreening;
import com.caweco.esra.ui.sanctions.PageTradeSactions;


public class SanctionUtil
{
	/**
	 * AdditionalSaveActions outcome.
	 *
	 */
	public static enum AdditionalSaveAction
	{
		REVIEW,
		NOEVIDENCE,
		NONE;
	}
	
	private static final Logger LOG = LoggerFactory.getLogger(SanctionUtil.class);
	
	
	public static Integer toFlag(Boolean isMarked)
	{
		final Integer flagValue = BooleanUtils.toIntegerObject(isMarked, 2, 0, null);
		return flagValue;
	}
	
	/* ******************************************************************* */
	////
	
	/**
	 * Detect if there are optional {@link AdditionalSaveAction}s allowed depending on the screening's data.<br />
	 * An additional save action if for example "Set Screening's state to {@link ScreeningStatus#NO_EXPOSURE}"
	 * <p>
	 * Evaluates also pending(unsaved) changes of PageSanctionScreening
	 * </p>
	 * 
	 * @param c
	 * @return
	 */
	public static AdditionalSaveAction getAdditionalSaveAction(final PageFinancialScreening c)
	{
		final Screening scr = c.getScreening();
		
		if(c.isInitialized())
		{
			if(c.hasRedFlag())
			{
				if (isFinished_TS(scr, false))
				{
					if (isFinished_BI(scr, false))
					{
						return AdditionalSaveAction.REVIEW;
					}
					else
					{
						// No Action (BI not finished)
					}
				}
				else
				{
					// No Action (TS not finished)
				}
			}
			else
			{
				if (isFinished_TS(scr, false))
				{
					if (hasRedFlagTS(scr))
					{
						if (isFinished_BI(scr, false))
						{
							return AdditionalSaveAction.REVIEW;
						}
						else
						{
							// No Action (BI not finished)
						}
					}
					else
					{
						return AdditionalSaveAction.NOEVIDENCE;
					}
				}
				else
				{
					// No Action (TS not finished)
				}
			}
		}
		else
		{
			// 2021-02-03: At least one watchlist entry is necessary
			// -> No additional action
		}
		
		return AdditionalSaveAction.NONE;
	}
	
	/**
	 * Detect if there are optional {@link AdditionalSaveAction}s allowed depending on the screening's data.<br />
	 * An additional save action if for example "Set Screening's state to {@link ScreeningStatus#NO_EXPOSURE}"
	 * <p>
	 * Evaluates also the given PageTradeSactions page.
	 * </p>
	 * 
	 * @param client
	 * @param c
	 * @return
	 */
	public static AdditionalSaveAction getAdditionalSaveAction(final Client client, final PageTradeSactions c)
	{
		final Screening scr = c.getScreening();
		
		if(isInitialized_Watchlist(scr))
		{
			if(hasRedFlagWatchlist(client, scr))
			{
				if(c.isInitialized())
				{
					if(BooleanUtils.isTrue(c.getValidStatus()))
					{
						if(isFinished_BI(scr, false))
						{
							return AdditionalSaveAction.REVIEW;
						}
						else
						{
							// No Action (BI not finished)
						}
					}
					else
					{
						// No Action (TS not finished)
					}
				}
				else
				{
					// 2021-02-03: TS IS NECESSARY!
					// -> No additional action
				}
			}
			else
			{
				if(c.isInitialized())
				{
					if(BooleanUtils.isTrue(c.getValidStatus()))
					{
						if(c.hasRedFlag())
						{
							if(isFinished_BI(scr, false))
							{
								return AdditionalSaveAction.REVIEW;
							}
							else
							{
								// No Action (BI not finished)
							}
						}
						else
						{
							return AdditionalSaveAction.NOEVIDENCE;
						}
					}
					else
					{
						// No Action (TS not finished)
					}
				}
				else
				{
					// 2021-02-03: TS IS NECESSARY!
					// -> No additional action
				}
			}
		}
		else
		{
			// 2021-02-03: At least one watchlist entry is necessary
			// -> No additional action
		}
		
		return AdditionalSaveAction.NONE;
	}
	

	
	/**
	 * Detect if there are optional {@link AdditionalSaveAction}s allowed depending on the screening's data.<br />
	 * An additional save action if for example "Set Screening's state to {@link ScreeningStatus#NO_EXPOSURE}"
	 * <p>
	 * Evaluates also the given PageBusinessInformation page.
	 * </p>
	 * 
	 * @param client
	 * @param c
	 * @return
	 */
	public static AdditionalSaveAction getAdditionalSaveAction(final Client client, final PageBusinessInformation c)
	{
		final Screening scr = c.getScreening();
		
		if(isInitialized_Watchlist(scr))
		{
			if(hasRedFlagWatchlist(client, scr))
			{
				if (isFinished_TS(scr, false))
				{
					if (BooleanUtils.isTrue(c.getValidStatus()))
					{
						return AdditionalSaveAction.REVIEW;
					}
					else
					{
						// No Action (BI not finished)
					}
				}
				else
				{
					// No Action (TS not finished)
				}
			}
			else
			{
				if (isFinished_TS(scr, false))
				{
					if (hasRedFlagTS(scr))
					{
						if (BooleanUtils.isTrue(c.getValidStatus()))
						{
							return AdditionalSaveAction.REVIEW;
						}
						else
						{
							// No Action (BI not finished)
						}
					}
					else
					{
						return AdditionalSaveAction.NOEVIDENCE;
					}
				}
				else
				{
					// No Action (TS not finished)
				}
			}
		}
		else
		{
			// 2021-02-03: At least one watchlist entry is necessary
			// -> No additional action
		}
		return AdditionalSaveAction.NONE;
	}
	
	/* ******************************************************************* */
	
	public static boolean needsBI(final Client c, final Screening scr)
	{
		if(isInitialized_Watchlist(scr))
		{
			if(hasRedFlagWatchlist(c, scr))
			{
				return true;
			}
		}
		
		if (isFinished_TS(scr, false))
		{
			if (hasRedFlagTS(scr))
			{
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Returns <code>true</code> if screening has at least one watchlist entry.
	 * 
	 * @param scr
	 * @return
	 */
	public static boolean isInitialized_Watchlist(final Screening scr)
	{
		final boolean companyEntriesNotNullAndNotEmpty = !scr.getWatchlistCompanyEntries(true).isEmpty();
		
		if(companyEntriesNotNullAndNotEmpty)
		{
			return true;
		}
		
		final boolean gsssEntriesNotNullAndNotEmpty = !scr.getWatchlistSearchEntriesGsss(true).isEmpty();
		
		if(gsssEntriesNotNullAndNotEmpty)
		{
			return true;
		}
		
		final boolean vesselSeaWebNotNullAndNotEmpty = !scr.getVesselsSeaWeb(true).isEmpty();

		if(vesselSeaWebNotNullAndNotEmpty)
		{
			return true;
		}
		
		return false;
	}
	
	/**
	 * Returns <code>true</code> if the screening's BusinessInformation questionnaire is set.
	 * 
	 * @param scr
	 * @return
	 */
	public static boolean isInitialized_BI(final Screening scr)
	{
		return scr.getBusinessInformationResult(true).getQuestionnaire() != null;
	}
	
	/**
	 * Returns <code>true</code> if the screening's TradeSanction questionnaire is set.
	 * 
	 * @param scr
	 * @return
	 */
	public static boolean isInitialized_TS(final Screening scr, final boolean force)
	{
		return scr.getTradeSanctionResult(force).getQuestionnaire() != null;
	}
	
	/**
	 * Returns <code>true</code> if the screening's BusinessInformation questionnaire is set and is finished.
	 * 
	 * @param scr
	 * @return
	 */
	public static boolean isFinished_BI(final Screening scr, final boolean force)
	{
		final boolean isFinished = isInitialized_BI(scr) && scr.getBusinessInformationResult(force).getFinishedDate() != null;
		return isFinished;
	}
	
	/**
	 * Returns <code>true</code> if the screening's TradeSanction questionnaire is set and is finished.
	 * 
	 * @param scr
	 * @return
	 */
	public static boolean isFinished_TS(final Screening scr, final boolean force)
	{
		final boolean isFinished = isInitialized_TS(scr, force) && scr.getTradeSanctionResult(force).getFinishedDate() != null;
		return isFinished;
	}
	
	/* ******************************************************************* */
	////
	
	public static boolean hasRedFlagTS(final Screening scr)
	{
		return Optional.ofNullable(scr.getTradeSanctionResult(false).getResultScore()).map(score -> score > 0).orElse(false);
	}
	
	public static boolean hasRedFlagWatchlist(final Client c, final Screening scr)
	{
		
		final List<SearchEntryCompany> itemsComp = scr.getWatchlistCompanyEntries(true);

		final Optional<SearchEntryCompany> firstMarkedItemComp = itemsComp.stream()
			.filter(it -> isMarked(c, it, it.getMatchData())).findFirst();
		if(firstMarkedItemComp.isPresent())
		{
			return true;
		}
		
		final List<SearchEntryGsss> itemsGsss = scr.getWatchlistSearchEntriesGsss(true);

		final Optional<SearchEntryGsss> firstMarkedItemGsss = itemsGsss.stream()
			.filter(it -> isMarked(c, it, it.getMatchData(), true)).findFirst();
		if(firstMarkedItemGsss.isPresent())
		{
			return true;
		}
		
		final List<SearchEntrySeaweb2Vessel> itemsSeaweb = scr.getVesselsSeaWeb(true);
		
		final Optional<SearchEntrySeaweb2Vessel> firstMarkedItemSeaweb = itemsSeaweb.stream()
			.filter(sge -> isMarked_internal(c, sge)).findFirst();
		if(firstMarkedItemSeaweb.isPresent())
		{
			return true;
		}
		
		return false;
	}
	
	
	/* ******************************************************************* */
	
	
	/* ******************************************************************* */

	/**
	 * 
	 * @param c
	 * @param it
	 * @return
	 */
	public static Boolean isMarked(final Client c, final SearchEntryGsss it)
	{
		if(it == null)
		{
			return false;
		}
		else
		{
			final Map<GsssMatch, MatchData> matchData = it.getMatchData();
			return isMarked(c, it, matchData, false);
		}
	}
	
	/**
	 * 
	 * @param c the Client
	 * @param it a SearchEntryGsss
	 * @param matchesAndPendingData MatchData for {@link GsssMatch} items
	 * @return
	 */
	public static Boolean isMarked(final Client c, final SearchEntryGsss it, final Map<GsssMatch, MatchData> matchesAndPendingData, boolean fallbackToAvoidNulls)
	{
		if(it == null || matchesAndPendingData == null)
		{
			return fallbackToAvoidNulls ? false : null;
		}
		else
		{
			final List<GsssMatch> res = it.getGsssMatchResults();
			if(res == null || res.isEmpty())
			{
				return false;
			}
			else
			{
				final Optional<GsssMatch> foundRedGsssMatch = res.stream()
					// eval
					.filter(gsss -> isMarked(c, gsss, matchesAndPendingData.get(gsss))).findFirst();
				
				return foundRedGsssMatch.isPresent();
			}
		}
	}
	

	
	/* ******************************************************************* */
	
	public static Boolean isMarked(final Client c, final SearchEntryCompany in)
	{
		if(in == null)
		{
			return false;
		}
		return isMarked(c, in.getItem(), in.getMatchData());
	}
	
	public static boolean isMarked(final Client c, final SearchEntryCompany in, final Map<GsssMatch, MatchData> matchesAndPendingData)
	{
		if(in == null || matchesAndPendingData == null)
		{
			return false;
		}
		else
		{
			return isMarked(c, in.getItem(), matchesAndPendingData);
		}
	}
	
	public static boolean isMarked(final Client c, final CIResponse in, final Map<GsssMatch, MatchData> matchesAndPendingData)
	{
		if(in == null || matchesAndPendingData == null)
		{
			return false;
		}
		else
		{
			final Optional<CompanyGsssMatch> firstRedCompanyGsssMatch = DataExtractorGsss
				.getCompanyGsssMatches(in)
				.filter(it -> isMarked(c, it, matchesAndPendingData))
				.findFirst();
			return firstRedCompanyGsssMatch.isPresent();
		}
	}
	
	/**
	 * True (=red flag) if at least one of the CompanyGsssMatch items has red flag.<br />
	 * CompanyGsssMatch red flag is calculated using {@link SanctionUtil#isMarked(Client, CompanyGsssMatch)}.
	 * 
	 * @param c the Client that provides rules for red flag. See {@link Client#getMatchCategoryTags()}
	 * @param in the CIResponse item
	 * @return
	 */
	public static boolean isMarked(final Client c, final CIResponse in)
	{
		final Optional<CompanyGsssMatch> firstRedCompanyGsssMatch = DataExtractorGsss
				.getCompanyGsssMatches(in)
				.filter(it -> isMarked(c, it))
				.findFirst();
		return firstRedCompanyGsssMatch.isPresent();
	}
	public static boolean isMarked(final Client c, final CompanyGsssMatch it, final Map<GsssMatch, MatchData> matchesAndPendingData)
	{
		if(it == null || matchesAndPendingData == null)
		{
			return false;
		}
		else
		{
			final List<GsssMatch> res = it.getGsssMatchResults();
			if(res == null || res.isEmpty())
			{
				return false;
			}
			else
			{
				final Optional<GsssMatch> foundRedGsssMatch = res.stream()
					// eval
					.filter(gsss -> isMarked(c, gsss, matchesAndPendingData.get(gsss))).findFirst();
				
				return foundRedGsssMatch.isPresent();
			}
		}
	}
	
	/**
	 * True (=red flag) if at least one of the GsssMatchResults {@link CompanyGsssMatch#getGsssMatchResults()} has red flag.<br />
	 * GsssMatchResult red flag is calculated using {@link SanctionUtil#isRedFlaggedByCategory(Client, GsssMatch)}
	 * @param c the Client that provides the rules for red flag. See {@link Client#getMatchCategoryTags()}
	 * @param it the item
	 * @return
	 */
	public static boolean isMarked(final Client c, final CompanyGsssMatch it)
	{
			final List<GsssMatch> res = it.getGsssMatchResults();
			if(res == null || res.isEmpty())
			{
				return false;
			}
			else
			{
				final Optional<GsssMatch> foundRedGsssMatch = res.stream()
					// eval
					.filter(gsss -> isRedFlaggedByCategory(c, gsss)).findFirst();
				
				return foundRedGsssMatch.isPresent();
			}
	}
	
	/* ******************************************************************* */
	//// BASE
	
	
	
	
	/**
	 * Get rating from {@link MatchData} and call {@link SanctionUtil#isMarked(Client, GsssMatch, String)}
	 * 
	 * @param c
	 * @param in
	 * @param matchData
	 * @return
	 */
	public static boolean isMarked(final Client c, final GsssMatch in, @Nullable final MatchData matchData)
	{
		return isMarked(c, in, matchData != null ? matchData.getRating() : null);
	}
	
	/**
	 * Converts matchRating String with {@link MatchRating#toRating(String)} item.
	 * <ul>
	 * <li>No GsssMatch or MatchRating.FALSE_POSITIVE: <b>false</b></li>
	 * <li>No MatchRating or GsssMatch available + MatchRating.UNKNOWN: <b>Depends on category</b></li>
	 * <li>GsssMatch available + MatchRating.TRUE_FINDING: <b>Depends on category</b></li>
	 * </ul>
	 * See {@link SanctionUtil#isRedFlaggedByCategory(Client, GsssMatch)}
	 * 
	 * @param c
	 * @param in
	 * @param matchRating
	 * @return
	 */
	public static boolean isMarked(final Client c, final GsssMatch in, final String matchRating)
	{
		final MatchRating rating = MatchRating.toRating(matchRating);
		
		if(in == null)
		{
			return false;
		}
		else
		{
			if(Objects.equals(MatchRating.FALSE_POSITIVE, rating))
			{
				return false;
			}
			else
			{
				// If MatchRating is unset
				// OR is MatchRating.TRUE_FINDING
				// OR is MatchRating.UNKNOWN: check Categories
				
				return isRedFlaggedByCategory(c, in);
			}
		}
	}
	
	/**
	 * Evals if GsssMatch is red flagged:<br />
	 * GsssMatch is red if(at least) one category entry of {@link GsssMatch#getCategories()} is red flagged.<br />
	 * IF a category entry is red is defined in entries of {@link Client#getMatchCategoryTags()} list.
	 * 
	 * @param c  the client
	 * @param in the GsssMatch entry
	 * @return
	 */
	public static boolean isRedFlaggedByCategory(final Client c, final GsssMatch in)
	{
		if(in.getCategories() == null || in.getCategories().isEmpty())
		{
			return false;
		}
		
		// @formatter:off
		
		final Collection<String> categoryValues = in.getCategories().values();
		
		final Optional<MatchCategoryTag> firstCategoryWithRedFlag = categoryValues.stream()
			.map(v -> DataExtractorGsss.getCategoryObject(c, v))
			.filter(Objects::nonNull)
			.filter(mct -> mct.isRedFlag())
			.findFirst();
		
		// @formatter:on
		
		return firstCategoryWithRedFlag.isPresent();
	}
	
	
	/**
	 * Uses "internal" match rating. Supply an VaadinSession in order to use the ESRADBClient of that particular session.
	 * 
	 * @param c
	 * @param match
	 * @return
	 */
	public static boolean isMarked_internal(final Client c, final SearchEntrySeaweb2Vessel match)
	{
		if(match == null)
		{
			return false;
		}
		else if(Objects.equals(MatchRating.FALSE_POSITIVE.name(), match.getRating()))
		{
			return false;
		}
		else
		{
			return SeawebRedFlagCalculator.hasRedFlag(c, match);
		}
	}
	
	
	

	
	/* ******************************************************************* */
	////
	
	/**
	 * 
	 * @param client
	 * @return
	 */
	public static Optional<Integer> getThresholdCIResponseMatches(final Client client)
	{
		final Optional<Integer> treshold = Optional.ofNullable(client).map(Client::getClientConfiguration)
			.map(EsraClientConfiguration::getThresholdGsssResultScore);
		return treshold;
	}
	
	
	/**
	 * Removes all GsssMatch items with a score below a treshold. <br />
	 * Does <b>not</b> store the {@link CIResponse} or the changed {@link Collection} of GsssMatch items.
	 * 
	 * @param restAnswer
	 * @return
	 */
	public static CIResponse cleanupCIResponseMatches(final CIResponse restAnswer, final Client client)
	{
		return cleanupCIResponseMatches(restAnswer, getThresholdCIResponseMatches(client));
	}
	

		
	/**
	 * Removes all GsssMatch items with a score below a threshold. <br />
	 * Does <b>not</b> store the {@link CIResponse} or the changed {@link Collection} of GsssMatch items.
	 * @param restAnswer
	 * @param treshold
	 * @return
	 */
	public static CIResponse cleanupCIResponseMatches(final CIResponse restAnswer, final Optional<Integer> treshold)
	{
		if(treshold.isPresent())
		{
			LOG.debug("COMPANYINFO result: Cleanup GsssMatch items with threshold {}", treshold.get());
			
			if(restAnswer.getCompanyGsssMatchResults() != null)
			{
				final CompanyGsssMatch it = restAnswer.getCompanyGsssMatchResults();
				if(it.getGsssMatchResults() != null)
				{
					final Set<GsssMatch> toRemove = it.getGsssMatchResults().stream()
						.filter(gsssMatch -> gsssMatch.getHitScoreNormalized() < treshold.get()).collect(Collectors.toSet());
					
					if(!toRemove.isEmpty())
					{
						it.getGsssMatchResults().removeAll(toRemove);
						LOG.debug(" - Removed {} item(s) from CompanyGsssMatchResult", toRemove.size());
					}
				}
			}
			
			if(restAnswer.getBenOwnGsssMatchResults() != null)
			{
				final Map<String, CompanyGsssMatch> itMap = restAnswer.getBenOwnGsssMatchResults();
				for (final Map.Entry<String, CompanyGsssMatch> it : itMap.entrySet())
				{
					final List<GsssMatch> gsssMatchResults = it.getValue().getGsssMatchResults();
					if(gsssMatchResults != null)
					{
						final Set<GsssMatch> toRemove = gsssMatchResults.stream()
							.filter(gsssMatch -> gsssMatch.getHitScoreNormalized() < treshold.get()).collect(Collectors.toSet());
						
						if(!toRemove.isEmpty())
						{
							gsssMatchResults.removeAll(toRemove);
							LOG.debug(" - Removed {} item(s) from Beneficial Owner entry {}", toRemove.size(), it.getKey());
						}
					}
				}
			}
			
			if(restAnswer.getInterGsssMatchResults() != null)
			{
				final Map<String, CompanyGsssMatch> itMap = restAnswer.getInterGsssMatchResults();
				for (final Map.Entry<String, CompanyGsssMatch> it : itMap.entrySet())
				{
					final List<GsssMatch> gsssMatchResults = it.getValue().getGsssMatchResults();
					if(gsssMatchResults != null)
					{
						final Set<GsssMatch> toRemove = gsssMatchResults.stream()
							.filter(gsssMatch -> gsssMatch.getHitScoreNormalized() < treshold.get()).collect(Collectors.toSet());
						
						if(!toRemove.isEmpty())
						{
							gsssMatchResults.removeAll(toRemove);
							LOG.debug(" - Removed {} item(s) from Intermediary entry {}", toRemove.size(), it.getKey());
						}
					}
				}
			}
		}
		return restAnswer;
	}
}
