package com.caweco.esra.ui.esu;

import java.util.HashSet;
import java.util.stream.Collectors;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.PersonalFilterDAO;
import com.caweco.esra.dao.core.FunctionDAO;
import com.caweco.esra.dao.core.LobDAO;
import com.caweco.esra.dao.core.OeDAO;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.entities.esu.ScreeningFilter;
import com.caweco.esra.ui.esu.part.PartFilteritemSelection;
import com.caweco.esra.ui.interfaces.ComboBoxValue;
import com.caweco.esra.ui.interfaces.DialogContent;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;


public class PagePersonalFilter extends HorizontalLayout implements DialogContent
{
	private PartFilteritemSelection<LineOfBusiness>		lobSelector;
	private PartFilteritemSelection<Function>			funcSelector;
	private PartFilteritemSelection<OE>					oeSelector;
	private PartFilteritemSelection<ScreeningStatus>	statusSelector;
	
	private ScreeningFilter								filter;
	
	public PagePersonalFilter()
	{
		super();
		this.initUI();
		this.initParts();
	}
	
	public PagePersonalFilter setItem(ScreeningFilter filter)
	{
		this.filter = filter;
		
		if(CurrentUtil.getClient() == null)
		{
			this.setEnabled(false);
			Notificator.error("Cannot obtain available values: No client selected!");
		}
		else
		{
			
			//// AVAILABLE DATA
			
			this.lobSelector.setAvailableItems(LobDAO.getLineOfBusinesses(CurrentUtil.getClient()));
			this.oeSelector.setAvailableItems(OeDAO.findAll());
			this.funcSelector.setAvailableItems(FunctionDAO.findAll());
			this.statusSelector.setAvailableItems(
				ScreeningStatus.stream().filter(it -> it.name().startsWith("REVIEW")).collect(Collectors.toSet()));
			
			//// Filter data
			
			if(filter.filterByLOB())
			{
				this.lobSelector.setSelected(filter.getLobItems());
			}
			else
			{
				this.lobSelector.setAllSelected();
			}
			
			if(filter.filterByOE())
			{
				this.oeSelector.setSelected(filter.getOeItems());
			}
			else
			{
				this.oeSelector.setAllSelected();
			}
			
			if(filter.filterByFunction())
			{
				this.funcSelector.setSelected(filter.getFunctionItems());
			}
			else
			{
				this.funcSelector.setAllSelected();
			}
			
			if(filter.filterByStatus())
			{
				this.statusSelector.setSelected(filter.getStatusItems());
			}
			else
			{
				this.statusSelector.setAllSelected();
			}
			
		}
		return this;
	}
	
	/**
	 * Writes new Filter settings to the {@link ScreeningFilter} item - does not save!
	 * 
	 * @param filter
	 * @return
	 */
	public boolean writeItem(ScreeningFilter filter)
	{
		
		if(CurrentUtil.getClient() == null)
		{
			this.setEnabled(false);
			Notificator.error("Cannot obtain available values: No client selected!");
			return false;
		}
		else
		{
			// Hint: If "all*Selected" is true -> That means *NO* filtering for this property!
			
			boolean allLobsSelected = this.lobSelector.evalAllSelected();
			filter.setByLOB(!allLobsSelected);
			filter.setLobItems(allLobsSelected ? new HashSet<>() : this.lobSelector.getSelected());
			
			boolean allOEsSelected = this.oeSelector.evalAllSelected();
			filter.setByOE(!allOEsSelected);
			filter.setOeItems(allOEsSelected ? new HashSet<>() : this.oeSelector.getSelected());
			
			boolean allFuncsSelected = this.funcSelector.evalAllSelected();
			filter.setByFunction(!allFuncsSelected);
			filter.setFunctionItems(allFuncsSelected ? new HashSet<>() : this.funcSelector.getSelected());
			
			boolean allStatesSelected = this.statusSelector.evalAllSelected();
			filter.setByStatus(!allStatesSelected);
			filter.setStatusItems(allStatesSelected ? new HashSet<>() : this.statusSelector.getSelected());
			
			return true;
		}
		
	}
	
	private void initParts()
	{
		this.lobSelector = new PartFilteritemSelection<LineOfBusiness>();
		this.lobSelector.setHeaderText("LOB").setRepresentationProvider(ComboBoxValue::getName);
		
		this.funcSelector = new PartFilteritemSelection<Function>();
		this.funcSelector.setHeaderText("Function").setRepresentationProvider(ComboBoxValue::getName);
		
		this.oeSelector = new PartFilteritemSelection<OE>();
		this.oeSelector.setHeaderText("Office").setRepresentationProvider(ComboBoxValue::getName);
		
		this.statusSelector = new PartFilteritemSelection<ScreeningStatus>();
		this.statusSelector.setHeaderText("Status").setRepresentationProvider(ScreeningStatus::getStatus);
		
		this.add(this.lobSelector, this.funcSelector, this.oeSelector, this.statusSelector);
		
	}
	
	@Override
	public void cancel()
	{
		// No Action
	}
	
	@Override
	public void save()
	{
		this.writeItem(this.filter);
		PersonalFilterDAO.savePersonalFilter(this.filter, CurrentUtil.getUser().getEmailAddress(), CurrentUtil.getClient().getUuid().toString());
		Notificator.success("Filter saved.");
	}
	
	@Override
	public String getHeader()
	{
		return "Edit personal filter";
	}
	
	@Override
	public String getConfirmButtonText()
	{
		return "OK";
	}
	
	@Override
	public String getCancelButtonText()
	{
		return "Cancel";
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.setSpacing(false);
		this.setJustifyContentMode(FlexComponent.JustifyContentMode.EVENLY);
		
		this.setSizeFull();
	} // </generated-code>
	
}
