package com.caweco.esra.entities.questionnaire;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import com.caweco.esra.business.func.data.QuestionnaireEvaluationUtil;
import com.caweco.esra.entities.core.Screening;
import com.rapidclipse.framework.server.resources.Caption;


public class QuestionnaireResult
{
	private Integer					resultID;
	private Questionnaire			questionnaire;
	private Integer					year;
	
	private List<QuestionResult>	results;
	
	private Instant					finishedDate;
	private Screening				parent;
	
	@Caption("ID")
	public Integer getResultID()
	{
		return this.resultID;
	}
	
	public void setResultID(final Integer resultID)
	{
		this.resultID = resultID;
	}
	
	@Caption("Questionnaire")
	public Questionnaire getQuestionnaire()
	{
		return this.questionnaire;
	}
	
	public void setQuestionnaire(final Questionnaire questionnaire)
	{
		this.questionnaire = questionnaire;
	}
	
	@Caption("Results")
	public List<QuestionResult> getResults()
	{
		if(this.results == null)
		{
			this.results = new ArrayList<>();
		}
		return this.results;
	}
	
	public void setResults(final List<QuestionResult> results)
	{
		this.results = results;
	}
	
	@Caption("Year")
	public Integer getYear()
	{
		return this.year;
	}
	
	public void setYear(final Integer year)
	{
		this.year = year;
	}
	
	@Caption("Score")
	public Integer getResultScore()
	{
		return QuestionnaireEvaluationUtil.getResultScore(this);
	}
	
	public Instant getFinishedDate()
	{
		return this.finishedDate;
	}
	
	public void setFinishedDate(Instant finishedDate)
	{
		this.finishedDate = finishedDate;
	}

	
	
	public Screening getParent() {
		return parent;
	}

	public void setParent(Screening parent) {
		this.parent = parent;
	}
	
	
	
}
