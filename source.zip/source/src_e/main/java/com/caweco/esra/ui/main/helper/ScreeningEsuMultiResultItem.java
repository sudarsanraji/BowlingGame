package com.caweco.esra.ui.main.helper;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.dto.ScreeningMetadataEsuBase;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.rapidclipse.framework.server.resources.Caption;


public class ScreeningEsuMultiResultItem implements ScreeningSearchResultEsu<ScreeningMetadataEsuBase>
{

	
	// This is the root of all of the items below.
	private final ScreeningMetadataEsuBase   screening;
	private final String clientId;
	
	public ScreeningEsuMultiResultItem(String clientId, ScreeningMetadataEsuBase screening)
	{
		super();
		this.clientId = clientId;
		this.screening = screening;
	}
	
	
	@Caption("Process ID")
	@Override
	public String getId()
	{
		return screening.getScreeningID();
	}
	
	@Override
	public String getRepresentation()
	{
		if (screening.getMatches() != null) {
			
			// A entry of "combined" is e.g. ["Company Profile, Organization", "Sulzer AG"]
			TreeMap<String, String> combined = screening.getMatches().entrySet().stream().collect(Collectors
				.toMap(ScreeningEsuMultiResultItem::combineTypes, e -> e.getKey(), (a, b) -> a, TreeMap::new));
			
			StringBuilder           sb       = new StringBuilder();
			combined.forEach((k, v) ->
			{
				if (!k.isEmpty())
				{
					sb.append("<div>");
					sb.append("<b>");
					sb.append(k);
					sb.append(":</b> ").append(v);
					sb.append("</div>\n");
				}
			});
			
			return sb.toString();
		}
		else {
			return "";
		}
	}
	
	private static String combineTypes(Entry<String, Set<String>> typesEntry)
	{
		if (typesEntry.getValue() == null)
			return "";
		else
			return typesEntry.getValue()
				.stream()
				.filter(Objects::nonNull)
				.sorted(Comparator.naturalOrder())
				.collect(Collectors.joining(", "));

	}
	
	@Override
	public ScreeningMetadataEsuBase getScreeningRaw()
	{
		return screening;
	}

	
	@Override
	public ScreeningSearchResult.Type getType()
	{
		return screening.getMatches() != null ? ScreeningSearchResult.Type.MULTI : ScreeningSearchResult.Type.COMMON_MATCH;
	}
	
	@Override
	public Set<Pair<String, String>> getMatches()
	{
		if (screening.getMatches() != null)
		{
			Set<Pair<String, String>> collect = screening.getMatches().entrySet().stream()
				.map(it -> Pair.of(it.getValue().stream().collect(Collectors.joining(", ")), it.getKey()))
				.collect(Collectors.toSet());
			return collect;
		}
		else {
			Set<Pair<String, String>> res = new HashSet<>();
			res.add(Pair.of("Name", this.getRepresentation()));
			return res;
		}
	}

	@Override
	public String getName() {
		return screening.getName();
	}


	@Override
	public LineOfBusiness getLob() {
		return screening.getLineOfBusiness();
	}


	@Override
	public Function getFunction() {
		return screening.getFunction();
	}


	@Override
	public OE getOe() {
		return screening.getOe();
	}


	@Override
	public ScreeningStatus getStatus() {
		return screening.getStatus();
	}


	@Override
	public LocalDate getScreeningDate() {
		return screening.getScreeningDate();
	}
	
	@Override
	public LocalDate getScreeningEsuDate() {
		return screening.getScreeningEsuDate();
	}
	
	@Override
	public String getScreeningOwnerEmail() {
		return screening.getScreeningOwner();
	}
	
	public String getScreeningEsuWorkerEmail() {
		return screening.getEsuWorker();
	}
	
	@Override
	public String getScreeningServiceUserEmail() {
		return screening.getScreeningServiceUser();
	}

	public ScreeningMetadataBase getScreeningMetadata() {
		return screening;
	}


	@Override
	public int getUnreadMessages() {
		return screening.getUnreadMessages();
	}


	@Override
	public String getClientId()
	{
		return clientId;
	}

}
