package com.caweco.esra.dao.questionnaire;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.QuestionDTO;
import com.caweco.esra.dto.creator.QuestionCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vaadin.flow.component.grid.dnd.GridDropLocation;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class QuestionDAO
{
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	public static void insert(final Questionnaire questionnaire, final Question question)
	{
		Logger.tag("REST").info("Inserting Question ID (start) " + question.getId());
		
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/questionnaire/" + questionnaire.getQuestionnaireID() + "/question/");
		
		final Response response = webTarget.request().post(Entity.entity(QuestionCreator.convertQuestionToDTO(question), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("REST").info("Inserting Question ID (end) " + question.getId());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the Question "  + question.getQuestionText() + " to the questionnaire : " +  questionnaire.getDescription() + " to the system");
	}
	
	public static void update(final Questionnaire questionnaire, final Question question)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/questionnaire/" + questionnaire.getQuestionnaireID() + "/question/" + question.getId());
		
		final Response response = webTarget.request().put(Entity.entity(QuestionCreator.convertQuestionToDTO(question), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the Question "  + question.getQuestionText() + " to the questionnaire : " +  questionnaire.getDescription() + " to the system");
	}
	
	public static List<Question> findByCategory(final Questionnaire questionnaire, final QuestionCategory category)
	{
		final List<Question> questionsOfCategory =
			questionnaire.getQuestions(true).stream().filter(q -> Objects.equals(q.getCategory(), category)).collect(
				Collectors.toList());
		return questionsOfCategory;
	}
	
	public static Integer getNextQuestionID(final List<Question> questions)
	{
		if(questions.isEmpty())
		{
			return 1;
		}
		final Comparator<Question> comp = (p1, p2) -> Integer.compare(
			Integer.valueOf(p1.getId()),
			Integer.valueOf(p2.getId()));
		final Question question = questions.stream().max(comp).get();
		
		return question.getId() + 1;
	}
	
	public static Integer getNextCategoryID(final List<QuestionCategory> categories)
	{
		if(categories.isEmpty())
		{
			return 1;
		}
		final Comparator<QuestionCategory> comp = (p1, p2) -> Integer.compare(
			Integer.valueOf(p1.getId()),
			Integer.valueOf(p2.getId()));
		final QuestionCategory category = categories.stream().max(comp).get();
		
		return category.getId() + 1;
	}
	
	public static void deleteCategory(final Questionnaire questionnaire, final QuestionCategory cat)
	{
		final List<QuestionCategory> categories = questionnaire.getCategories();
		categories.remove(cat);
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire/" + questionnaire.getQuestionnaireID().toString()
				+ "/category/" + cat.getId());
		
		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the Question category "  + cat.getCategory() + " from the questionnaire : " +  questionnaire.getDescription() + "");
	}
	
	public static void deleteQuestion(final Questionnaire questionnaire, final Question question, final boolean force)
	{
		final List<Question> questions = questionnaire.getQuestions(force);
		questions.remove(question);
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire/" + questionnaire.getQuestionnaireID().toString()
				+ "/question/" + question.getId());
		
		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the Question "  + question.getQuestionText() + " from the questionnaire : " +  questionnaire.getDescription() + " to the system");
	}
	
	public static void reorderChooseableValues(
		final Questionnaire questionnaire,
		final Question question,
		final List<ChooseableValues> qu,
		final ChooseableValues sourceValue,
		final ChooseableValues targetValue,
		final GridDropLocation location)
	{
		qu.remove(sourceValue);
		
		if(location.equals(GridDropLocation.ABOVE))
		{
			qu.add(qu.indexOf(targetValue), sourceValue);
		}
		else
		{
			qu.add(qu.indexOf(targetValue) + 1, sourceValue);
		}
		
		QuestionDAO.reindexChooseableValues(questionnaire, qu);
	}
	
	public static void reindexChooseableValues(final Questionnaire questionnaire, final List<ChooseableValues> qu)
	{
		final AtomicInteger index = new AtomicInteger(1);
		qu.stream().forEach(val ->
		{
			val.setId(index.getAndIncrement());
		});
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/questionnaire/" + questionnaire.getQuestionnaireID() + "/question/replace");
		
		final Response response = webTarget.request().post(Entity.entity(questionnaire.getQuestions(true), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}

	public static void saveExistingChoosableValue(final ChooseableValues chooseableValue, final String clientId,
			final Integer questionnaireID, final Integer id) {
		
		
		
	}

	public static void saveNewChoosableValue(final ChooseableValues chooseableValue, final String string, final Integer questionnaireID,
			final Integer id) {
		// TODO Auto-generated method stub
		
	}

	public static List<Question> getQuestions(final Questionnaire questionnaire, final Client client) {
		return getQuestions(String.valueOf(questionnaire.getQuestionnaireID()), client.getUuid().toString());
	}
	
	public static List<Question> getQuestions(final String questionnaireId, final String clientId) {
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + clientId + "/questionnaire/" + questionnaireId + "/questions");
		
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		final String responseBody = response.readEntity(String.class);
		
		final JavaType type = om.getTypeFactory().constructCollectionType(ArrayList.class, QuestionDTO.class);
		
		if(response.getStatus() == 200) {
			try {
				final ArrayList<QuestionDTO> dtoSet = om.readValue(responseBody, type);

				final List<Question> questionSet = new ArrayList<>();
				try {
					final int questionnaireIdInt = Integer.valueOf(questionnaireId);
					dtoSet.forEach(dto -> {
						questionSet.add(QuestionCreator.convertDTOToQuestion(questionnaireIdInt, dto));
					});
				} catch (NumberFormatException e) {
					Logger.error("INVALID NUMBER FORMAT: ", e);
					return new ArrayList<>();
				}

				return questionSet;
			} catch (final JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return new ArrayList<>();
			}
		}
		
		return new ArrayList<>();
	}

	public static Optional<Question> findById(final String clientId, final Integer questionnaireId, final Integer questionId) {
		final List<Question> questions = getQuestions(String.valueOf(questionnaireId), clientId);
		
		return questions.stream().filter(q -> q.getId().equals(questionId)).findFirst();
	}

	public static int getNextChooseableValueID(final List<ChooseableValues> valueList) {
		if(valueList.isEmpty())
		{
			return 1;
		}
		
		final Comparator<ChooseableValues> comp = (v1, v2) -> Integer.compare(
			Integer.valueOf(v1.getId()),
			Integer.valueOf(v2.getId()));
		final ChooseableValues value = valueList.stream().max(comp).get();
		
		return value.getId() + 1;
	}
}
