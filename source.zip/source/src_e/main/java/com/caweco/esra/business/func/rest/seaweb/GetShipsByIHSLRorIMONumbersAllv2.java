
package com.caweco.esra.business.func.rest.seaweb;

import java.util.List;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CompletionStage;
import java.util.stream.Collectors;

import com.caweco.esra.business.func.rest.RestClientSeaWeb2;
import com.caweco.esra.business.func.rest.SeaWeb2Helper;
import com.caweco.esra.business.utils.CompletionHelper;
import com.caweco.esra.entities.rest.seaweb2.APSShipMultiResult_v2;
import com.caweco.esra.entities.rest.seaweb2.APSShipResult_v2;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;


/**
 * http://maritimewebservices.ihs.com/MaritimeWCF/APSShipService.svc/RESTful/GetShipsByIHSLRorIMONumbersAll?IMONumbers=5130159
 */
public class GetShipsByIHSLRorIMONumbersAllv2
{
	private GetShipsByIHSLRorIMONumbersAllv2()
	{
	}

	/**
	 * The name of the REST method.
	 */
	public static String METHOD = "GetShipsByIHSLRorIMONumbersAll";

	/**
	 * 
	 */
	public static String PARAM1 = "IMONumbers";
	
	/**
	 * The maximum amount of IMO numbers for a single request.
	 */
	public static int    MAX_IMONUMBER_COUNT = 20;

	
	static CompletionStage<APSShipMultiResult_v2> fetchImoNumberBatch(
		final RestClientSeaWeb2 instance,
		final List<String> imoNumberBatch)
	{
		final String joinedimoNumbers = SeaWeb2Helper.processSearchtext_Step2_Join(imoNumberBatch);
		
		final WebTarget currentTarget = instance.getMethodTarget(METHOD);
		
		final CompletionStage<APSShipMultiResult_v2> cs = currentTarget
			.queryParam(PARAM1, joinedimoNumbers)
			.request(MediaType.APPLICATION_JSON)
			.rx()
			.get(APSShipMultiResult_v2.class);
		
		return cs;
	}
	
	/**
	 * For single batch of iso numbers:
	 * Prepares a {@link CompletionStage} to fetch data from REST service.<br />
	 * Throws a exception if "ErrorLevel" of the result is other then "None".
	 * 
	 * @param instance
	 * @param imoNumberBatch
	 * @return
	 */
	public static CompletionStage<APSShipMultiResult_v2> fetchImoNumberBatch_withCheck(
		final RestClientSeaWeb2 instance,
		final List<String> imoNumberBatch)
	{
		return fetchImoNumberBatch(instance, imoNumberBatch)
			.thenApply(res ->
			{
				final String errorLevel = res.getAPSStatus().getErrorLevel();
				if (!"None".equals(errorLevel))
				{
					throw new CompletionException(new SeawebProcessingException(res.getAPSStatus()));
				}
				return res;
			});
	}
	
	/**
	 * Fetch imo numbers from REST endpoint: 
	 * <ul><li>Partition into batches</li>
	 * <li>Perform REST request per batch</li>
	 * <li>Collect results from batch request results (APSShipMultiResult_v2 items)</li></ul>
	 * 
	 * Throws a exception if "ErrorLevel" of the result is other then "None".
	 * @param instance
	 * @param validImoNumbers
	 * @return
	 */
	public static CompletionStage<List<APSShipResult_v2>> fetchImoNumbers_withCheck_useBatches(
		final RestClientSeaWeb2 instance,
		final List<String> validImoNumbers)
	{
		// Partition into batches
		List<List<String>> batches = SeaWeb2Helper
		.processSearchtext_Step2_Grouping(validImoNumbers);
		
		// Perform REST request per batch
		CompletionStage<List<APSShipMultiResult_v2>> result = CompletionHelper.sequence(
			batches.stream()
//				.peek(System.out::println)
				.map(batch -> GetShipsByIHSLRorIMONumbersAllv2.fetchImoNumberBatch_withCheck(instance, batch))
				.collect(Collectors.toList()));
		
		// Collect results from APSShipMultiResult_v2
		CompletionStage<List<APSShipResult_v2>> flatResults = result.thenApply(rawResultList ->
			{
				return rawResultList.stream().flatMap(mr -> mr.getShipResult().stream()).collect(Collectors.toList());
			});
		return flatResults;
	}
	

}
