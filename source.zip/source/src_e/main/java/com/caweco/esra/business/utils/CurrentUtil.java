package com.caweco.esra.business.utils;

import java.util.Optional;

import org.tinylog.Logger;

import com.caweco.esra.dev.DevelopmentHelper;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ConfigMailServer;
import com.caweco.esra.entities.config.EsraClientConfiguration;
import com.rapidclipse.framework.security.authorization.Subject;
import com.vaadin.flow.server.VaadinSession;


public class CurrentUtil
{
	
	/*
	 * VAADIN
	 */
	
	/**
	 * Scope: VaadinSession
	 * 
	 * @return the current {@link VaadinSession}
	 */
	public static VaadinSession getVSession()
	{
		return VaadinSession.getCurrent();
	}
	
	/*
	 * CLIENT & USER
	 */
	
	/**
	 * <b>DO NOT USE IN BACKGROUND THREADS</b>
	 * @return the current {@link Client}
	 */
	public static Client getClient()
	{
		try
		{
			return VaadinSession.getCurrent().getAttribute(Client.class);
		}
		catch(Exception e)
		{
			Logger.error(e, "CurrentUtil error!");
			return null;
		}
	}
	

	
	/**
	 * <b>DO NOT USE IN BACKGROUND THREADS</b>
	 * @return the current {@link User}
	 */
	public static User getUser()
	{
		try
		{
			return VaadinSession.getCurrent().getAttribute(User.class);
		}
		catch(Exception e)
		{
			Logger.error(e, "CurrentUtil error!");
			return null;
		}
	}
	
	/**
	 * @return the current {@link Subject}
	 */
	public static Subject getSubject()
	{
		return VaadinSession.getCurrent().getAttribute(Subject.class);
	}
	
	/*
	 * SET & GET TO/FROM SESSION
	 */
	
	public static <T> void toSession(final Class<T> type, final T value)
	{
		VaadinSession.getCurrent().setAttribute(type, value);
	}
	
	public static <T> void toSession(final String identifier, final T value)
	{
		VaadinSession.getCurrent().setAttribute(identifier, value);
	}
	
	public static <T> void toSession(VaadinSession session, final String identifier, final T value)
	{
		session.setAttribute(identifier, value);
	}
	
	public static <T> T fromSession(final Class<T> type)
	{
		return VaadinSession.getCurrent().getAttribute(type);
	}
	
	public static <T> Optional<T> fromSession(String key)
	{
		return fromSession(VaadinSession.getCurrent(), key);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> Optional<T> fromSession(VaadinSession session, String key)
	{
		if (session == null || key == null)
		{
			return Optional.empty();
		}
		else
		{
			return Optional.ofNullable(session.getAttribute(key)).map(it -> (T) it);
		}
	}
	
	/**
	 * Provides the Mailserver settings of the <b>current client</b> if it has a {@link EsraClientConfiguration} object
	 * and
	 * this object contains a
	 * {@link ConfigMailServer} item.
	 * 
	 * @return a ConfigMailServer object if found, or <code>null</code> otherwise.
	 */
	public static ConfigMailServer getEmailSettings()
	{
		if(DevelopmentHelper.useDevData_MailServer())
		{
			return DevelopmentHelper.getDevData_Mailsettings();
		}
		
		if(CurrentUtil.getClient() != null)
		{
			EsraClientConfiguration clientConfiguration = CurrentUtil.getClient().getClientConfiguration();
			if(clientConfiguration != null)
			{
				return clientConfiguration.getConfigMailServer();
			}
			return null;
		}
		return null;
	}
}
