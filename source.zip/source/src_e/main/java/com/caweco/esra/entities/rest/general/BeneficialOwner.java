package com.caweco.esra.entities.rest.general;

import com.caweco.esra.entities.rest.monitoring.BvdInfoTypeA;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.rapidclipse.framework.server.resources.Caption;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(as = BvdInfoTypeA.class)
public class BeneficialOwner implements BvdInfoTypeA
{
	private String	name;
	private String	bvdId;
	private String	salutation;
	private String	firstName;
	private String	lastName;
	private String	gender;
	private String	dateOfBirth;
	private String	address;
	private String	city;
	private String	postcode;
	private String	country;
	private String	alsoManagerRole;
	
	public BeneficialOwner()
	{
		// Empty Constructor for Framework
	}
	
	@Override
	@Caption("Name")
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	@Override
	@Caption("BvD ID")
	public String getBvdId()
	{
		return this.bvdId;
	}
	
	public void setBvdId(final String bvdId)
	{
		this.bvdId = bvdId;
	}
	
	@Caption("Salutation")
	public String getSalutation()
	{
		return this.salutation;
	}
	
	public void setSalutation(final String salutation)
	{
		this.salutation = salutation;
	}
	
	@Caption("Firstname")
	public String getFirstName()
	{
		return this.firstName;
	}
	
	public void setFirstName(final String firstName)
	{
		this.firstName = firstName;
	}
	
	@Caption("Lastname")
	public String getLastName()
	{
		return this.lastName;
	}
	
	public void setLastName(final String lastName)
	{
		this.lastName = lastName;
	}
	
	@Caption("Gender")
	public String getGender()
	{
		return this.gender;
	}
	
	public void setGender(final String gender)
	{
		this.gender = gender;
	}
	
	@Caption("Birthdate")
	public String getDateOfBirth()
	{
		return this.dateOfBirth;
	}
	
	public void setDateOfBirth(final String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}
	
	@Caption("Address")
	public String getAddress()
	{
		return this.address;
	}
	
	public void setAddress(final String address)
	{
		this.address = address;
	}
	
	@Override
	@Caption("City")
	public String getCity()
	{
		return this.city;
	}
	
	public void setCity(final String city)
	{
		this.city = city;
	}
	
	@Caption("Postcode")
	public String getPostcode()
	{
		return this.postcode;
	}
	
	public void setPostcode(final String postcode)
	{
		this.postcode = postcode;
	}
	
	@Override
	@Caption("Country")
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(final String country)
	{
		this.country = country;
	}
	
	@Caption("Also Director")
	public String getAlsoManagerRole()
	{
		return this.alsoManagerRole;
	}
	
	public void setAlsoManagerRole(final String alsoManagerRole)
	{
		this.alsoManagerRole = alsoManagerRole;
	}
}
