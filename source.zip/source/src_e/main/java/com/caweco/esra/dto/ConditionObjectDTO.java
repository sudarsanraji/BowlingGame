package com.caweco.esra.dto;

import com.caweco.esra.entities.questionnaire.ChooseableValues;

public class ConditionObjectDTO {

	private Integer			questionId;
	private String			questionText;
	private ChooseableValues	value;
	
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public ChooseableValues getValue() {
		return value;
	}
	public void setValue(ChooseableValues value) {
		this.value = value;
	}
	
	public String getQuestionText() {
		return questionText;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	
	
}
