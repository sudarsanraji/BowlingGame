package com.caweco.esra.entities.questionnaire;

public class FreeTextAnswer extends Answer
{
	
	private String text;
	
	public FreeTextAnswer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getText()
	{
		return this.text;
	}
	
	public void setText(final String text)
	{
		this.text = text;
	}
}
