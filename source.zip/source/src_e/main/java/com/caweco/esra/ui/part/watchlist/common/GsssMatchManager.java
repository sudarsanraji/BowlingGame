package com.caweco.esra.ui.part.watchlist.common;

import java.util.List;
import java.util.Map;
import com.caweco.esra.entities.core.HasMatchData;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.shared.Registration;


public interface GsssMatchManager<T, V extends HasMatchData>
{
	
	///
	public ScreeningPageContext getContext();
	
	/// UI Related
	
	public String getContentLabel();

	/// DATA
	
	public List<T> getMatches();
	
	/**
	 * 
	 * @return
	 */
	public Map<T, V> getMatchDataMap();
	
	/**
	 * If match is in parent item's list ( {@link GsssMatchManager#getMatches()}: <br />
	 * Returns MatchData for match or creates MatchData and adds it to local MatchData map if not exists yet.<br />
	 * Returns <code>null</code> if match not in list.
	 * 
	 */
	public V getMatchDataFor(T match);

	
	/// Actions
	
	/**
	 * Update Local UI. 
	 * @param isFromClient
	 * @param match
	 */
	void onRatingChange(boolean isFromClient, T match);
	
	/**
	 * To be called from Subcomponents whenever a MatchData item changes.<br />
	 * Proposed actions: Send {@link MatchDataSetChangeEventMD} and call {@link GsssMatchManager#onRatingChange(boolean, Object)}
	 * 
	 * @param isFromClient
	 * @param match
	 * @param matchData
	 * @param isNew
	 */
	public void notifyMatchDataChange(boolean isFromClient, T match, V matchData, boolean isNew);
	
	
//	/**
//	 * For backward compatibility
//	 * @param isFromClient
//	 * @param match
//	 * @param newRating
//	 */
//	default void doRatingChange(boolean isFromClient, T match, MatchRating newRating) {
//		// Do nothing by default
//	}
	
	
	public Registration addMatchDataSetChangeListener(final ComponentEventListener<MatchDataSetChangeEventMD> listener);

	

	
	default <X extends Component> MatchDataSetChangeEventMD createMatchDataSetChangeEvent(
		X emitter, final boolean fromClient, final GsssMatch item, final MatchData matchdata, final boolean isNew)
	{
		final MatchDataSetChangeEventMD ev =
			new MatchDataSetChangeEventMD(
				emitter,
				item,
				fromClient,
				matchdata,
				isNew);
		return ev;
	}
}
