package com.caweco.esra.ui.esu;

import java.beans.Beans;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dao.esu.ScreeningFilterDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.entities.esu.ScreeningFilter;
import com.caweco.esra.entities.meta.TableString;
import com.caweco.esra.ui.beans.MultiValueComboBox;
import com.caweco.esra.ui.data.provider.CustomFilterableDataProvider;
import com.caweco.esra.ui.dialogs.DialogContainer;
import com.caweco.esra.ui.esu.gencols.GenColScreeningGrid;
import com.caweco.esra.ui.esu.gencols.RendererEsuTags;
import com.caweco.esra.ui.esu.gencols.RendererFavButton;
import com.caweco.esra.ui.gencols.GenColUnreadMessages;
import com.caweco.esra.ui.interfaces.HasHomeNavigationTarget;
import com.caweco.esra.ui.interfaces.HasRefreshableGrid;
import com.caweco.esra.ui.main.helper.ScreeningEsuMultiResultItem;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.FilterData;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.ShortcutRegistration;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.renderer.LocalDateRenderer;
import com.vaadin.flow.dom.ElementConstants;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasDynamicTitle;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.Route;


@AccessibleRule(AuthorizationResources.ESUACCESS)
@Route(value = "esu_worklist", layout = PageESUContainer.class)
public class PageESUWorklist extends VerticalLayout
	implements HasUrlParameter<String>, HasHomeNavigationTarget, HasRefreshableGrid, HasDynamicTitle
{
	
	private EsuView					viewType	= EsuView.ALL_ESU;
	private ScreeningFilter			personalScreeningFilter;

	
	CustomFilterableDataProvider<ScreeningEsuMultiResultItem> dp;
	
	private final MultiValueComboBox<TableString>		tagBox;

	private final MultiValueComboBox<TableString>		countryBox;
	
	public PageESUWorklist()
	{
		super();
		this.initUI();
		
		this.initGrid();
		this.tagBox = new MultiValueComboBox<TableString>(TableString::new).setPlaceholder("tag");
		this.countryBox = new MultiValueComboBox<TableString>(TableString::new).setPlaceholder("country");
		
		
		if(!Beans.isDesignTime())
		{
			if(CurrentUtil.getClient() != null)
			{
				this.personalScreeningFilter = ScreeningFilterDAO.getOrCreateFilter();
				
				final ListDataProvider<String> tagDataProvider =
					DataProvider.ofCollection(CurrentUtil.getClient().getEsuTags(true));
				tagDataProvider.setSortOrder(it -> it, SortDirection.ASCENDING);
				
				final ListDataProvider<String> countryDataProvider =
					DataProvider.ofCollection(CurrentUtil.getClient().getPrcCountries(true));
				tagDataProvider.setSortOrder(it -> it, SortDirection.ASCENDING);
				
				this.tagBox.setAvailableItems(TableString.toTableStringList(tagDataProvider.getItems()));
				this.countryBox.setAvailableItems(TableString.toTableStringList(countryDataProvider.getItems()));
				
				this.tagBox.setConsumer(c -> {
					this.refreshGridData();
				});
				
				this.countryBox.setConsumer(c -> {
					this.refreshGridData();
				});
			}
		}
		
		this.cbTags.add(this.tagBox);
		this.cbCountries.add(this.countryBox);
	}
	
	@Override
	protected void onAttach(final AttachEvent attachEvent) {
		super.onAttach(attachEvent);

		if (CurrentUtil.getClient() != null)
		{
			
			// TODO: Rework to use REST
			
//			ListDataProvider<String> dataProvider = DataProvider.ofCollection(CurrentUtil.getClient().getEsuTags(true));
//				dataProvider.setSortOrder(it -> it, SortDirection.ASCENDING);
//				this.cbTags.setDataProvider(dataProvider);
//
//
//			this.dp = new CustomFilterableDataProvider<ScreeningSearchResult>(
//					(d,q) -> {
//						Client c = CurrentUtil.getClient();
//						return ScreeningDAO.getScreenings(c, d,q)
//						.stream()
//						.map(base -> new ScreeningTextSearchMultiResultItem2(base));
//					},
//					qq -> ScreeningDAO.countScreenings(CurrentUtil.getClient(), qq));
//
//
//			this.gridSearchResults.setDataProvider(dp);
//
//			this.switchAllOrOwnScreenings.setValue("all");
		}
	}
	
	@Override
	public String getPageTitle()
	{
		return "ESU Backend: " + this.viewType.getRepresentation() + " | ESRA";
	}
	
	@Override
	public void setParameter(final BeforeEvent event, @OptionalParameter final String parameter)
	{
		if(CurrentUtil.getClient() == null)
		{
			this.setEnabled(false);
			Notificator.error("No client selected!");
		}
		else if(parameter != null && !parameter.isEmpty())
		{
			if(EsuView.INBOX.name().equalsIgnoreCase(parameter))
			{
				this.setViewType(EsuView.INBOX);
			}
			else if(EsuView.FAVOURITES.name().equalsIgnoreCase(parameter))
			{
				this.setViewType(EsuView.FAVOURITES);
			}
			else if(EsuView.ALL_ESU.name().equalsIgnoreCase(parameter))
			{
				this.setViewType(EsuView.ALL_ESU);
			}
		}
		else
		{
			this.setViewType(EsuView.INBOX);
		}
		
		// TODO: Maybe necessary: this.grid.recalculateColumnWidths();
	}
	
	@Override
	public Class<? extends Component> getHomeTarget()
	{
		return PageESUWorklist.class;
	}
	
	public EsuView getViewType()
	{
		return this.viewType;
	}
	
	public void setViewType(final EsuView viewType)
	{
		this.viewType = viewType;
		this.editUI();
		this.refreshGridData();
		this.refreshFilterComponent();
		
		this.btnFilter.setVisible(EsuView.INBOX == this.viewType);
	}
	
	/**
	 * Changes grid content. (ONLY grid content, NOT the FilterComponent!)
	 */
	@Override
	public void refreshGridData()
	{
		if(this.viewType == EsuView.ALL_ESU)
		{
			this.dp = new CustomFilterableDataProvider<>(
				(d,q) -> {
					final Client c = CurrentUtil.getClient();
					return ScreeningDAO.getEsuScreenings(c, CurrentUtil.getUser(), d, q, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems()))
					.stream()
					.map(base -> new ScreeningEsuMultiResultItem(c.getUuid().toString(), base));
				},
				qq -> ScreeningDAO.countEsuScreenings(CurrentUtil.getClient(), qq, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems())));
		}
		
		else if(this.viewType == EsuView.FAVOURITES)
		{
			this.dp = new CustomFilterableDataProvider<>(
				(d,q) -> {
					final Client c = CurrentUtil.getClient();
					return ScreeningDAO.getEsuFavoriteScreenings(c, CurrentUtil.getUser(), d, q, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems()))
					.stream()
					.map(base -> new ScreeningEsuMultiResultItem(c.getUuid().toString(), base));
				},
				qq -> ScreeningDAO.countEsuFavoriteScreenings(CurrentUtil.getClient(), CurrentUtil.getUser(), qq, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems())));
		}
		
		else if(this.viewType == EsuView.INBOX)
		{
			this.dp = new CustomFilterableDataProvider<>(
				(d,q) -> {
					final Client c = CurrentUtil.getClient();
					return ScreeningDAO.getEsuInboxScreenings(c, CurrentUtil.getUser(), d,q, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems()))
					.stream()
					.map(base -> new ScreeningEsuMultiResultItem(c.getUuid().toString(), base));
				},
				qq -> ScreeningDAO.countEsuInboxScreenings(CurrentUtil.getClient(), CurrentUtil.getUser(), qq, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems())));
		}
		else
		{
			LoggerFactory.getLogger(PageESUWorklist.class).error("Unsupported viewType \"{}\"", this.viewType);
		}
		
		this.dp.setLuceneSearchText(this.filterComponent.getSearchText());
		this.grid.setDataProvider(this.dp);
		
	}
	
	private void refreshFilterComponent()
	{
		UIUtils.lookupComponentTree(this.filterComponent, Button.class, b ->
		{
			b.setVisible(EsuView.ALL_ESU == this.viewType);
			return b;
		});
		this.filterComponent.connectWith(this.grid.getDataProvider());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnFilter}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnFilter_onClick(final ClickEvent<Button> event)
	{
		final PagePersonalFilter FilterContainer = new PagePersonalFilter().setItem(this.personalScreeningFilter);
		FilterContainer.getElement().getStyle().set("max-width", "1000px");
		FilterContainer.getStyle().set(ElementConstants.STYLE_WIDTH, "80vw");
		
		final DialogContainer<PagePersonalFilter> dialogContainer = new DialogContainer<>(FilterContainer);
		dialogContainer.onOk(p -> {
			this.refreshGridData();
			this.refreshFilterComponent();
		});
		
		dialogContainer.setHeight("80vh");
		dialogContainer.setWidth(null);
		
		dialogContainer.open();
	}
	
	private void initGrid()
	{
		final List<Column<ScreeningEsuMultiResultItem>> columnsCopy = new ArrayList<>(this.grid.getColumns());
		
		//// Row sorting
		
		final Column<ScreeningEsuMultiResultItem> dateColumn = this.grid.getColumnByKey("screeningDate");
		this.grid.sort(GridSortOrder.desc(dateColumn).build());
		
		this.grid.getColumnByKey("screeningEsuDate").setSortProperty("screeningEsuDate");

		//// Add Fav & Action columns
		final var favs = ScreeningFilterDAO.getOrCreateFavourites()
			.stream()
			.map(s -> s.getScreeningID().toString())
			.collect(Collectors.toList());
		
		final Predicate<String> isFavourite = s -> favs
			.stream()
			.anyMatch(s::equals);
		
		// BiConsumer<ScreeningID, NewFavState>
		final BiConsumer<String, Boolean> updateScreening = (s, isFavNow) ->
		{
			if (isFavNow)
			{
				favs.add(s);
			}
			else
			{
				favs.stream().filter(s::equals).findAny().ifPresent(a ->
				{
					Logger.tag("PageESUWorklist").info("Removing favourite: {}", a);
					favs.remove(a);
				});
			}
		};

		// @formatter:off
		final Column<ScreeningEsuMultiResultItem> favColumn = this.grid
			.addColumn(RenderedComponent.Renderer(() -> RendererFavButton.New(updateScreening, isFavourite)))
			.setKey("rendererFav")
			.setSortable(false).setAutoWidth(true).setFlexGrow(0);
		final Column<ScreeningEsuMultiResultItem> actionColumn = this.grid
			.addColumn(RenderedComponent.Renderer(() -> GenColScreeningGrid.New()))
			.setKey("rendererAction").setHeader("...")
			.setSortable(false).setAutoWidth(true).setFlexGrow(0);
		// @formatter:on
		
		// Added DataProvider
		
		this.dp = new CustomFilterableDataProvider<>(
				(d,q) -> {
					final Client c = CurrentUtil.getClient();
					return ScreeningDAO.getEsuScreenings(c, CurrentUtil.getUser(), d, q, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems()))
					.stream()
					.map(base -> new ScreeningEsuMultiResultItem(c.getUuid().toString(), base));
				},
				qq -> ScreeningDAO.countEsuScreenings(CurrentUtil.getClient(), qq, TableString.toStringSet(this.tagBox.getItems()), TableString.toStringSet(this.countryBox.getItems())));
		
		this.grid.setDataProvider(this.dp);
		
		//// Column order
		columnsCopy.add(0, favColumn);
		columnsCopy.add(actionColumn);
		this.grid.setColumnOrder(columnsCopy);
	}
	
	public void refreshGrid() {
		this.grid.getDataProvider().refreshAll();
	}
	
	private void editUI()
	{
		this.headline.setText(this.viewType.getRepresentation());
		
		if (this.viewType == EsuView.ALL_ESU)
		{
			final Column<ScreeningEsuMultiResultItem> tagColumn = this.grid.getColumnByKey("rendererTags");
			if(tagColumn == null)
			{
				final List<Column<ScreeningEsuMultiResultItem>> columnsCopy = new ArrayList<>(this.grid.getColumns());
				
				// @formatter:off
				final Column<ScreeningEsuMultiResultItem> tagColumnN =
					this.grid.addColumn(RenderedComponent.Renderer(() -> RendererEsuTags.New()))
					.setKey("rendererTags").setSortable(false)
					.setAutoWidth(true).setFlexGrow(1);
				// @formatter:on
				// Column order
				columnsCopy.add(2, tagColumnN);
				this.grid.setColumnOrder(columnsCopy);
			}
			
			this.cbTags.setVisible(true);
		}
		else
		{
			final Column<ScreeningEsuMultiResultItem> tagColumn = this.grid.getColumnByKey("rendererTags");
			if(tagColumn != null)
			{
				this.grid.removeColumn(tagColumn);
			}
			
			this.tagBox.resetItems();

		}
	}
	
	/**
	 * Event handler delegate method for the {@link FilterComponent} {@link #filterComponent}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void filterComponent_valueChanged(final ComponentValueChangeEvent<FilterComponent, FilterData> event)
	{
		this.dp.setLuceneSearchText(event.isFromClient(), event.getValue().getSearchTerm());
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #button}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void button_onClick(final ClickEvent<Button> event)
	{
		this.dp.refreshAll();
	}

	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout = new HorizontalLayout();
		this.headline = new H2();
		this.div = new Div();
		this.btnFilter = new Button();
		this.horizontalLayout2 = new HorizontalLayout();
		this.cbTags = new Div();
		this.cbCountries = new Div();
		this.filterComponent = new FilterComponent();
		this.button = new Button();
		this.grid = new Grid<>(ScreeningEsuMultiResultItem.class, false);
	
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.headline.setText("Inbox");
		this.headline.getStyle().set("margin-top", "unset");
		this.headline.getStyle().set("font-size", "var(--lumo-font-size-xl)");
		this.btnFilter.setText("Filter");
		this.btnFilter.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnFilter.setIcon(VaadinIcon.FILTER.create());
		this.cbTags.getStyle().set("min-width", "250px");
		this.cbCountries.getStyle().set("min-width", "250px");
		this.button.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		final ShortcutRegistration buttonShortcut = this.button.addClickShortcut(Key.ENTER);
		buttonShortcut.setBrowserDefaultAllowed(true);
		buttonShortcut.setEventPropagationAllowed(false);
		this.button.setIcon(VaadinIcon.SEARCH.create());
		this.grid.setClassName("test001");
		this.grid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.grid.addColumn(ScreeningEsuMultiResultItem::getName)
			.setKey("name")
			.setHeader("Name")
			.setResizable(true)
			.setSortable(true);
		this.grid.addColumn(ScreeningEsuMultiResultItem::getScreeningDate)
			.setKey("screeningDate")
			.setHeader("Date")
			.setResizable(true)
			.setSortable(true);
		this.grid.addColumn(
			new LocalDateRenderer<>(
				ScreeningEsuMultiResultItem::getScreeningEsuDate,
				DateTimeFormatter.ofPattern("yyyy-MM-dd"),
				""
			)
		).setKey("screeningEsuDate").setHeader("Review Request Date").setResizable(true).setSortable(true);
		this.grid.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningEsuMultiResultItem::getOe).map(OE::getName).orElse(null)
		).setKey("oe.name").setHeader("Office").setResizable(true).setSortable(true);
		this.grid.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningEsuMultiResultItem::getLob).map(LineOfBusiness::getName).orElse(null)
		).setKey("lob.name").setHeader("Line Of Business").setResizable(true).setSortable(true);
		this.grid.addColumn(
			v -> Optional.ofNullable(v).map(ScreeningEsuMultiResultItem::getFunction).map(Function::getName).orElse(null)
		).setKey("function.name").setHeader("Function").setResizable(true).setSortable(true);
		this.grid.addColumn(
			v -> Optional.ofNullable(v)
				.map(ScreeningEsuMultiResultItem::getStatus)
				.map(ScreeningStatus::getStatus)
				.orElse(null)
		).setKey("status.status").setHeader("Process Status").setResizable(true).setSortable(true);
		this.grid.addColumn(ScreeningEsuMultiResultItem::getScreeningOwnerEmail)
			.setKey("screeningOwnerEmail")
			.setHeader("Requestor")
			.setResizable(true)
			.setSortable(true);
		this.grid.addColumn(ScreeningEsuMultiResultItem::getScreeningEsuWorkerEmail)
			.setKey("screeningEsuWorkerEmail")
			.setHeader("Reviewer")
			.setResizable(true)
			.setSortable(true);
		this.grid.addColumn(RenderedComponent.Renderer(GenColUnreadMessages::new))
			.setKey("renderer")
			.setSortable(false)
			.setAutoWidth(true)
			.setFlexGrow(0);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
	
		this.filterComponent.connectWith(this.grid);
	
		this.headline.setSizeUndefined();
		this.div.setSizeUndefined();
		this.btnFilter.setWidth("200px");
		this.btnFilter.setHeight(null);
		this.horizontalLayout.add(this.headline, this.div, this.btnFilter);
		this.horizontalLayout.setFlexGrow(1.0, this.div);
		this.cbTags.setWidth("20%");
		this.cbTags.setHeight(null);
		this.cbCountries.setWidth("20%");
		this.cbCountries.setHeight(null);
		this.filterComponent.setSizeUndefined();
		this.button.setSizeUndefined();
		this.horizontalLayout2.add(this.cbTags, this.cbCountries, this.filterComponent, this.button);
		this.horizontalLayout2.setFlexGrow(1.0, this.filterComponent);
		this.horizontalLayout.setWidthFull();
		this.horizontalLayout.setHeight(null);
		this.horizontalLayout2.setSizeUndefined();
		this.grid.setSizeFull();
		this.add(this.horizontalLayout, this.horizontalLayout2, this.grid);
		this.setFlexGrow(1.0, this.grid);
		this.setSizeFull();
	
		this.btnFilter.addClickListener(this::btnFilter_onClick);
		this.filterComponent.addValueChangeListener(this::filterComponent_valueChanged);
		this.button.addClickListener(this::button_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button btnFilter, button;
	private HorizontalLayout horizontalLayout, horizontalLayout2;
	private Div div, cbTags, cbCountries;
	private H2 headline;
	private FilterComponent filterComponent;
	private Grid<ScreeningEsuMultiResultItem> grid;
	// </generated-code>
	
}
