
package com.caweco.esra.ui.part.watchlist.company;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.caweco.esra.business.func.data.SanctionUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.ui.interfaces.HasResettableDataCommunicator;
import com.caweco.esra.ui.page.common.ScreeningPageContext;
import com.caweco.esra.ui.part.watchlist.WatchlistItemCompanyComponent;
import com.caweco.esra.ui.part.watchlist.common.BeanWatchlistItemHeader;
import com.caweco.esra.ui.part.watchlist.common.GsssMatchContainer;
import com.caweco.esra.ui.part.watchlist.common.GsssMatchManager;
import com.caweco.esra.ui.part.watchlist.common.MatchDataSetChangeEventMD;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElement;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElementType;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.dom.ClassList;
import com.vaadin.flow.function.SerializableBiConsumer;
import com.vaadin.flow.shared.Registration;


public class PartWatchlistItemCompanyGsssMatch extends Details
	implements WatchlistElement<PartWatchlistItemCompanyGsssMatch>, HasResettableDataCommunicator,
	GsssMatchManager<GsssMatch, MatchData>
{
	WatchlistItemCompanyComponent                                                parentWI;
	
	// Data / Dataprovider
	/**
	 * Portion of parent's matchData belonging to GsssMatch objects of this CompanyGsssMatch item.
	 */
	protected Map<GsssMatch, MatchData>                                          localMatchData = new HashMap<>();
	protected CompanyGsssMatch                                                   item;
	protected Integer                                                            flagValue      = null;
	protected Integer                                                            flagValueOld   = null;
	protected boolean                                                            readOnly       = false;
	
	// TEMPORARY DATA
	protected boolean                                                            isInitialized  = false;
	
	// Listener
	protected SerializableBiConsumer<PartWatchlistItemCompanyGsssMatch, Boolean> flagChangeListener;
	
	// UI
	protected BeanWatchlistItemHeader                                            header;
	protected GsssMatchContainer                                                 contentElement;

	// Needs to be cached as content is added later and needs that info
	private boolean esuPart = false;
	
	public PartWatchlistItemCompanyGsssMatch(WatchlistItemCompanyComponent parentWI, final String prefix)
	{
		super();
		this.initUI();
		Objects.requireNonNull(parentWI);
		
		this.getElement().setAttribute("class", "screeningheader inner with-workaround-edge");
		
		this.parentWI = parentWI;
		
		this.header   = new BeanWatchlistItemHeader(
			WatchlistElementType.ESRA_WATCHLIST_SUBITEM,
			prefix,
			"---").setMarkedB(false);
		
		this.setSummary(this.header);
		
		this.setOpened(false);
	}
	
	
	/*************************************************************/
	
	/**
	 * 
	 * @param item
	 *            a CompanyGsssMatch
	 * @param allMatchData
	 *            MatchData map from parent SearchEntryCompany (contains MatchData items for all CompanyGsssMatch items
	 *            of the parent)
	 * @return
	 */
	public PartWatchlistItemCompanyGsssMatch setItem(CompanyGsssMatch item, Map<GsssMatch, MatchData> allMatchData)
	{
		this.item = item;
		
		if(item != null && allMatchData != null)
		{
			localMatchData = extractMatchData(item, allMatchData);
		}
		
		header.setName(getContentLabel());
		
		//// Update UI - MAIN FLAG
		
		Client client = getContext().getClient();
		int    flag   = SanctionUtil.toFlag(SanctionUtil.isMarked(client, this.item, allMatchData));
		
		// Use "fromInternal" = true to prevent executing "flagChangeListener"
		this.setValue(flag, true, false);
		
		return this;
	}
	
	/**
	 * Extract MatchData items from given map that belong to GsssMatch items from current CompanyGsssMatch item.
	 * 
	 * @param item
	 *            a CompanyGsssMatch item
	 * @param allMatchData
	 *            map from SearchEntryCompany
	 * @return
	 */
	protected Map<GsssMatch, MatchData> extractMatchData(CompanyGsssMatch item, Map<GsssMatch, MatchData> allMatchData)
	{
		if(item == null || item.getGsssMatchResults() == null || item.getGsssMatchResults().isEmpty())
		{
			return new HashMap<>(0);
		}
		if(allMatchData == null || allMatchData.isEmpty())
		{
			return new HashMap<>(0);
		}
		
		List<GsssMatch>           matchResultsOfItem = item.getGsssMatchResults();
		
		Map<GsssMatch, MatchData> res                = allMatchData.entrySet()
			.stream()
			.filter(entry -> matchResultsOfItem.contains(entry.getKey()))
			.collect(Collectors.toMap(in -> in.getKey(), in -> in.getValue(), (a, b) -> a, HashMap::new));
		return res;
	}
	
	
	/**
	 * Only for readOnly change</br >
	 * Default: WatchlistElementType.ESRA_WATCHLIST_SUBITEM</br >
	 * ReadOnly: WatchlistElementType.ESU_WATCHLIST_SUBITEM
	 * 
	 * @param type
	 * @return
	 */
	protected void setType(final WatchlistElementType type)
	{
		this.header.setType(type);
		
		// Edit CSS classes
		final ClassList classList = this.getElement().getClassList();
		
		if(type == WatchlistElementType.ESU_WATCHLIST_SUBITEM)
		{
			classList.remove("inner");
			classList.add("inner-overview");
		}
		else
		{
			classList.remove("inner-overview");
			classList.add("inner");
		}
		
		if(contentElement != null)
		{
			this.contentElement.setType(type);
		}
		
	}
	
	protected boolean valueEquals(final Integer value1, final Integer value2)
	{
		return Objects.equals(value1, value2);
	}
	
	// from AbstractFieldSupport
	protected void setValue(final Integer newValue, final boolean fromInternal, final boolean fromClient)
	{
		if(fromClient && this.readOnly)
		{
			// TODO: reset UI to previous value
			// this.applyValue(flagValue);
			return;
		}
		
		final int currentValue    = this.getFlagValue();
		final Integer currentOldValue = this.flagValueOld;
		
		if(this.valueEquals(newValue, currentValue))
		{
			return;
		}
		
		this.flagValueOld = currentValue;
		this.flagValue    = newValue;
		
		try
		{
			if(this.header != null)
			{
				this.header.setMarked(this.flagValue);
			}
			
		}
		catch(final RuntimeException e)
		{
			this.flagValueOld = currentOldValue;
			this.flagValue    = currentValue;
			throw e;
		}
		
		if(!fromInternal)
		{
			if(this.flagChangeListener != null)
			{
				this.flagChangeListener.accept(this, fromClient);
			}
		}
	}
	
	/*****************************************************************/
	// as WatchlistElement
	
	@Override
	public Optional<PartWatchList> getWatchListRoot()
	{
		return parentWI.getWatchListRoot();
	}
	
	@Override
	public void setReadOnlyCustom(final boolean readOnly)
	{
		if(this.readOnly != readOnly)
		{
			this.readOnly = readOnly;
			
			// Header & Content
			if(this.readOnly)
			{
				setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
			}
			else
			{
				setType(WatchlistElementType.ESRA_WATCHLIST_SUBITEM);
			}
		}
	}
	
	@Override
	public void asEsuPart() 
	{
		// Needs to be cached as content is added later and needs that info
		this.esuPart  = true;
		setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
	}

	
	public boolean isReadOnlyCustom()
	{
		return readOnly;
	}
	
	@Override
	public int getFlagValue()
	{
		return this.flagValue == null ? -1 : this.flagValue;
	}
	
	@Override
	public int getFlagValueOld()
	{
		return this.flagValueOld == null ? -1 : this.flagValueOld;
	}
	
	@Override
	public void setFlagChangeListener(
		final SerializableBiConsumer<PartWatchlistItemCompanyGsssMatch, Boolean> flagChangeListener)
	{
		this.flagChangeListener = flagChangeListener;
	}
	
	@Override
	public void recalcFlag()
	{
		// Calculate "marked" flag (boolean)
		Client        client                = getContext().getClient();
		final boolean calculatedMarkedValue = SanctionUtil.isMarked(client, this.item, this.getMatchDataMap());
		
		// Map to "flagValue" (integer) for UI representation
		int           flagValue             = SanctionUtil.toFlag(calculatedMarkedValue);
		
		this.setValue(flagValue, false, true);
	}
	
	/*********************************************************************/
	
	/**
	 * Event handler delegate method for the {@link Details}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void this_onOpenedChange(final OpenedChangeEvent event)
	{
		if(event.isOpened() && !this.isInitialized)
		{
			this.initAndAddContent();
		}
	}
	
	/**
	 * Create and attach content UI Components
	 */
	protected void initAndAddContent()
	{
		if(this.item != null)
		{
			this.contentElement = new GsssMatchContainer(this);
			this.setContent(this.contentElement);
			
			this.isInitialized = true;
			
			// Apply readOnly to new child component(s) if necessary
			// see setReadOnlyCustom
			if(readOnly || esuPart)
			{
				// Content
				this.contentElement.setType(WatchlistElementType.ESU_WATCHLIST_SUBITEM);
			}

		}
	}
	
	/*********************************************************************/
	
	@Override
	public void resetDataCommunicators()
	{
		if(this.isInitialized)
		{
			this.getContent().filter(Objects::nonNull)
				.filter(c -> c instanceof HasResettableDataCommunicator)
				.forEach(c -> ((HasResettableDataCommunicator)c).resetDataCommunicators());
		}
	}
	
	/*********************************************************************/
	// as GsssMatchManager
	
	@Override
	public ScreeningPageContext getContext()
	{
		return parentWI.getContext();
	}
	
	@Override
	public String getContentLabel()
	{
		return item.getNameToSearch();
	}
	
	@Override
	public List<GsssMatch> getMatches()
	{
		return item.getGsssMatchResults();
	}
	
	@Override
	public Map<GsssMatch, MatchData> getMatchDataMap()
	{
		return localMatchData;
	}
	
	@Override
	public MatchData getMatchDataFor(GsssMatch match)
	{
		if(match != null && getMatches().contains(match))
		{
			MatchData existingMatchData = getMatchDataMap().get(match);
			if(existingMatchData != null)
			{
				return existingMatchData;
			}
			else
			{
				MatchData newMatchData = new MatchData();
				getMatchDataMap().put(match, newMatchData);
				return newMatchData;
			}
		}
		return null;
	}
	
	@Override
	public void onRatingChange(boolean isFromClient, GsssMatch match)
	{
		this.recalcFlag();
	}
	
	@Override
	public void notifyMatchDataChange(boolean isFromClient, GsssMatch match, MatchData matchData, boolean isNew)
	{
		if(match != null && getMatches().contains(match))
		{		
			getMatchDataMap().put(match, matchData);
			// Notify Listener
			MatchDataSetChangeEventMD ev = createMatchDataSetChangeEvent(this, isFromClient, match, matchData, isNew);
			ComponentUtil.fireEvent(this, ev);
		}
	}
	
//	@Override
//	public void doRatingChange(boolean isFromClient, GsssMatch match, MatchRating newRating)
//	{
//		MatchRating newRating_ = newRating != null ? newRating : MatchRating.UNKNOWN;
//		
//		MatchData   matchData  = getMatchDataFor(match);
//		
//		if(!Objects.equals(matchData.getRating(), newRating_.name()))
//		{
//			matchData.setRating(newRating_.name());
//			
//			// Notify Listener
//			MatchDataSetChangeEventMD ev = createMatchDataSetChangeEvent(this, isFromClient, match, matchData, false);
//			ComponentUtil.fireEvent(this, ev);
//			
//			// Update UI
//			onRatingChange(isFromClient, match);
//		}
//	}
	
	@Override
	public Registration addMatchDataSetChangeListener(ComponentEventListener<MatchDataSetChangeEventMD> listener)
	{
		return this.addListener(MatchDataSetChangeEventMD.class, listener);
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
		
		this.addOpenedChangeListener(this::this_onOpenedChange);
	} // </generated-code>


	@Override
	public String getName() {
		return item.getNameToSearch();
	}

	
}
