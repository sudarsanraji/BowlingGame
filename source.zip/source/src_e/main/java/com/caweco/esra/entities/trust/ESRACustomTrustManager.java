package com.caweco.esra.entities.trust;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.rest.RestClientBIH;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;

/**
 * A custom trust manager that allows the usage of two trust managers at once. Required in order to accept
 * Allianz's custom self-signed certificate while also allowing access to everything else (Seaweb, S3 etc.).
 * @author MarcoHoffmann
 */
public class ESRACustomTrustManager implements X509TrustManager {
	
	final X509TrustManager defaultTm;
	final X509TrustManager esraTm;
	
	public ESRACustomTrustManager() throws NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException
	{
		TrustManagerFactory tmf = TrustManagerFactory
			    .getInstance(TrustManagerFactory.getDefaultAlgorithm());
			// Using null here initialises the TMF with the default trust store.
			tmf.init((KeyStore) null);

			// Get hold of the default trust manager
			X509TrustManager defaultTm = null;
			for (TrustManager tm : tmf.getTrustManagers()) {
			    if (tm instanceof X509TrustManager) {
			        defaultTm = (X509TrustManager) tm;
			        break;
			    }
			}
			
			this.defaultTm = defaultTm;
			
			// Create our own Trust Manager with the AZ Certificate
			String certLocation = ApplicationPropertyProvider.getAllianzCertificateLocation();
			try (FileInputStream fis = new FileInputStream(certLocation);
					BufferedInputStream bis = new BufferedInputStream(fis)) {
				X509Certificate ca = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(bis);
				KeyStore esraKeyStore = KeyStore.getInstance(KeyStore.getDefaultType());
				esraKeyStore.load(null, null);
				esraKeyStore.setCertificateEntry(Integer.toString(1), ca);
				TrustManagerFactory esraTmf = TrustManagerFactory
						.getInstance(TrustManagerFactory.getDefaultAlgorithm());
				esraTmf.init(esraKeyStore);
				// Get hold of the the ESRA trust manager
				X509TrustManager esraTm = null;
				for (TrustManager tm : esraTmf.getTrustManagers()) {
					if (tm instanceof X509TrustManager) {
						esraTm = (X509TrustManager) tm;
						break;
					}
				}
				this.esraTm = esraTm;
			}
	}

	/**
	 * Gets the accepted issuers from the default trust manager.
	 */
	@Override
    public X509Certificate[] getAcceptedIssuers() {
        return defaultTm.getAcceptedIssuers();
    }

	/**
	 * Checks certificate of the connection, first using the custom Trust Manager (which has the Allianz
	 * Certificate), and then afterwards with the default Trust Manager (which has everything else).
	 */
    @Override
    public void checkServerTrusted(X509Certificate[] chain,
            String authType) throws CertificateException {
        try {
        	//Check against Allianz Certificate
            esraTm.checkServerTrusted(chain, authType);
        } catch (CertificateException e) {
            //Check against all other certificates, will throw another exception if it fails
            defaultTm.checkServerTrusted(chain, authType);
        }
    }

    /**
     * Checks the trusted clients from the default trust manager.
     */
    @Override
    public void checkClientTrusted(X509Certificate[] chain,
            String authType) throws CertificateException {
        defaultTm.checkClientTrusted(chain, authType);
    }

}
