package com.caweco.esra.ui.admin;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ManualClientUserAssignment;
import com.caweco.esra.ui.admin.clients.UserClientAssignment;
import com.caweco.esra.ui.admin.dialogs.DialogUserSelection;
import com.caweco.esra.ui.dialogs.DialogContainer;
import com.caweco.esra.ui.gencols.RendererBoolean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.data.renderer.CaptionRenderer;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.GridFilterSubjectFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.formlayout.FormLayout.FormItem;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;


@AccessibleRule(appAdmin = true)
@PageTitle("Backend: Clients | ESRA")
@Route(value = "clients", layout = AdminBackendContainer.class)
public class PageClientAndClientuser extends HorizontalLayout
{
	public static final Logger	LOG	= LoggerFactory.getLogger(PageClientAndClientuser.class);
	
	private Client				client;
	
	/**
	 * 
	 */
	public PageClientAndClientuser()
	{
		super();
		this.initUI();
		
		this.gridClients.setItems(ClientDAO.findAll());
		this.filterComponent.connectWith(this.gridClients.getDataProvider());
		
		//// Row sorting
		
		// Column<UserClientAssignment> lastnameColumn = this.gridUser.getColumnByKey("user.lastname");
		// this.gridUser.sort(GridSortOrder.asc(lastnameColumn).build());
		
		this.gridUser.addColumn(
			RenderedComponent.Renderer(
				() -> new RendererBoolean<>(UserClientAssignment::isManuallyAssigned))).setHeader(
					"Manually assigned").setKey("manually").setSortable(false).setAutoWidth(true).setFlexGrow(0);
		
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridClients}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridClients_selectionChange(final SelectionEvent<Grid<Client>, Client> event)
	{
		if(event.isFromClient())
		{
			this.client = event.getFirstSelectedItem().orElse(null);
			
			this.updateForm();
			this.updateUserPart();
		}
		
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		// Client
		try
		{
			final boolean isNew = !ClientDAO.findAll().contains(this.client);
			
			this.binder.writeBean(this.client);
			
			if(isNew)
			{
				ClientDAO.insert(this.client, CurrentUtil.getUser());
				Notificator.success("Client created.");
			}
			else
			{
				ClientDAO.update(this.client);
				Notificator.success("Client updated.");
			}
			
			this.gridClients.getDataProvider().refreshAll();
			
			// this.client = null;
			// this.gridClients.select(null);
			// this.updateForm();
			// this.updateUserPart();
		}
		catch(final ValidationException e)
		{
			LOG.debug("Error validating client.", e);
			Notificator.error("Validation failed: " + e.getMessage());
		}
		catch(final JsonProcessingException e)
		{
			LOG.error("Error processing new Client JSON", e);
			Notificator.error("Error processing new Client JSON: " + e.getMessage());
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNewClient}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNewClient_onClick(final ClickEvent<Button> event)
	{
		this.client = new Client();
		this.gridClients.select(null);
		this.updateForm();
		this.updateUserPart();
	}
	
	public void updateUserPart()
	{
		if(this.client == null)
		{
			this.updateUserGrid();
			this.verticalLayout2.setEnabled(false);
		}
		else
		{
			this.verticalLayout2.setEnabled(true);
			this.updateUserGrid();
			
		}
	}
	
	public void updateForm()
	{
		this.binder.readBean(this.client);
		if(this.client == null)
		{
			this.form.setEnabled(false);
			this.btnSave.setEnabled(false);
		}
		else
		{
			this.form.setEnabled(true);
			this.btnSave.setEnabled(true);
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnAddUser}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnAddUser_onClick(final ClickEvent<Button> event)
	{
		final DialogUserSelection c = new DialogUserSelection(this.client);
		final DialogContainer<DialogUserSelection> dialog = new DialogContainer<>(c).onOk(it ->
		{
			final Set<User> userToAdd = it.getSelectedUser();
			if(!userToAdd.isEmpty())
			{
				userToAdd.forEach(u ->
				{
					ClientDAO.addUser(this.client, u, ManualClientUserAssignment.New(CurrentUtil.getUser().getEmailAddress()));
				});
				
				this.updateUserGrid();
				Notificator.success(userToAdd.size() + " user added.");
			}
		});
		dialog.setHeight("80vh");
		dialog.open();
	}
	
	public void updateUserGrid()
	{
		if(this.client == null)
		{
			this.gridUser.setItems(new HashSet<>());
			this.filterComponent2.connectWith(this.gridUser.getDataProvider());
		}
		else
		{
			final List<UserClientAssignment> collect =
				this.client.getUserFull(true).entrySet().stream().map(UserClientAssignment::new).collect(
					Collectors.toList());
			this.gridUser.setItems(collect);
			this.filterComponent2.connectWith(this.gridUser.getDataProvider());
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnRemoveUser}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnRemoveUser_onClick(final ClickEvent<Button> event)
	{
		
		final Set<UserClientAssignment> userToRemove = this.gridUser.getSelectedItems();
		if(!userToRemove.isEmpty())
		{
			userToRemove.forEach(u ->
			{
				ClientDAO.removeUser(this.client, u.getUser());
			});
			
			this.updateUserGrid();
			Notificator.success("User removed from client.");
		}
		else
		{
			Notificator.error("No user selected.");
		}
		
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.verticalLayout = new VerticalLayout();
		this.filterComponent = new FilterComponent();
		this.gridClients = new Grid<>(Client.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.btnNewClient = new Button();
		this.btnSave = new Button();
		this.form = new FormLayout();
		this.formItem2 = new FormItem();
		this.lblClientDescription = new Label();
		this.txtClientDescription = new TextField();
		this.binder = new Binder<>();
		this.verticalLayout2 = new VerticalLayout();
		this.filterComponent2 = new FilterComponent();
		this.gridUser = new Grid<>(UserClientAssignment.class, false);
		this.horizontalLayout2 = new HorizontalLayout();
		this.btnAddUser = new Button();
		this.btnRemoveUser = new Button();
		
		this.gridClients.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridClients.addColumn(new CaptionRenderer<>(Client::getUuid)).setKey("uuid").setHeader(
			CaptionUtils.resolveCaption(Client.class, "uuid")).setSortable(true);
		this.gridClients.addColumn(Client::getClientDescription).setKey("clientDescription").setHeader(
			CaptionUtils.resolveCaption(Client.class, "clientDescription")).setSortable(true);
		this.gridClients.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.btnNewClient.setText("New Client");
		this.btnNewClient.setIcon(VaadinIcon.PLUS.create());
		this.btnSave.setText("Save");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		this.form.setResponsiveSteps(
			new FormLayout.ResponsiveStep("0px", 1, FormLayout.ResponsiveStep.LabelsPosition.TOP));
		this.lblClientDescription.setText("Name");
		this.verticalLayout2.setEnabled(false);
		this.gridUser.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
		this.gridUser.addColumn(
			v -> Optional.ofNullable(v).map(UserClientAssignment::getUser).map(User::getLastname).orElse(null)).setKey(
				"user.lastname").setHeader("Lastname").setResizable(true).setSortable(true);
		this.gridUser.addColumn(
			v -> Optional.ofNullable(v).map(UserClientAssignment::getUser).map(User::getFirstname).orElse(null)).setKey(
				"user.firstname").setHeader("Firstname").setResizable(true).setSortable(true);
		this.gridUser.addColumn(
			v -> Optional.ofNullable(v).map(UserClientAssignment::getUser).map(User::getEmailAddress).orElse(
				null)).setKey(
					"user.emailAddress").setHeader("Email").setResizable(true).setSortable(true);
		this.gridUser.setSelectionMode(Grid.SelectionMode.MULTI);
		this.btnAddUser.setText("Add User");
		this.btnAddUser.setIcon(VaadinIcon.PLUS.create());
		this.btnRemoveUser.setText("Remove selected User");
		this.btnRemoveUser.setIcon(VaadinIcon.PLUS.create());
		
		this.binder.forField(this.txtClientDescription).asRequired().withNullRepresentation("").bind(
			Client::getClientDescription,
			Client::setClientDescription);
		
		this.filterComponent.connectWith(this.gridClients.getDataProvider());
		this.filterComponent.setFilterSubject(
			GridFilterSubjectFactory.CreateFilterSubject(
				this.gridClients,
				Arrays.asList("clientDescription"),
				Arrays.asList("uuid", "clientDescription")));
		this.filterComponent2.connectWith(this.gridUser.getDataProvider());
		this.filterComponent2.setFilterSubject(
			GridFilterSubjectFactory.CreateFilterSubject(
				this.gridUser,
				Arrays.asList("user.lastname", "user.firstname", "user.emailAddress"),
				Arrays.asList("user.lastname", "user.firstname", "user.emailAddress", "manuallyAssigned")));
		
		this.btnNewClient.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.btnNewClient, this.btnSave);
		this.lblClientDescription.setSizeUndefined();
		this.lblClientDescription.getElement().setAttribute("slot", "label");
		this.txtClientDescription.setWidthFull();
		this.txtClientDescription.setHeight(null);
		this.formItem2.add(this.lblClientDescription, this.txtClientDescription);
		this.form.add(this.formItem2);
		this.filterComponent.setWidthFull();
		this.filterComponent.setHeight(null);
		this.gridClients.setWidthFull();
		this.gridClients.setHeight(null);
		this.horizontalLayout.setWidthFull();
		this.horizontalLayout.setHeight(null);
		this.form.setWidthFull();
		this.form.setHeight(null);
		this.verticalLayout.add(this.filterComponent, this.gridClients, this.horizontalLayout, this.form);
		this.verticalLayout.setFlexGrow(1.0, this.gridClients);
		this.btnAddUser.setSizeUndefined();
		this.btnRemoveUser.setSizeUndefined();
		this.horizontalLayout2.add(this.btnAddUser, this.btnRemoveUser);
		this.filterComponent2.setWidthFull();
		this.filterComponent2.setHeight(null);
		this.gridUser.setWidthFull();
		this.gridUser.setHeight(null);
		this.horizontalLayout2.setWidthFull();
		this.horizontalLayout2.setHeight(null);
		this.verticalLayout2.add(this.filterComponent2, this.gridUser, this.horizontalLayout2);
		this.verticalLayout.setSizeFull();
		this.verticalLayout2.setSizeFull();
		this.add(this.verticalLayout, this.verticalLayout2);
		this.setSizeFull();
		
		this.gridClients.addSelectionListener(this::gridClients_selectionChange);
		this.btnNewClient.addClickListener(this::btnNewClient_onClick);
		this.btnSave.addClickListener(this::btnSave_onClick);
		this.btnAddUser.addClickListener(this::btnAddUser_onClick);
		this.btnRemoveUser.addClickListener(this::btnRemoveUser_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private FormLayout					form;
	private Binder<Client>				binder;
	private Grid<UserClientAssignment>	gridUser;
	private Button						btnNewClient, btnSave, btnAddUser, btnRemoveUser;
	private VerticalLayout				verticalLayout, verticalLayout2;
	private HorizontalLayout			horizontalLayout, horizontalLayout2;
	private Grid<Client>				gridClients;
	private Label						lblClientDescription;
	private FilterComponent				filterComponent, filterComponent2;
	private TextField					txtClientDescription;
	private FormItem					formItem2;
	// </generated-code>
	
}
