
package com.caweco.esra;

import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;

import com.rapidclipse.framework.server.RapServlet;
import com.vaadin.flow.server.VaadinServletConfiguration;


@VaadinServletConfiguration(productionMode = true, closeIdleSessions = true)
@WebServlet(
    urlPatterns = "/*", asyncSupported = true, initParams = {
        @WebInitParam(name = "original.frontend.resources", value = "true")
    })
@SuppressWarnings("ucd") // required for Vaadin
public class AppServlet extends RapServlet
{
	public AppServlet()
	{
		super();
	}
}
