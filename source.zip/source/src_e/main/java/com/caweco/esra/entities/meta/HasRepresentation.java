package com.caweco.esra.entities.meta;

public interface HasRepresentation
{
	public String getRepresentation();
}
