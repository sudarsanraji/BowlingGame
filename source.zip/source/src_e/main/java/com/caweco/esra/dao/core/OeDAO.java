package com.caweco.esra.dao.core;

import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.OE;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class OeDAO
{
	
	public static Set<OE> findAll(Client parent)
	{
		return parent.getOes(true);
	}
	
	public static void insert(final Client parent, final OE it)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oe/");
		
		Response response = webTarget.request().post(Entity.entity(it, MediaType.APPLICATION_JSON));
		
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the Office "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	
	public static void update(final Client parent, final OE it)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oe/" + it.getId());
		
		Response response = webTarget.request().put(Entity.entity(it, MediaType.APPLICATION_JSON));
		
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the Office "  + it.getName() + " to the client : " +  parent.getClientDescription());	
	}
	
	public static boolean delete(final Client parent, final OE it)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + parent.getUuid() + "/oe/" + it.getId());
		
		Response response = webTarget.request().delete();
		
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the Office "  + it.getName() + " to the client : " +  parent.getClientDescription());
		
		return true;
	}
	
	public static Set<OE> findAll()
	{
		return findAll(CurrentUtil.getClient());
	}

}
