package com.caweco.esra.business.ldap;

public enum LdapField
{
	/**
	 * <b>ID</b> of an item<br />
	 * Key: "cn"
	 */
	CN("cn", true, true),
	
	/**
	 * Full LDAP path of an item<br />
	 * Key: "distinguishedName"
	 */
	DISTINGUISHEDNAME("distinguishedName", true, true),
	
	/**
	 * <b>Description</b> of an item<br />
	 * Key: "displayName"
	 */
	DISPLAYNAME("displayName", true, true),
	
	/**
	 * <b>Mail</b> of an "user" item.<br />
	 * Key: "mail"
	 * 
	 */
	MAIL("mail", true, false),
	
	/**
	 * <b>Given name</b> of an "user" item<br />
	 * Key: "givenName"
	 */
	GIVENNAME("givenName", true, false),
	
	/**
	 * <b>Surname</b> of an "user" item<br />
	 * Key: "sn"
	 */
	SN("sn", true, false),
	
	/**
	 * <b>Country</b> of an "user" item<br />
	 * Key: "c"
	 */
	C("c", true, false),
	
	/**
	 * Full LDAP path of an "user" item's <b>Company Organization</b><br />
	 * Key: "allianz-OECompanyID"
	 */
	ALLIANZ_OECOMPANYID("allianz-OECompanyID", true, false),
	
	/**
	 * Full LDAP path of an "user" item's <b>Department Organization</b><br />
	 * Key: "allianz-OrgID"
	 */
	ALLIANZ_ORGID("allianz-OrgID", true, false),
	
	/**
	 * <b>Department</b> of an "user" item<br />
	 * Key: "departmentNumber"
	 */
	DEPARTMENTNUMBER("departmentNumber", true,
		false),
	
	/**
	 * <b>OrganizationalClass</b> of an "Organization" item.<br />
	 * Key: "allianz-OrganizationalClass"<br />
	 * Known values: "C" for top-level Organizations, "O" for lower-level Organizations.
	 */
	ALLIANZ_ORGANIZATIONALCLASS("allianz-OrganizationalClass", false, true),
	
	/**
	 * Full LDAP path of an "Organization" item's <b>parent Organization</b>.<br />
	 * Key: "allianz-SuperiorObjectID"
	 */
	ALLIANZ_SUPERIOROBJECTID("allianz-SuperiorObjectID", false, true);
	
	
	String  ldapKey;
	boolean forUser;
	boolean forOrganization;
	
	LdapField(String ldapAttributeKey, boolean forUser, boolean forOrganization) {
		this.ldapKey = ldapAttributeKey;
		this.forUser = forUser;
		this.forOrganization = forOrganization;
	}
	
	public String getLdapKey()
	{
		return this.ldapKey;
	}
	
	public boolean isForUser()
	{
		return this.forUser;
	}
	
	public boolean isForOrganization()
	{
		return this.forOrganization;
	}
}
