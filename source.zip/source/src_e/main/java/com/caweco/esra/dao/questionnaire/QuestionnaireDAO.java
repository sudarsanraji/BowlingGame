package com.caweco.esra.dao.questionnaire;

import java.util.Comparator;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.QuestionnaireDTO;
import com.caweco.esra.dto.QuestionnaireUsageDTO;
import com.caweco.esra.dto.creator.QuestionCreator;
import com.caweco.esra.dto.creator.QuestionnaireCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.questionnaire.DateChooserQuestion;
import com.caweco.esra.entities.questionnaire.DurationChooserQuestion;
import com.caweco.esra.entities.questionnaire.FreeTextQuestion;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.QuestionnaireCategory;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;
import com.vaadin.flow.component.grid.dnd.GridDropLocation;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class QuestionnaireDAO
{
	public static final String CL_CURRENT                   = "/client/{clientUuid}";
	public static final String QUEST_COPY_WITHDESCRIPTION                  = CL_CURRENT + "/questionnaire/{questionnaireId}/copyWithText/{description}";
	
	public static void insert(final Questionnaire questionnaire)
	{
		CurrentUtil.getClient().getQuestionnaires(true).add(questionnaire);
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire");
		
		final Response response = webTarget.request().post(Entity.entity(QuestionnaireCreator.questionnaireToDto(questionnaire), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the Questionnaire "  + questionnaire.getDescription() + " with category : " +  questionnaire.getCategory() + " to the system");	
	}
	
	public static void update(final Questionnaire questionnaire)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire/" + questionnaire.getQuestionnaireID().toString());
		
		final Response response = webTarget.request().put(Entity.entity(QuestionnaireCreator.questionnaireToDto(questionnaire), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the Questionnaire "  + questionnaire.getDescription() + " with category : " +  questionnaire.getCategory() + " to the system");
	}
	
	public static void delete(final Questionnaire qu)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire/" + qu.getQuestionnaireID().toString());
		
		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the Questionnaire "  + qu.getDescription() + " with category : " +  qu.getCategory() + " to the system");	
	}
	
	public static Questionnaire clone(Client client, final Questionnaire source, final String description, final boolean inactiveByDefault)
	{
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(QUEST_COPY_WITHDESCRIPTION)
			.resolveTemplate("clientUuid", client.getUuid().toString())
			.resolveTemplate("questionnaireId", source.getQuestionnaireID())
			.resolveTemplate("description", description);
		
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() != 400)
		{
			final QuestionnaireDTO qu = response.readEntity(QuestionnaireDTO.class);
			return QuestionnaireCreator.dtoToQuestionnaire(qu);			
		}
		else
		{
			return null;
		}
	}
	
	public static Questionnaire cloneNoSave(final Questionnaire source, final String description)
	{
		final Questionnaire q = new Questionnaire();
		
		q.setDescription(description);
		q.setActive(BooleanUtils.isTrue(source.getActive()));
		q.setCategory(source.getCategory());
		q.setVersion(source.getVersion() + 1);
		q.setQuestionnaireID(getNextQuestionnaireID());
		

		for (final QuestionCategory cat : source.getCategories())
		{
			q.getCategories().add(new QuestionCategory(cat));
		}
		
		// First add all the questions without the rules
		for (final Question question : source.getQuestions(true))
		{
			if (question.getCategory() == null) {
				Logger.error("## Potential data consistency problem: Questionnaire \"{}\": Question \"{}\" has no Category!",
					source.getDescription(),
					question.getQuestionText() + " [id=" + question.getId() + "]");
			}
			else if (!source.getCategories().contains(question.getCategory()))
			{
				Logger.error("## Potential data consistency problem: Questionnaire \"{}\": Category \"{}\" of Question \"{}\" does not exist!",
					source.getDescription(),
					question.getCategory().getCategory(),
					question.getQuestionText() + " [id=" + question.getId() + "]"
					);
			}
			else
			{
				if(question instanceof DateChooserQuestion)
				{
					q.getQuestions(false).add(((DateChooserQuestion) question).copyNoRules());
				}
				else if(question instanceof DurationChooserQuestion)
				{
					q.getQuestions(false).add(((DurationChooserQuestion) question).copyNoRules());
				}
				else if(question instanceof FreeTextQuestion)
				{
					q.getQuestions(false).add(((FreeTextQuestion) question).copyNoRules());
				}
				else if(question instanceof MultiOptionQuestion)
				{
					q.getQuestions(false).add(((MultiOptionQuestion) question).copyNoRules());
				}
				else if(question instanceof SingleOptionQuestion)
				{
					q.getQuestions(false).add(((SingleOptionQuestion) question).copyNoRules());
				}
				else
				{
					q.getQuestions(false).add(question.copyNoRules());
				}
			}

		}
		
		// Then set all the rules accordingly
		final var sourceQuestions = source.getQuestions(false);
		final var targetQuestions = q.getQuestions(false);
		for (int i = 0; i < q.getQuestions(false).size(); i++)
		{
			final var sourceRule = sourceQuestions.get(i).getRule();
			if(sourceRule != null)
			{
				targetQuestions.get(i).setRule(sourceRule.copy(targetQuestions));
			}
		}

		
		return q;
	}
	
	public static Set<Questionnaire> findAll()
	{
		return CurrentUtil.getClient().getQuestionnaires(true);
	}
	
	public static Set<Questionnaire> findAll(final Predicate<Questionnaire> filter)
	{
		return findAll().stream().filter(filter).collect(Collectors.toSet());
	}
	
	public static Set<Questionnaire> findAllActive_BI()
	{
		return findAll().stream().filter(qu -> BooleanUtils.isTrue(qu.getActive())).filter(
			qu -> qu.getCategory().equals(QuestionnaireCategory.BUSINESS_INFORMATION)).collect(Collectors.toSet());
	}
	
	public static Set<Questionnaire> findAllActive_TS()
	{
		return findAll().stream().filter(qu -> BooleanUtils.isTrue(qu.getActive())).filter(
			qu -> qu.getCategory().equals(QuestionnaireCategory.TRADE_SANCTION)).collect(Collectors.toSet());
	}
	
	public static synchronized Integer getNextQuestionnaireID()
	{
		try
		{
			final Comparator<Questionnaire> comp = (p1, p2) -> Integer.compare(
				Integer.valueOf(p1.getQuestionnaireID()),
				Integer.valueOf(p2.getQuestionnaireID()));
			final Questionnaire questionnaire = QuestionnaireDAO.findAll().stream().max(comp).get();
			
			return questionnaire.getQuestionnaireID() + 1;
		}
		catch(final Exception e)
		{
			
			return 1;
		}
	}
	
	public static void reorderCategories(
		final Questionnaire qu,
		final QuestionCategory sourceCat,
		final QuestionCategory targetCat,
		final GridDropLocation location)
	{
		qu.getCategories().remove(sourceCat);
		
		if(location.equals(GridDropLocation.ABOVE))
		{
			qu.getCategories().add(qu.getCategories().indexOf(targetCat), sourceCat);
		}
		else
		{
			qu.getCategories().add(qu.getCategories().indexOf(targetCat) + 1, sourceCat);
		}
		
		qu.getCategories().forEach(i -> i.setId(qu.getCategories().indexOf(i)));
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() 
				+ "/questionnaire/" + qu.getQuestionnaireID().toString() + "/categories/reorder");
		
		final Response response = webTarget.request().put(Entity.entity(QuestionnaireCreator.questionnaireToDto(qu), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	public static void reorderQuestions(
		final Questionnaire qu,
		final Question sourceQuestion,
		final Question targetQuestion,
		final GridDropLocation location)
	{
		qu.getQuestions(true).remove(sourceQuestion);
		
		if(location.equals(GridDropLocation.ABOVE))
		{
			qu.getQuestions(false).add(qu.getQuestions(false).indexOf(targetQuestion), sourceQuestion);
		}
		else
		{
			qu.getQuestions(false).add(qu.getQuestions(false).indexOf(targetQuestion) + 1, sourceQuestion);
		}
	}

	public static void saveExistingCategory(final QuestionCategory questionCategory, final Client client,
			final Questionnaire questionnaire) {
		
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + 
				"/questionnaire/" + questionnaire.getQuestionnaireID() +
				"/category/" + questionCategory.getId());
		
		final Response response = webTarget.request().put(Entity.entity(questionCategory, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}

	public static Questionnaire findById(final String clientId, final Integer questionnaireID) {
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + clientId + 
				"/questionnaire/" + questionnaireID);
		
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() != 400)
		{
			final QuestionnaireDTO qu = response.readEntity(QuestionnaireDTO.class);
			return QuestionnaireCreator.dtoToQuestionnaire(qu);			
		}
		else
		{
			return null;
		}
		
	}

	public static void insertWithAllQuestions(final Questionnaire q) {
		QuestionnaireDAO.insert(q);
		
		q.getQuestions(false).forEach(qu -> {
			QuestionDAO.insert(q, qu);
		});
	}

	public static boolean isInUse(final Client client, final Questionnaire questionnaire) {
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + 
				"/questionnaire/" + questionnaire.getQuestionnaireID() + "/isInUse");
		
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 200)
		{
			final QuestionnaireUsageDTO qu = response.readEntity(QuestionnaireUsageDTO.class);
			return qu.isInUse();
		}
		else
		{
			return true;
		}
	}
	
	public static void replaceQuestions(final Client client, final Questionnaire questionnaire)
	{
		final RestClientESRADB rest = RestUtil.getRestClient_ESRADB();

		final WebTarget webTarget = rest.getMethodTarget(
			"/client/" + CurrentUtil.getClient().getUuid().toString() + "/questionnaire/" + questionnaire
				.getQuestionnaireID()
				.toString() + "/question/replace"
		);

		final var questions = questionnaire.getQuestions(false)
			.stream()
			.map(QuestionCreator::convertQuestionToDTO)
			.collect(Collectors.toList());

		webTarget.request().post(Entity.entity(questions, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info("Updated questionnaire questions");
	}
}
