package com.caweco.esra.subsidary.frontend;

import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.caweco.esra.subsidary.common.event.ScreeningBlockingChangeEvent;
import com.vaadin.flow.shared.Registration;

/**
 * Frontend-local cache of SCREENING_LOCKS.<br />
 * 
 * TODO: Replace this when a new messaging system is available.
 * <p>
 * Currently it is not possible for the backend to establish a communication connection to a frontend, all Connections
 * are intialized by the frontend.<br />
 * So, the backend cannot notify frontend components for changes.
 * </p>
 * -> Use a mature messaging system to make this possible.
 * 
 *
 */
public class FrontendScreeningBlockingStateManager
{
	
	/**
	 * Maps "screeningId" to "taskId"
	 */
	protected static ConcurrentHashMap<String, String>        SCREENING_LOCKS         = new ConcurrentHashMap<>();
	
	/*******************************************************/
	
	static Executor                                           executor                = Executors.newSingleThreadExecutor();
	
	static LinkedList<Consumer<ScreeningBlockingChangeEvent>> screeningStateListeners = new LinkedList<>();
	
	public static synchronized Registration registerScreeningStateListener(Consumer<ScreeningBlockingChangeEvent> listener)
	{
		screeningStateListeners.add(listener);
		
		return () ->
		{
			synchronized (SubsidiaryTaskManager.class)
			{
				screeningStateListeners.remove(listener);
			}
		};
	}
	
	static synchronized void notifyListener(String screeningId, boolean blocked)
	{
		for (Consumer<ScreeningBlockingChangeEvent> listener : screeningStateListeners)
		{
			executor.execute(() -> listener.accept(ScreeningBlockingChangeEvent.New(screeningId, blocked)));
		}
	}
	
	/*******************************************************/
	
	/**
	 * Unblocks screening.<br />
	 * <b>Notifies screeningState Listeners</b>
	 * 
	 * @param screeningId
	 * @return the previous taskId
	 */
	public static String unblockScreening(String screeningId)
	{
		String previousBlockingTaskId = SCREENING_LOCKS.remove(screeningId);
		// If previousBlockingTaskId NOT exists -> no change
		if (previousBlockingTaskId != null)
			notifyListener(screeningId, false);
		return previousBlockingTaskId;
	}
	
	/**
	 * Block screening no matter if screening is already blocked. <br />
	 * If already blocked, just changes the "blocked by" to new "taskId".<br />
	 * <b>Notifies screeningState Listeners</b>
	 * 
	 * @param screeningId
	 * @param taskId
	 */
	public static void blockScreening(String screeningId, String taskId)
	{
		String previousBlockingTaskId = SCREENING_LOCKS.put(screeningId, taskId);
		// If previousBlockingTaskId exists -> no "blocked" state change
		if (previousBlockingTaskId == null)
			notifyListener(screeningId, true);
	}
}
