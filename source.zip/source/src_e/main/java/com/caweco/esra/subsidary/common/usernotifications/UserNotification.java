package com.caweco.esra.subsidary.common.usernotifications;

import java.time.Instant;

public interface UserNotification
{
	public String getTargetUserId();
	public String getId();
	public Instant getCreated();
	public String getMessage();
}
