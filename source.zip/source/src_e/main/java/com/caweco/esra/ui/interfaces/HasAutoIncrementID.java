package com.caweco.esra.ui.interfaces;

public interface HasAutoIncrementID
{
	public int getId();
}
