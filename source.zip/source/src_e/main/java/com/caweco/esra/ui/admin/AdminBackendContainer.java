
package com.caweco.esra.ui.admin;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.ui.admin.access.PageAccessControl;
import com.caweco.esra.ui.admin.esu_template.PageTemplateOverview;
import com.caweco.esra.ui.admin.questionnaire.PageQuestionnaireOverview;
import com.caweco.esra.ui.main.PageMain;
import com.rapidclipse.framework.server.navigation.Navigation;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluatingComponentExtension;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluationStrategy;
import com.vaadin.flow.component.HasElement;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.html.Nav;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.router.ParentLayout;
import com.vaadin.flow.router.RouterLayout;


@ParentLayout(PageMain.class)
public class AdminBackendContainer extends HorizontalLayout implements RouterLayout
{
	private static final long serialVersionUID = 1L;
	Nav        nav;
	Main       main;
	
	public Tab tabAppClients;
	public Tab tabAppRules;
	public Tab tabAppBackup;
	public Tab tabAppUser;
	
	public Tab tabClientSettings;
	public Tab tabClientUser;
	public Tab tabClientRoles;
	public Tab tabClientValues;
	public Tab tabClientQuestionnaires;
	public Tab tabClientEsuTemplates;
	public Tab tabClientReporting;
	public Tab tabClientArchive;
	
	public AdminBackendContainer()
	{
		super();
		this.initUI();
		this.nav  = new Nav(this.tabs);
		this.main = new Main();
		
		this.nav.setSizeUndefined();
		this.nav.getElement().getStyle().set("display", "flex");
		this.main.setSizeUndefined();
		this.add(this.nav, this.main);
		this.setFlexGrow(1.0, this.main);
		
		this.tabAppClients           = this.getTab(VaadinIcon.OFFICE, "Clients", false);
		this.tabAppRules             = this.getTab(VaadinIcon.OFFICE, "Rules", false);
		this.tabAppBackup            = this.getTab(VaadinIcon.STORAGE, "Backup", false);
		this.tabAppUser              = this.getTab(VaadinIcon.USERS, "All User", false);
		
		this.tabClientSettings       = this.getTab(VaadinIcon.COG, "Settings", true);
		this.tabClientUser           = this.getTab(VaadinIcon.USER, "Client User", true);
		this.tabClientRoles          = this.getTab(VaadinIcon.GROUP, "Groups", true);
		this.tabClientValues         = this.getTab(VaadinIcon.ARCHIVES, "Values", true);
		this.tabClientQuestionnaires = this.getTab(VaadinIcon.QUESTION_CIRCLE, "Questionnaires", true);
		this.tabClientEsuTemplates   = this.getTab(VaadinIcon.TEXT_INPUT, "ESU Templates", true);
		this.tabClientReporting      = this.getTab(VaadinIcon.PIE_BAR_CHART, "Reporting", true);
		this.tabClientArchive        = this.getTab(VaadinIcon.ARCHIVE, "Archive", true);
		
		this.tabs.add(this.tabAppClients, this.tabAppRules, this.tabAppBackup, this.tabAppUser, this.tabClientSettings,
			this.tabClientUser, this.tabClientRoles, this.tabClientValues, this.tabClientQuestionnaires,
			this.tabClientEsuTemplates, this.tabClientReporting, this.tabClientArchive);
		
		this.tabs.setSelectedTab(this.tabClientSettings);
		
		this.tabs.addSelectedChangeListener(event -> {
			if(event.getSelectedTab().equals(this.tabAppClients))
			{
				Navigation.navigateTo(PageClientAndClientuser.class);
			}
			else if(event.getSelectedTab().equals(this.tabAppRules))
			{
				Navigation.navigateTo(PageAccessControl.class);
			}
			else if(event.getSelectedTab().equals(this.tabAppBackup))
			{
				Navigation.navigateTo(PageBackup.class);
			}
			else if(event.getSelectedTab().equals(this.tabAppUser))
			{
				Navigation.navigateTo(PageAllUser.class);
			}
			
			else if(event.getSelectedTab().equals(this.tabClientSettings))
			{
				Navigation.navigateTo(PageClientConfig.class);
			}
			else if(event.getSelectedTab().equals(this.tabClientUser))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageUserRoles.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientRoles))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageRolesPermission.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientValues))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageComboBoxData.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientQuestionnaires))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageQuestionnaireOverview.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientEsuTemplates))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageTemplateOverview.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientReporting))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageDataReporting.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			else if(event.getSelectedTab().equals(this.tabClientArchive))
			{
				if(CurrentUtil.getClient() != null)
				{
					Navigation.navigateTo(PageArchive.class);
				}
				else
				{
					Notificator.warn("No Client selected!");
				}
			}
			
		});
		
		// PERMISSION EVAL
		
		Authorization.evaluateComponents(this);
		
		final boolean isAppAdmin = AuthorizationUtil.isAppAdmin();
		this.tabAppClients.setEnabled(isAppAdmin);
		this.tabAppRules.setEnabled(isAppAdmin);
		this.tabAppBackup.setEnabled(isAppAdmin);
		this.tabAppUser.setEnabled(isAppAdmin);
		if(isAppAdmin)
		{
			this.tabClientUser.setEnabled(true);
			this.tabClientRoles.setEnabled(true);
		}
		
	}
	
	private Tab getTab(final VaadinIcon icon, final String name, final boolean isClientTab)
	{
		final VerticalLayout vl = new VerticalLayout(new Icon(icon), new Span(name));
		vl.getStyle().set("alignItems", "center");
		
		final Tab tab = new Tab(vl);
		tab.getElement().getClassList().add("menu");
		
		if(isClientTab)
		{
			Authorization.setSubjectEvaluatingComponentExtension(tab,
				SubjectEvaluatingComponentExtension.Builder.New()
					.add(AuthorizationResources.CLIENTADMINCOMMON.resource(), SubjectEvaluationStrategy.ENABLED)
					.build());
		}
		if(!isClientTab)
		{
			tab.getElement().getClassList().add("marked");
		}
		
		return tab;
	}
	
	@Override
	public void showRouterLayoutContent(final HasElement content)
	{
		this.main.removeAll();
		this.main.getElement().appendChild(content.getElement());
	}
	
	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.tabs = new Tabs();
		
		this.setSpacing(false);
		this.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.tabs.setOrientation(Tabs.Orientation.VERTICAL);
		
		this.tabs.setWidth("150px");
		this.tabs.setHeight(null);
		this.add(this.tabs);
		this.setSizeFull();
		
		this.tabs.setSelectedIndex(-1);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Tabs tabs;
	// </generated-code>
	
}
