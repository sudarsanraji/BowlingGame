package com.caweco.esra.business.utils;


import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.html.Image;

public class UiHelper
{
	public static void image_addEmptyAltAttribute(Image image)
	{
		image.setAlt("");
		image.getElement().setAttribute("alt", "");
	}
	
	public static void setAriaLabel(Component component, String ariaLabel)
	{
		if (component != null)
		{
			component.getElement().setAttribute("aria-label", ariaLabel);
		}
	}
	
	public static void setTitle(Component component, String title)
	{
		if (component != null)
		{
			component.getElement().setAttribute("title", title);
		}
	}
}
