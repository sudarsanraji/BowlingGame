
package com.caweco.esra.subsidary.frontend;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import org.tinylog.Logger;

import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.subsidary.common.SubNode;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningAppliedData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskRunData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.common.usertask.UserTask;


public class SubsidiaryScreeningTaskF implements UserTask
{
	public final UUID                           id;
	public final Instant                        created;
	public final String                         createdBy;
	public final UUID                           clientId;
	public final UUID                           screeningId;
	public final UUID                           searchEntryCompanyId;
	public final String                         rootBvdId;
	public final String                         rootCompanyName;
	
	protected SubsidiaryScreeningTaskState      state                        =
		SubsidiaryScreeningTaskState.CREATED_WAITING;
	
	//// WorkingData
	protected boolean                           resultDataAvailableInBackend = false;
	protected boolean                           thisIsFromBackend            = false;
	
	/**
	 * StatusData - Contains e.g. the error message or the reason why task was skipped.
	 */
	protected SubsidiaryScreeningTaskRunData    runData;
	
	/**
	 * Subsidiaries Tree - available when Task is finished
	 */
	protected SubNode                           resultTree;
	
	/**
	 * Subsidiary Screening data - available from time when Task is finished until data are applied to screening<br />
	 * -> Not available in "applied" state
	 */
	protected Optional<SubsidiaryScreeningData> resultData;
	
	/**
	 * AppliedData -> Available in "applied" state
	 * Contains Infos about "applied" result
	 */
	protected SubsidiaryScreeningAppliedData    appliedData;
	
	public SubsidiaryScreeningTaskF(
		UUID id,
		Instant created,
		final String createdBy,
		
		final UUID clientId,
		final UUID screeningId,
		final UUID searchEntryCompanyId,
		
		final String rootBvdId,
		final String rootCompanyName,
		SubsidiaryScreeningTaskState state,
		
		boolean resultDataAvailableInBackend,
		boolean thisIsFromBackend,
		SubsidiaryScreeningTaskRunData runData,
		
		SubNode resultTree,
		SubsidiaryScreeningData resultData,
		SubsidiaryScreeningAppliedData appliedData)
	{
		super();
		this.id                           = id;
		this.created                      = created;
		this.createdBy                    = createdBy;
		this.clientId                     = clientId;
		this.screeningId                  = screeningId;
		this.searchEntryCompanyId         = searchEntryCompanyId;
		this.rootBvdId                    = rootBvdId;
		this.rootCompanyName              = rootCompanyName;
		this.state                        = state;
		this.resultDataAvailableInBackend = resultDataAvailableInBackend;
		this.thisIsFromBackend            = thisIsFromBackend;
		this.runData                      = runData;
		this.resultTree                   = resultTree;
		this.resultData                   = Optional.ofNullable(resultData);
		this.appliedData                  = appliedData;
	}
	
	public SubsidiaryScreeningTaskF(
		final String createdBy,
		final UUID clientId,
		final UUID screeningId,
		final UUID searchEntryCompanyId,
		final CIResponse rootItem)
	{
		super();
		id                        = UUID.randomUUID();
		created                   = Instant.now();
		this.createdBy            = createdBy;
		this.clientId             = clientId;
		this.screeningId          = screeningId;
		this.searchEntryCompanyId = searchEntryCompanyId;
		this.rootBvdId            = rootItem.getCompanyBvdId();
		rootCompanyName           = rootItem.getCompanyInfoBvd().getName();
	}
	
	@Override
	public UUID getId()
	{
		return this.id;
	}
	
	@Override
	public Instant getCreated()
	{
		return this.created;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public UUID getClientId()
	{
		return this.clientId;
	}
	
	public UUID getScreeningId()
	{
		return this.screeningId;
	}
	
	public UUID getSearchEntryCompanyId()
	{
		return this.searchEntryCompanyId;
	}
	
	public String getRootBvdId()
	{
		return this.rootBvdId;
	}
	
	public String getRootCompanyName()
	{
		return this.rootCompanyName;
	}
	
	public SubsidiaryScreeningTaskState getState()
	{
		return this.state;
	}
	
	public void setState(final SubsidiaryScreeningTaskState state)
	{
		this.state = state;
	}
	
	////
	//// WorkingData
	////
	
	////
	//// StatusData
	////
	
	public SubsidiaryScreeningTaskRunData getRunData()
	{
		return runData;
	}
	
	public void setRunData(SubsidiaryScreeningTaskRunData runData)
	{
		this.runData = runData;
	}
	
	////
	//// ScreeningData
	////
	
	public SubNode getResultTree()
	{
		return this.resultTree;
	}
	
	public void setResultTree(final SubNode resultTree)
	{
		this.resultTree = resultTree;
	}
	
	public SubsidiaryScreeningData getResultData(boolean force)
	{
		if(force)
		{
			if(thisIsFromBackend && resultDataAvailableInBackend)
			{
				this.resultData = Optional.ofNullable(SubsidiaryTaskDAO.getTaskResultData(id.toString()));
			}
			else
			{
				Logger.debug("Try to get ScreeningData for ScreeningTask that is not in backend yet.");
			}
		}
		return this.resultData != null ? this.resultData.orElse(null) : null;
	}
	
	public void setResultData(final SubsidiaryScreeningData resultData)
	{
		this.resultData = Optional.ofNullable(resultData);
	}
	
	public SubsidiaryScreeningAppliedData getAppliedData()
	{
		return appliedData;
	}
	
	public void setAppliedData(SubsidiaryScreeningAppliedData appliedData)
	{
		this.appliedData = appliedData;
	}
	
	@Override
	public String getUser()
	{
		return getCreatedBy();
	}
	
	@Override
	public String getSummary()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Subsidiary Screening Task");
		// sb.append("Client: ").append(this.getClientId()).append("\\n");
		// sb.append("Screening: ").append(this.getScreeningId()).append("\\n");
		// sb.append("Company: ").append(this.getRootCompanyName()).append(" /
		// ").append(this.getRootBvdId()).append("\\n");
		return sb.toString();
	}
	
}
