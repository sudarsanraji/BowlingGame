package com.caweco.esra.ui.gencols;

import java.util.Objects;

import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.function.ValueProvider;


public class RendererBoolean<T> extends Checkbox implements RenderedComponent<T>
{
	private ValueProvider<T, Boolean>	getter;
	private T							item;
	
	public RendererBoolean(ValueProvider<T, Boolean> getter)
	{
		super();
		Objects.requireNonNull(getter);
		this.getter = getter;
		
	}
	
	@Override
	public void renderComponent(T item)
	{
		this.item = item;
		this.setValue(this.getter.apply(item));
		this.setReadOnly(true);
	}
	
}
