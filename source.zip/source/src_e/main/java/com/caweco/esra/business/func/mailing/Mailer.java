package com.caweco.esra.business.func.mailing;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.core.MailTemplateDAO;
import com.caweco.esra.dao.messaging.MessageGroupService;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ConfigMailServer;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.mailing.MailTemplate;
import com.caweco.esra.entities.mailing.MailType;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;


public class Mailer
{
	
	private static final Logger LOG = LoggerFactory.getLogger(Mailer.class);
	
	private Mailer()
	{
	}
	
	/**********************************************************************************/
	//// COMMON
	
	/**
	 * Sends a Mail according to provided {@link MailData} item and {@link MailServerConfig}.
	 *
	 * @param input         the MailData
	 * @param emailSettings the MailServerConfig
	 * @return the message id of the underlying MimeMessage
	 * @throws EmailException
	 * @see {@link Email#send()}
	 */
	public static String sendMail(final MailData input, final ConfigMailServer emailSettings) throws EmailException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
		if (ApplicationPropertyProvider.sendMailsToConsole())
		{
			sendMailToConsole(input);
			return "";
		}
		final MailProvider provider = new MailProvider();
		final Email        mail     = provider.prepareMail(input.isHtmlFormatted(), input.getSubjectText(), input
			.getBodyText(), emailSettings, input.getSender() != null ? input.getSender()
				: emailSettings.getSmtpSenderEmailAddress());
		
		if (CollectionUtils.isNotEmpty(input.getRecipients()))
		{
			mail.addTo(input.getRecipients().toArray(new String[0]));
		}
		if (CollectionUtils.isNotEmpty(input.getRecipientsCC()))
		{
			mail.addCc(input.getRecipientsCC().toArray(new String[0]));
		}
		if (CollectionUtils.isNotEmpty(input.getRecipientsBCC()))
		{
			mail.addBcc(input.getRecipientsBCC().toArray(new String[0]));
		}
		
		final String messageId = mail.send();
		return messageId;
	}
	
	public static void sendMailToConsole(final MailData input)
	{
		LOG.warn("DEVELOPER SETTING DETECTED: Send mail only to console.");
		final String allReceiver = Stream.concat(input.getRecipients().stream(), input.getRecipientsBCC().stream())
			.collect(Collectors.joining(", "));
		LOG.warn("Sending Mail(s) to {} with Text: {}", allReceiver, input.getBodyText());
	}
	
	/**********************************************************************************/
	//// WORKFLOW
	
	public static void sendMail_reviewFinished(final Screening r)
	{
		final Client              client              = CurrentUtil.getClient();
		final User                user                = CurrentUtil.getUser();
		
		//// DATA
		final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.REVIEW_FINISHED);
		final Map<String, String> props               = MailTextProvider.prepareMap_reviewFinished(r, user.getEmailAddress());
		
		//// TEXT
		final String              bodyText            = MailTextProvider.getEmailBody(template, props);
		
		//// SUBJECT
		final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
		
		//// Server Settings
		final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
		
		//// Combine all data
		final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
			.addRecipient(r.getScreeningOwner().getEmailAddress());
		
		//// Send
		// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
		
		try
		{
			Mailer.sendMail(mailData, clientEmailSettings);
			
			LOG.info("Sent \"Review finished\" notification.");
			
		}
		catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
		{
			LOG.error("Error sending \"Review finished\" notification.", e);
		}
	}
	
	public static void sendMail_screeningOwnerTakeover(final Screening r, final String additionalNotificationFromUser, final User oldScreeningOwner)
	{
		final Client              client              = CurrentUtil.getClient();
		final User                user                = CurrentUtil.getUser();
		
		//// DATA
		final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.SCREENING_OWNER_TAKEOVER);
		final Map<String, String> props               = MailTextProvider.prepareMap_screeningOwnerTakeover(r, user.getEmailAddress(), oldScreeningOwner);
		
		//// TEXT
		final String              bodyText            = MailTextProvider.getEmailBody(template, props);
		
		//// SUBJECT
		final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
		
		//// Server Settings
		final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
		
		//// Combine all data
		final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
			.addRecipient(oldScreeningOwner.getEmailAddress());
		
		//// Send
		// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
		
		try
		{
			Mailer.sendMail(mailData, clientEmailSettings);
			
			LOG.info("Sent \"Screeningownertakeover\" notification.");
			
		}
		catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
		{
			LOG.error("Error sending \"Screeningownertakeover\" notification.", e);
		}
	}
	
	public static void sendMail_screeningOwnerChange(final Screening r, final String additionalNotificationFromUser)
	{
		final Client              client              = CurrentUtil.getClient();
		final User                user                = CurrentUtil.getUser();
		
		//// DATA
		final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.SCREENING_OWNER_CHANGE);
		final Map<String, String> props               = MailTextProvider.prepareMap_screeningOwnerChanged(r, user.getEmailAddress(), additionalNotificationFromUser);
		
		//// TEXT
		final String              bodyText            = MailTextProvider.getEmailBody(template, props);
		
		//// SUBJECT
		final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
		
		//// Server Settings
		final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
		
		//// Combine all data
		final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
			.addRecipient(r.getScreeningOwner().getEmailAddress());
		
		//// Send
		// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
		
		try
		{
			Mailer.sendMail(mailData, clientEmailSettings);
			
			LOG.info("Sent \"Screeningownerchange\" notification.");
			
		}
		catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
		{
			LOG.error("Error sending \"Screeningownerchange\" notification.", e);
		}
	}
	
	public static void sendMail_screeningServiceUserChange(final Screening screening, final String additionalNotificationFromUser) throws EmailException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
		final Client              client              = CurrentUtil.getClient();
		final User                user                = CurrentUtil.getUser();
		
		//// DATA
		final MailTemplate template = MailTemplateDAO.findOrInit(client, MailType.SCREENING_SERVICEUSER_CHANGE);
		final Map<String, String> props               = MailTextProvider.prepareMap_screeningServiceUserChanged(screening, user.getEmailAddress(), additionalNotificationFromUser);
		
		//// TEXT
		final String              bodyText            = MailTextProvider.getEmailBody(template, props);
		
		//// SUBJECT
		final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
		
		//// Server Settings
		final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
		
		//// Combine all data
		final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
			.addRecipient(screening.getScreeningServiceUser().getEmailAddress());
		
		//// Send
		// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
		

		Mailer.sendMail(mailData, clientEmailSettings);
			
		LOG.info("Sent \"ScreeningServiceuserchange\" notification.");
	}
	
	
	/**********************************************************************************/
	//// MESSAGING
	
	public static void sendMail_newGroupMessage(
		final User author,
		final Screening r,
		final MessageGroup g)
	{
		final Client      client           = CurrentUtil.getClient();
		
		//// RECEIVER
		final Set<String> receiverToNotify = g.getMembers(true).entrySet().stream()
			// do not notify message author
			.filter(u -> !Objects.equals(u.getKey(), author))
			
			// Currently: Notification to ALL group user
			// check subscription
			// .filter(e -> BooleanUtils.isTrue(e.getValue()))
			
			// get email addresses
			.map(e -> e.getKey().getEmailAddress()).filter(Objects::nonNull).collect(Collectors.toSet());
		
		final String      groupName        = g.getName();
		
		if (receiverToNotify.isEmpty())
		{
			LOG.info("New message for group \"{}\": Nobody wants to be notified, skip sending Mail!", groupName);
		}
		else
		{
			//// DATA
			final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.NEW_GROUPMESSAGE);
			final Map<String, String> props               = MailTextProvider.prepareMap_newGroupMessage(r, g);
			
			//// TEXT
			final String              bodyText            = MailTextProvider.getEmailBody(template, props);
			
			//// SUBJECT
			final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
			
			//// Server Settings
			final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
			
			//// Combine all data
			
			final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
				.addRecipient(author.getEmailAddress())
				.setRecipientsBCC(receiverToNotify);
			
			//// Send
			// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
			
			try
			{
				Mailer.sendMail(mailData, clientEmailSettings);
				
				LOG.info("Sent \"New groupmessage\" mail to {} user.", receiverToNotify.size());
				
			}
			catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
			{
				LOG.error("Error sending group message notifications.", e);
			}
		}
	}
	
	public static void sendMail_newPublicMessage(
		final User author,
		final Screening r)
	{
		final Client      client           = CurrentUtil.getClient();
		
		//// RECEIVER
		final Set<User>   follower         = MessageGroupService.getPublicMessageHolder(r).getFollower();
		final Set<String> receiverToNotify = follower
			.stream()
			// do not notify message author
			.filter(u -> !Objects.equals(u, author))
			// get email addresses
			.map(e -> e.getEmailAddress()).filter(Objects::nonNull).collect(Collectors.toSet());
		
		if (receiverToNotify.isEmpty())
		{
			LOG.info("Public messages for \"{}\": Nobody wants to be notified. Skip sending Mail!", r.getName());
		}
		else
		{
			//// DATA
			final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.NEW_PUBLICMESSAGE);
			final Map<String, String> props               = MailTextProvider.prepareMap_newPublicMessage(r);
			
			//// TEXT
			final String              bodyText            = MailTextProvider.getEmailBody(template, props);
			
			//// SUBJECT
			final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
			
			//// Server Settings
			final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
			
			//// Combine all data
			
			final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
				.addRecipient(author.getEmailAddress())
				.setRecipientsBCC(receiverToNotify);
			
			//// Send
//			Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
			
			try
			{
				Mailer.sendMail(mailData, clientEmailSettings);
				
				LOG.info("Sent \"New groupmessage\" mail to {} user.", receiverToNotify.size());
				
			}
			catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
			{
				LOG.error("Error sending public message notifications.", e);
			}
		}
	}
	
	public static void sendMail_inviteUserToExpertGroup(
		final User author,
		final Screening r,
		final MessageGroup g,
		final Collection<User> userToInvite)
	{
		final Client      client           = CurrentUtil.getClient();
		
		//// RECEIVER
		final Set<String> receiverToNotify = userToInvite.stream().map(e -> e.getEmailAddress()).filter(Objects::nonNull)
			.collect(Collectors.toSet());
		
		if (receiverToNotify.isEmpty())
		{
			LOG.debug("Nobody to invite to Expert group. Skip sending Mail! Recipient: {}", r.getName());
		}
		else
		{
			//// DATA
			final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.MESSAGING_GROUPINVITATION);
			final Map<String, String> props               = MailTextProvider
				.prepareMap_GroupInvitation(r, g, author.getRepresentation());
			
			//// TEXT
			final String              bodyText            = MailTextProvider.getEmailBody(template, props);
			
			//// SUBJECT
			final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
			
			//// Server Settings
			final ConfigMailServer    clientEmailSettings = CurrentUtil.getEmailSettings();
			
			//// Combine all data
			final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
				.addRecipient(author.getEmailAddress())
				.setRecipientsBCC(receiverToNotify);
			
			//// Send
//			Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
			
			try
			{
				Mailer.sendMail(mailData, clientEmailSettings);
				
				LOG.info("Sent \"Group invitation\" notification to {} user.", receiverToNotify.size());
			}
			catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
			{
				LOG.error("Error sending public message notifications.", e);
			}
		}
	}
	

	public static void sendMail_subsidiaryScreeningTaskFinished(final Client client, final Screening screening, final SubsidiaryScreeningTaskF task)
	{
		
		//// DATA
		final MailTemplate        template            = MailTemplateDAO.findOrInit(client, MailType.SUBSIDIARY_SCREENING_FINISHED);
		final Map<String, String> props               = MailTextProvider.prepareMap_newSubsidiaryScreeningFinishedMsg(screening, task);
		
		//// TEXT
		final String              bodyText            = MailTextProvider.getEmailBody(template, props);
		
		//// SUBJECT
		final String              emailSubject        = MailTextProvider.getEmailTopic(template, props);
		
		//// Server Settings
		final ConfigMailServer    clientEmailSettings = client.getClientConfiguration().getConfigMailServer();
		
		//// Combine all data
		final MailData.Default    mailData            = MailData.New(bodyText, emailSubject)
			.addRecipient(task.getCreatedBy());
		
		//// Send
		// Mailer.sendMailAsync(UI.getCurrent(), mailData, clientEmailSettings);
		
		try
		{
			Mailer.sendMail(mailData, clientEmailSettings);
			
			LOG.info("Sent \"subsidiary screening task finished\" notification.");
			
		}
		catch (EmailException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e)
		{
			LOG.error("Error sending \"subsidiary screening task finished\" notification.", e);
		}
	}

}
