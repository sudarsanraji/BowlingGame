package com.caweco.esra.business.report;

import java.util.ArrayList;
import java.util.List;

public class TocSubItem
{
	private final String display;
	private final String link;
	private final List<TocSubItem> subItems = new ArrayList<>();

	public TocSubItem(final String display)
	{
		this(display, null);
	}

	public TocSubItem(final String display, final String link)
	{
		this.display = display;
		this.link = link;
	}

	public String getDisplay()
	{
		return this.display;
	}

	public String getLink()
	{
		return this.link;
	}

	public List<TocSubItem> getSubItems()
	{
		return new ArrayList<>(this.subItems);
	}
}
