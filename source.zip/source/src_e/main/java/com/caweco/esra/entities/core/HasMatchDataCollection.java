package com.caweco.esra.entities.core;

import java.util.Map;

import com.caweco.esra.entities.rest.general.GsssMatch;

public interface HasMatchDataCollection
{
	String getComment();
	
	HasMatchDataCollection setComment(String comment);
	
	
	Map<GsssMatch, MatchData> getMatchData();
	
	HasMatchDataCollection setMatchData(Map<GsssMatch, MatchData> matchData);
	
}
