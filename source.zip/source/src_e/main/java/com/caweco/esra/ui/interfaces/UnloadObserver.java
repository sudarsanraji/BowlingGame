package com.caweco.esra.ui.interfaces;

import com.caweco.esra.ui.dialogs.DialogConfirm;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeLeaveEvent;
import com.vaadin.flow.router.BeforeLeaveEvent.ContinueNavigationAction;
import com.vaadin.flow.router.BeforeLeaveObserver;
import com.vaadin.flow.shared.ui.LoadMode;

/**
 * A component implementing this interface can handle unsaved changes on page leave.<br />
 * For that this interface extends both, <b>BeforeLeaveObserver</b> and <b>AfterNavigationObserver</b> interface and
 * <b>provides a default implementation</b> for {@link BeforeLeaveObserver#beforeLeave(BeforeLeaveEvent)} and
 * {@link AfterNavigationObserver#afterNavigation(AfterNavigationEvent)}.
 * <p>
 * <b>Be aware of this when the component needs these interfaces for another reason!</b>
 * </p>
 * 
 * <p>
 * There are two ways to leave a page:
 * <ul>
 * <li>by brower: Reload page or to navigate to another page by browser.</li>
 * <li>vaadin's internal navigation that just replaces a part of the page</li>
 * </ul>
 * A component implementing this interface can handle both ways.
 * </p>
 * 
 */
public interface UnloadObserver extends BeforeLeaveObserver, AfterNavigationObserver
{
	void setOrigLocation(String orig);
	
	String getOrigLocation();
	
	boolean hasPendingChanges();
	
	@Override
	default void beforeLeave(BeforeLeaveEvent event)
	{
		
		if(this.hasPendingChanges())
		{
			this.updatePendingChangesIndicator(false);
			ContinueNavigationAction postpone = event.postpone();
			DialogConfirm.show(
				postpone::proceed,
				() -> this.onCancel(),
				"Unsaved Changes",
				"You have unsaved changes. Are you sure you want to leave this page anyway?");
			
		}
	}
	
	@Override
	default void afterNavigation(AfterNavigationEvent event)
	{
		// See https://github.com/vaadin/flow/issues/3619
		this.setOrigLocation(event.getLocation().getPathWithQueryParameters());
	}
	
	default void updatePendingChangesIndicator(boolean hasChanges)
	{
		UI.getCurrent().getPage().addJavaScript("../frontend/scripts/detectChanges.js", LoadMode.EAGER);
		
		if(hasChanges)
		{
			UI.getCurrent().getPage().executeJs("setChanges();");
		}
		else
		{
			UI.getCurrent().getPage().executeJs("resetChanges();");
		}
	}
	
	default void onCancel()
	{
		UI.getCurrent().getPage().addJavaScript("../frontend/scripts/detectChanges.js", LoadMode.EAGER);
		// Reset URL in browser nav bar
		// See https://github.com/vaadin/flow/issues/3619
		if(this.getOrigLocation() != null)
			UI.getCurrent().getPage().executeJs("history.replaceState({},'','" + this.getOrigLocation() + "');");
	}
}
