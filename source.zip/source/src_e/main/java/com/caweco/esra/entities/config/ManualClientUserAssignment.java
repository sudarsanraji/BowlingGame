package com.caweco.esra.entities.config;

import java.time.Instant;
import java.util.Objects;


/**
 * Indicates a manually added assignment of a user to a client.<br />
 * Such manual assignments won't be removed automatically if user's saml infos changes, e.g. if a user changes
 * company/department/...
 *
 */
public class ManualClientUserAssignment
{
	
	public ManualClientUserAssignment()
	{
		
	}
	
	public static ManualClientUserAssignment New(String assignedBy)
	{
		return new ManualClientUserAssignment(assignedBy);
	}
	
	private Instant	assignedAt	= Instant.now();
	private String	assignedBy;
	
	public ManualClientUserAssignment(String assignedBy)
	{
		super();
		Objects.requireNonNull(assignedBy);
		this.assignedBy = assignedBy;
	}
	
	public String getAssignedBy()
	{
		return this.assignedBy;
	}
	
	public Instant getAssignedAt()
	{
		return this.assignedAt;
	}
	
}
