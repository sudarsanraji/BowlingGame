package com.caweco.esra.business.report;

import java.util.HashMap;
import java.util.Map;

import com.vaadin.flow.component.UI;

import net.sf.jasperreports.engine.JasperReport;

public enum Reports
{
	BENEFICIAL_OWNER_LIST_SUBREPORT,
	ULTIMATE_BENEFICIARIES_LIST_SUBREPORT,
	COMPANY_INFORMATION,
	COMPANY_INFORMATION_SUBREPORT,
	HEADER,
	TOC,
	INTERMEDIARIES_LIST_SUBREPORT,
	GSSS_MATCHES_SUBREPORT,
	GSSS_MATCHES_SUBREPORT_IDENTIFICATIONS_SUBREPORT,
	GSSS_MATCHES_SUBREPORT_STRING_WRAPPER_SUBREPORT,
	GSSS_MATCHES_SUBREPORT_LINKED_PROFILES_SUBREPORT,
	QUESTIONNAIRE_RESULT,
	QUESTIONS_AND_ANSWERS_SUBREPORT,
	ESU,
	SCREENING_INFORMATION,
	HEADER_SUBREPORT,
	HEADER_SUBREPORT_SUBREPORT,
	FALSE_POSITIVES,
	GSSS_MATCHES_SUBREPORT_NO_FOOTER,
	SCREENING_INFORMATION_CHANGE_ENTRY_SUBREPORT,
	CREATED_LIST_SUBREPORT,
	SEAWEB;

	private static final Map<Reports, JasperReport> CACHE = new HashMap<>();

	public JasperReport get(final UI ui)
	{
		if (CACHE.get(this) == null)
		{
			CACHE.put(this, ReportUtils.loadReport(this.name().toLowerCase(), ui));
		}

		return CACHE.get(this);
	}
}
