package com.caweco.esra.ui.questionnaire.parts;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.caweco.esra.business.func.data.QuestionnaireEvaluationUtil;
import com.caweco.esra.business.utils.QuestionnaireUtils;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.QuestionnaireCategory;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;
import com.caweco.esra.ui.beans.DetailGroup;
import com.caweco.esra.ui.interfaces.HasQuestionnaireStatus;
import com.caweco.esra.ui.interfaces.HasScreening;
import com.caweco.esra.ui.part.watchlist.common.BeanWatchlistItemHeader;
import com.caweco.esra.ui.part.watchlist.common.WatchlistElementType;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.DetailsVariant;
import com.vaadin.flow.component.html.H3;


public class PartQuestionnaireOverview extends DetailGroup
{
	
	public enum Mode
	{
		PRESENTATION,
		READONLY, // NO_UCD - kept for data consistency purposes
		READWRITE;
	}
	
	private PartQuestionnaireOverview.Mode                   uiMode  = PartQuestionnaireOverview.Mode.READWRITE;
	private final HasScreening                                     parentPage;
	
	private final Map<PartFillinCategory, BeanWatchlistItemHeader> catList  = new LinkedHashMap<>();
	private final QuestionnaireResult                              result;
	private final QuestionnaireCategory                            qcategory;
	
	
	public PartQuestionnaireOverview(final HasScreening parent,
		final QuestionnaireResult result,
		final PartQuestionnaireOverview.Mode uiMode)
	{
		super();
		this.parentPage = parent;
		this.result = result;
		this.setUiMode(uiMode);
		
		this.initUI();
		this.getContent().setSizeFull();
		
		switch (this.result.getQuestionnaire().getCategory()) {
		case TRADE_SANCTION:
			this.parentPage.getScreening().setTradeSanctionResult(this.result);
			break;
		case BUSINESS_INFORMATION:
			this.parentPage.getScreening().setBusinessInformationResult(this.result);
			break;
		default:
			break;
		}
		
		this.qcategory = Optional.ofNullable(this.result.getQuestionnaire()).map(Questionnaire::getCategory).orElse(null);
		
		if (PartQuestionnaireOverview.Mode.PRESENTATION == uiMode)
		{
			this.buildContentUI_presentation();
		}
		else
		{
			
			this.buildContentUI();
		}
	}
	
	private void buildContentUI()
	{
		boolean                               isFirstDetail                         = true;
		
		final var allQuestions = this.result.getQuestionnaire().getQuestions(true);
		final var groupedQuestions = allQuestions.stream()
			.filter(qu -> Objects.nonNull(qu.getCategory()))
			.collect(Collectors.groupingBy(Question::getCategory));
		
		Details                               lastDetailElement                     = null;
		
		for (final QuestionCategory cat : this.result.getQuestionnaire().getCategories())
		{
			final BeanWatchlistItemHeader header = this.getHeader(cat);
			
			final Details                 el     = new Details();
			el.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
			el.setSummary(header);
			el.getElement().setAttribute("class", "screeningheader overview");
			el.setOpened(isFirstDetail);
			
			if (groupedQuestions.containsKey(cat))
			{
				final PartFillinCategory part = new PartFillinCategory(
					this,
					cat,
					this.result,
					groupedQuestions,
					allQuestions);
				
				el.addContent(part);
				
				this.catList.put(part, header);
			}
			
			this.add(el);
			isFirstDetail = false;
			lastDetailElement = el;
		}
		
		if (lastDetailElement != null)
		{
			final H3 endOf = new H3();
			endOf.setText("End of Questionnaire");
			endOf.setSizeUndefined();
			endOf.getElement().getStyle().set("padding", "1em");
			lastDetailElement.addContent(endOf);
		}
		
	}
	
	
	private void buildContentUI_presentation()
	{
		if (this.result != null && this.result.getQuestionnaire() != null)
		{
			final Map<QuestionCategory, List<Question>> questions_groupedByCategory_unordered = QuestionnaireUtils
				.getQuestions_groupedByCategory(this.result);
			
			for (final QuestionCategory cat : this.result.getQuestionnaire().getCategories())
			{
				final BeanWatchlistItemHeader header                  = this.getHeader(cat);
				final int                     resultScore_forCategory = QuestionnaireEvaluationUtil
					.getResultScore_forCategory(cat, this.result);
				header.setMarked(resultScore_forCategory);
				
				
				final Details el = new Details();
				el.addThemeVariants(DetailsVariant.REVERSE, DetailsVariant.SMALL);
				el.setSummary(header);
				el.getElement().setAttribute("class", "screeningheader overview");
				
				if (questions_groupedByCategory_unordered.containsKey(cat))
				{
					final PartFillInCategoryReadOnly part = new PartFillInCategoryReadOnly(this.result,
						questions_groupedByCategory_unordered.get(cat));
					el.addContent(part);
				}
				
				this.add(el);
			}
		}
	}
	
	private BeanWatchlistItemHeader getHeader(final QuestionCategory cat)
	{
		final BeanWatchlistItemHeader header = new BeanWatchlistItemHeader(
			WatchlistElementType.ESRA_QUESTCATEGORY,
			"",
			cat.getCategory());
		
		if (QuestionnaireCategory.BUSINESS_INFORMATION == this.qcategory)
		{
			header.hideTag();
		}
		else
		{
			header.setMarked(0);
		}
		return header;
	}
	
	public PartQuestionnaireOverview.Mode getUiMode()
	{
		return this.uiMode;
	}

	public void setUiMode(final PartQuestionnaireOverview.Mode uiMode)
	{
		this.uiMode = uiMode;
	}

	
	public HasScreening getParent_logical()
	{
		return this.parentPage;
	}


	public boolean getQuestionnaireProgress()
	{
		for (final PartFillinCategory partFillinCategory : this.catList.keySet())
		{
			if (!partFillinCategory.getQuestionCategoryProgress())
			{
				return false;
			}
		}
		return true;
	}
	
	public void updateCategoryResultScores()
	{
		this.catList.entrySet().forEach(entry ->
		{
			final int resultScore_forCategory = QuestionnaireEvaluationUtil
				.getResultScore_forCategory(entry.getKey().getQuestionCategory(), this.result);
			entry.getValue().setMarked(resultScore_forCategory);
		});
	}
	
	
	public QuestionnaireResult getResult()
	{
		return this.result;
	}
	
	
	public Set<PartFillinCategory> getCategoryParts_unmodifiable()
	{
			return Collections.unmodifiableSet(this.catList.keySet());	
	}
	
	public PartQuestionnaireOverview setHeight(final String height)
	{
		this.getContent().setHeight(height);
		return this;
	}
	
	public void onQuestionChange()
	{
		// Update Childern
		if (QuestionnaireCategory.TRADE_SANCTION == this.qcategory)
		{
			this.updateCategoryResultScores();
		}
		
		// Update Parent
		final HasQuestionnaireStatus statusUpdateReceiver = UIUtils.getNextParent(this, HasQuestionnaireStatus.class);
		if (statusUpdateReceiver != null)
		{
			final boolean questionnaireIsComplete = this.getQuestionnaireProgress();
			statusUpdateReceiver.setValidStatus(questionnaireIsComplete);
			statusUpdateReceiver.setResultScore(this.result.getResultScore());
		}
	}
	
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
	} // </generated-code>
	
}
