package com.caweco.esra.ui.part.watchlist.seawebimo;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.ui.part.watchlist.seawebimo.ck.KeyContentElemDarkActivity;
import com.caweco.esra.ui.part.watchlist.seawebimo.ck.KeyContentElemOwnerInfo;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

public class SeawebElementProvider
{
	
	private SeawebElementProvider()
	{
	}
	
	public static Component getElement(String key, SearchEntrySeaweb2Vessel item)
	{
		Div div = new Div();
		
		if (StringUtils.equalsIgnoreCase("shipDarkActivityIndicator", key))
		{
			KeyContentElemDarkActivity keyContent = new KeyContentElemDarkActivity();
			keyContent.setItem(item);
			return keyContent;
		}
		if (StringUtils.containsIgnoreCase(key, "shipOwner"))
		{
			KeyContentElemOwnerInfo keyContent = new KeyContentElemOwnerInfo();
			keyContent.setItem(item);
			return keyContent;
		}
		else
		{
			Label label = new Label("No further information available");
			div.add(label);
		}
		
		return div;
	}
	
}
