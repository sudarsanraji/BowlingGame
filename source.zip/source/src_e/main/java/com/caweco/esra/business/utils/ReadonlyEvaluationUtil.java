package com.caweco.esra.business.utils;

import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.ui.main.helper.ScreeningSearchResult;

public class ReadonlyEvaluationUtil
{
	
	private ReadonlyEvaluationUtil()
	{
	}
	
	public static Optional<String> evalEditableSetting_ESU(final Screening screening)
	{
		// not editable by default
		Optional<String> screeningNotEditableReason = Optional.of("Not editable by default.");
		
		if (!ScreeningDAO.existsInStorage(screening))
		{
			// Is new screening -> something is really wrong
			LoggerFactory.getLogger(ReadonlyEvaluationUtil.class).error("LOGIC failure: New screening was opened in ESU page.");
			return Optional.of("New items cannot be in ESU state");
		}
		
		if (screening == null)
		{
			screeningNotEditableReason = Optional.of("Screening not available.");
			return screeningNotEditableReason;
		}
		
		if (!ScreeningDAO.hasEsuState(screening))
		{
			screeningNotEditableReason = Optional.of("Not reviewable in state " + screening.getStatus().getStatus());
			return screeningNotEditableReason;
		}
		
		if (ScreeningDAO.hasFrozenState(screening))
		{
			screeningNotEditableReason = Optional.of("Screening is frozen.");
			return screeningNotEditableReason;
		}
		
		if (screening.getEsuWorker() != null && !Objects.equals(CurrentUtil.getUser(), screening.getEsuWorker()))
		{
			screeningNotEditableReason = Optional.of("You are not reviewer of this screening.");
			return screeningNotEditableReason;
		}
		
		if (!AuthorizationUtil.isEsuUser())
		{
			screeningNotEditableReason = Optional.of(" ");
			return screeningNotEditableReason;
		}
		
		// Allow
		return Optional.empty();
	}
	
	public static Optional<String> evalEditableSetting_ESRA(final Client client, final ScreeningSearchResult screening, final User currentUser)
	{
		// not editable by default
		Optional<String> screeningNotEditableReason = Optional.of("Not editable by default.");
		
		if (currentUser == null)
		{
			screeningNotEditableReason = Optional.of("User not available.");
			return screeningNotEditableReason;
		}
		
		if (screening == null)
		{
			screeningNotEditableReason = Optional.of("Screening not available.");
			return screeningNotEditableReason;
		}
		
		if (!ScreeningDAO.existsInStorage(client, screening.getId()))
		{
			// Is new screening -> allow here
			return Optional.empty();
		}
		
		if (screening.getStatus().isEsuState())
		{
			screeningNotEditableReason = Optional.of("Not editable in state " + screening.getStatus().getStatus());
			return screeningNotEditableReason;
		}
		
		if (screening.getStatus().isFrozenState())
		{
			screeningNotEditableReason = Optional.of("Screening is frozen.");
			return screeningNotEditableReason;
		}
		
		final boolean so = StringUtils.equalsIgnoreCase(currentUser.getEmailAddress(), screening.getScreeningOwnerEmail());
		final boolean ssu = StringUtils.equalsIgnoreCase(currentUser.getEmailAddress(), screening.getScreeningServiceUserEmail());
		if (!(so || ssu))
		{
			screeningNotEditableReason = Optional.of("You are neither ScreeningOwner nor ScreeningServiceUser of this entry.");
			return screeningNotEditableReason;
		}
		
		// Allow
		return Optional.empty();
	}
	
	public static Optional<String> evalEditableSetting_ESRA(final Screening screening, final User currentUser)
	{
		// not editable by default
		Optional<String> screeningNotEditableReason = Optional.of("Not editable by default.");
		
		if (screening == null)
		{
			screeningNotEditableReason = Optional.of("Screening not available.");
			return screeningNotEditableReason;
		}
		
		if (currentUser == null)
		{
			screeningNotEditableReason = Optional.of("User not available.");
			return screeningNotEditableReason;
		}
		
		if(screening.isArchived())
		{
			screeningNotEditableReason = Optional.of("Screening is archived.");
			return screeningNotEditableReason;
		}
		
		if (!ScreeningDAO.existsInStorage(screening))
		{
			// Is new screening -> allow here
			return Optional.empty();
		}
		

		

		
		if (ScreeningDAO.hasEsuState(screening))
		{
			screeningNotEditableReason = Optional.of("Not editable in state " + screening.getStatus().getStatus());
			return screeningNotEditableReason;
		}
		
		if (ScreeningDAO.hasFrozenState(screening))
		{
			screeningNotEditableReason = Optional.of("Screening is frozen.");
			return screeningNotEditableReason;
		}
		
		if (!ScreeningDAO.isScreeningUser(screening, currentUser))
		{
			screeningNotEditableReason = Optional.of("You are neither ScreeningOwner nor ScreeningServiceUser of this entry.");
			return screeningNotEditableReason;
		}
		
		// Allow
		return Optional.empty();
	}
	
}
