
package com.caweco.esra.subsidary.common;

import java.time.Instant;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SubsidiaryScreeningTaskDTO
{
	public final UUID                        id;
	public final Instant                     created;
	public final String                      createdBy;
	public final UUID                        clientId;
	public final UUID                        screeningId;
	public final UUID                        searchEntryCompanyId;
	public final String                      rootBvdId;
	public final String                      rootCompanyName;
	
	protected SubsidiaryScreeningTaskState   state;
	
	//// WorkingData
	protected boolean                        resultDataAvailableInBackend;
	protected boolean                        thisIsFromBackend;
	
	/**
	 * StatusData - Contains e.g. the error message or the reason why task was skipped.
	 */
	protected SubsidiaryScreeningTaskRunData runData;
	
	/**
	 * Subsidiaries Tree - available when Task is finished
	 */
	protected SubNode                        resultTree;
	
	/**
	 * Subsidiary Screening data - available from time when Task is finished until data are applied to screening<br />
	 * -> Not available in "applied" state
	 */
	protected SubsidiaryScreeningData     resultData;
	
	/**
	 * AppliedData -> Available in "applied" state
	 * Contains Infos about "applied" result
	 */
	protected SubsidiaryScreeningAppliedData appliedData;
	
	@JsonCreator
	public SubsidiaryScreeningTaskDTO(
		@JsonProperty("id") UUID id,
		@JsonProperty("created") Instant created,
		@JsonProperty("createdBy") final String createdBy,
		
		@JsonProperty("clientId") final UUID clientId,
		@JsonProperty("screeningId") final UUID screeningId,
		@JsonProperty("searchEntryCompanyId") final UUID searchEntryCompanyId,
		
		@JsonProperty("rootBvdId") final String rootBvdId,
		@JsonProperty("rootCompanyName") final String rootCompanyName,
		@JsonProperty("state") SubsidiaryScreeningTaskState state,
		
		@JsonProperty("resultDataAvailableInBackend") boolean resultDataAvailableInBackend,
		@JsonProperty("thisIsFromBackend") boolean thisIsFromBackend,
		@JsonProperty("runData") SubsidiaryScreeningTaskRunData runData,
		
		@JsonProperty("resultTree") SubNode resultTree,
		@JsonProperty("resultData") SubsidiaryScreeningData resultData,
		@JsonProperty("appliedData") SubsidiaryScreeningAppliedData appliedData)
	{
		super();
		this.id                           = id;
		this.created                      = created;
		this.createdBy                    = createdBy;
		this.clientId                     = clientId;
		this.screeningId                  = screeningId;
		this.searchEntryCompanyId         = searchEntryCompanyId;
		this.rootBvdId                    = rootBvdId;
		this.rootCompanyName              = rootCompanyName;
		this.state                        = state;
		this.resultDataAvailableInBackend = resultDataAvailableInBackend;
		this.thisIsFromBackend            = thisIsFromBackend;
		this.runData                      = runData;
		this.resultTree                   = resultTree;
		this.resultData                   = resultData;
		this.appliedData                  = appliedData;
	}

	public SubsidiaryScreeningTaskState getState()
	{
		return state;
	}

	public void setState(SubsidiaryScreeningTaskState state)
	{
		this.state = state;
	}

	public boolean isResultDataAvailableInBackend()
	{
		return resultDataAvailableInBackend;
	}

	public void setResultDataAvailableInBackend(boolean resultDataAvailableInBackend)
	{
		this.resultDataAvailableInBackend = resultDataAvailableInBackend;
	}

	public boolean isThisIsFromBackend()
	{
		return thisIsFromBackend;
	}

	public void setThisIsFromBackend(boolean thisIsFromBackend)
	{
		this.thisIsFromBackend = thisIsFromBackend;
	}

	public SubsidiaryScreeningTaskRunData getRunData()
	{
		return runData;
	}

	public void setRunData(SubsidiaryScreeningTaskRunData runData)
	{
		this.runData = runData;
	}

	public SubNode getResultTree()
	{
		return resultTree;
	}

	public void setResultTree(SubNode resultTree)
	{
		this.resultTree = resultTree;
	}

	public SubsidiaryScreeningData getResultData()
	{
		return resultData;
	}

	public void setResultData(SubsidiaryScreeningData resultData)
	{
		this.resultData = resultData;
	}

	public SubsidiaryScreeningAppliedData getAppliedData()
	{
		return appliedData;
	}

	public void setAppliedData(SubsidiaryScreeningAppliedData appliedData)
	{
		this.appliedData = appliedData;
	}

	public UUID getId()
	{
		return id;
	}

	public Instant getCreated()
	{
		return created;
	}

	public String getCreatedBy()
	{
		return createdBy;
	}

	public UUID getClientId()
	{
		return clientId;
	}

	public UUID getScreeningId()
	{
		return screeningId;
	}

	public UUID getSearchEntryCompanyId()
	{
		return searchEntryCompanyId;
	}

	public String getRootBvdId()
	{
		return rootBvdId;
	}

	public String getRootCompanyName()
	{
		return rootCompanyName;
	}
}
