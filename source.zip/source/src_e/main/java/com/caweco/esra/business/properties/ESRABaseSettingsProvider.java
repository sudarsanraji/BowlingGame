
package com.caweco.esra.business.properties;

import java.util.Locale;


public class ESRABaseSettingsProvider
{
	/**
	 * The app name
	 */
	public final static String APPNAME           = "ESRA";
	
	/**
	 * The current application Version
	 */
	public final static String VERSION           = "2.0.0.56";
	
	/**
	 * The path to a external configuration file.
	 */
	public final static String PATH              = "C:/storage/esra.properties";
	
	//// DEFAULT SETTINGS.
	
	/**
	 * The default Locale if not otherwise defined.
	 */
	public final static Locale DEFAULT_LOCALE    = Locale.ENGLISH;
	
	/**
	 * The default ZoneId-id if not otherwise defined.
	 */
	public final static String DEFAULT_ZONEID    = "Europe/Berlin";
	
}
