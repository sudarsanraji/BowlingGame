
package com.caweco.esra.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.jetbrains.annotations.Nullable;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.ClientDTO;
import com.caweco.esra.dto.ClientMetadataDTO;
import com.caweco.esra.dto.ManualClientUserAssignmentDTO;
import com.caweco.esra.dto.creator.ClientCreator;
import com.caweco.esra.dto.creator.ManualClientUserAssignmentCreator;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.config.ConfigRestEndpoint;
import com.caweco.esra.entities.config.ManualClientUserAssignment;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;
import com.caweco.esra.entities.esra.MatchCategoryTag;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class ClientDAO
{
	private static ObjectMapper om               = new ObjectMapper().findAndRegisterModules();
	
	public static final String  CL_CONFIG_CARA   = "/client/{clientId}/config/endpoints/bih";
	public static final String  CL_CONFIG_SEAWEB = "/client/{clientId}/config/endpoints/seaweb";
	
	
	public static Optional<ConfigRestEndpoint> getEndpointConfigurationBih(final String clientId)
	{
		final WebTarget            webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(CL_CONFIG_CARA)
			.resolveTemplate("clientId", clientId);
		try {
			ConfigRestEndpoint result    = webTarget.request().get(ConfigRestEndpoint.class);
			return Optional.ofNullable(result);
		}
		catch (Exception e) 
		{
			Logger.error(e);
			return Optional.empty();
		}
	}
	
	public static Optional<ConfigRestEndpoint> getEndpointConfigurationSeaweb(final String clientId)
	{
		final WebTarget            webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(CL_CONFIG_SEAWEB)
			.resolveTemplate("clientId", clientId);
		try {
			ConfigRestEndpoint result    = webTarget.request().get(ConfigRestEndpoint.class);
			return Optional.ofNullable(result);
		}
		catch (Exception e) 
		{
			Logger.error(e);
			return Optional.empty();
		}
	}
	
	public static void update(final Client client)
	{
		final ClientMetadataDTO        dto        = ClientCreator.convertClientToMetadataDto(client);
		
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid());
		Response               response   = webTarget.request().put(Entity.entity(dto, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		final WebTarget userSync = restClient.getMethodTarget("/client/" + client.getUuid() + "/syncUsers");
		
		response = userSync.request().post(Entity.entity(client.getUser(), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the client " + client.getClientDescription() + " to the system") ;
	}
	
	public static Set<Client> findAll()
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/all");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, ClientMetadataDTO.class);
		
		try
		{
			final Set<ClientMetadataDTO> dtoSet    = om.readValue(responseBody, type);
			
			final Set<Client>            clientSet = new HashSet<>();
			
			dtoSet.forEach(dto -> {
				clientSet.add(ClientCreator.convertMetadataDTOToClient(dto));
			});
			
			return clientSet;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static void insert(final Client client, final User currentUser) throws JsonProcessingException
	{
		final ClientDTO        dto        = ClientCreator.convertClientToDto(client);
		
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid());
		
		final Response         response   =
			webTarget.request().post(Entity.entity(om.writeValueAsString(dto), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the client " + client.getClientDescription() + " to the system") ;
	}
	
	
	public static Optional<Client> findById(final UUID clientID)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + clientID);
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final ClientMetadataDTO responseBody = response.readEntity(ClientMetadataDTO.class);
		return Optional.of(ClientCreator.convertMetadataDTOToClient(responseBody));
	}
	
	/* ********************************************************************** */
	
	public static void removeUser(final Client parent, final User user)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		final WebTarget        webTarget  =
			restClient.getMethodTarget("/client/" + parent.getUuid().toString() + "/user/remove/");
		
		final Response         response   = webTarget.request().post(Entity.entity(user, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the user "  + user.getFirstname() + " from the " +  parent.getClientDescription());

		
	}
	
	public static Set<Client> findByUser(final User user)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/user/" + user.getEmailAddress());
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, ClientMetadataDTO.class);
		
		try
		{
			final Set<ClientMetadataDTO> dtoSet    = om.readValue(responseBody, type);
			
			final Set<Client>            clientSet = new HashSet<>();
			
			dtoSet.forEach(dto -> {
				clientSet.add(ClientCreator.convertMetadataDTOToClient(dto));
			});
			
			return clientSet;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	
	public static Set<Client> findByUser_onlyAuto(final User user)
	{
		final Set<Client> collect =
			findAll().stream().filter(c -> {
				final boolean isAutoAssignedToThisClient = c.getUserFull(false).containsKey(user)
					&&
					c.getUserFull(false).get(user) == null;
				return isAutoAssignedToThisClient;
			}).collect(Collectors.toSet());
		return collect;
	}
	
	public static void
		addUser(final Client cl, final User user, @Nullable final ManualClientUserAssignment manualAssignment)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		final WebTarget        webTarget  =
			restClient.getMethodTarget("/client/" + cl.getUuid().toString() + "/user/add/");
		
		final Response         response   = webTarget.request().post(Entity.entity(ManualClientUserAssignmentCreator
			.convertToDTO(manualAssignment, UserCreator.convertUserToMetadataDTO(user)), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the user "  + user.getFirstname() + " to the client : " +  cl.getClientDescription());
		
	}
	
	public static Map<User, ManualClientUserAssignment> getUserFull(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/userFull/");
		
		final Response         response   = webTarget.request().get();
		
		if(response.getStatus() == 200)
		{
			Logger.tag("REST").info(response.toString());
			
			final String   responseBody = response.readEntity(String.class);
			
			final JavaType type         =
				om.getTypeFactory().constructCollectionType(Set.class, ManualClientUserAssignmentDTO.class);
			
			try
			{
				final Set<ManualClientUserAssignmentDTO>    dtoSet = om.readValue(responseBody, type);
				
				final Map<User, ManualClientUserAssignment> map    = new HashMap<>();
				
				dtoSet.forEach(dto -> {
					map.put(UserCreator.convertMetadataDTOToUser(dto.getUser()), dto.getUserAssignment());
				});
				
				return map;
			}
			catch(final JsonProcessingException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
				return new HashMap<>();
			}
		}
		else
		{
			return new HashMap<>();
		}
	}
	
	public static Set<OeRegion> getOeRegions(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/oeRegion/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 404)
		{
			return new HashSet<>();
		}
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, OeRegion.class);
		
		try
		{
			final Set<OeRegion> dtoSet = om.readValue(responseBody, type);
			
			return dtoSet;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<OE> getOe(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/oe/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 404)
		{
			return new HashSet<>();
		}
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, OE.class);
		
		try
		{
			final Set<OE> dtoSet = om.readValue(responseBody, type);
			
			return dtoSet;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<Function> getFunctions(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/function/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 404)
		{
			return new HashSet<>();
		}
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, Function.class);
		
		try
		{
			final Set<Function> dtoSet = om.readValue(responseBody, type);
			
			return dtoSet;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<String> getMatchRatingStatements(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/watchlist/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, String.class);
		
		try
		{
			final Set<String> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<String> getESUTags(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/esuTags/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, String.class);
		
		try
		{
			final Set<String> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<String> getESUCountries(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/esuCountry/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, String.class);
		
		try
		{
			final Set<String> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<String> getPRCCountries(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/prcCountry/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, String.class);
		
		try
		{
			final Set<String> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static List<MatchCategoryTag> getMatchRatingCategories(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  = restClient.getMethodTarget("/client/" + client.getUuid() + "/tag/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(List.class, MatchCategoryTag.class);
		
		try
		{
			final List<MatchCategoryTag> list = om.readValue(responseBody, type);
			
			return list;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<>();
		}
	}
	
	public static Set<Questionnaire> getQuestionnaires(final Client client)
	{
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget        webTarget  =
			restClient.getMethodTarget("/client/" + client.getUuid() + "/questionnaire/");
		
		final Response         response   = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         = om.getTypeFactory().constructCollectionType(Set.class, Questionnaire.class);
		
		try
		{
			final Set<Questionnaire> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Set<ComplianceScreeningKeyData> getSeaweb2ScreeningKeyConfig(final Client client)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();

		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/screeningKey/");
		
		final Response  response  = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String   responseBody = response.readEntity(String.class);
		
		final JavaType type         =
			om.getTypeFactory().constructCollectionType(Set.class, ComplianceScreeningKeyData.class);
		
		try
		{
			final Set<ComplianceScreeningKeyData> set = om.readValue(responseBody, type);
			
			return set;
		}
		catch(final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	/* ********************************************************************** */
	
}
