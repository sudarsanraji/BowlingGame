package com.caweco.esra.ui.part.watchlist.common;

public enum WatchlistElementType
{
	ESRA_WATCHLIST_ITEM,
	ESRA_WATCHLIST_SUBITEM,
	ESRA_QUESTCATEGORY,
	
	ESU_QUESTCATEGORY,
	ESU_WATCHLIST,
	ESU_WATCHLIST_ITEM,
	ESU_WATCHLIST_SUBITEM;
}
