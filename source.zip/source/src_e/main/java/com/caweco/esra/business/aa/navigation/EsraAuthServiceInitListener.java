package com.caweco.esra.business.aa.navigation;

import java.beans.Beans;

import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.VaadinServiceInitListener;


@SuppressWarnings("ucd") // required for Vaadin
public class EsraAuthServiceInitListener implements VaadinServiceInitListener
{
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public void serviceInit(final ServiceInitEvent event)
	{
		if(Beans.isDesignTime())
		{
			/*
			 * Controller in design time causes unwanted routing.
			 */
			return;
		}
		
		event.getSource().addUIInitListener(
			e ->
			{
				e.getUI().addBeforeEnterListener(new EsraAuthNavigationListener());
				// e.getUI().
			});
	}
	
}
