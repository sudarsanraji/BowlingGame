package com.caweco.esra.entities.questionnaire;

import java.util.List;
import java.util.Optional;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.Pair;
import com.caweco.esra.dao.questionnaire.QuestionDAO;

public class ConditionObject
{

	private Optional<Question> question;
	private ChooseableValues value;

	//Left: Questionnaire ID
	//Right: Question ID
	private Pair<Integer, Integer> questionIDs;

	public ConditionObject()
	{
		//for Jackson
	}

	public ConditionObject(
		final Pair<Integer, Integer> questionIDs,
		final Question question,
		final ChooseableValues value
	)
	{
		super();
		this.questionIDs = questionIDs;
		this.question = Optional.of(question);
		this.value = value;
	}

	public ConditionObject(final Pair<Integer, Integer> questionIDs, final ChooseableValues value)
	{
		super();
		this.questionIDs = questionIDs;
		this.question = Optional.empty();
		this.value = value;
	}

	public Question getQuestion(final boolean forceUpdate)
	{
		if (this.question.isPresent() && !forceUpdate)
		{
			return this.question.get();
		}

		this.question = QuestionDAO.findById(
			CurrentUtil.getClient().getUuid().toString(),
			this.questionIDs.getFirst(),
			this.questionIDs.getSecond()
		);

		return this.question.get();
	}

	public Question getQuestion(final List<Question> allQuestions)
	{
		if (this.question.isPresent())
		{
			return this.question.get();
		}

		this.question = allQuestions.stream().filter(q -> q.getId().equals(this.questionIDs.getSecond())).findFirst();

		return this.question.get();
	}

	public void setQuestion(final Question question)
	{
		this.question = Optional.of(question);
	}

	public Optional<Question> getQuestion()
	{
		return this.question;
	}

	public ChooseableValues getValue()
	{
		return this.value;
	}

	public void setValue(final ChooseableValues value)
	{
		this.value = value;
	}

	public Pair<Integer, Integer> getQuestionIDs()
	{
		return this.questionIDs;
	}

	public void setQuestionIDs(final Pair<Integer, Integer> questionIDs)
	{
		this.questionIDs = questionIDs;
	}

	/**
	 * Copies this {@link ConditionObject}, but referencing the {@link Question} of
	 * the <code>questions</code> list instead of {@link #getQuestion()}
	 */
	public ConditionObject copy(final List<Question> questions)
	{
		final var copy = new ConditionObject();
		if (this.question.isPresent())
		{
			questions.stream().filter(this.question.get()::equals).findAny().ifPresent(copy::setQuestion);
		}
		if (this.questionIDs != null)
		{
			copy.setQuestionIDs(new Pair<>(this.questionIDs.getFirst(), this.questionIDs.getSecond()));
		}
		if (this.value != null)
		{
			final var newValue = new ChooseableValues();
			newValue.setId(this.value.getId());
			newValue.setText(this.value.getText());
			newValue.setValue(this.value.getValue());
			copy.setValue(newValue);
		}
		return copy;
	}
}
