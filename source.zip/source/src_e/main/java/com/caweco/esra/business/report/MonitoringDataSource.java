package com.caweco.esra.business.report;

import java.util.Collection;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class MonitoringDataSource extends JRBeanCollectionDataSource {
	@FunctionalInterface
	public static interface Listener {
		void consume(final int finishedCount, final int totalCount);
	}

	private final Listener listener;
	private int finishedCount;

	public MonitoringDataSource(final Collection<?> beanCollection, final Listener listener) {
		this(beanCollection, listener, true);
	}

	public MonitoringDataSource(final Collection<?> beanCollection, final Listener consumer,
			final boolean isUseFieldDescription) {
		super(beanCollection, isUseFieldDescription);
		this.listener = consumer;
	}

	@Override
	public boolean next() {
		this.finishedCount++;
		listener.consume(finishedCount, this.getRecordCount());
		return super.next();
	}

	@Override
	public void moveFirst() {
		this.finishedCount = 0;
		super.moveFirst();
	}
}
