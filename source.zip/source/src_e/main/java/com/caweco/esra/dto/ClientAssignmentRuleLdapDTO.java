package com.caweco.esra.dto;

import java.time.Instant;
import java.util.Set;

import com.caweco.esra.entities.ldap.LdapOrg;
import com.caweco.esra.entities.saml.SamlCountry;

public class ClientAssignmentRuleLdapDTO {

	private Instant created;
	private AccessControlCompanyDTO company;
	private SamlCountry samlCountry;
	private LdapOrg department;
	
	private String id;
	private String clientId;
	private Set<RoleMetadataDTO> roles;
	
	public Instant getCreated() {
		return created;
	}
	public void setCreated(Instant created) {
		this.created = created;
	}
	public AccessControlCompanyDTO getCompany() {
		return company;
	}
	public void setCompany(AccessControlCompanyDTO company) {
		this.company = company;
	}
	public SamlCountry getSamlCountry() {
		return samlCountry;
	}
	public void setSamlCountry(SamlCountry samlCountry) {
		this.samlCountry = samlCountry;
	}
	public LdapOrg getDepartment() {
		return department;
	}
	public void setDepartment(LdapOrg department) {
		this.department = department;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public Set<RoleMetadataDTO> getRoles() {
		return roles;
	}
	public void setRoles(Set<RoleMetadataDTO> roles) {
		this.roles = roles;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
