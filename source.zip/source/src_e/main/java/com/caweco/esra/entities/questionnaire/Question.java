package com.caweco.esra.entities.questionnaire;

import java.util.Objects;
import java.util.UUID;

import com.rapidclipse.framework.server.resources.Caption;


public class Question
{
	private UUID uid;
	private Integer				id;
	private QuestionCategory	category;
	private String				questionText;
	private String				helperText;
	private Boolean				active		= true;
	private Boolean				standard	= true;
	private Rule		rule		= null;
	private String				instructionText;
	
	public Question()
	{
		super();
	}
	
	/**
	 * @param questionText
	 * @param helperText
	 * @param active
	 * @param standard
	 * @param rule
	 */
	public Question(final String questionText, final String helperText, final Boolean active, final Boolean standard)
	{
		super();
		this.questionText = questionText;
		this.helperText = helperText;
		this.active = active;
		this.standard = standard;
	}
	
	public UUID getUid()
	{
		return uid;
	}

	public void setUid(UUID uid)
	{
		this.uid = uid;
	}
	
	public QuestionCategory getCategory()
	{
		return this.category;
	}
	
	public void setCategory(final QuestionCategory category)
	{
		this.category = category;
	}
	
	@Caption("Rule")
	public Rule getRule()
	{
		return this.rule;
	}
	
	public void setRule(final Rule rule)
	{
		this.rule = rule;
	}
	
	@Caption("Question")
	public String getQuestionText()
	{
		return this.questionText;
	}
	
	public void setQuestionText(final String questionText)
	{
		this.questionText = questionText;
	}
	
	@Caption("Hint")
	public String getHelperText()
	{
		return this.helperText;
	}
	
	public void setHelperText(final String helperText)
	{
		this.helperText = helperText;
	}
	
	@Caption("Instruction")
	public String getInstructionText()
	{
		return this.instructionText;
	}
	
	public void setInstructionText(final String instructionText)
	{
		this.instructionText = instructionText;
	}
	
	@Caption("Active")
	public Boolean getActive()
	{
		return this.active;
	}
	
	public void setActive(final Boolean active)
	{
		this.active = active;
	}
	
	@Caption("Default")
	public Boolean getStandard()
	{
		return this.standard;
	}
	
	public void setStandard(final Boolean standard)
	{
		this.standard = standard;
	}
	
	
	@Caption("ID")
	public Integer getId()
	{
		return this.id;
	}
	
	public void setId(final Integer id)
	{
		this.id = id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.id);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (this.getClass() != obj.getClass())
		{
			return false;
		}
		final Question other = (Question) obj;
		return Objects.equals(this.id, other.id);
	}
	
	public Question copyNoRules()
	{
		final var copy = new Question();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		return copy;
	}


	
}
