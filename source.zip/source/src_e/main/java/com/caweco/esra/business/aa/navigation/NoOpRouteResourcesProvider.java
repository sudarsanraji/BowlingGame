package com.caweco.esra.business.aa.navigation;

import java.util.Collection;

import com.rapidclipse.framework.security.authorization.Resource;
import com.rapidclipse.framework.server.security.authorization.RouteResourcesProvider;


public class NoOpRouteResourcesProvider implements RouteResourcesProvider
{
	
	@Override
	public Collection<Resource> getResourcesFor(Class<?> target)
	{
		return null;
	}
	
}
