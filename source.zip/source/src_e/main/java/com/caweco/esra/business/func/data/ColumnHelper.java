package com.caweco.esra.business.func.data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.OptionalInt;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.namematch.BvdMatch;
import com.caweco.esra.entities.rest.seaweb2.APSDarkActivityConfirmed_v2;


public class ColumnHelper
{
	
	private static final Logger LOG = LoggerFactory.getLogger(ColumnHelper.class);
	public static DateTimeFormatter seaweb2DatePattern1 = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	
	public static Integer getColumnValue_BvdMatch_HitScore(BvdMatch it)
	{
		if(it == null)
		{
			return null;
		}
		else
		{
			return (int)Math.round(it.getScore() * 100);
		}
	}
	
	public static Integer getColumnValue_GsssMatch_HitScoreNormalized(GsssMatch it)
	{
		if(it == null)
		{
			return null;
		}
		else
		{
			return (int)Math.round(it.getHitScoreNormalized());
		}
	}
	
	public static String getCSSClass_ComplianceScreeningKeyData_redFlag(ComplianceScreeningKeyData it)
	{
		if (it == null || !it.isActive()) {
			return "undefined";
		}

		OptionalInt max = it.getAvailableValues().stream().filter(Objects::nonNull).mapToInt(Integer::intValue).max();
		if (it.getMinValueForRed() > max.orElse(0))
		{
			return "green";
		}
		else {
			return "red";
		}
	}
	
	public static LocalDateTime getColumnValue_APSDarkActivityConfirmed_v2_DarkTime(APSDarkActivityConfirmed_v2 it)
	{
		
		String dateString = StringUtils.stripToNull(it.getDarkTime());
		if (dateString == null)
			return null;
		
		LocalDateTime dateTime = LocalDateTime.parse(dateString, seaweb2DatePattern1);
		return dateTime;
	}
	
	
}
