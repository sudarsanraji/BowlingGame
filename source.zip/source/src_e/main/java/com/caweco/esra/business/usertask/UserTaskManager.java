package com.caweco.esra.business.usertask;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.caweco.esra.subsidary.common.usertask.UserTask;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningCachedTask;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;
import com.caweco.esra.subsidary.frontend.SubsidiaryTaskDAO;
import com.caweco.esra.subsidary.frontend.SubsidiaryTaskManager;
import com.vaadin.flow.shared.Registration;

public class UserTaskManager
{
	static ConcurrentHashMap<String, UserTask> CACHE              = new ConcurrentHashMap<>();
	
	static Executor                            executor           = Executors.newSingleThreadExecutor();
	
	
	//// TASK STATE CHANGES
	
	static LinkedList<Consumer<String>>        taskStateListeners = new LinkedList<>();
	
	public static synchronized Registration registerTaskStateListener(Consumer<String> listener)
	{
		taskStateListeners.add(listener);
		
		return () ->
		{
			synchronized (SubsidiaryTaskManager.class)
			{
				taskStateListeners.remove(listener);
			}
		};
	}
	
	public static synchronized void notifyOnTaskStateChange(String taskId)
	{
		for (Consumer<String> listener : taskStateListeners)
		{
			executor.execute(() -> listener.accept(taskId));
		}
	}
	
	/**
	 * Search for task in {@link UserTaskManager#CACHE}, from {@link SubsidiaryTaskManager#getCachedTask(String)} and from
	 * backend.
	 * 
	 * @param taskId
	 * @return
	 */
	public static UserTask getTask(String taskId)
	{
		UserTask userTask = CACHE.get(taskId);
		if (userTask != null)
		{
			return userTask;
		}
		
		SubsidiaryScreeningCachedTask cachedTask = SubsidiaryTaskManager.getCachedTask(taskId);
		if (cachedTask != null)
		{
			return cachedTask;
		}
		
		SubsidiaryScreeningTaskF task_byTaskID = SubsidiaryTaskDAO.getTask_byTaskID(taskId);
		return task_byTaskID;
	}
	
	/**
	 * Tasks from {@link UserTaskManager#CACHE} and from backend.
	 * 
	 * @param userId
	 * @return
	 */
	public static List<UserTask> getTasksForUser(String userId)
	{
		List<UserTask> tasks = Stream.concat(CACHE.values().stream()
			.filter(ut -> Objects.equals(ut.getUser(), userId)), SubsidiaryTaskDAO.getTasks_ByUser(userId).stream())
			.collect(Collectors.toList());
		
		tasks.sort(Comparator.comparing(UserTask::getCreated));
		
		return tasks;
	}
}
