package com.caweco.esra.ui.interfaces;

public interface HasQuestionnaireStatus
{
	public void setValidStatus(boolean isValid);
	
	public Boolean getValidStatus();
	
	default void setResultScore(Integer score)
	{
	}
	
	default Integer getResultScore()
	{
		return null;
	}
}
