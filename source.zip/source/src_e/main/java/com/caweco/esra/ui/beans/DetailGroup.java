package com.caweco.esra.ui.beans;

import java.util.Objects;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.details.Details;
import com.vaadin.flow.component.details.Details.OpenedChangeEvent;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.dom.ClassList;


public class DetailGroup extends Composite<Div>
{
	
	public DetailGroup()
	{
		super();
		this.getContent().getElement().getClassList().add("esra-common-innerscroll");
	}
	
	public void add(Details... components)
	{
		Objects.requireNonNull(components, "Components should not be null");
		for(Details component : components)
		{
			Objects.requireNonNull(component, "Component to add cannot be null");
			
			component.getElement().getClassList().add("esra-common-innerscroll");
			this.getContent().add(component);
			component.addOpenedChangeListener(this::recalcOpened);
		}
	}
	
	protected void recalcOpened(OpenedChangeEvent event)
	{
		
		boolean atLeastOneDetailsChildIsOpened =
			this.getContent().getChildren().filter(Details.class::isInstance).map(Details.class::cast).filter(
				Details::isOpened).findFirst().isPresent();
		if(atLeastOneDetailsChildIsOpened)
		{
			this.getContent().getElement().setAttribute("hasOpenChild", "");
		}
		else
		{
			this.getContent().getElement().removeAttribute("hasOpenChild");
		}
	}
	
	public ClassList getClassNames()
	{
		return this.getContent().getClassNames();
	}
	
}
