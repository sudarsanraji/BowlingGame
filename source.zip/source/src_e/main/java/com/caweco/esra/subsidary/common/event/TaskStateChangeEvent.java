
package com.caweco.esra.subsidary.common.event;

import java.time.Instant;
import java.util.UUID;

import com.caweco.esra.subsidary.common.usernotifications.UserNotification;



public class TaskStateChangeEvent implements UserNotification
{
	public static TaskStateChangeEvent New(String message, String targetUserId, String taskId)
	{
		return new TaskStateChangeEvent(message, targetUserId, taskId);
	}
	
	final Instant created = Instant.now();
	final String  id      = UUID.randomUUID().toString();
	final String  message;
	final String  targetUserId;
	final String  taskId;
	
	protected TaskStateChangeEvent(String message, String targetUserId, String taskId)
	{
		this.message = message;
		this.targetUserId  = targetUserId;
		this.taskId = taskId;
	}
	
	@Override
	public String getTargetUserId()
	{
		return targetUserId;
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}
	
	@Override
	public String getId()
	{
		return id;
	}
	
	@Override
	public Instant getCreated()
	{
		return created;
	}
	
	public String getTaskId()
	{
		return taskId;
	}
	
}
