
package com.caweco.esra.dev.mockup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import org.jetbrains.annotations.Nullable;
import org.tinylog.Logger;

import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.general.Subsidiary;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.entities.rest.information.CompanyInfo;


public class MockDataProviderCompany
{
	
	static ConcurrentHashMap<String, CIResponse> CACHE = new ConcurrentHashMap<>();
	
	public static class DummyCompany
	{
		
		public final String name;
		public final String bvdId;
		
		public DummyCompany(final String name, final String bvdId)
		{
			super();
			this.name  = name;
			this.bvdId = bvdId;
		}
		
	}
	
	public static CIResponse getOrGenerateCompanyInfoFor(final String bvdId)
	{
		if(MockDataProviderCompany.CACHE.containsKey(bvdId))
		{
			Logger.info("Found CIResponse for {} in Cache.", bvdId);
			return MockDataProviderCompany.CACHE.get(bvdId);
		}
		
		final Optional<DummyCompany> findFirst           =
			MockDataProviderCompany.BASE_COM.stream().filter(dc -> Objects.equals(dc.bvdId, bvdId)).findFirst();
		CIResponse                   generatedCIResponse = null;
		if(findFirst.isPresent())
		{
			Logger.info("Found DummyCompany for {} in BaseList.", bvdId);
			generatedCIResponse = MockDataProviderCompany.generateCIResponse(findFirst.get());
		}
		else
		{
			Logger.info("Found \"{}\" nowhere.", bvdId);
			generatedCIResponse =
				MockDataProviderCompany.generateCIResponse(bvdId,
					MockDataProviderCompany.generateCompanyNameFor(bvdId));
		}
		MockDataProviderCompany.CACHE.put(bvdId, generatedCIResponse);
		
		return generatedCIResponse;
	}
	
	/////////////////////////////
	
	/////////////////////////////
	
	/**
	 * Generate a random BvdId
	 *
	 * @return a bvdId
	 */
	public static String generateRandomBvdId()
	{
		final StringBuilder sb = new StringBuilder();
		sb.append(
			MockDataProviderCompany.BASE_DUMMY_COUNTRIES
				.get(MockDataProviderCompany.rInt(0, MockDataProviderCompany.BASE_DUMMY_COUNTRIES.size())));
		sb.append(String.format("%08d", MockDataProviderCompany.rInt(100000, 1000000)));
		return sb.toString();
	}
	
	public static String generateCompanyNameFor(final String bvdId)
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("Generated ").append(bvdId).append(" Inc.");
		return sb.toString();
	}
	
	static CIResponse generateCIResponse(final DummyCompany root)
	{
		// exclude self
		final List<Subsidiary> subs_      = MockDataProviderCompany.generateSubsidiaryList();
		CIResponse             cIResponse = NewCIResponse(root.name, root.bvdId, subs_);
		
		if(ThreadLocalRandom.current().nextBoolean())
		{
			CompanyGsssMatch it = generateRedFlagCompanyGssMatch();
			cIResponse.getBenOwnGsssMatchResults().put("benOwn1GsssMatchResults", it);
		}
		return cIResponse;
	}
	
	/**
	 * Use only if bvdId is not in DummyCompany list !!
	 *
	 * @param bvdId
	 * @param name
	 * @return
	 */
	public static CIResponse generateCIResponse(final String bvdId, final String name)
	{
		final List<Subsidiary> subs_      = MockDataProviderCompany.generateSubsidiaryList();
		CIResponse             cIResponse = NewCIResponse(name, bvdId, subs_);
		
		if(ThreadLocalRandom.current().nextBoolean())
		{
			CompanyGsssMatch it = generateRedFlagCompanyGssMatch();
			cIResponse.getBenOwnGsssMatchResults().put("benOwn1GsssMatchResults", it);
		}
		return cIResponse;
	}
	
	private static CompanyGsssMatch generateRedFlagCompanyGssMatch()
	{
		CompanyGsssMatch c = new CompanyGsssMatch("Hans Peter Franz Schmidt");
		c.setNumberOfHits("1");
		c.setStatusMessage("OK / CompanyGsssMatch");
		
		GsssMatch g = new GsssMatch();
		g.setHitScore(120.0d);
		g.setName("Hans Peter Franz Schmidt");
		g.getCategories().put("category1", "Politically Exposed Person (PEP)");
		g.getCategories().put("category2", "Special Interest Person (SIP)-Sanctions Lists");
		g.setGender("Unknown");
		c.getGsssMatchResults().add(g);
		return c;
	}
	
	///////////////////////
	//
	// Subsidiary generation
	//

	/**
	 * Get List with random number of Subsidiary items (0..10 items)
	 *
	 * @return
	 */
	static List<Subsidiary> generateSubsidiaryList()
	{
		// exclude self
		final List<DummyCompany> subs  = MockDataProviderCompany.rDC(MockDataProviderCompany.rInt(0, 11));
		
		final List<Subsidiary>   subs_ =
			subs.stream().map(sub -> MockDataProviderCompany.generateSubsidiary(sub, null))
				.collect(Collectors.toList());
		
		return subs_;
	}
	
	static Subsidiary generateSubsidiary(final DummyCompany it, @Nullable final Float anteilDirect)
	{
		final int anteilDirect_ =
			(anteilDirect != null && anteilDirect > 0) ? MockDataProviderCompany.toTwoDigitSpecial(anteilDirect)
				: MockDataProviderCompany.rInt(100, 10001);
		
		///// Generate AnteilTotal
		
		String    anteilTotal_  = "n.a";                                                                        // means
																												// "unknown"
		if(anteilDirect_ > 9500)
		{
			anteilTotal_ = "100.00";
		}
		else
		{
			final boolean unknown = ThreadLocalRandom.current().nextBoolean();
			if(!unknown)
			{
				anteilTotal_ = (MockDataProviderCompany.rInt(anteilDirect_ - 1, 10001) / 100f) + "";
			}
		}
		
		return NewSubsidiary(it.name, it.bvdId, (anteilDirect_ / 100f) + "", anteilTotal_);
	}
	
	/**
	 * Get a certain number of different DummyCompanies
	 *
	 * @param number
	 * @param exclusions
	 *            DummyCompanies that may not be in result
	 * @return
	 */
	public static List<DummyCompany> rDC(final int number, final DummyCompany... exclusions)
	{
		final ArrayList<DummyCompany> base = new ArrayList<>(MockDataProviderCompany.BASE_COM);
		if(exclusions != null)
		{
			base.removeAll(Arrays.asList(exclusions));
		}
		
		final List<DummyCompany> returns = new ArrayList<>();
		for(int i = 1; i <= number; i++)
		{
			final int          index        = MockDataProviderCompany.rInt(0, base.size());
			final DummyCompany dummyCompany = base.get(index);
			base.remove(index);
			returns.add(dummyCompany);
		}
		
		return returns;
	}
	
	static int toTwoDigitSpecial(final float f)
	{
		 final float f1_b = f * 100;
		 final int intValue = (int) f1_b;
		 return intValue;
	}
	
	//////////////////////
	//
	//
	//
	
	//////////////////////
	//
	//
	//
	
	/**
	 * See {@link ThreadLocalRandom#nextInt(int, int)}
	 *
	 * @param min
	 * @param max
	 * @return
	 */
	static int rInt(final int min, final int max)
	{
		return ThreadLocalRandom.current().nextInt(min, max);
	}
	
	static List<String>       BASE_DUMMY_COUNTRIES =
		List.of("XDE", "XCH", "XUS", "XPC", "XRU", "XFR", "XBR", "XVAE", "XTU");
	
	static List<String>       BASE_NAMES           = List.of("TAUI", "AGW", "AS Data",
		"Wolff AG", "Hummel Kopp AG & Co. KGaA", "Kaiser Rohde KG", "Kroll", "Fiedler Menzel GmbH",
		"Dorn GmbH & Co. KG", "Brückner GmbH & Co. KG", "Beyer GmbH", "Decker AG", "Keller AG", "Hammer AG",
		"Stein GmbH", "Engelmann GmbH", "Heinz Lorenz GmbH", "Kern AG", "Stadler Heinemann AG", "Herzog", "Stumpf",
		"Ehlers GmbH & Co. OHG", "Eckert GmbH & Co. KG", "Hentschel", "Gerlach OHG mbH", "Pape Reuter GmbH",
		"Weiss Groß GmbH", "Sauter", "Michel Esser GmbH & Co. KG", "Fadel-Moen", "Lubowitz, Mayert and Anderson",
		"Russel, Cronin and Bailey", "Cruickshank-Lemke", "Purdy-Schuppe", "Schumm, Miller and Altenwerth",
		"Boyle Group", "Johns, Cummings and Bednar", "Bartoletti, Kohler and Mohr", "O'Reilly-Spencer",
		"Considine-Senger",
		"Cruickshank-Walter", "Schulist, Fay and Hegmann", "Cormier-Erdman", "Tremblay-Swift", "Gleichner LLC",
		"Dicki, Bernhard and Schaden", "Stark Group", "Torp-O'Hara", "Renner Inc", "Denesik, O'Keefe and Rempel",
		"Jones-Schuster", "Bayer, Borer and Krajcik", "Altenwerth-Dibbert", "Rohan Group", "Shields Group",
		"Hansen-Herzog", "Pollich, Homenick and Schimmel", "Bode PLC", "Berge Group", "Fahey-O'Conner",
		"Miller-Shanahan", "Robel and Sons", "Bergnaum-Nienow", "Ruecker Group", "Powlowski Ltd", "Balistreri Ltd",
		"Johnson-Rohan", "Padberg PLC", "Hills-Langosh", "Schamberger, Yundt and Emard", "Mills-Lesch", "Kub LLC",
		"Romaguera Group", "Abernathy Ltd", "Beier, Cummerata and Kozey", "Leuschke Group", "Roberts LLC",
		"Schiller, Marquardt and Wintheiser", "Mitchell, Hackett and Hackett", "Dumont S.A.R.L.", "Bouvet Vincent SARL",
		"Barbe", "Gregoire SA", "Grenier", "Dupuy Gomes SA", "Maurice S.A.R.L.", "Guillot", "Charpentier",
		"Barbier", "Georges", "Toussaint", "Berthelot", "Hamel", "Reynaud S.A.", "Brunet SARL", "Molina e Reis",
		"Zaragoça S.A.", "Quintana Comercial Ltda.", "Valência e Esteves", "Chaves-Jimenes", "Urias-Oliveira",
		"Carmona e Camacho", "Madeira-Lira", "Gonçalves Ltda.", "Barreto Comercial Ltda.", "Serna e Queirós e Filhos",
		"Ferraz-Aranda", "Colaço e Filhos", "Ramires e das Dores", "Oliveira e Filhos", "Ferreira e Mascarenhas",
		"Uchoa e de Aguiar", "Carmona Comercial Ltda.", "Ortega e Paz Ltda.", "Martines e Associados",
		"Rosa Comercial Ltda.", "Reis e Gusmão e Associados", "Fernandes-Romero", "Casanova e Velasques",
		"Galhardo-Oliveira", "Beltrão Comercial Ltda.", "Paes-Dominato", "Verdugo S.A.", "Batista e Verdugo S.A.",
		"Montenegro e Zambrano",
		"Paz e Teles", "Ortega-Gomes", "Aragão e Queirós", "Garcia-Paes", "Valentin Comercial Ltda.",
		"Aragão e Associados", "Teles-das Dores", "Meireles e Vale S.A.", "Batista S.A.", "Valdez Comercial Ltda.",
		"Marinho e Marinho", "Ferreira S.A.", "Kinnula-Nikula", "Karvonen Tmi.", "Aija, Haapasalo and Äyräs",
		"Linnala RY", "Nurkkala, Jauhiainen and Vanhoja", "Tuominen, Mujunen and Melasniemi", "Suutarinen-Suosalo",
		"Aitomaa OY AB", "Vesa-Väätänen", "Pirttijärvi-Syrjä", "Kannelmäki OY", "Ilmarinen Inc.", "Mielonen-Pakola",
		"Raiski-Keskioja", "Paakkanen-Viinikka", "Simonen-Litmanen", "Valo, Rantamaa and Oja", "Lehtisalo Ltd",
		"Peuranen Ltd", "Sadloňová-Kopecká", "Růžičková, Veselý and Holubová", "Tóthová, Medveď and Zelenayová",
		"Nemcová, Šouc and Šimonová", "Taliánová, Cyprich and Holubová", "Máliková-Staneková", "Hrdá-Gonová",
		"Dzurjanin-Mečíř", "Staneková a.s.", "Šurka, Švehla and Labuda");
	
	/**
	 * MUST BE AFTER "BASE_NAMES"!!!
	 *
	 * @return
	 */
	
	static List<DummyCompany> BASE_COM             = MockDataProviderCompany.generateBaseCompanies();
	
	static List<DummyCompany> generateBaseCompanies()
	{
		// create unique IDs
		final Set<String> ids = new HashSet<>(MockDataProviderCompany.BASE_NAMES.size());
		while(ids.size() < MockDataProviderCompany.BASE_NAMES.size())
		{
			ids.add(MockDataProviderCompany.generateRandomBvdId());
		}
		final ArrayList<String>  ids_ = new ArrayList<>(ids);
		
		// create DummyCompany items
		final List<DummyCompany> cl   = new ArrayList<>(MockDataProviderCompany.BASE_NAMES.size());
		for(int i = 0; i < MockDataProviderCompany.BASE_NAMES.size(); i++)
		{
			cl.add(new DummyCompany(MockDataProviderCompany.BASE_NAMES.get(i), ids_.get(i)));
		}
		
		Logger.info("Generated {} base DummyCompany items from {} names", cl.size(),
			MockDataProviderCompany.BASE_NAMES.size());
		
		return cl;
	}
	
	//
	//
	//
	//
	
	public static Subsidiary
		NewSubsidiary(final String name, final String bvdId, final String direct, final String total)
	{
		Subsidiary subsidiary = new Subsidiary();
		subsidiary.setName(name);
		subsidiary.setBvdId(bvdId);
		subsidiary.setDirect(direct);
		subsidiary.setTotal(total);
		return subsidiary;
	}
	
	public static CIResponse NewCIResponse(final String name, final String bvdId, final List<Subsidiary> subsidiaries)
	{
		final CIResponse it = new CIResponse();
		CompanyInfo      ci = new CompanyInfo();
		ci.setName(name);
		it.setStatusMessage(new String[] {"OK"});
		ci.setSubsidiaryData(toSubsidiaryMap(subsidiaries));
		
		it.setCompanyBvdId(bvdId);
		it.setCompanyInfoBvd(ci);
		
		return it;
	}
	
	protected static Map<String, Subsidiary> toSubsidiaryMap(final List<Subsidiary> subsidiaries)
	{
		if(subsidiaries == null || subsidiaries.isEmpty())
		{
			return null;
		}
		else
		{
			Map<String, Subsidiary> subsidiaryData = new HashMap<>();
			for(int i = 0; i < subsidiaries.size(); i++)
			{
				final Subsidiary sub = subsidiaries.get(i);
				subsidiaryData.put("subsidiary" + i, sub);
			}
			return subsidiaryData;
		}
	}
	
}
