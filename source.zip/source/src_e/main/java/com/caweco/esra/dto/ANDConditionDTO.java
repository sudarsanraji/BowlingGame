package com.caweco.esra.dto;

import java.util.HashSet;
import java.util.Set;

public class ANDConditionDTO {
	private Set<ConditionObjectDTO> ands = new HashSet<>();

	public Set<ConditionObjectDTO> getAnds() {
		return ands;
	}

	public void setAnds(Set<ConditionObjectDTO> ands) {
		this.ands = ands;
	}
	
	
}
