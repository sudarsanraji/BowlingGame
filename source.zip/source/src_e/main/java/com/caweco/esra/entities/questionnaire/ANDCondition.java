package com.caweco.esra.entities.questionnaire;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


public class ANDCondition
{
	/**
	 * Conditions, ALL must be valid. [Connected with AND]
	 */
	private Set<ConditionObject> ands = new HashSet<>();
	
	/**
	 * 
	 */
	public ANDCondition()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param ands
	 */
	public ANDCondition(final HashSet<ConditionObject> ands)
	{
		super();
		this.ands = ands;
	}
	
	/**
	 * Sub-Conditions, ALL must be valid. [Connected with <b>AND</b>]<br />
	 * 
	 * @return
	 */
	public Set<ConditionObject> getAnds()
	{
		return this.ands;
	}
	
	public void setAnds(final Set<ConditionObject> ands)
	{
		this.ands = ands;
	}

	public ANDCondition copy(final List<Question> questions)
	{
		final var copy = new ANDCondition();
		if(this.ands != null)
		{
			copy.setAnds(this.ands.stream()
				.map(c-> c.copy(questions))
				.collect(Collectors.toSet()));
		}
		return copy;
	}
}
