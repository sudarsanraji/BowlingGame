package com.caweco.esra.entities.questionnaire;

import java.util.List;


public interface HasChooseableValues
{
	public List<ChooseableValues> getValues();
	
	public void setValues(List<ChooseableValues> values);
}
