package com.caweco.esra.business.func.data;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.jetbrains.annotations.Nullable;


public class DataHelper
{
	public static <T> List<T> toList(@Nullable Set<T> in, @Nullable Comparator<T> sort)
	{
		List<T> out = Optional.ofNullable(in).map(item -> new ArrayList<T>(item)).orElse(new ArrayList<T>());
		if(sort != null)
		{
			out.sort(sort);
		}
		return out;
	}
}
