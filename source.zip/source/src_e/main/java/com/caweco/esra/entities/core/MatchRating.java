package com.caweco.esra.entities.core;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;


public enum MatchRating
{
	TRUE_FINDING("True finding"),
	FALSE_POSITIVE("False positive"),
	UNKNOWN("Unclear");
	
	private String representation;
	
	private MatchRating(final String representation)
	{
		this.representation = representation;
	}
	
	public String getRepresentation()
	{
		return this.representation;
	}
	
	public static Stream<MatchRating> stream()
	{
		return Stream.of(MatchRating.values());
	}
	
	public static List<MatchRating> asList_byRepresentation()
	{
		return MatchRating.stream().sorted(
			Comparator.comparing(
				MatchRating::getRepresentation,
				Comparator.nullsFirst(Comparator.naturalOrder()))).collect(Collectors.toList());
	}
	
	/**
	 * Maps input String to MatchRating. <br />
	 * If String is <code>null</code> or cannot be mapped, returns <b>MatchRating.UNKNOWN</b>.
	 * 
	 * @param ratingName
	 * @return
	 */
	public static MatchRating toRating(final String ratingName)
	{
		final String in = StringUtils.stripToNull(ratingName);
		if(in == null)
		{
			return MatchRating.UNKNOWN;
		}
		// @formatter:off
		final MatchRating mappedTo =
			MatchRating.stream()
			.filter(rating -> StringUtils.equals(rating.name(), in))
			.findFirst().orElse(MatchRating.UNKNOWN);
		// @formatter:on
		return mappedTo;
	}
}
