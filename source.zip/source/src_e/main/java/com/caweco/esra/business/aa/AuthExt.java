package com.caweco.esra.business.aa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.onelogin.saml2.Auth;
import com.onelogin.saml2.authn.SamlResponse;
import com.onelogin.saml2.exception.Error;
import com.onelogin.saml2.exception.SettingsException;
import com.onelogin.saml2.http.HttpRequest;
import com.onelogin.saml2.servlet.ServletUtils;
import com.onelogin.saml2.settings.Saml2Settings;


/**
 * Replacement for {@link Auth#processResponse(String)}
 * to manipulate "Destination Url". <br />
 * This may be necessary in situations when a external proxy changes the connection from "http" to "https".
 * 
 */
public class AuthExt
{
	
	private static final Logger			LOGGER			= LoggerFactory.getLogger(AuthExt.class);
	
	private final Saml2Settings			settings;
	private final HttpServletRequest	request;
	
	private String						nameid;
	private String						nameidFormat;
	private String						sessionIndex;
	private DateTime					sessionExpiration;
	private String						lastMessageId;
	private String						lastAssertionId;
	private List<Instant>				lastAssertionNotOnOrAfter;
	private Map<String, List<String>>	attributes		= new HashMap<>();
	private boolean						authenticated	= false;
	private final List<String>			errors			= new ArrayList<>();
	private String						errorReason;
	private String						lastRequest;
	private String						lastResponse;
	
	public AuthExt(final Saml2Settings settings, final HttpServletRequest request)
		throws SettingsException
	{
		this.settings = settings;
		this.request = request;
		
		// Check settings
		final List<String> settingsErrors = settings.checkSettings();
		if(!settingsErrors.isEmpty())
		{
			String errorMsg = "Invalid settings: ";
			errorMsg += StringUtils.join(settingsErrors, ", ");
			AuthExt.LOGGER.error(errorMsg);
			throw new SettingsException(errorMsg, SettingsException.SETTINGS_INVALID);
		}
		AuthExt.LOGGER.debug("Settings validated");
	}
	
	public void processResponse(final String requestId, final boolean destinationToHttps) throws Exception
	{
		
		if(destinationToHttps)
		{
			final String destination = this.request.getRequestURL().toString();
			if(destination != null && destination.startsWith("http:"))
			{
				final String destinationUrl = destination.replace("http:", "https:");
				this.processResponse(requestId, destinationUrl);
			}
			else
			{
				this.processResponse(requestId, null);
			}
		}
		else
		{
			this.processResponse(requestId, null);
		}
	}
	
	public void processResponse(final String requestId, final String destinationUrl) throws Exception
	{
		AuthExt.LOGGER.info("Process response");
		
		final HttpRequest httpRequest = ServletUtils.makeHttpRequest(this.request);
		final String samlResponseParameter = httpRequest.getParameter("SAMLResponse");
		
		if(samlResponseParameter != null)
		{
			final SamlResponse samlResponse = new SamlResponse(this.settings, httpRequest);
			if(destinationUrl != null)
			{
				samlResponse.setDestinationUrl(destinationUrl);
			}
			
			this.lastResponse = samlResponse.getSAMLResponseXml();
			
			if(samlResponse.isValid(requestId))
			{
				this.nameid = samlResponse.getNameId();
				this.nameidFormat = samlResponse.getNameIdFormat();
				this.authenticated = true;
				this.attributes = samlResponse.getAttributes();
				this.sessionIndex = samlResponse.getSessionIndex();
				this.sessionExpiration = samlResponse.getSessionNotOnOrAfter();
				this.lastMessageId = samlResponse.getId();
				this.lastAssertionId = samlResponse.getAssertionId();
				this.lastAssertionNotOnOrAfter = samlResponse.getAssertionNotOnOrAfter();
				AuthExt.LOGGER.debug("processResponse success --> " + samlResponseParameter);
			}
			else
			{
				this.errors.add("invalid_response");
				AuthExt.LOGGER.error("processResponse error. invalid_response");
				AuthExt.LOGGER.debug(" --> " + samlResponseParameter);
				this.errorReason = samlResponse.getError();
			}
		}
		else
		{
			this.errors.add("invalid_binding");
			final String errorMsg = "SAML Response not found, Only supported HTTP_POST Binding";
			AuthExt.LOGGER.error("processResponse error." + errorMsg);
			throw new Error(errorMsg, Error.SAML_RESPONSE_NOT_FOUND);
		}
	}
	
	public Saml2Settings getSettings()
	{
		return this.settings;
	}
	
	public HttpServletRequest getRequest()
	{
		return this.request;
	}
	
	public String getNameId()
	{
		return this.nameid;
	}
	
	public String getNameIdFormat()
	{
		return this.nameidFormat;
	}
	
	public String getSessionIndex()
	{
		return this.sessionIndex;
	}
	
	public DateTime getSessionExpiration()
	{
		return this.sessionExpiration;
	}
	
	public String getLastMessageId()
	{
		return this.lastMessageId;
	}
	
	public String getLastAssertionId()
	{
		return this.lastAssertionId;
	}
	
	public List<Instant> getLastAssertionNotOnOrAfter()
	{
		return this.lastAssertionNotOnOrAfter;
	}
	
	public Map<String, List<String>> getAttributes()
	{
		return this.attributes;
	}
	
	public boolean isAuthenticated()
	{
		return this.authenticated;
	}
	
	public List<String> getErrors()
	{
		return this.errors;
	}
	
	public String getErrorReason()
	{
		return this.errorReason;
	}
	
	public String getLastRequest()
	{
		return this.lastRequest;
	}
	
	public String getLastResponse()
	{
		return this.lastResponse;
	}
	
	public Boolean isDebugActive()
	{
		return this.settings.isDebugActive();
	}
}
