package com.caweco.esra.entities.rest.monitoring;

import java.util.HashMap;
import java.util.Map;

import com.caweco.esra.business.properties.RestSettingsProvider;
import com.caweco.esra.entities.rest.general.BeneficialOwner;
import com.caweco.esra.entities.rest.general.GlobalUltimateOwner;
import com.caweco.esra.entities.rest.general.Intermediaries;
import com.caweco.esra.entities.rest.general.UltimateBeneficiaries;


/**
 * https://paas-cara-dev.apps.adp.allianz/api/v1/cara/rest/CompanyMoniterService/
 *
 * @author JonasArtmann
 *
 */
public class CMSearch
{
	private String								username					= "";
	private String								password					= "";
	private String								systemName					= "";
	private String								sessionHandle				= "";
	private String								companyBvdId				= "";
	private String								name						= "";
	private String								monitorToDate				= "";
	private String								city						= "";
	private String								country						= "";
	
	private Map<String, BeneficialOwner>		beneficialOwners			= new HashMap<>();
	private Map<String, UltimateBeneficiaries>	otherUltimateBeneficiaries	= new HashMap<>();
	private Map<String, Intermediaries>			boIntermediaries			= new HashMap<>();
	private GlobalUltimateOwner					globalUltimateOwner;
	
	private String								customField1				= "";
	private String								customField2				= "";
	private String								customField3				= "";
	private String								customField4				= "";
	private String								customField5				= "";
	
	public CMSearch()
	{
		
	}
	
	/**
	 * Mandatory fields
	 * 
	 * @param username
	 * @param password
	 * @param systemName
	 * @param sessionHandle
	 * @param companyBvdId
	 * @param name
	 */
	public CMSearch(
		final String username,
		final String password,
		final String systemName,
		final String sessionHandle,
		final String companyBvdId,
		final String name)
	{
		super();
		this.username = username;
		this.password = password;
		this.systemName = systemName;
		this.sessionHandle = sessionHandle;
		this.companyBvdId = companyBvdId;
		this.name = name;
		
		this.customField1 = RestSettingsProvider.DEFAULT_SEARCHDEFINITION_VALUE;
		this.customField2 = RestSettingsProvider.DEFAULT_BUSINESSUNIT_VALUE;
	}
	
	public String getUsername()
	{
		return this.username;
	}
	
	public CMSearch setUsername(final String username) // NO_UCD - setter
	{
		this.username = username;
		return this;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public CMSearch setPassword(final String password) // NO_UCD - setter
	{
		this.password = password;
		return this;
	}
	
	public String getSystemName()
	{
		return this.systemName;
	}
	
	public CMSearch setSystemName(final String systemName) // NO_UCD - setter
	{
		this.systemName = systemName;
		return this;
	}
	
	public String getSessionHandle()
	{
		return this.sessionHandle;
	}
	
	public CMSearch setSessionHandle(final String sessionHandle) // NO_UCD - setter
	{
		this.sessionHandle = sessionHandle;
		return this;
	}
	
	public String getCompanyBvdId()
	{
		return this.companyBvdId;
	}
	
	public CMSearch setCompanyBvdId(final String companyBvdId) // NO_UCD - setter
	{
		this.companyBvdId = companyBvdId;
		return this;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public CMSearch setName(final String name) // NO_UCD - setter
	{
		this.name = name;
		return this;
	}
	
	public String getMonitorToDate()
	{
		return this.monitorToDate;
	}
	
	public CMSearch setMonitorToDate(final String monitorToDate)
	{
		this.monitorToDate = monitorToDate;
		return this;
	}
	
	public String getCity()
	{
		return this.city;
	}
	
	public CMSearch setCity(final String city) // NO_UCD - setter
	{
		this.city = city;
		return this;
	}
	
	public String getCountry()
	{
		return this.country;
	}
	
	public CMSearch setCountry(final String country) // NO_UCD - setter
	{
		this.country = country;
		return this;
	}
	
	public Map<String, BeneficialOwner> getBeneficialOwners()
	{
		return this.beneficialOwners;
	}
	
	public CMSearch setBeneficialOwners(final Map<String, BeneficialOwner> beneficialOwners) // NO_UCD - setter
	{
		this.beneficialOwners = beneficialOwners;
		return this;
	}
	
	public Map<String, UltimateBeneficiaries> getOtherUltimateBeneficiaries()
	{
		return this.otherUltimateBeneficiaries;
	}
	
	public CMSearch setOtherUltimateBeneficiaries(final Map<String, UltimateBeneficiaries> otherUltimateBeneficiaries) // NO_UCD - setter
	{
		this.otherUltimateBeneficiaries = otherUltimateBeneficiaries;
		return this;
	}
	
	public Map<String, Intermediaries> getBoIntermediaries()
	{
		return this.boIntermediaries;
	}
	
	public CMSearch setBoIntermediaries(final Map<String, Intermediaries> boIntermediaries)  // NO_UCD (unused code)
	{
		this.boIntermediaries = boIntermediaries;
		return this;
	}
	
	public GlobalUltimateOwner getGlobalUltimateOwner()
	{
		return this.globalUltimateOwner;
	}
	
	public CMSearch setGlobalUltimateOwner(final GlobalUltimateOwner globalUltimateOwner)
	{
		this.globalUltimateOwner = globalUltimateOwner;
		return this;
	}
	
	public String getCustomField1()
	{
		return this.customField1;
	}
	
	public CMSearch setCustomField1(final String customField1) // NO_UCD - setter
	{
		this.customField1 = customField1;
		return this;
	}
	
	public String getCustomField2()
	{
		return this.customField2;
	}
	
	public CMSearch setCustomField2(final String customField2) // NO_UCD - setter
	{
		this.customField2 = customField2;
		return this;
	}
	
	public String getCustomField3()
	{
		return this.customField3;
	}
	
	public CMSearch setCustomField3(final String customField3)
	{
		this.customField3 = customField3;
		return this;
	}
	
	public String getCustomField4()
	{
		return this.customField4;
	}
	
	public CMSearch setCustomField4(final String customField4) // NO_UCD - setter
	{
		this.customField4 = customField4;
		return this;
	}
	
	public String getCustomField5()
	{
		return this.customField5;
	}
	
	public CMSearch setCustomField5(final String customField5) // NO_UCD - setter
	{
		this.customField5 = customField5;
		return this;
	}
}
