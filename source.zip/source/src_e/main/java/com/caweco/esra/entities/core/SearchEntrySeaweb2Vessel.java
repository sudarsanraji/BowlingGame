
package com.caweco.esra.entities.core;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;
import com.caweco.esra.entities.rest.seaweb2.APSShipResult_v2;
import com.caweco.esra.entities.rest.seaweb2.APSStatus_v2;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.caweco.esra.microstream.converters.GenericObjectKeyDeserializer;
import com.caweco.esra.microstream.converters.GenericObjectKeySerializer;


public class SearchEntrySeaweb2Vessel implements HasMatchData
{
	private final Instant        created                  = Instant.now();
	private String               createdBy;
	
	private APSShipDetail_v2     shipDetails;
	protected Integer            shipCount;
	protected APSStatus_v2       apsStatus;
	
	private String               entryComment             = "";
	
	private String               rating;
	private String               ratingStatement;
	private String               username;
	
	@JsonSerialize(keyUsing = GenericObjectKeySerializer.class)
	@JsonDeserialize(keyUsing = GenericObjectKeyDeserializer.class)
	private Map<String, Boolean> redFlagSettings_atFreeze = new HashMap<>();
	
	private UUID                 id                       = UUID.randomUUID();
	
	public static SearchEntrySeaweb2Vessel New(final APSShipResult_v2 ship)
	{
		final SearchEntrySeaweb2Vessel entry = new SearchEntrySeaweb2Vessel(ship);
		entry.setCreatedBy(CurrentUtil.getUser().getEmailAddress());
		return entry;
	}
	
	public static SearchEntrySeaweb2Vessel New(final APSShipResult_v2 apsShipResult_v2, String email) {
		final SearchEntrySeaweb2Vessel entry = new SearchEntrySeaweb2Vessel(apsShipResult_v2);
		entry.setCreatedBy(email);
		return entry;
	}
	
	/**
	 * HINT: Uses "current" user. Ensure that a user is set in VaadinSession.
	 * 
	 * @param ship
	 */
	protected SearchEntrySeaweb2Vessel(final APSShipResult_v2 ship)
	{
		super();
		this.shipDetails = ship.getAPSShipDetail();
		this.shipCount   = ship.getShipCount();
		this.apsStatus   = ship.getAPSStatus();
	}
	
	public SearchEntrySeaweb2Vessel()
	{
		//required for Jackson
	}
	
	public UUID getId()
	{
		return this.id;
	}
	
	public void setId(final UUID id)
	{
		this.id = id;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public APSShipDetail_v2 getShipDetails()
	{
		return this.shipDetails;
	}
	
	public void setShipDetails(final APSShipDetail_v2 shipDetails)
	{
		this.shipDetails = shipDetails;
	}
	
	public Integer getShipCount()
	{
		return this.shipCount;
	}
	
	public APSStatus_v2 getApsStatus()
	{
		return this.apsStatus;
	}
	
	public String getEntryComment()
	{
		return this.entryComment;
	}
	
	public SearchEntrySeaweb2Vessel setEntryComment(final String entryComment)
	{
		this.entryComment = entryComment;
		return this;
	}
	
	@Override
	public String getRating()
	{
		return this.rating;
	}
	
	@Override
	public SearchEntrySeaweb2Vessel setRating(final String rating)
	{
		this.rating = rating;
		return this;
	}
	
	@Override
	public String getRatingStatement()
	{
		return this.ratingStatement;
	}
	
	@Override
	public SearchEntrySeaweb2Vessel setRatingStatement(final String ratingStatement)
	{
		this.ratingStatement = ratingStatement;
		return this;
	}
	
	@Override
	public String getComment()
	{
		return this.getEntryComment();
	}
	
	@Override
	public SearchEntrySeaweb2Vessel setComment(final String comment)
	{
		return this.setEntryComment(comment);
	}
	
	public Map<String, Boolean> getRedFlagSettings_atFreeze()
	{
		return this.redFlagSettings_atFreeze;
	}
	
	public void setRedFlagSettings_atFreeze(final Map<String, Boolean> redFlag_atFreeze)
	{
		this.redFlagSettings_atFreeze = redFlag_atFreeze;
	}

	@Override
	public String getUsername()
	{
		return username;
	}

	@Override
	public HasMatchData setUsername(final String username)
	{
		this.username = username;
		return this;
	}
	
	@Override
	public String toString() {
		String shipDetailsString = shipDetails != null ? shipDetails.toString()
				: "none";
		String apsStatusString = apsStatus != null ? apsStatus.toString()
				: "none";
		return "SearchEntrySeaweb2Vessel [created=" + created + ", createdBy=" + createdBy + ", shipDetails="
				+ shipDetailsString + ", shipCount=" + shipCount + ", apsStatus=" + apsStatusString + ", entryComment="
				+ entryComment + ", rating=" + rating + ", ratingStatement=" + ratingStatement + ", username="
				+ username + ", redFlagSettings_atFreeze=" + redFlagSettings_atFreeze + ", id=" + id + "]";
	}


	
}
