package com.caweco.esra.ui.component;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.ui.beans.mvcb.HasTags_20210201;
import com.vaadin.flow.data.binder.HasItemsAndComponents.ItemComponent;

public class MultiValueComboboxTag<T> extends TagItem implements ItemComponent<T>
{
	
	private static final long serialVersionUID = 1L;
	
	private final T           item;
	private final HasTags_20210201<T> parent;
	
	public MultiValueComboboxTag(final T item, final String labelText, final HasTags_20210201<T> parent)
	{
		super(labelText);
		this.item = item;
		this.parent = parent;
		
		this.onDelete(it -> this.parent.delete(this));
		this.setButtonAria(Aria.get("ESUTag_remove"));
	}
	
	@Override
	public T getItem()
	{
		return this.item;
	}
}
