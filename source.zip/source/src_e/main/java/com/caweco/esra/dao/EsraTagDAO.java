package com.caweco.esra.dao;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.esra.MatchCategoryTag;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class EsraTagDAO {

	public static void deleteTag(MatchCategoryTag it, Client client) {
		// TODO Auto-generated method stub
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/tag/" + it.getTag());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the ESRA Tag "  + it.getTag() + " to the client : " +  client.getClientDescription());
	}
	
	public static void updateTag(MatchCategoryTag it, Client client) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/tag/" + it.getTag());
		
		Response response = webTarget.request().put(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());;
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the ESRA Tag "  + it.getTag() + " to the client : " +  client.getClientDescription());
	}
	
	public static void createTag(MatchCategoryTag it, Client client) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/tag/");
		
		Response response = webTarget.request().post(Entity.entity(it, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" created the ESRA Tag "  + it.getTag() + " to the client : " +  client.getClientDescription());
	}

}
