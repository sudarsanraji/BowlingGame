package com.caweco.esra.ui.part.watchlist;

import com.caweco.esra.ui.part.watchlist.common.WatchlistElement;
import com.vaadin.flow.component.Component;


public interface RemovableWatchlistElement<C extends Component & RemovableWatchlistElement<C>> extends WatchlistElement<C>
{
	void removeSelfFromWatchlist();
}
