package com.caweco.esra.entities.questionnaire;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import com.caweco.esra.entities.core.Screening;
import com.rapidclipse.framework.server.resources.Caption;


public class QuestionnaireResultReportData
{
	private Integer					resultID;
	private Questionnaire			questionnaire;
	private Integer					year;
	
	private List<QuestionResult>	results;
	
	private Instant					finishedDate;
	private Screening				parent;
	private final int	resultScore;
	
	public QuestionnaireResultReportData(final QuestionnaireResult qr)
	{
		this.resultID = qr.getResultID();
		this.questionnaire = qr.getQuestionnaire();
		this.year = qr.getYear();
		this.results = qr.getResults();
		this.finishedDate = qr.getFinishedDate();
		this.resultScore = qr.getResultScore();
	}
	
	@Caption("ID")
	public Integer getResultID()
	{
		return this.resultID;
	}
	
	public void setResultID(final Integer resultID)
	{
		this.resultID = resultID;
	}
	
	@Caption("Questionnaire")
	public Questionnaire getQuestionnaire()
	{
		return this.questionnaire;
	}
	
	public void setQuestionnaire(final Questionnaire questionnaire)
	{
		this.questionnaire = questionnaire;
	}
	
	@Caption("Results")
	public List<QuestionResult> getResults()
	{
		if(this.results == null)
		{
			this.results = new ArrayList<>();
		}
		return this.results;
	}
	
	public void setResults(final List<QuestionResult> results)
	{
		this.results = results;
	}
	
	@Caption("Year")
	public Integer getYear()
	{
		return this.year;
	}
	
	public void setYear(final Integer year)
	{
		this.year = year;
	}
	
	@Caption("Score")
	public Integer getResultScore()
	{
		return this.resultScore;
	}
	
	public Instant getFinishedDate()
	{
		return this.finishedDate;
	}
	
	public void setFinishedDate(final Instant finishedDate)
	{
		this.finishedDate = finishedDate;
	}
	
}
