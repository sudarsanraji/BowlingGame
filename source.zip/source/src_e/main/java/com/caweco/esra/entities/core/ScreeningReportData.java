
package com.caweco.esra.entities.core;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.applog.ChangeEntry;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.entities.questionnaire.QuestionnaireResultReportData;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * This class is for report generation.
 * 
 * @author MarcoHoffmann
 *
 */
public class ScreeningReportData
{
	private final UUID                          screeningID;
	private final LocalDate                     screeningDate;
	private User                                screeningOwner;
	private User                                screeningServiceUser;
	
	private String                              name;
	private LineOfBusiness                      lineOfBusiness;
	private OE                                  oe;
	private Function                            function;
	
	//// Infos
	private ScreeningStatus                     status                     = ScreeningStatus.IN_PROGRESS;
	private final InternalWorkflowStatus              workflowStatus             =
		InternalWorkflowStatus.RISK_EVALUATION;
	private Monitoring                          latestMonitoring;
	
	private List<SearchEntryCompany>            watchlistCompanyEntries    = new ArrayList<>();
	private List<SearchEntryGsss>               watchlistSearchEntriesGsss = new ArrayList<>();
	private List<SearchEntrySeaweb2Vessel>      vesselsSeaWeb              = new ArrayList<>();
	
	//// TS SCREENING DATA
	private final QuestionnaireResultReportData tradeSanctionResult;
	
	//// BUSINESS DATA
	private final QuestionnaireResultReportData businessInformationResult;
	
	//// ESU DATA
	private User                                esuWorker;
	private String                              ESUTemplateResult;
	private Set<String>                         esuTags                    = new HashSet<>();
	private Set<String>                         esuCountries               = new HashSet<>();
	private Set<String>                         prcCountries               = new HashSet<>();
	private LocalDate screeningEsuDate;
	private Instant screeningFinalizedTimestamp;
	
	//// MESSGAING DATA
	private final MessageGroup                  esuMessagesPublic          = new MessageGroup();
	private final List<Message>                 publicMessages;
	
	@JsonIgnore
	private final Map<UUID, MessageGroup>       esuMessageGroups           = new HashMap<>();
	
	private Map<String, List<Message>>          esuMessagesPrivate         = new HashMap<>();
	
	//// FILES
	private List<? extends BinaryElement> files                      = new ArrayList<>();
	
	// Timestamps & Infos
	
	private Instant                             created                    = Instant.now();
	private String                              createdBy;
	
	private Instant                             lastChanged                = Instant.now();
	private String                              lastChangedBy;
	
	private List<ChangeEntry>                   notableChanges             = new ArrayList<>();
	
	private boolean                             archived                   = false;
	

	public ScreeningReportData(final Screening screening)
	{
		this.screeningID                = screening.getScreeningID();
		this.screeningDate              = screening.getScreeningDate();
		this.screeningOwner             = screening.getScreeningOwner();
		this.screeningServiceUser       = screening.getScreeningServiceUser();
		this.name                       = screening.getName();
		this.lineOfBusiness             = screening.getLineOfBusiness();
		this.oe                         = screening.getOe();
		this.function                   = screening.getFunction();
		this.status                     = screening.getStatus();
		this.latestMonitoring           = screening.getMonitoring();
		this.watchlistCompanyEntries    = screening.getWatchlistCompanyEntries(true);
		this.watchlistSearchEntriesGsss = screening.getWatchlistSearchEntriesGsss(true);
		this.vesselsSeaWeb              = screening.getVesselsSeaWeb(true);
		this.tradeSanctionResult        = new QuestionnaireResultReportData(screening.getTradeSanctionResult(true));
		this.businessInformationResult  =
			new QuestionnaireResultReportData(screening.getBusinessInformationResult(true));
		this.esuWorker                  = screening.getEsuWorker();
		this.ESUTemplateResult          = screening.getESUTemplateResult();
		this.esuTags                    = screening.getEsuTags();
		this.esuCountries               = screening.getEsuCountries();
		this.prcCountries               = screening.getPrcCountries();
		this.esuMessagesPrivate         = screening.getPrivateMessages();
		this.files                      = screening.getFiles(true);
		this.created                    = screening.getCreated();
		this.lastChanged                = screening.getLastChanged();
		this.lastChangedBy              = screening.getLastChangedBy();
		this.notableChanges             = screening.getNotableChanges(true);
		this.archived                   = screening.isArchived();
		this.publicMessages             = screening.getPublicMessages(true).getMessages(true);
		this.screeningEsuDate = screening.getScreeningEsuDate().orElse(null);
		this.screeningFinalizedTimestamp = screening.getNotableChanges(true)
			.stream()
			.filter(c -> c.getChangeType().equals("State change to \"Published\""))
			.findAny()
			.map(ChangeEntry::getChanged)
			.orElse(null);
	}
	
	public Instant getScreeningFinalizedTimestamp() {
		return this.screeningFinalizedTimestamp;
	}

	public void setScreeningFinalizedTimestamp(final Instant screeningFinalizedTimestamp) {
		this.screeningFinalizedTimestamp = screeningFinalizedTimestamp;
	}

	public LocalDate getScreeningEsuDate() {
		return this.screeningEsuDate;
	}

	public void setScreeningEsuDate(final LocalDate screeningEsuDate) {
		this.screeningEsuDate = screeningEsuDate;
	}

	public User getScreeningOwner()
	{
		return this.screeningOwner;
	}
	
	public void setScreeningOwner(final User screeningOwner)
	{
		this.screeningOwner = screeningOwner;
	}
	
	public User getScreeningServiceUser()
	{
		return this.screeningServiceUser;
	}
	
	public void setScreeningServiceUser(final User screeningServiceUser)
	{
		this.screeningServiceUser = screeningServiceUser;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public LineOfBusiness getLineOfBusiness()
	{
		return this.lineOfBusiness;
	}
	
	public void setLineOfBusiness(final LineOfBusiness lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}
	
	public OE getOe()
	{
		return this.oe;
	}
	
	public void setOe(final OE oe)
	{
		this.oe = oe;
	}
	
	public Function getFunction()
	{
		return this.function;
	}
	
	public void setFunction(final Function function)
	{
		this.function = function;
	}
	
	public Monitoring getLatestMonitoring()
	{
		return this.latestMonitoring;
	}
	
	public Monitoring getMonitoring()
	{
		return this.getLatestMonitoring();
	}
	
	public void setLatestMonitoring(final Monitoring latestMonitoring)
	{
		this.latestMonitoring = latestMonitoring;
	}
	
	public User getEsuWorker()
	{
		return this.esuWorker;
	}
	
	public void setEsuWorker(final User esuWorker)
	{
		this.esuWorker = esuWorker;
	}
	
	public String getESUTemplateResult()
	{
		return this.ESUTemplateResult;
	}
	
	public void setESUTemplateResult(final String eSUTemplateResult)
	{
		this.ESUTemplateResult = eSUTemplateResult;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public String getLastChangedBy()
	{
		return this.lastChangedBy;
	}
	
	public void setLastChangedBy(final String lastChangedBy)
	{
		this.lastChangedBy = lastChangedBy;
	}
	
	public UUID getScreeningID()
	{
		return this.screeningID;
	}
	
	public LocalDate getScreeningDate()
	{
		return this.screeningDate;
	}
	
	public ScreeningStatus getStatus()
	{
		return this.status;
	}
	
	public InternalWorkflowStatus getWorkflowStatus()
	{
		return this.workflowStatus;
	}
	
	public List<SearchEntryCompany> getWatchlistCompanyEntries()
	{
		return this.watchlistCompanyEntries;
	}
	
	public List<SearchEntryGsss> getWatchlistSearchEntriesGsss()
	{
		return this.watchlistSearchEntriesGsss;
	}
	
	public List<SearchEntrySeaweb2Vessel> getVesselsSeaWeb()
	{
		return this.vesselsSeaWeb;
	}
	
	public QuestionnaireResultReportData getTradeSanctionResult()
	{
		return this.tradeSanctionResult;
	}
	
	public QuestionnaireResultReportData getBusinessInformationResult()
	{
		return this.businessInformationResult;
	}
	
	public Set<String> getEsuTags()
	{
		return this.esuTags;
	}
	
	public Set<String> getEsuCountries()
	{
		return this.esuCountries;
	}
	
	public Set<String> getPrcCountries()
	{
		return this.prcCountries;
	}
	
	public MessageGroup getEsuMessagesPublic()
	{
		return this.esuMessagesPublic;
	}
	
	public List<Message> getPublicMessages()
	{
		return this.publicMessages;
	}
	
	public Map<UUID, MessageGroup> getEsuMessageGroups()
	{
		return this.esuMessageGroups;
	}
	
	public Map<String, List<Message>> getEsuMessagesPrivate()
	{
		return this.esuMessagesPrivate;
	}
	
	public List<? extends BinaryElement> getFiles()
	{
		return this.files;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public Instant getLastChanged()
	{
		return this.lastChanged;
	}
	
	public List<ChangeEntry> getNotableChanges()
	{
		return this.notableChanges;
	}
	
	public boolean isArchived()
	{
		return this.archived;
	}
	
}
