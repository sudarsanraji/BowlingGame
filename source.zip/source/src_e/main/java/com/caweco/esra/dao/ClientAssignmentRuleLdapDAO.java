
package com.caweco.esra.dao;

import java.util.Objects;
import java.util.UUID;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.dto.creator.ClientAssignmentRuleLdapCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.access.ClientAssignmentRuleLdap;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class ClientAssignmentRuleLdapDAO
{
	
	public static void create(ClientAssignmentRuleLdap rule)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget        webTarget  = restClient.getMethodTarget("/accesscontrol/ClientAssignmentRules/");
		
		if(Objects.isNull(rule.getUuid()))
		{
			rule.setUuid(UUID.randomUUID());
		}
		
		Response response = webTarget.request().post(Entity
			.entity(ClientAssignmentRuleLdapCreator.convertAssignmentRuleToDTO(rule), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
}
