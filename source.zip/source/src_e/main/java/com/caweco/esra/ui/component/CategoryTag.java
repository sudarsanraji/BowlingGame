package com.caweco.esra.ui.component;

import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.entities.esra.MatchCategoryTag;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

@Tag("esra-category-tag")
public class CategoryTag extends Div
{
	
	public CategoryTag(MatchCategoryTag in)
	{
		super();
		UiHelper.setAriaLabel(this, in.getTag());
		
		Label label = new Label(in.getTag());
		this.getStyle().set("background-color", in.getColor());
		label.setSizeUndefined();
		this.setSizeUndefined();
		this.add(label);
	}
	
}
