package com.caweco.esra.business.ldap;

import javax.naming.NamingException;

public class LdapUtils
{
	private static String ldapusername = "CN=tuw09898,OU=Service Accounts,DC=GIDS,DC=ALLIANZ,DC=COM";
	private static String ldappwd      = "er8w3Q#Hjva";
	
	public static LdapClientGids getLdapClient() throws NamingException
	{
		return new LdapClientGids(ldapusername, ldappwd);
	}
}
