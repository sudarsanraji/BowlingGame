package com.caweco.esra.dao.messaging;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.ui.broadcaster.Broadcaster;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class MessageDAO
{
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	public static Optional<List<Message>> getGroupMessages(final MessageGroup group)
	{
		if(group == null)
		{
			return Optional.empty();
		}
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId().toString() + "/message");
		
		final Response response = webTarget.request().get();
		
		Logger.tag("REST").info(response.toString());
		final String responseBody = response.readEntity(String.class);
		
		final JavaType type = om.getTypeFactory().constructCollectionType(List.class, Message.class);
		
		try {
			final List<Message> listUnsorted = om.readValue(responseBody, type);
			
			listUnsorted.sort(Comparator.comparing(Message::getCreated));
			return Optional.of(listUnsorted);
		} catch (final JsonProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return Optional.empty();
		}
		
	}
	
	public static void deleteMessage(final List<Message> holder, final Message m, final MessageGroup group)
	{
		holder.remove(m);
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId().toString() + "/" + m.getId().toString());

		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
	}
	
	public static void deleteNote(final List<Message> holder, final Client client, final Screening screening, final Message m)
	{
		holder.remove(m);
		
		final RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/screening/" + screening.getScreeningID().toString() + "/notes/" + CurrentUtil.getUser().getEmailAddress() + "/" + m.getId());

		final Response response = webTarget.request().delete();

		Logger.tag("REST").info(response.toString());
	}
	
	//// MESSAGES
	public static void saveGroupMessage(final Message message, final MessageGroup group)
	{
		saveMessage(group, message);
	}
	
	public static void savePrivateMessage(final Screening r, final Message message, final User u)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/screening/" + r.getScreeningID() + "/notes/" + u.getEmailAddress());
		
		final Response response = webTarget.request().post(Entity.entity(message, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	public static void savePublicMessage(final MessageGroup r, final Message message)
	{
		saveMessage(r, message);
	}
	
	protected static void saveMessage(final MessageGroup group, final Message message)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId() + "/message");
		
		Broadcaster.broadcast(message, group);
		
		final Response response = webTarget.request().post(Entity.entity(message, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
}
