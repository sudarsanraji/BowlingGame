package com.caweco.esra.entities.rest.general;

import java.util.Objects;

public class Profile
{
	private long	factivaEntryID;
	private String	relationship;
	// CARA v5
	private String	name;
	// CARA v5
	private String	desc;
	
	public Profile()
	{
		// empty Constructor for Framework
	}
	
	public long getFactivaEntryID()
	{
		return this.factivaEntryID;
	}
	
	public void setFactivaEntryID(final long factivaEntryID)
	{
		this.factivaEntryID = factivaEntryID;
	}
	
	public String getRelationship()
	{
		return this.relationship;
	}
	
	public void setRelationship(final String relationship)
	{
		this.relationship = relationship;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public String getDesc()
	{
		return this.desc;
	}
	
	public void setDesc(final String desc)
	{
		this.desc = desc;
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.desc, this.factivaEntryID, this.name, this.relationship);
	}

	@Override
	public boolean equals(final Object obj)
	{
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(this.getClass() != obj.getClass())
		{
			return false;
		}
		final Profile other = (Profile)obj;
		return Objects.equals(this.desc, other.desc)
			&& this.factivaEntryID == other.factivaEntryID
			&& Objects.equals(this.name, other.name)
			&& Objects.equals(this.relationship, other.relationship);
	}
	
	
}
