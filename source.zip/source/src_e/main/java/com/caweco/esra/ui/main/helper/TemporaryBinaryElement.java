package com.caweco.esra.ui.main.helper;

import java.time.Instant;

public class TemporaryBinaryElement
{
	private final Instant created = Instant.now();
	private byte[] binaryData;
	private String fileName;
	private String mimeType;

	public TemporaryBinaryElement(final byte[] binaryData)
	{
		super();
		this.binaryData = binaryData;
	}
	
	public Instant getCreated()
	{
		return created;
	}

	public byte[] getBinaryData()
	{
		return this.binaryData;
	}

	public void setBinaryData(byte[] binaryData)
	{
		this.binaryData = binaryData;
	}

	public String getFileName()
	{
		return this.fileName;
	}

	public void setFileName(final String fileName)
	{
		this.fileName = fileName;
	}

	public String getMimeType()
	{
		return this.mimeType;
	}

	public void setMimeType(final String mimeType)
	{
		this.mimeType = mimeType;
	}
}
