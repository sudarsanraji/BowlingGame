package com.caweco.esra.entities.access;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.saml.SamlAttributes;

public interface HasClientAssignmentInfo
{
	public Client getClientToAssignTo();
	
	public boolean fit(SamlAttributes attr);
}
