package com.caweco.esra.business.func.rest.data;

import java.util.HashMap;

public interface QueryDescription {

	String getLuceneSearchText();

	String getPropertySearchText();

	String[] getPropertySearchFields();

	HashMap<String, Object> getPropertyQueryParams();

	HashMap<String, String> getQueryParams();

}