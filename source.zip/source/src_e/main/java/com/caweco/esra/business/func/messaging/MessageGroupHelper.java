package com.caweco.esra.business.func.messaging;

import java.util.Collection;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.messaging.MessageGroup;

public class MessageGroupHelper
{
	/**
	 * Requestor Group name: "Requestor & ESU" 
	 */
	public static final String GROUPNAME_REQUESTOR_GROUP = "Requestor & ESU";
	
	/**
	 * Create "requestor" group with name {@link MessageGroupHelper#GROUPNAME_REQUESTOR_GROUP}
	 * 
	 * @param currentUser
	 * @return a new MessageGroup
	 */
	public static MessageGroup createRequestorGroup(User currentUser)
	{
		final MessageGroup newMessageGroup = new MessageGroup(currentUser, GROUPNAME_REQUESTOR_GROUP);
		return newMessageGroup;
	}
	
	/**
	 * Search group with name {@link MessageGroupHelper#GROUPNAME_REQUESTOR_GROUP}
	 * @param availableGroups
	 * @return a MessageGroup if found
	 */
	public static Optional<MessageGroup> getRequestorGroup(Collection<MessageGroup> availableGroups)
	{
		if (availableGroups == null)
		{
			return Optional.empty();
		}
		Optional<MessageGroup> requestorGroup = availableGroups.stream()
			.filter(mg -> StringUtils.equalsIgnoreCase(mg.getName(), GROUPNAME_REQUESTOR_GROUP)).findFirst();
		return requestorGroup;
	}
	
}
