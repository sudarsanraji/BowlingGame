
package com.caweco.esra.subsidary.common;

public interface SubsidiaryDataDefines
{
	public static final float THRESHOLD_DIRECT          = 25.0f;
	public static final int   THRESHOLD_MAXLEVEL        = 2;
	public static final int   THRESHOLD_MAXSUBSIDIARIES = 200;
}
