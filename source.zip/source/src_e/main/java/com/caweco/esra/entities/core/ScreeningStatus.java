package com.caweco.esra.entities.core;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public enum ScreeningStatus
{
	/**
	 * Screenings are editable for ESU user.
	 */
	REVIEW_REQUESTED("Review requested"),
	
	/**
	 * Screenings are editable for ESU user.
	 */
	REVIEW_ONGOING("Review ongoing"),
	
	/**
	 * Finalized. Screenings with this state are frozen.
	 */
	REVIEW_FINALIZED("Review finalized"),
	
	/**
	 * Initial state.
	 */
	IN_PROGRESS("in progress"),
	
	/**
	 * Finalized. Screenings with this state are frozen.
	 */
	NO_EXPOSURE("no exposure"),
	
	/**
	 * Screenings with this state are IN_PROGRESS but wait for a service user.
	 */
	SERVICE_REQUESTED("service requested");
	
	private String status;
	
	private ScreeningStatus(String status)
	{
		this.status = status;
	}

	public String getStatus()
	{
		return this.status;
	}
	
	public static Stream<ScreeningStatus> stream()
	{
		return Stream.of(ScreeningStatus.values());
	}
	
	public static List<ScreeningStatus> asList_byStatus()
	{
		return ScreeningStatus.stream().sorted(
			Comparator.comparing(ScreeningStatus::getStatus, Comparator.nullsFirst(Comparator.naturalOrder()))).collect(
				Collectors.toList());
	}

	public boolean isEsuState()
	{
		if (this == ScreeningStatus.REVIEW_REQUESTED
			||
			this == ScreeningStatus.REVIEW_ONGOING
			||
			this == ScreeningStatus.REVIEW_FINALIZED)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean isFrozenState()
	{
		if (this == ScreeningStatus.NO_EXPOSURE
			||
			this == ScreeningStatus.REVIEW_FINALIZED)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
