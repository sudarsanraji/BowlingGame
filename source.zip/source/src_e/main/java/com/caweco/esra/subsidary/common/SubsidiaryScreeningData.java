
package com.caweco.esra.subsidary.common;

import java.time.Duration;
import java.util.Map;

import com.caweco.esra.entities.rest.information.CIResponse;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * <p>Results of finished run (no matter if successful or not).
 * Generated for temporarily storing in backend-storage until data applied to screening.</p>
 * Usage: Frontend, Backend & as DTO
 */
public class SubsidiaryScreeningData
{
	public final CIResponse              rootItem; // NO_UCD (unused code) - kept for data consistency 
	
	/**
	 * Mapping "bvdId" -> "CIResponse data"<br />
	 * Successful BIH requests.
	 */
	public final Map<String, CIResponse> dataFetches;
	
	
	/**
	 * Mapping "bvdId" -> "error"<br />
	 * Failed BIH requests.
	 */
	public final Map<String, String>     dataFailedFetches; // NO_UCD - kept for data consistency
	
	/**
	 * Mapping "bvdId" -> "duration<br />
	 * Duration of all BIH requests no matter if successful.
	 */
	public final Map<String, Duration>   dataFetchesTimes; // NO_UCD - kept for data consistency
	
	@JsonCreator
	public SubsidiaryScreeningData(
		@JsonProperty("rootItem") CIResponse rootItem,
		@JsonProperty("dataFetches") Map<String, CIResponse> dataFetches,
		@JsonProperty("dataFailedFetches") Map<String, String> dataFailedFetches,
		@JsonProperty("dataFetchesTimes") Map<String, Duration> dataFetchesTimes)
	{
		super();
		this.rootItem          = rootItem;
		this.dataFetches       = dataFetches;
		this.dataFailedFetches = dataFailedFetches;
		this.dataFetchesTimes  = dataFetchesTimes;
	}
}
