package com.caweco.esra.entities.core;

import java.util.UUID;

import com.rapidclipse.framework.server.resources.Caption;


public class OeRegion
{
	public static OeRegion New(String name)
	{
		return new OeRegion(name);
	}
	
	private String name;
	private UUID id;
	
	public OeRegion()
	{
		super();
	}
	
	public OeRegion(String name)
	{
		super();
		this.name = name;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Caption("Region")
	public String getName()
	{
		return this.name;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}
	
	
	
	
}
