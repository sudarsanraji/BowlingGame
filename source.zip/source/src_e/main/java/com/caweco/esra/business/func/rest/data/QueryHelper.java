package com.caweco.esra.business.func.rest.data;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import io.micronaut.data.model.Sort.Order.Direction;
import jakarta.ws.rs.client.WebTarget;

public class QueryHelper {
	
	public static WebTarget enhance(final WebTarget base, final QueryDescription desc, final Query<?, ?> query)
	{
		WebTarget result = base;

		if (query != null)
		{
			System.out.println("QUERYLIMIT " + query.getLimit());
			result = result.queryParam("offset", query.getOffset()).queryParam("limit", query.getLimit());
			
			for (final QuerySortOrder qso : query.getSortOrders())
			{
				final String dir = qso.getDirection() == SortDirection.ASCENDING ? Direction.ASC.name() : Direction.DESC.name();
				result = result.queryParam("sort", "screening."+qso.getSorted() + "," + dir);
			}
		}
		
		if (desc.getLuceneSearchText() != null) {
			result = result.queryParam("lucene",desc.getLuceneSearchText());
		}
		
		if (desc.getPropertySearchText() != null) {
			result = result.queryParam("s_search",desc.getPropertySearchText());
		}
		
		if (desc.getPropertySearchFields() != null) {
			final String combined = Stream.of(desc.getPropertySearchFields()).collect(Collectors.joining(","));
			result = result.queryParam("s_searchfields",combined);
		}
		
		for (final Map.Entry<String, Object> x : desc.getPropertyQueryParams().entrySet()) {
			if (x.getValue() == null) {
				result = result.queryParam(x.getKey(), "");
			}
			else {
				result = result.queryParam(x.getKey(), x.getValue().toString());
			}
		}
		
		for (final Map.Entry<String, String> x : desc.getQueryParams().entrySet()) {
			if (x.getValue() == null) {
				result = result.queryParam(x.getKey(), "");
			}
			else {
				result = result.queryParam(x.getKey(), x.getValue());
			}
		}
		
		return result;
	}
	
	public static WebTarget enhanceEsu(final WebTarget base, final QueryDescription desc, final Query<?, ?> query, final Set<String> setTags, final Set<String> setCountries)
	{
		WebTarget result = enhance(base, desc, query);
		
		if (setTags != null && !setTags.isEmpty()) {
			final String combined = setTags.stream().collect(Collectors.joining(","));
			result = result.queryParam("tags",combined);
		}
		
		if (setCountries != null && !setCountries.isEmpty()) {
			final String combined = setCountries.stream().collect(Collectors.joining(","));
			result = result.queryParam("countries",combined);
		}
		
		return result;
	}
}
