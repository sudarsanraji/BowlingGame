package com.caweco.esra.entities.core;


public class MatchData implements HasMatchData
{
	
	String	comment	= "";
	String	rating	= "";
	String	ratingStatement;
	String  userName = "<unknown>";
	
	@Override
	public String getComment()
	{
		return this.comment;
	}
	
	@Override
	public MatchData setComment(final String comment)
	{
		this.comment = comment;
		return this;
	}
	
	@Override
	public String getRating()
	{
		return this.rating;
	}
	
	@Override
	public MatchData setRating(final String rating)
	{
		this.rating = rating;
		return this;
	}
	
	@Override
	public String getRatingStatement()
	{
		return this.ratingStatement;
	}
	
	@Override
	public MatchData setRatingStatement(final String ratingStatement)
	{
		this.ratingStatement = ratingStatement;
		return this;
	}

	@Override
	public String getUsername()
	{
		if(this.userName == null)
		{
			return "<unset>";
		}
		return this.userName;
	}

	@Override
	public HasMatchData setUsername(final String username)
	{
		this.userName = username;
		return this;
	}
	
	
	
	
	
}
