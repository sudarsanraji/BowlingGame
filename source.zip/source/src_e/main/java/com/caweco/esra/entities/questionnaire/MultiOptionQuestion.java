package com.caweco.esra.entities.questionnaire;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class MultiOptionQuestion extends Question implements HasChooseableValues
{
	
	private List<ChooseableValues> values = new ArrayList<ChooseableValues>();
	
	public MultiOptionQuestion()
	{
		super();
	}
	
	/**
	 * @param questionText
	 * @param helperText
	 * @param active
	 * @param standard
	 */
	public MultiOptionQuestion(
		final String questionText,
		final String helperText,
		final Boolean active,
		final Boolean standard)
	{
		super(questionText, helperText, active, standard);
	}
	
	@Override
	public List<ChooseableValues> getValues()
	{
		return this.values;
	}
	
	@Override
	public void setValues(final List<ChooseableValues> values)
	{
		this.values = values;
	}
	
	
	public MultiOptionQuestion copyNoRules()
	{
		final var copy = new MultiOptionQuestion();
		copy.setActive(this.getActive());
		copy.setCategory(new QuestionCategory(this.getCategory()));
		copy.setHelperText(this.getHelperText());
		copy.setId(this.getId());
		copy.setInstructionText(this.getInstructionText());
		copy.setQuestionText(this.getQuestionText());
		copy.setStandard(this.getStandard());
		copy.setValues(this.values == null ? null : this.values.stream().map(v ->
		{
			final var ret = new ChooseableValues();
			ret.setId(v.getId());
			ret.setText(v.getText());
			ret.setValue(v.getValue());
			return ret;
		}).collect(Collectors.toList()));
		return copy;
	}
}
