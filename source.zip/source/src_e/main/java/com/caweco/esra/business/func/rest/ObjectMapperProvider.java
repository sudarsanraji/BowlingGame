
package com.caweco.esra.business.func.rest;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import jakarta.ws.rs.ext.ContextResolver;


public class ObjectMapperProvider implements ContextResolver<ObjectMapper>
{
	// https://eclipse-ee4j.github.io/jersey.github.io/documentation/latest/user-guide.html#json.jackson
	
	final ObjectMapper defaultObjectMapper;
	
	public ObjectMapperProvider()
	{
		this.defaultObjectMapper = createDefaultMapper();
	}
	
	@Override
	public ObjectMapper getContext(final Class<?> type)
	{
		return this.defaultObjectMapper;
	}
	
	private static ObjectMapper createDefaultMapper()
	{
		final ObjectMapper result = new ObjectMapper()
			.registerModule(new JavaTimeModule())
			.disable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
		return result;
	}
}
