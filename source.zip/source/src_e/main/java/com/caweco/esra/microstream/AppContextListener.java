
package com.caweco.esra.microstream;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.lang3.StringUtils;
import org.quartz.Scheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.rest.RestClientBIH;
import com.caweco.esra.business.utils.SysUtils;
import com.caweco.esra.entities.trust.ESRACustomTrustManager;


@WebListener
@SuppressWarnings("ucd") // required for Vaadin
public class AppContextListener implements ServletContextListener
{
	
	private Scheduler		storageBackupScheduler;
	
	public static Logger	LOG	= LoggerFactory.getLogger(AppContextListener.class);
	
	@Override
	public void contextInitialized(final ServletContextEvent sce)
	{		
		//Set default SSL Context
		try {
			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(null, new TrustManager[] { new ESRACustomTrustManager() }, null);
			SSLContext.setDefault(sslContext);
			
			AppContextListener.LOG.info("Default SSLContext has been changed to custom.");
		}
		catch (Exception exc)
		{
			AppContextListener.LOG.error("Creation of custom ESRA SSLContext failed", exc);
		}
		
		// App Config to ensure BIH Server availability in OpenShift environments: Add BIH Server to "nonProxyHost" system
		// parameter
		initNonProxyServer();
		initNonProxyServerSeaweb();
		AppContextListener.LOG.info("NonProxyHosts initialized.");
	}
	
	/**
	 * Manipulates {@link System#getProperties()} values: Adds BIH-Server to property with key
	 * {@link SysUtils#SYSTEMPROPERTYNAME_NONPROXYHOSTS}
	 */
	public static void initNonProxyServer()
	{
		RestClientBIH.BIH_SERVER.forEach(t ->
		{
			initNonProxyServer(t.getLeft());
		});
		SysUtils.printProp(SysUtils.SYSTEMPROPERTYNAME_NONPROXYHOSTS, true);
	}
	
	public static void initNonProxyServerSeaweb()
	{
		initNonProxyServer();
		SysUtils.printProp(SysUtils.SYSTEMPROPERTYNAME_NONPROXYHOSTS, true);
	}
	
	public static void initNonProxyServer(String server)
	{
		
		String http_nonProxyHosts_property =
			StringUtils.stripToNull(System.getProperty(SysUtils.SYSTEMPROPERTYNAME_NONPROXYHOSTS));
		if(http_nonProxyHosts_property == null)
		{
			System.setProperty(SysUtils.SYSTEMPROPERTYNAME_NONPROXYHOSTS, server);
		}
		else if(!http_nonProxyHosts_property.contains(server))
		{
			System.setProperty(SysUtils.SYSTEMPROPERTYNAME_NONPROXYHOSTS, http_nonProxyHosts_property + "|" + server);
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}
}
