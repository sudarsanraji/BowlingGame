package com.caweco.esra.entities.rest.general;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;


public class Intermediaries
{
	private String						name;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String						directPercentage;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String						totalPercentage;
	private Map<String, Intermediary>	intermediaries	= new HashMap<>();
	
	public Intermediaries()
	{
		// Empty Constructor for Framework
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public String getDirectPercentage()
	{
		return this.directPercentage;
	}
	
	public void setDirectPercentage(final String directPercentage)
	{
		this.directPercentage = directPercentage;
	}
	
	public String getTotalPercentage()
	{
		return this.totalPercentage;
	}
	
	public void setTotalPercentage(final String totalPercentage)
	{
		this.totalPercentage = totalPercentage;
	}
	
	public Map<String, Intermediary> getIntermediaries()
	{
		return this.intermediaries;
	}
	
	public void setIntermediaries(final Map<String, Intermediary> intermediaries)
	{
		this.intermediaries = intermediaries;
	}
	
	public IntermediaryTreeModel craeteIntermediaryModel()
	{
		IntermediaryTreeModel lastModel = null;
		IntermediaryTreeModel firstItem = null;
		
		for(Intermediary i : this.getIntermediaries().values())
		{
			if(lastModel == null)
			{
				lastModel = new IntermediaryTreeModel(i);
				firstItem = lastModel;
			}
			else
			{
				IntermediaryTreeModel intermediaryTreeModel = new IntermediaryTreeModel(i);
				lastModel.getIntermediary().add(intermediaryTreeModel);
				lastModel = intermediaryTreeModel;
			}
		}
		
		return firstItem;
	}
}
