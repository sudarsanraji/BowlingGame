package com.caweco.esra.dao.access;

import java.util.HashSet;
import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.saml.SamlCountry;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;

public class AccessControlCountriesDAO {
	private static ObjectMapper om = new ObjectMapper();
	
	public static Set<SamlCountry> findAll()
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcountries");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(Set.class, SamlCountry.class);

		try {
			return om.readValue(responseBody, type);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static void delete(SamlCountry item)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldapcountries/" + item.getCountryName());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		
		try {
			om.readValue(responseBody, SamlCountry.class);
			Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
			+" added the country "  + item.getCountryName() );
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
