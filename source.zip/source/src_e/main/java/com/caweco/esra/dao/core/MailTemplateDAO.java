package com.caweco.esra.dao.core;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.mailing.MailTemplate;
import com.caweco.esra.entities.mailing.MailType;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;


public class MailTemplateDAO
{
	
	public static MailTemplate findOrInit(Client parent, MailType type)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + parent.getUuid().toString() + "/mailTemplate/" + type.toString());
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		return response.readEntity(MailTemplate.class);
	}
}
