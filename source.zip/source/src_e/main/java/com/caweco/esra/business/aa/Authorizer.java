
package com.caweco.esra.business.aa;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.User;
import com.rapidclipse.framework.security.authorization.AuthorizationConfiguration;
import com.rapidclipse.framework.security.authorization.AuthorizationConfigurationProvider;
import com.rapidclipse.framework.security.authorization.AuthorizationManager;
import com.rapidclipse.framework.security.authorization.Subject;
import com.rapidclipse.framework.server.security.authentication.Authentication;
import com.rapidclipse.framework.server.security.authorization.AuthorizationResource;
import com.rapidclipse.framework.server.security.authorization.AuthorizationRole;
import com.rapidclipse.framework.server.security.authorization.AuthorizationSubject;
import com.vaadin.flow.server.VaadinSession;


public class Authorizer implements AuthorizationConfigurationProvider
{
	private static final Logger								LOG	= LoggerFactory.getLogger(Authorizer.class);
	
	private final Class<? extends AuthorizationSubject>		subjectEntityType;
	private final Class<? extends AuthorizationRole>		roleEntityType;
	private final Class<? extends AuthorizationResource>	resourceEntityType;
	
	public Authorizer(
		final Class<? extends AuthorizationSubject> subjectEntityType,
		final Class<? extends AuthorizationRole> roleEntityType,
		final Class<? extends AuthorizationResource> resourceEntityType)
	{
		this.subjectEntityType = subjectEntityType;
		this.roleEntityType = roleEntityType;
		this.resourceEntityType = resourceEntityType;
	}
	
	/**
	 * @return the subjectEntityType
	 */
	public Class<? extends AuthorizationSubject> getSubjectEntityType()
	{
		return this.subjectEntityType;
	}
	
	/**
	 * @return the roleEntityType
	 */
	public Class<? extends AuthorizationRole> getRoleEntityType()
	{
		return this.roleEntityType;
	}
	
	/**
	 * @return the resourceEntityType
	 */
	public Class<? extends AuthorizationResource> getResourceEntityType()
	{
		return this.resourceEntityType;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public AuthorizationConfiguration provideConfiguration()
	{
		final Map<String, Set<String>> resourceResources = new HashMap<>();
		final Map<String, Set<String>> roleRoles = new HashMap<>();
		final Map<String, Map<String, Integer>> rolePermissions = new HashMap<>();
		final Map<String, Set<String>> subjectRoles = new HashMap<>();
		
		final Set<User> subjects = this.getSubjects();
		final Set<Role> roles = this.getRoles();
		final Set<? extends AuthorizationResource> resources = this.getResources();
		
		for(final AuthorizationSubject subject : subjects)
		{
			subjectRoles.put(subject.subjectName(), this.unboxRoles(subject.roles()));
		}
		
		for(final AuthorizationRole role : roles)
		{
			rolePermissions.put(role.roleName(), this.unboxResources(role.resources()));
			roleRoles.put(role.roleName(), this.unboxRoles(role.roles()));
		}
		
		for(final AuthorizationResource resource : resources)
		{
			resourceResources.put(resource.resourceName(), new HashSet<String>());
		}
		
		return AuthorizationConfiguration.New(
			resourceResources,
			roleRoles,
			rolePermissions,
			subjectRoles);
	}
	
	protected Set<User> getSubjects()
	{
		HashSet<User> userSet = new HashSet<User>();
		Optional<User> optUser = UserDAO.find(CurrentUtil.getUser().getEmailAddress());
		
		if(optUser.isPresent())
		{
			userSet.add(optUser.get());
		}
		
		return userSet;
		
//		return UserDAO.findAll();
	}
	
	protected Set<Role> getRoles()
	{
		/*
		 * CLIENT DEPENDENT - NO CLIENT->NO ROLES->NO PERMISSIONS
		 */
		
		final Client client = CurrentUtil.getClient();
		if(client != null)
		{
			return client.getRoles(true);
		}
		else
		{
			return Collections.emptySet();
		}
	}
	
	protected Set<? extends AuthorizationResource> getResources()
	{
		/*
		 * CLIENT DEPENDENT - NO CLIENT->NO PERMISSIONS
		 */
		
		final Client client = CurrentUtil.getClient();
		if(client != null)
		{
			return AuthorizationResources.asSet();
		}
		else
		{
			return Collections.emptySet();
		}
	}
	
	protected Set<String> unboxRoles(final Collection<? extends AuthorizationRole> roles)
	{
		if(roles == null)
		{
			return null;
		}
		
		return roles.stream().map(AuthorizationRole::roleName).collect(Collectors.toSet());
	}
	
	protected Map<String, Integer> unboxResources(
		final Collection<? extends AuthorizationResource> resources)
	{
		if(resources == null)
		{
			return null;
		}
		
		return resources.stream().collect(Collectors.toMap(AuthorizationResource::resourceName,  _unused -> 1));
	}
	
	/* **************************************************************************************** */
	
	/**
	 * Reloads Authorization and updates user's permissions.
	 * <br />
	 * If this is used after client change, call this method AFTER current client set to in session, as "Roles" are
	 * taken from Role list of this client.
	 * 
	 * @param session
	 *            a VaadinSession
	 * @param user
	 *            a User
	 */
	public static void updatePermissions(
		final VaadinSession session,
		final User user)
	{
		
		//// UPDATE AUTHORIZATION
		
		final AuthorizationManager authorizationManager =
			Authorizer.updateAuthorizationManager(session);
		
		//// UPDATE USER AUTH
		
		// See Authentication.tryLogin(...)
		Subject subject = null;
		
		if(authorizationManager != null)
		{
			subject = authorizationManager.subject(user.getEmailAddress());
		}
		else
		{
			LOG.warn("LOGIC PROBLEM: AuthorizationManager not available!");
		}
		
		if(subject == null)
		{
			subject = Subject.New(user.getEmailAddress(), new HashSet<>());
			LOG.warn(
				"LOGIC PROBLEM: Subject not available. New Subject created for {}",
				user.getEmailAddress());
		}
		
		// See Authentication.setUser(...)
		session.setAttribute(Subject.class, subject);
		session.setAttribute(Authentication.class.getName() + ".AUTHENTICATION_RESULT", true);
	}
	
	/**
	 * Obtains {@link AuthorizationManager} from session.<br />
	 * If there is no AuthorizationManager in session, creates a new
	 * one with {@link Authorizer#createAuthorizationManager()} and sets it to session.
	 * 
	 * @see {@link Authorizer#createAuthorizationManager()}
	 * @param session
	 * @return
	 */
	public static AuthorizationManager getOrCreateAuthorizationManager(final VaadinSession session)
	{
		try
		{
			final AuthorizationManager authorizationManager = session.getAttribute(AuthorizationManager.class);
			if(authorizationManager == null)
			{
				final AuthorizationManager newAuthorizationManager = createAuthorizationManager();
				session.setAttribute(AuthorizationManager.class, newAuthorizationManager);
				return newAuthorizationManager;
			}
			else
			{
				return authorizationManager;
			}
		}
		catch(final Exception e)
		{
			LOG.error("Error creating AuthorizationManager.", e);
			return null;
		}
	}
	
	/**
	 * Creates a new AuthorizationManager from scratch.<br />
	 * Uses internally an {@link Authorizer} instance which uses {@link CurrentUtil#getClient()} to obtain Roles of
	 * current client.
	 * <p>
	 * Uses {@link CurrentUtil#getClient()}
	 * </p>
	 * 
	 * @return
	 */
	public static AuthorizationManager createAuthorizationManager()
	{
		final AppConfigurationProvider authorizationConfigurationProvider = AppConfigurationProvider.getInstance();
		final AuthorizationManager newAuthorizationManager =
			AuthorizationManager.New(authorizationConfigurationProvider);
		return newAuthorizationManager;
	}
	
	/**
	 * Obtains {@link AuthorizationManager} and reloads Authorization informations.
	 * 
	 * @param session
	 * @return
	 */
	public static AuthorizationManager updateAuthorizationManager(final VaadinSession session)
	{
		//// UPDATE AUTHORIZATION
		
		final AuthorizationManager authorizationManager =
			Authorizer.getOrCreateAuthorizationManager(session);
		
		if(authorizationManager != null)
		{
			authorizationManager.reloadAuthorizations();
		}
		return authorizationManager;
	}
	
}
