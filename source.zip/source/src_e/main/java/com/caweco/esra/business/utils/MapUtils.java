package com.caweco.esra.business.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public final class MapUtils {
	@SafeVarargs
	public static <K, V> Map<K, V> createMap(final Pair<K, V>... entries) {
		final Map<K, V> map = new HashMap<>();

		Stream.of(entries).forEach(p -> {
			map.put(p.getFirst(), p.getSecond());
		});

		return map;
	}

	private MapUtils() {
		throw new UnsupportedOperationException();
	}
}
