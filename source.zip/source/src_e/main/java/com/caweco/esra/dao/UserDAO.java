package com.caweco.esra.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.func.removing.UsageInfoUser;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.RemovableHelper;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.dto.RoleMetadataDTO;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.RoleCreator;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.rapidclipse.framework.server.data.DataAccessObject;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class UserDAO implements DataAccessObject<User>
{
	private static ObjectMapper om = new ObjectMapper().registerModule(new JavaTimeModule());
	
	public static Set<User> findAll()
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/all");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(List.class, UserMetadataDTO.class);
		
		try {
			List<UserMetadataDTO> a = om.readValue(responseBody, type);
			
			Set<User> userSet = new HashSet<>();
			
			a.forEach(dto -> {
				userSet.add(UserCreator.convertMetadataDTOToUser(dto));
			});
			
			return userSet;
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static Optional<User> find(final String mail)
	{
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/" + mail);
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatusInfo().getStatusCode() == 200)
		{
			UserMetadataDTO responseBody = response.readEntity(UserMetadataDTO.class);
			return Optional.of(UserCreator.convertMetadataDTOToUser(responseBody));
		}
		else
		{
			return Optional.empty();
		}
	}
	
	public static void insert(final User user)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
		Response response = webTarget.request().put(Entity.entity(UserCreator.convertUserToMetadataDTO(user), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the user :" + user.getFirstname() +" "+ user.getLastname() + " into the system");	
	}
	
	public static void update(final User user)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
		
		Response response = webTarget.request().post(Entity.entity(UserCreator.convertUserToMetadataDTO(user), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the user " + user.getFirstname() +" "+ user.getLastname() + " into the system");	
	}
	
	public static void delete(User user)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
		
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the user " + user.getFirstname() +" "+ user.getLastname() + " from the system");	
	}
	
	public static User getOrCreate(final String email)
	{
		
		final Optional<User> maybeFound = UserDAO.find(email);
		if (maybeFound.isPresent())
		{
			Logger.tag("REST").debug("User found for email: {}", email);
			return maybeFound.get();
		}
		else
		{
			final User newUser = new User(email);
			UserDAO.insert(newUser);
			Logger.tag("REST").debug("User created and added: {}", email);
			return newUser;
		}
	}
	
	/**
	 * Removes user from {@link Client}s and it's {@link MessageGroup}s.<br />
	 * <b>Does NOT remove user in a client's {@link Screening} as screeningOwner or esuWorker. This SHOULD be excluded by
	 * previous code</b>,<br />
	 * e.g. with a check by {@link RemovableHelper#isFullyRemovable(List)}, which returns only "true" if user is NOT
	 * screeningOwner, screeningServiceUser or esuWorker.
	 * 
	 * @param user
	 * @param usages
	 */
	public static void deleteFull(User user, List<UsageInfoUser> usages)
	{
		// Remove user from clients and it's MessageGroups
		
		usages.forEach(usage ->
		{
			// Remove user from this client
			if (usage.isAssigned())
			{
				ClientDAO.removeUser(usage.getClient(), user);
			}
			
			// Remove as PublicMessageGroupFollower from client's screenings
			
			usage.getUserIsPublicMessageGroupFollower().forEach(scr ->
			{
				MessageGroupDAO.removeMember(scr.getPublicMessages(false), user);
			});
			
			// Remove as MessageGroup Member from client's screenings
			
			usage.getUserIsMessageGroupMember().forEach(scr ->
			{			
				for (Entry<UUID, MessageGroup> it : scr.getMessageGroups(true).entrySet())
				{
					MessageGroupDAO.removeMember(it.getValue(), user);
					
//					if (groupToProcessFurther != null)
//					{
//						messageGroupsToDelete.add(groupToProcessFurther);
//					}
				}
				
				// TODO: Maybe delete empty MessageGroups?
			});
			
			// No need to remove user as screeningOwner, screeningServiceUser or esu user, this is excluded by definition.
		});
		
		
		// Remove user from root user list
		UserDAO.delete(user);
		
	}
	
	
	public static void removeRole(User user, Role role) 
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress() + "/role/" + role.getId());
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
	}

	public static void removeRoles(Client client, User user, Set<Role> selectedItems) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		ArrayList<RoleMetadataDTO> roleMetadata = new ArrayList<>();
		
		selectedItems.forEach((role) -> {
			roleMetadata.add(RoleCreator.convertRoleToMetadataDTO(role));
		});
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/user/" + user.getEmailAddress() + "/removeRole");
		
		Response response = webTarget.request().put(Entity.entity(roleMetadata, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the roles"+ CommonUtil.getCommaSeparatedRoleNames(selectedItems) + " for the user " + user.getFirstname() +" "+ user.getLastname() + " from the system");	
	}

	public static void addRoles(Client client, User user, Set<Role> selectedItems) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		ArrayList<RoleMetadataDTO> roleMetadata = new ArrayList<>();
		
		selectedItems.forEach((role) -> {
			roleMetadata.add(RoleCreator.convertRoleToMetadataDTO(role));
		});
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/user/" + user.getEmailAddress() + "/addRole");
		
		Response response = webTarget.request().put(Entity.entity(roleMetadata, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the roles "+ CommonUtil.getCommaSeparatedRoleNames(selectedItems)+ " for the user " + user.getFirstname() +" "+ user.getLastname() + " from the system");	
	}

	public static Set<Role> getRoles(User user) {
		return getRoles(Arrays.asList(user)).get(user);
	}
	
	/**
	 * Check if the specified role is used by any of the specified users.
	 */
	public static boolean isRoleUsed(final Role role, final String clientid)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/user/roles/is-in-use")
			.queryParam("roleid", role.getId().toString())
			.queryParam("clientid", clientid);
		Response response = webTarget.request().post(null);
		Logger.tag("REST").info(response.toString());
		
		return Boolean.parseBoolean(response.readEntity(String.class));
	}

	/**
	 * Receive all sets of roles for the specified users. 
	 * More efficient than the single {@link #getRoles(User)} method,
	 * as this will batch all users in a single call.
	 */
	public static Map<User, Set<Role>> getRoles(final List<User> users) {
		final int batchSize = 100;
		final var batch = new ArrayList<User>(batchSize);
		final var retval = new HashMap<User, Set<Role>>();
		
		int batchIdx = 0;
		for(int i = 0; i < users.size(); i++)
		{
			batch.add(users.get(i));
			batchIdx++;
			if(i == users.size() - 1 || batchIdx == batchSize)
			{
				batchIdx = 0;
				Logger.tag("REST").info("Calling getRoles() for user in idx {}-{} out of {}", i - batch.size(), i, users.size());
				getRolesInternal(batch).forEach((k, v) -> retval.merge(k, v, (v1,v2)->v2));
			}
		}
		
		users.forEach(u -> {
			retval.putIfAbsent(u, new HashSet<Role>());
		});
		
		return retval;
	}
	
	private static Map<User, Set<Role>> getRolesInternal(final Collection<User> users) {
		final var client = RestUtil.getRestClient_ESRADB();
		
		final var webTarget = client.getMethodTarget("/user/roles")
			.queryParam("emails", String.join(",", users.stream().map(User::getEmailAddress).collect(Collectors.toList())));
		
		final var httpResponse = webTarget.request().get();
		Logger.tag("REST").info(httpResponse.toString());
		
		// Map<Email of User, List<Roles of User>>
		final var responseTyperef = new TypeReference<Map<String, List<RoleMetadataDTO>>>() {};
		final var responseBodyJson = httpResponse.readEntity(String.class);
		final Map<String, List<RoleMetadataDTO>> responseEntity;
		
		try {
			responseEntity = om.readValue(responseBodyJson, responseTyperef);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return responseEntity.entrySet().stream().collect(Collectors.toMap(
				e -> users.stream().filter(u -> u.getEmailAddress().equals(e.getKey())).findFirst().get(),
				e -> e.getValue().stream().map(RoleCreator::convertMetadataDTOToRole).collect(Collectors.toSet())));
	}

	public static Set<Role> getRolesForClient(User user, Client client) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/user/" + user.getEmailAddress() + "/roles");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(List.class, RoleMetadataDTO.class);
		
		try {
			List<RoleMetadataDTO> a = om.readValue(responseBody, type);
			
			Set<Role> roleSet = new HashSet<>();
			
			a.forEach(dto -> {
				roleSet.add(RoleCreator.convertMetadataDTOToRole(dto));
			});
			
			return roleSet;
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	
	/*******************************************************************/
	
	public static boolean isEsuUser(Client client, User user)
	{
		Set<Role> roles = client.getRoles(false);
		
		Optional<Role> esuRole = roles.stream().filter(role -> 
			user.getRoles(false).contains(role) && role.getResources().contains(AuthorizationResources.ESUACCESS)
		)
		.findFirst();
		
		return esuRole.isPresent();
	}
	
	
}
