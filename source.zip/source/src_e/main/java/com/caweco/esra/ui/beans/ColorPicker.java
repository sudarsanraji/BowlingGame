package com.caweco.esra.ui.beans;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CssHelper;
import com.caweco.esra.business.utils.UiHelper;
import com.vaadin.flow.component.AbstractSinglePropertyField;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.Tag;

@Tag("input")
public class ColorPicker extends AbstractSinglePropertyField<ColorPicker, String> implements HasStyle
{
	
	// See also "DatePicker" from
	// https://vaadin.com/docs/v14/flow/binding-data/tutorial-flow-field.html#converting-property-values
	
	public ColorPicker()
	{
		super("value", null, true);
		this.getElement().setAttribute("type", "color");
		
		UiHelper.setAriaLabel(this, Aria.get("Values_esraTag_color"));
		
		this.setSynchronizedEvent("change");
	}
	
	@Override
	public void setValue(String value)
	{
		
		if(CssHelper.isValidCssHexColor(value))
		{
			super.setValue(value);
			return;
		}
		
		String cssHexColorForCssColorKeyword = CssHelper.getCssHexColorForCssColorKeyword(value);
		if(cssHexColorForCssColorKeyword != null)
		{
			super.setValue(cssHexColorForCssColorKeyword);
			return;
		}
		
		super.setValue(value);
		
	}
}
