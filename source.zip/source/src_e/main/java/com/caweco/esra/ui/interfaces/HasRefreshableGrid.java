package com.caweco.esra.ui.interfaces;

public interface HasRefreshableGrid
{
	
	void refreshGridData();
	
}
