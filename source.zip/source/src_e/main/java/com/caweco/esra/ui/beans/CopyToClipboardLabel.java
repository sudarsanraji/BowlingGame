package com.caweco.esra.ui.beans;

import java.beans.Beans;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.shared.ui.LoadMode;

public class CopyToClipboardLabel extends Label
{
	public CopyToClipboardLabel()
	{
		super();
		
		UI.getCurrent().getPage().addJavaScript("../frontend/ctoc/ctoc.js", LoadMode.EAGER);
		
		if(!Beans.isDesignTime())
		{
			this.getElement().getClassList().add("has-tooltip");
			this.getElement().executeJs("adjustClipboard($0);", this);			
		}
	}
	
	@Override
	public void setText(String text)
	{
		super.setText(text);
		this.getElement().setAttribute("data-clipboard-text", this.getText());
	}
}
