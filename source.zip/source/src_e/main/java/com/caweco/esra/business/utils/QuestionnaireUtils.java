package com.caweco.esra.business.utils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.caweco.esra.dao.questionnaire.QuestionnaireDAO;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.ConditionObject;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionResult;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;


public class QuestionnaireUtils
{
	/**
	 * Returns true if the question has a rule that relies on given choosable, false otherwise
	 * 
	 * @param question
	 *            a Question
	 * @param choosable
	 *            a ChoosableValue
	 * @return
	 */
	public static boolean hasMatchingRule(final Question question, final ChooseableValues choosable)
	{
		// @formatter:off
		if(question.getRule() == null) {
			return false;
		}
		else {
			final Optional<ConditionObject> qHasC = question.getRule()
				.getAnds()
				.stream()
				.flatMap(ac -> ac.getAnds().stream())
				.filter(co -> Objects.equals(choosable, co.getValue()))
				.findFirst();
			// @formatter:on
			return qHasC.isPresent();
		}
	}
	
	public static boolean isAlreadyInUse(final Questionnaire questionnaire)
	{
		return QuestionnaireDAO.isInUse(CurrentUtil.getClient(), questionnaire);
		
//		return ScreeningDAO.findAll().values().stream().filter(
//			s -> (s.getTradeSanctionResult(true).getQuestionnaire() != null
//				? s.getTradeSanctionResult(false).getQuestionnaire().equals(questionnaire)
//				: false)
//				|| (s.getBusinessInformationResult(true).getQuestionnaire() != null
//					? s.getBusinessInformationResult(false).getQuestionnaire().equals(questionnaire)
//					: false)).findAny().isPresent();
	}
	
	public static Optional<QuestionResult> getQuestionResult_forQuestion(final QuestionnaireResult parent, final Question q)
	{
		// @formatter:off
		
		final Optional<QuestionResult> maybeFound = 
			parent.getResults().stream()
			
				.filter(res -> res.getQuestion().equals(q))
				.findFirst();
		
		return maybeFound;
		
		// @formatter:on
	}
	
	public static Map<QuestionCategory, List<Question>> getQuestions_groupedByCategory(final QuestionnaireResult parent)
	{
		// @formatter:off
		
		final List<Question> allQuestions = parent.getQuestionnaire().getQuestions(true);
		
		final Map<QuestionCategory, List<Question>> groupedQuestions = allQuestions.stream()
			
			.filter(qu -> Objects.nonNull(qu.getCategory()))
			.collect(Collectors.groupingBy(Question::getCategory));
		
		return groupedQuestions;
		
		// @formatter:on
	}
}
