
package com.caweco.esra.ui.main;

import java.beans.Beans;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.usernotifications.UserNotificationManager;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.ui.admin.PageClientConfig;
import com.caweco.esra.ui.dialogs.DialogUserNotifications;
import com.caweco.esra.ui.page.PageUserTasks;
import com.rapidclipse.framework.security.authorization.Subject;
import com.rapidclipse.framework.server.navigation.Navigation;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluatingComponentExtension;
import com.rapidclipse.framework.server.security.authorization.SubjectEvaluationStrategy;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.shared.Registration;


public class PartAppHeader extends HorizontalLayout
{
	private Registration userNotificationListenerRegistration;
	
	public PartAppHeader()
	{
		super();
		this.initUI();
		
		UiHelper.image_addEmptyAltAttribute(this.image);
		UiHelper.setAriaLabel(this.image, Aria.get("AppHeader_toStartPage"));
		UiHelper.setAriaLabel(this.btnBackend, Aria.get("AppHeader_settings"));
		UiHelper.setAriaLabel(this.btnLogout, Aria.get("AppHeader_logout"));
		UiHelper.setAriaLabel(this.cboClientChooser, Aria.get("AppHeader_changeClient"));
		UiHelper.setAriaLabel(this.btnNotifications, Aria.get("AppHeader_showNotifications"));
		UiHelper.setAriaLabel(this.btnUserTasks, Aria.get("AppHeader_showTasks"));
		
		final User user = CurrentUtil.getUser();
		
		this.label3.setVisible(isBannerVisible());
		
		if(user != null)
		{
			this.lblUser.setText(user.getFirstname() + " " + user.getLastname());
			
			final ListDataProvider<Client> dataProvider = DataProvider.ofCollection(ClientDAO.findByUser(user));
			dataProvider.setSortOrder(Client::getClientDescription, SortDirection.ASCENDING);
			this.cboClientChooser.setDataProvider(dataProvider);
			
			if(CurrentUtil.getClient() != null)
			{
				this.cboClientChooser.setValue(CurrentUtil.getClient());
			}
			if(user.isAppAdmin())
			{
				this.btnBackend.setEnabled(true);
			}
		}
		else
		{
			this.setEnabled(false);
		}
		
		if (!Beans.isDesignTime())
		{
			this.anchor.setHref("mailto:" + CurrentUtil.getClient().getClientConfiguration().getSupportEmail());
			this.anchor.setText(CurrentUtil.getClient().getClientConfiguration().getSupportEmail());
		}
	}
	
	@Override
	protected void onAttach(final AttachEvent attachEvent)
	{
		super.onAttach(attachEvent);
		final UI ui = attachEvent.getUI();
		final User user = CurrentUtil.getUser();
		if(user != null)
		{
			this.userNotificationListenerRegistration = UserNotificationManager.registerNotificationListener(user.getEmailAddress(), notification -> {
				ui.access(() -> this.onNewNotification());
			});
		}
	}
	
	@Override
	protected void onDetach(final DetachEvent detachEvent)
	{
		if(this.userNotificationListenerRegistration != null)
		{
			this.userNotificationListenerRegistration.remove();
		}
		super.onDetach(detachEvent);
	}
	
	protected void onNewNotification()
	{
		// TODO: Change button color?

		this.btnNotifications.setIcon(VaadinIcon.BELL.create());
		this.btnNotifications.addThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SUCCESS);
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnBackend}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnBackend_onClick(final ClickEvent<Button> event)
	{
		Navigation.navigateTo(PageClientConfig.class);
	}
	
	/**
	 * Event handler delegate method for the {@link Image} {@link #image}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void image_onClick(final ClickEvent<Image> event)
	{
		Navigation.navigateTo(PageSanctionSearch.class);
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #cboClientChooser}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void cboClientChooser_valueChanged(final ComponentValueChangeEvent<ComboBox<Client>, Client> event)
	{
		if(event.getValue() != null)
		{
			if(event.isFromClient())
			{
				CommonUtil.changeClient(this.cboClientChooser.getValue(), true);
				Authorization.evaluateComponents(this.btnBackend);
				if(CurrentUtil.getUser() != null && CurrentUtil.getUser().isAppAdmin())
				{
					this.btnBackend.setEnabled(true);
				}
				else
				{
					System.err.println("User " + CurrentUtil.getUser().toString() + " is not a app admin");
				}
				
				UI.getCurrent().navigate(PageSanctionSearch.class);
				Notificator.success("Client changed.");
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnLogout}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnLogout_onClick(final ClickEvent<Button> event)
	{
		CurrentUtil.toSession(User.class, null);
		CurrentUtil.toSession(Subject.class, null);
		
		VaadinSession.getCurrent().getSession().invalidate();
		UI.getCurrent().navigate(PageLoggedOut.class);
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNotifications}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNotifications_onClick(final ClickEvent<Button> event)
	{
		this.btnNotifications.setIcon(VaadinIcon.BELL_O.create());
		this.btnNotifications.removeThemeVariants(ButtonVariant.LUMO_PRIMARY, ButtonVariant.LUMO_SUCCESS);
		
		DialogUserNotifications.show();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnUserTasks}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnUserTasks_onClick(final ClickEvent<Button> event)
	{
		UI.getCurrent().navigate(PageUserTasks.class);
	}
	
	/**
	 * This method determines if the banner "Test Environment" should be shown or not
	 * @return boolean
	 */
	private boolean isBannerVisible() {
		boolean showBanner = Boolean.FALSE;
		VaadinRequest vaadinRequest = VaadinService.getCurrentRequest();
		if (vaadinRequest instanceof HttpServletRequest) {
			String applicationBaseUrl = ((HttpServletRequest) vaadinRequest).getServerName();
			String evironmentProperties = ApplicationPropertyProvider.getEnvBanner();
			if (!StringUtils.isEmpty(evironmentProperties) && null != applicationBaseUrl) {
				String[] environments = evironmentProperties.split(",");
				showBanner = Arrays.stream(environments).map(String::trim).anyMatch(applicationBaseUrl::contains);
			}
		}
		return showBanner;
	}

	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.image = new Image();
		this.label = new Label();
		this.verticalLayout = new VerticalLayout();
		this.label3 = new Label();
		this.horizontalLayout2 = new HorizontalLayout();
		this.horizontalLayout = new HorizontalLayout();
		this.label2 = new Label();
		this.cboClientChooser = new ComboBox<>();
		this.lblUser = new Label();
		this.btnNotifications = new Button();
		this.btnUserTasks = new Button();
		this.btnBackend = new Button();
		this.btnLogout = new Button();
		this.horizontalLayout3 = new HorizontalLayout();
		this.lblSupportDesc = new Label();
		this.anchor = new Anchor();
	
		this.setClassName("c-main-header");
		this.setPadding(true);
		this.image.setClassName("esra-clickable");
		this.image.setMinHeight("50px");
		this.image.setMinWidth("65px");
		this.image.setSrc("frontend/images/AllianzIcon.png");
		this.label.setText("ESRA");
		this.label.getStyle().set("font-weight", "bold");
		this.label.getStyle().set("font-size", "18px");
		this.label3.setText("TEST Environment");
		this.label3.setVisible(false);
		this.label3.getStyle().set("font-family", "Arial");
		this.label3.getStyle().set("font-weight", "bold");
		this.label3.getStyle().set("font-size", "18");
		this.label3.getStyle().set("color", "red");
		this.horizontalLayout2.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
		this.horizontalLayout2.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.horizontalLayout2.getStyle().set("flex-wrap", "wrap-reverse");
		this.label2.setText("Client");
		this.cboClientChooser.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(Client::getClientDescription));
		this.lblUser.setText("Label");
		this.lblUser.getStyle().set("flex-basis", "200px");
		this.btnNotifications.setIcon(VaadinIcon.BELL_O.create());
		this.btnUserTasks.setVisible(false);
		this.btnUserTasks.setIcon(VaadinIcon.TASKS.create());
		this.btnBackend.setIcon(VaadinIcon.COG.create());
		this.btnLogout.setIcon(VaadinIcon.SIGN_OUT.create());
		this.lblSupportDesc.setText("For any ESRA-related questions, please contact");
		this.anchor.setHref("mailto:agcs-esra@allianz.com");
		this.anchor.setText("agcs-esra@allianz.com");
		this.anchor.getStyle().set("margin-left", "0.5em");
	
		Authorization.setSubjectEvaluatingComponentExtension(this.btnBackend, SubjectEvaluatingComponentExtension.Builder
				.New().add(AuthorizationResources.BACKENDACCESS.resource(), SubjectEvaluationStrategy.ENABLED).build());
	
		this.label2.setSizeUndefined();
		this.cboClientChooser.setSizeUndefined();
		this.lblUser.setSizeUndefined();
		this.btnNotifications.setSizeUndefined();
		this.btnUserTasks.setSizeUndefined();
		this.btnBackend.setSizeUndefined();
		this.btnLogout.setSizeUndefined();
		this.horizontalLayout.add(this.label2, this.cboClientChooser, this.lblUser, this.btnNotifications,
				this.btnUserTasks, this.btnBackend, this.btnLogout);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label2);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblUser);
		this.horizontalLayout.setWidth(null);
		this.horizontalLayout.setHeightFull();
		this.horizontalLayout2.add(this.horizontalLayout);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.horizontalLayout);
		this.lblSupportDesc.setSizeUndefined();
		this.anchor.setSizeUndefined();
		this.horizontalLayout3.add(this.lblSupportDesc, this.anchor);
		this.horizontalLayout3.setVerticalComponentAlignment(FlexComponent.Alignment.END, this.lblSupportDesc);
		this.horizontalLayout3.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.anchor);
		this.label3.setSizeUndefined();
		this.horizontalLayout2.setSizeUndefined();
		this.horizontalLayout3.setWidth(null);
		this.horizontalLayout3.setHeightFull();
		this.verticalLayout.add(this.label3, this.horizontalLayout2, this.horizontalLayout3);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.label3);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.END, this.horizontalLayout2);
		this.verticalLayout.setFlexGrow(1.0, this.horizontalLayout2);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.END, this.horizontalLayout3);
		this.image.setWidth("60px");
		this.image.setHeight("60px");
		this.label.setSizeUndefined();
		this.verticalLayout.setWidthFull();
		this.verticalLayout.setHeight(null);
		this.add(this.image, this.label, this.verticalLayout);
		this.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.image);
		this.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.setWidthFull();
		this.setHeight(null);
	
		Authorization.evaluateComponents(this);
	
		this.image.addClickListener(this::image_onClick);
		this.cboClientChooser.addValueChangeListener(this::cboClientChooser_valueChanged);
		this.btnNotifications.addClickListener(this::btnNotifications_onClick);
		this.btnUserTasks.addClickListener(this::btnUserTasks_onClick);
		this.btnBackend.addClickListener(this::btnBackend_onClick);
		this.btnLogout.addClickListener(this::btnLogout_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button btnNotifications, btnUserTasks, btnBackend, btnLogout;
	private Image image;
	private Anchor anchor;
	private VerticalLayout verticalLayout;
	private HorizontalLayout horizontalLayout2, horizontalLayout, horizontalLayout3;
	private Label label, label3, label2, lblUser, lblSupportDesc;
	private ComboBox<Client> cboClientChooser;
	// </generated-code>
	
}
