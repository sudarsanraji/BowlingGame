package com.caweco.esra.business.func.rest;

public enum RestEndpoint
{
	CARA,
	SEAWEB;
}
