package com.caweco.esra.entities.applog;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.ScreeningStatus;

public class ChangeEntry
{
	
	public static ChangeEntry NewOwnerChange(final User changedBy, final User from, final User to)
	{
		// @formatter:off
		final ChangeEntry changeEntry = New(
				"Owner change", 
				changedBy, 
				(from != null ? from.getEmailAddress(): null), 
				(to != null ? to.getEmailAddress() : null)
			);
		// @formatter:on
		return changeEntry;
	}
	
	public static ChangeEntry NewStateChangeToReviewFinalized(final User changedBy, final ScreeningStatus from)
	{
		// @formatter:off
		final ChangeEntry changeEntry = New(
				"State change to \"Published\"", 
				changedBy, 
				(from != null ? from.getStatus() : null), 
				ScreeningStatus.REVIEW_FINALIZED.getStatus()
			);
		// @formatter:on
		return changeEntry;
	}
	
	public static ChangeEntry TakeoverOwnership(final User changedBy, final User originalOwner)
	{
		// @formatter:off
		final ChangeEntry changeEntry = New(
				"Ownership was taken over", 
				changedBy, 
				originalOwner.getEmailAddress(), 
				changedBy.getEmailAddress()
			);
		// @formatter:on
		return changeEntry;
	}
	
	public static ChangeEntry New(final String type, final User changedBy, final String from, final String to)
	{
		Objects.requireNonNull(type);
		Objects.requireNonNull(changedBy);
		final ChangeEntry changeEntry = new ChangeEntry();
		changeEntry.setChangedBy(changedBy.getEmailAddress());
		changeEntry.setChangeType(type);
		changeEntry.setPreviousValue(from);
		changeEntry.setNewValue(to);
		return changeEntry;
	}
	
	private String  changedBy;
	private final Instant changed = Instant.now();
	private String  changeType;
	private String  previousValue;
	private String  newValue;
	private UUID	changeId;
	
	@Override
	public boolean equals(final Object obj)
	{
		if (!(obj instanceof ChangeEntry)) {
			return false;
		}

		if (this == obj) {
			return true;
		}
		
		final ChangeEntry other = (ChangeEntry)obj;
		
		return Objects.equals(this.changedBy, other.changedBy) &&
			Objects.equals(this.changed, other.changed) &&
			Objects.equals(this.changeType, other.changeType) &&
			Objects.equals(this.newValue, other.newValue) &&
			Objects.equals(this.previousValue, other.previousValue);
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(this.changedBy, this.changed, this.changeType, this.newValue, this.previousValue);
	}
	
	protected ChangeEntry()
	{
		super();
	}
	
	public String getChangedBy()
	{
		return this.changedBy;
	}
	
	protected void setChangedBy(final String changedBy)
	{
		this.changedBy = changedBy;
	}
	
	public String getChangeType()
	{
		return this.changeType;
	}
	
	public void setChangeType(final String changeType)
	{
		Objects.requireNonNull(changeType);
		this.changeType = changeType;
	}
	
	public String getPreviousValue()
	{
		return this.previousValue;
	}
	
	public void setPreviousValue(final String previousValue)
	{
		this.previousValue = previousValue;
	}
	
	public String getNewValue()
	{
		return this.newValue;
	}
	
	public void setNewValue(final String newValue)
	{
		this.newValue = newValue;
	}
	
	public Instant getChanged()
	{
		return this.changed;
	}

	public UUID getChangeId() {
		return this.changeId;
	}

	public void setChangeId(final UUID changeId) {
		this.changeId = changeId;
	}
	
	
	
}
