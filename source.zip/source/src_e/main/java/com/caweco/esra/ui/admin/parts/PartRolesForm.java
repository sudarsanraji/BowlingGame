package com.caweco.esra.ui.admin.parts;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.RoleDAO;
import com.caweco.esra.entities.Role;
import com.caweco.esra.ui.admin.parts.renderer.RendererRoleBackendActions;
import com.caweco.esra.ui.interfaces.HasRefreshableGrid;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.GridFilterSubjectFactory;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.formlayout.FormLayout.FormItem;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;


public class PartRolesForm extends VerticalLayout implements HasRefreshableGrid
{
	
	
	public static final Logger LOG            = LoggerFactory.getLogger(PartRolesForm.class);
	
	private Role role;
	
	Comparator<Role>           roleComparator = Comparator
		.comparing(Role::getName, Comparator.nullsFirst(String.CASE_INSENSITIVE_ORDER));
	
	/**
	 *
	 */
	public PartRolesForm()
	{
		super();
		this.initUI();
		

		this.gridRoles.addColumn(RenderedComponent.Renderer(() -> new RendererRoleBackendActions(this)))
			.setResizable(true)
			.setSortable(false)
			.setAutoWidth(true)
			.setFlexGrow(0);
		
		this.refreshGridData();
	}
	
	@Override
	public void refreshGridData()
	{
		Set<Role>  roles       = CurrentUtil.getClient().getRoles(true);
		List<Role> rolesSorted = roles.stream().sorted(this.roleComparator).collect(Collectors.toList());
		
		this.gridRoles.setItems(rolesSorted);
		this.filterComponent.connectWith(this.gridRoles);
	}
	
	protected void setCurrentRole(Role it)
	{
		this.role = it;
		
		this.binder.readBean(this.role);
		
		this.mainForm.setEnabled(this.role != null);
		this.btnSave.setEnabled(this.role != null);
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #gridRoles}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridRoles_selectionChange(SelectionEvent<Grid<Role>, Role> event)
	{
		Optional<Role> firstSelectedItem = event.getFirstSelectedItem();
		
		this.setCurrentRole(firstSelectedItem.orElse(null));
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNew_onClick(final ClickEvent<Button> event)
	{
		this.gridRoles.deselectAll();
		
		this.setCurrentRole(new Role());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		try
		{
			boolean isNewRole = !CurrentUtil.getClient().getRoles(true).contains(this.role);
			
			this.binder.writeBean(this.role);
			
			if (isNewRole)
			{
				this.role.setId(UUID.randomUUID());
				RoleDAO.insert(this.role);
				
				this.refreshGridData();
				this.gridRoles.select(this.role);
			}
			else
			{
				RoleDAO.update(this.role);
				this.gridRoles.getDataProvider().refreshItem(this.role);
			}
			
		}
		catch(final ValidationException e)
		{
			LOG.debug("Error validation role.", e);
			Notificator.error("Validation failed: " + e.getMessage());
		}
		
	}
	
	public void addSelListener(final SelectionListener<Grid<Role>, Role> selListener)
	{
		this.gridRoles.addSelectionListener(selListener);
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.filterComponent = new FilterComponent();
		this.gridRoles = new Grid<>(Role.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.btnNew = new Button();
		this.btnSave = new Button();
		this.mainForm = new FormLayout();
		this.formItem2 = new FormItem();
		this.lblName = new Label();
		this.txtName = new TextField();
		this.formItem = new FormItem();
		this.lblDescription = new Label();
		this.txtDescription = new TextArea();
		this.binder = new Binder<>();
		
		this.gridRoles.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
		this.gridRoles.addColumn(Role::getName).setKey("name").setHeader(CaptionUtils.resolveCaption(Role.class, "name"))
			.setSortable(true);
		this.gridRoles.addColumn(Role::getDescription).setKey("description")
			.setHeader(CaptionUtils.resolveCaption(Role.class, "description")).setSortable(true);
		this.gridRoles.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.btnNew.setText("New");
		this.btnNew.setIcon(VaadinIcon.PLUS.create());
		this.btnSave.setEnabled(false);
		this.btnSave.setText("Save");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		this.mainForm.setResponsiveSteps(new FormLayout.ResponsiveStep("0px", 1, FormLayout.ResponsiveStep.LabelsPosition.TOP));
		this.lblName.setText("Role");
		this.lblDescription.setText("Description");
		
		this.binder.forField(this.txtDescription).withNullRepresentation("").bind(Role::getDescription, Role::setDescription);
		this.binder.forField(this.txtName).asRequired().withNullRepresentation("").bind(Role::getName, Role::setName);
		
		this.filterComponent.connectWith(this.gridRoles.getDataProvider());
		this.filterComponent.setFilterSubject(GridFilterSubjectFactory
			.CreateFilterSubject(this.gridRoles, Arrays.asList("name", "description"), Arrays.asList("name", "description")));
		
		this.btnNew.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.btnNew, this.btnSave);
		this.lblName.setSizeUndefined();
		this.lblName.getElement().setAttribute("slot", "label");
		this.txtName.setWidthFull();
		this.txtName.setHeight(null);
		this.formItem2.add(this.lblName, this.txtName);
		this.lblDescription.setSizeUndefined();
		this.lblDescription.getElement().setAttribute("slot", "label");
		this.txtDescription.setWidthFull();
		this.txtDescription.setHeight("100px");
		this.formItem.add(this.lblDescription, this.txtDescription);
		this.mainForm.add(this.formItem2, this.formItem);
		this.filterComponent.setWidthFull();
		this.filterComponent.setHeight(null);
		this.gridRoles.setWidthFull();
		this.gridRoles.setHeight(null);
		this.horizontalLayout.setWidthFull();
		this.horizontalLayout.setHeight(null);
		this.mainForm.setWidthFull();
		this.mainForm.setHeight(null);
		this.add(this.filterComponent, this.gridRoles, this.horizontalLayout, this.mainForm);
		this.setFlexGrow(1.0, this.gridRoles);
		this.setSizeFull();
		
		this.gridRoles.addSelectionListener(this::gridRoles_selectionChange);
		this.btnNew.addClickListener(this::btnNew_onClick);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private FormLayout mainForm;
	private Button btnNew, btnSave;
	private TextArea txtDescription;
	private HorizontalLayout horizontalLayout;
	private Label lblName, lblDescription;
	private Binder<Role> binder;
	private FilterComponent filterComponent;
	private TextField txtName;
	private FormItem formItem2, formItem;
	private Grid<Role> gridRoles;
	// </generated-code>
	
	
}
