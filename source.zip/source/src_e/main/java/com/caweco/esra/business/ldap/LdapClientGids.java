package com.caweco.esra.business.ldap;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CollectionUtil;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.ldap.LdapOrg;

public class LdapClientGids
{
	public static final Logger LOG = LoggerFactory.getLogger(LdapClientGids.class);

	public static final String LDAP_URL = "ldap://gids.srv.allianz";
	public static final String LDAP_PORT = "389";
	public static final String LDAP_BASE = "DC=GIDS,DC=ALLIANZ,DC=COM";
	public static final String LDAP_URL_FULL = LDAP_URL + ":" + LDAP_PORT + "/" + LDAP_BASE;

	public static final String LDAP_CONTEXT_FACTORY_VALUE = "com.sun.jndi.ldap.LdapCtxFactory";
	public static final String LDAP_CONNECT_TIMEOUT_KEY = "com.sun.jndi.ldap.connect.timeout";
	public static final String LDAP_READ_TIMEOUT_KEY = "com.sun.jndi.ldap.read.timeout";

	public static final String LDAP_OU_ORGS = "OU=orgs";
	public static final String LDAP_OU_USERS = "OU=users";

	private final DirContext ctx;

	Comparator<LdapOrg> sorter = Comparator.comparing(
		LdapOrg::getDisplayName,
		Comparator.nullsFirst(Comparator.naturalOrder())
	);

	public LdapClientGids(final String ldapUser, final String ldapPwd) throws NamingException
	{
		final Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, LdapClientGids.LDAP_CONTEXT_FACTORY_VALUE);
		env.put(Context.PROVIDER_URL, LDAP_URL + ":" + LDAP_PORT + "/" + LDAP_BASE);
		//env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, ldapUser);
		env.put(Context.SECURITY_CREDENTIALS, ldapPwd);

		// Specify connection timeout to be 10 seconds
		env.put(LdapClientGids.LDAP_CONNECT_TIMEOUT_KEY, "10000");
		// Specify read timeout to be 10 seconds
		env.put(LdapClientGids.LDAP_READ_TIMEOUT_KEY, "10000");

		this.ctx = new InitialDirContext(env);
	}

	public DirContext getCtx()
	{
		return this.ctx;
	}

	/**
	 * Searches in LDAP for user with email.<br />
	 * Returns the attributes of the first finding.
	 * 
	 * @param email
	 * @return
	 */
	public Optional<Map<String, String>> getUserInfos(final String email) throws NamingException
	{
		final SearchControls ctrl = new SearchControls();

		final String filter = "(&(mail=" + email + "))";

		final NamingEnumeration<SearchResult> userInfo = this.ctx.search(LDAP_OU_USERS, filter, ctrl);
		Optional<Map<String, String>> result = Optional.empty();

		if (userInfo.hasMore())
		{
			final SearchResult userDetails = userInfo.next();
			final Attributes attrContainer = userDetails.getAttributes();

			result = getAttributesAsMap(attrContainer);
		}

		userInfo.close();
		return result;
	}

	public List<LdapOrg> getTopLevelOrgs_Filtered(final String orgNamePart)
	{
		final SearchControls ctrl = new SearchControls();

		// Filter 1: (allianz-OrganizationalClass=C)
		final String orgClassFilter = createFilter(LdapField.ALLIANZ_ORGANIZATIONALCLASS.ldapKey, "C");
		// Filter 2: (displayName=*orgNamePart*)
		final String displayNameFilter = createWildcardFilter(LdapField.DISPLAYNAME.ldapKey, orgNamePart);

		final String filter = createCombinedFilter(orgClassFilter, displayNameFilter);

		try
		{
			return CollectionUtil.stream(this.ctx.search(LDAP_OU_ORGS, filter, ctrl))
				.map(LdapClientGids::toOrg)
				.filter(Objects::nonNull)
				.sorted(this.sorter)
				.collect(Collectors.toList());
		}
		catch (final NamingException e)
		{
			LOG.error("Could not obtain org info from LDAP.", e);
		}

		return Collections.emptyList();
	}

	public Set<LdapOrg> getDepartments(final LdapOrg companyLdapOrg)
	{
		// WARNING: Hardcoded Garbage Ahead
		// We have to select between these two hardcoded strings:
		// 1. For AGCS Departments =
		// 		(&(allianz-ECCS-CompanyCode=DE0055)(allianz-Status=Active)(allianz-OrganizationalClass=O)(!(allianz-CSVObjectID=44-2+9*)))
		// 2. For Allianz Australia Insurance Ltd. AGCS Departments = 
		// 		(&(allianz-ECCS-CompanyCode=AU0002)(allianz-Status=Active)(allianz-OrganizationalClass=O)(displayName=*AGCS*))

		final String company = companyLdapOrg.getDisplayName().strip();
		final String filter;

		if (company.equals("AGCS"))
		{
			filter =
				"(&(allianz-ECCS-CompanyCode=DE0055)(allianz-Status=Active)(allianz-OrganizationalClass=O)(!(allianz-CSVObjectID=44-2+9*)))";
		}
		else if (company.equals("Allianz Australia Insurance Ltd."))
		{
			filter =
				"(&(allianz-ECCS-CompanyCode=AU0002)(allianz-Status=Active)(allianz-OrganizationalClass=O)(displayName=*AGCS*))";
		}
		else
		{
			Notificator.error("Only AGCS and Allianz Australia Insurance Ltd. are currently supported!");
			return new HashSet<>();
		}

		try
		{
			return CollectionUtil.stream(
				this.ctx.search(LDAP_OU_ORGS, filter, new SearchControls())
			).map(LdapClientGids::toOrg).filter(Objects::nonNull).collect(Collectors.toSet());
		}
		catch (final NamingException e)
		{
			LOG.error("Could not obtain org info from LDAP.", e);
			throw new RuntimeException(e);
		}
	}

	public List<LdapOrg> getDepartments_Filtered(final AccessControlCompany root, final String orgNamePart)
	{
		return this.getDepartments(root)
			.stream()
			.filter(org -> StringUtils.containsIgnoreCase(org.getDisplayName(), orgNamePart))
			.sorted(this.sorter)
			.collect(Collectors.toList());
	}

	/**
	 * Converts the {@link Attribute}s from the given {@link Attributes} object to a
	 * Map.
	 * 
	 * @param attrContainer
	 * @return
	 * @throws NamingException
	 */
	public static Optional<Map<String, String>> getAttributesAsMap(final Attributes attrContainer)
		throws NamingException
	{
		if (attrContainer == null)
		{
			return Optional.empty();
		}

		final Map<String, String> result = new HashMap<>();

		final NamingEnumeration<? extends Attribute> all = attrContainer.getAll();
		CollectionUtil.stream(all)
			.filter(it -> it.getID() != null)
			.sorted(Comparator.comparing(Attribute::getID))
			.forEach(attr ->
			{
				if (attr != null)
				{
					try
					{
						final Object object = attr.get(0);
						result.put(attr.getID(), (object != null ? object.toString() : ""));
					}
					catch (final NamingException e)
					{
						LOG.warn("Could not obtain value for LDAP attribute " + attr.getID() + ".", e);
						result.put(attr.getID(), null);
					}
				}
			});
		all.close();

		return Optional.of(result);
	}

	/*****************************************************************************/

	public static LdapOrg toOrg(final SearchResult sr)
	{
		if (sr == null)
		{
			return null;
		}
		try
		{
			final Attributes attrContainer = sr.getAttributes();
			final Optional<Map<String, String>> attributesAsMap = getAttributesAsMap(attrContainer);
			final Optional<LdapOrg> org = toOrg(attributesAsMap);
			return org.orElse(null);
		}
		catch (final Exception e)
		{
			LOG.warn("Could not convert SearchResult to Org.", e);
			return null;
		}

	}

	/**
	 * Create a new LdapOrg object using values from attributes map with key
	 * {@link LdapField#DISPLAYNAME}, {@link LdapField#DISTINGUISHEDNAME}, and
	 * {@link LdapField#CN}
	 * 
	 * @param attributes
	 * @return
	 */
	protected static Optional<LdapOrg> toOrg(final Optional<Map<String, String>> attributes)
	{
		if (attributes != null && attributes.isPresent())
		{
			final String displayName = attributes.get().get(LdapField.DISPLAYNAME.ldapKey);
			final String distName = attributes.get().get(LdapField.DISTINGUISHEDNAME.ldapKey);

			final LdapOrg ldapOrg = new LdapOrg(distName, displayName);
			ldapOrg.setCnId(attributes.get().get(LdapField.CN.ldapKey));

			return Optional.ofNullable(ldapOrg);
		}
		else
		{
			return Optional.empty();
		}
	}

	/*****************************************************************************/

	/**
	 * Builds an LDAP filter.
	 */
	public static String createFilter(final String key, final String value)
	{
		return String.format("(%s=%s)", key, value);
	}

	/**
	 * Builds an LDAP filter.
	 */
	public static String createWildcardFilter(final String key, final String value)
	{
		return String.format("(%s=*%s*)", key, value);
	}

	/**
	 * Builds an LDAP filter.
	 */
	public static String createNotFilter(final String key, final String value)
	{
		return String.format("(!%s)", createFilter(key, value));
	}

	public static String createCombinedFilter(final String... filter)
	{
		// builds combined filter:
		// (&(filter[0])(filter[1])(filter[2]))
		return "(&" + String.join("", filter) + ")";
	}
}
