
package com.caweco.esra.subsidary.common;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

import com.caweco.esra.entities.config.EsraClientConfiguration;

/**
 * Contains information about 
 * <ul>
 * <li>all fetched BvdIds of this SubsidiaryScreening run</li>
 * <li>the red flagged BvdIds (at time of the application of the fetched data)</li>
 * <li>the red flagged BvdIds that are applied to the screening (at time of the application of the fetched data)</li>
 * <li>the red flagged BvdIds that are <b>not</b> applied to the screening (at time of the application of the fetched data)
 * because they already exists in the screening</li>
 * </ul>
 * Usage: Frontend, Backend & as DTO
 */
public class SubsidiaryScreeningAppliedData
{
	public static SubsidiaryScreeningAppliedData New(
		Integer thresholdForGsssMatchesAtAppliedDate,
		Set<String> allCompanies,
		Set<String> notRed,
		Set<String> redApplied,
		Set<String> redDuplicates)
	{
		return new SubsidiaryScreeningAppliedData(
			Instant.now(),
			thresholdForGsssMatchesAtAppliedDate,
			allCompanies,
			notRed,
			redApplied,
			redDuplicates);
	}
	
	
	protected Instant appliedDateTime;
	
	/**
	 * Value from {@link EsraClientConfiguration#getThresholdGsssResultScore()} at time when data of the task was applied to the screening.  
	 */
	protected Integer thresholdForGsssMatchesAtAppliedDate;
	protected Set<String> allCompanies = new HashSet<>();
	protected Set<String> notRed = new HashSet<>();
	protected Set<String> redApplied = new HashSet<>();
	protected Set<String> redDuplicates = new HashSet<>();
	
	
	/**
	 * For Jackson. Do not use.
	 */
	protected SubsidiaryScreeningAppliedData() {
		super();
	}
	
	protected SubsidiaryScreeningAppliedData(
		Instant appliedDateTime,
		Integer thresholdForGsssMatchesAtAppliedDate,
		Set<String> allCompanies,
		Set<String> notRed,
		Set<String> redApplied,
		Set<String> redDuplicates)
	{
		super();
		this.appliedDateTime = appliedDateTime;
		this.thresholdForGsssMatchesAtAppliedDate   = thresholdForGsssMatchesAtAppliedDate;
		this.allCompanies           = allCompanies;
		this.notRed           = notRed;
		this.redApplied    = redApplied;
		this.redDuplicates = redDuplicates;
	}
	
	public Instant getAppliedDateTime()
	{
		// MUST be "getAppliedDateTime", not "getAppliedDate", otherwise Json deserialization does not work
		return appliedDateTime;
	}
	public Integer getThresholdForGsssMatchesAtAppliedDate()
	{
		return thresholdForGsssMatchesAtAppliedDate;
	}
	public Set<String> getAllCompanies()
	{
		return allCompanies;
	}
	public Set<String> getNotRed()
	{
		return notRed;
	}
	public Set<String> getRedApplied()
	{
		return redApplied;
	}
	public Set<String> getRedDuplicates()
	{
		return redDuplicates;
	}

}
