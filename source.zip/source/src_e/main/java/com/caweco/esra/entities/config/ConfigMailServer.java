package com.caweco.esra.entities.config;

import java.util.HashMap;
import java.util.Map;


public class ConfigMailServer
{
	private String						smtpUsername;
	private String						smtpPassword;
	private String						smtpServerURL;
	private String						smtpPort;
	
	private String						smtpSenderEmailAddress;
	private boolean						ssh			= false;
	private boolean						tls			= false;
	
	private final Map<String, String>	additional	= new HashMap<>();
	
	public String getSmtpUsername()
	{
		return smtpUsername;
	}
	
	public void setSmtpUsername(String smtpUsername)
	{
		this.smtpUsername = smtpUsername;
	}
	
	public String getSmtpPassword()
	{
		return smtpPassword;
	}
	
	public void setSmtpPassword(String smtpPassword)
	{
		this.smtpPassword = smtpPassword;
	}
	
	public String getSmtpServerURL()
	{
		return smtpServerURL;
	}
	
	public void setSmtpServerURL(String smtpServerURL)
	{
		this.smtpServerURL = smtpServerURL;
	}
	
	public String getSmtpPort()
	{
		return smtpPort;
	}
	
	public void setSmtpPort(String smtpPort)
	{
		this.smtpPort = smtpPort;
	}
	
	public String getSmtpSenderEmailAddress()
	{
		return smtpSenderEmailAddress;
	}
	
	public void setSmtpSenderEmailAddress(String smtpSenderEmailAddress)
	{
		this.smtpSenderEmailAddress = smtpSenderEmailAddress;
	}
	
	public boolean isSsh()
	{
		return ssh;
	}
	
	public void setSsh(boolean ssh)
	{
		this.ssh = ssh;
	}
	
	public boolean isTls()
	{
		return tls;
	}
	
	public void setTls(boolean tls)
	{
		this.tls = tls;
	}
	
	public Map<String, String> getAdditional()
	{
		return additional;
	}
}
