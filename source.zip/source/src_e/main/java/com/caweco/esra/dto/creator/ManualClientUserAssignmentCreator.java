package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.ManualClientUserAssignmentDTO;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.entities.config.ManualClientUserAssignment;

public class ManualClientUserAssignmentCreator {

	public static ManualClientUserAssignmentDTO convertToDTO(ManualClientUserAssignment assignment, UserMetadataDTO user)
	{
		ManualClientUserAssignmentDTO dto = new ManualClientUserAssignmentDTO();
		dto.setUser(user);
		dto.setUserAssignment(assignment);
		
		return dto;
	}
}