package com.caweco.esra.entities.rest.namematch;

import java.io.Serializable;


public class BvdMatch implements Serializable
{
	private String	bvDID;
	private double	score;
	private Hint	hint;
	private String	name;
	private String	nameInLocalAlphabet;	// TODO: non English Alphabet possible
	private String	address;
	private String	postCode;
	private String	city;
	private String	country;
	private String	region;
	private String	addressType;
	private String	phoneOrFax;
	private String	nationalId;
	private String	ticker;
	private String	isin;
	private String	state;
	private String	status;
	private String	bvD9;
	private String	emailOrWebsite;
	private String	legalForm;
	private String	consolidationCode;
	private String	customRule;
	
	public BvdMatch()
	{
		// empty Constructor for Framework
	}
	
	public String getLegalForm()
	{
		return legalForm;
	}
	
	public void setLegalForm(String legalForm)
	{
		this.legalForm = legalForm;
	}
	
	public String getConsolidationCode()
	{
		return consolidationCode;
	}
	
	public void setConsolidationCode(String consolidationCode)
	{
		this.consolidationCode = consolidationCode;
	}
	
	public String getCustomRule()
	{
		return customRule;
	}
	
	public void setCustomRule(String customRule)
	{
		this.customRule = customRule;
	}
	
	public String getBvDID()
	{
		return this.bvDID;
	}
	
	public void setBvDID(final String bvDID)
	{
		this.bvDID = bvDID;
	}
	
	public double getScore()
	{
		return this.score;
	}
	
	public void setScore(final double score)
	{
		this.score = score;
	}
	
	public Hint getHint()
	{
		return this.hint;
	}
	
	public void setHint(final Hint hint)
	{
		this.hint = hint;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public String getNameInLocalAlphabet()
	{
		return this.nameInLocalAlphabet;
	}
	
	public void setNameInLocalAlphabet(final String nameInLocalAlphabet)
	{
		this.nameInLocalAlphabet = nameInLocalAlphabet;
	}
	
	public String getAddress()
	{
		return this.address;
	}
	
	public void setAddress(final String address)
	{
		this.address = address;
	}
	
	public String getPostCode()
	{
		return this.postCode;
	}
	
	public void setPostCode(final String postCode)
	{
		this.postCode = postCode;
	}
	
	public String getCity()
	{
		return this.city;
	}
	
	public void setCity(final String city)
	{
		this.city = city;
	}
	
	public String getCountry()
	{
		return this.country;
	}
	
	public void setCountry(final String country)
	{
		this.country = country;
	}
	
	public String getRegion()
	{
		return this.region;
	}
	
	public void setRegion(final String region)
	{
		this.region = region;
	}
	
	public String getPhoneOrFax()
	{
		return this.phoneOrFax;
	}
	
	public void setPhoneOrFax(final String phoneOrFax)
	{
		this.phoneOrFax = phoneOrFax;
	}
	
	public String getNationalId()
	{
		return this.nationalId;
	}
	
	public void setNationalId(final String nationalId)
	{
		this.nationalId = nationalId;
	}
	
	public String getTicker()
	{
		return this.ticker;
	}
	
	public void setTicker(final String ticker)
	{
		this.ticker = ticker;
	}
	
	public String getIsin()
	{
		return this.isin;
	}
	
	public void setIsin(final String isin)
	{
		this.isin = isin;
	}
	
	public String getState()
	{
		return this.state;
	}
	
	public void setState(final String state)
	{
		this.state = state;
	}
	
	public String getStatus()
	{
		return this.status;
	}
	
	public void setStatus(final String status)
	{
		this.status = status;
	}
	
	public String getBvD9()
	{
		return this.bvD9;
	}
	
	public void setBvD9(final String bvD9)
	{
		this.bvD9 = bvD9;
	}
	
	public String getEmailOrWebsite()
	{
		return this.emailOrWebsite;
	}
	
	public void setEmailOrWebsite(final String emailOrWebsite)
	{
		this.emailOrWebsite = emailOrWebsite;
	}
	
	public String getAddressType()
	{
		return addressType;
	}
	
	public void setAddressType(String addressType)
	{
		this.addressType = addressType;
	}
	
}
