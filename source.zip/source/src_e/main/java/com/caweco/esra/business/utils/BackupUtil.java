package com.caweco.esra.business.utils;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class BackupUtil {

	public static void backupImmediately() {
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/maintenance/backup/start");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" has intitated the backup job from the admin page");	
		
		
	}

}
