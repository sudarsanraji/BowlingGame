
package com.caweco.esra.business.func.reporting;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Convenience methods for Apache POI
 *
 */
public class PoiHelper
{
	/* ********************************************************************** */
	/* CELLS */
	
	/**
	 * Add a new {@link Cell} to the {@link Row} at given column and with given style.
	 * @param row a Row
	 * @param style a {@link CellStyle}
	 * @param nr the Column number
	 * @return the new Cell
	 */
	protected static Cell newCell(final Row row, final XSSFCellStyle style, final int nr)
	{
		final Cell cell = row.createCell(nr);
		if(style != null)
		{
			cell.setCellStyle(style);
		}
		return cell;
	}
	
	/* ********************************************************************** */
	/* COLORS */
	
	/**
	 * Creates a color with given RBG values
	 * @param workbook
	 * @param r
	 * @param g
	 * @param b
	 * @return
	 */
	public static XSSFColor generateColor(final XSSFWorkbook workbook, final int r, final int g, final int b)
	{
		final byte[]    byteColor = new byte[]{(byte)r, (byte)g, (byte)b};
		final XSSFColor color     = new XSSFColor(workbook.getStylesSource().getIndexedColors());
		color.setRGB(byteColor);
		return color;
	}
	
	/* ********************************************************************** */
	/* STYLES */
	
	
	/**
	 * Creates a {@link XSSFCellStyle} with thin borders and {@link VerticalAlignment#TOP}.
	 * @param workbook
	 * @return the cell style
	 */
	public static XSSFCellStyle createBaseCellStyle(final XSSFWorkbook workbook)
	{
		final XSSFCellStyle style = workbook.createCellStyle();
		style.setVerticalAlignment(VerticalAlignment.TOP);
		style.setBorderBottom(BorderStyle.THIN);
		style.setBorderTop(BorderStyle.THIN);
		style.setBorderLeft(BorderStyle.THIN);
		style.setBorderRight(BorderStyle.THIN);
		
		return style;
	}
	
	/**
	 * Creates a {@link XSSFCellStyle} with thin borders, {@link VerticalAlignment#TOP} and "wrap text" set to true.
	 * @param workbook
	 * @return  the cell style
	 */
	public static XSSFCellStyle createMultilineCellStyle(final XSSFWorkbook workbook)
	{
		final XSSFCellStyle style = createBaseCellStyle(workbook);
		style.setWrapText(true);
		return style;
	}
	
	/**
	 * Creates a {@link XSSFCellStyle} with thin borders, {@link VerticalAlignment#TOP} and Data Format "m/d/yy".
	 * @param workbook
	 * @return  the cell style
	 */
	public static XSSFCellStyle createDateStyle(final XSSFWorkbook workbook)
	{
		final XSSFCellStyle style = createBaseCellStyle(workbook);
		style.setDataFormat(workbook.getCreationHelper().createDataFormat().getFormat("m/d/yy"));
		style.setAlignment(HorizontalAlignment.LEFT);
		
		return style;
	}
}
