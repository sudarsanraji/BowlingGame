
package com.caweco.esra.ui.main.helper;

import java.time.LocalDate;

import com.caweco.esra.dto.ScreeningMetadataBase;
import com.rapidclipse.framework.server.resources.Caption;


public interface ScreeningSearchResultEsu<T extends ScreeningMetadataBase> extends ScreeningSearchResult<T>
{
	@Caption("Unread Messages")
	public int getUnreadMessages();
	
	@Caption("Request Review Date")
	public LocalDate getScreeningEsuDate();
}
