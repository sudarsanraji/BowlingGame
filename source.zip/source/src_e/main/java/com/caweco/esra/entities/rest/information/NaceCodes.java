package com.caweco.esra.entities.rest.information;

import java.util.HashMap;
import java.util.Map;


public class NaceCodes
{
	private String				mainSection;
	private Map<String, String>	coreCodes		= new HashMap<>();
	private Map<String, String>	primaryCodes	= new HashMap<>();
	private Map<String, String>	secondaryCodes	= new HashMap<>();
	
	public NaceCodes()
	{
		// Empty Constructor for Framework
	}
	
	public String getMainSection()
	{
		return this.mainSection;
	}
	
	public void setMainSection(final String mainSection)
	{
		this.mainSection = mainSection;
	}
	
	public Map<String, String> getCoreCodes()
	{
		return this.coreCodes;
	}
	
	public void setCoreCodes(final Map<String, String> coreCodes)
	{
		this.coreCodes = coreCodes;
	}
	
	public Map<String, String> getPrimaryCodes()
	{
		return this.primaryCodes;
	}
	
	public void setPrimaryCodes(final Map<String, String> primaryCodes)
	{
		this.primaryCodes = primaryCodes;
	}
	
	public Map<String, String> getSecondaryCodes()
	{
		return this.secondaryCodes;
	}
	
	public void setSecondaryCodes(final Map<String, String> secondaryCodes)
	{
		this.secondaryCodes = secondaryCodes;
	}

	@Override
	public String toString() {
		return "NaceCodes [mainSection=" + mainSection + ", coreCodes=" + coreCodes + ", primaryCodes=" + primaryCodes
				+ ", secondaryCodes=" + secondaryCodes + "]";
	}
	
}
