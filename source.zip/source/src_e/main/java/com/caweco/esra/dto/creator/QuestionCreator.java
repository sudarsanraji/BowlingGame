package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.QuestionDTO;
import com.caweco.esra.entities.questionnaire.DateChooserQuestion;
import com.caweco.esra.entities.questionnaire.DurationChooserQuestion;
import com.caweco.esra.entities.questionnaire.FreeTextQuestion;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionType;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;

public class QuestionCreator {
	public static QuestionDTO convertQuestionToDTO(Question question)
	{
		QuestionDTO dto = new QuestionDTO();
		dto.setActive(question.getActive());
		dto.setCategory(question.getCategory());
		dto.setHelperText(question.getHelperText());
		dto.setId(question.getId());
		dto.setInstructionText(question.getInstructionText());
		dto.setQuestionTest(question.getQuestionText());
		dto.setStandard(question.getStandard());
		
		if(question.getRule() != null)
		{
			dto.setRule(RuleCreator.convertRuleToDTO(question.getRule()));
		}
	
		if(question instanceof FreeTextQuestion)
		{
			dto.setQuestionType(QuestionType.FREETEXT);
		}
		else if(question instanceof DateChooserQuestion)
		{
			dto.setQuestionType(QuestionType.DATE);
		}
		else if(question instanceof DurationChooserQuestion)
		{
			dto.setQuestionType(QuestionType.DURATION);
		}
		else if(question instanceof MultiOptionQuestion)
		{
			dto.setQuestionType(QuestionType.MULTI);
			dto.setValues(((MultiOptionQuestion) question).getValues());
		}
		else if(question instanceof SingleOptionQuestion)
		{
			dto.setQuestionType(QuestionType.SINGLE);
			dto.setValues(((SingleOptionQuestion) question).getValues());
		}
		
		return dto;
	}

	public static Question convertDTOToQuestion(Integer questionnaireId, QuestionDTO singleDto) {
		
		Question question;
		
		if(singleDto.getQuestionType().equals(QuestionType.FREETEXT))
		{
			question = new FreeTextQuestion();
		}
		else if(singleDto.getQuestionType().equals(QuestionType.DATE))
		{
			question = new DateChooserQuestion();
		}
		else if(singleDto.getQuestionType().equals(QuestionType.DURATION))
		{
			question = new DurationChooserQuestion();
		}
		else if(singleDto.getQuestionType().equals(QuestionType.MULTI))
		{
			question = new MultiOptionQuestion();
			((MultiOptionQuestion) question).setValues(singleDto.getValues());
		}
		else if(singleDto.getQuestionType().equals(QuestionType.SINGLE))
		{
			question = new SingleOptionQuestion();
			((SingleOptionQuestion) question).setValues(singleDto.getValues());
		}
		else
		{
			question = new Question();
		}
		
		question.setActive(singleDto.getActive());
		question.setCategory(singleDto.getCategory());
		question.setHelperText(singleDto.getHelperText());
		question.setId(singleDto.getId());
		question.setInstructionText(singleDto.getInstructionText());
		question.setQuestionText(singleDto.getQuestionTest());
		question.setStandard(singleDto.getStandard());
		
		if(singleDto.getRule() != null)
		{
			question.setRule(RuleCreator.convertDTOToRule(questionnaireId, singleDto.getRule()));
		}
		
		return question;
	}
}
