package com.caweco.esra.ui.beans;

import java.util.Collection;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.InputEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializableConsumer;


public class PartStringValueForm extends VerticalLayout
{
	
	private final Collection<String>	items;
	String                           valueAtSelect;
	private SerializableConsumer<String> deleteExistingMethod;
	private SerializableConsumer<String> saveNewMethod;
	
	/**
	 *
	 */
	public PartStringValueForm(final Collection<String> items, final String name,  
	 SerializableConsumer<String> deleteExistingMethod,
	 SerializableConsumer<String> saveNewMethod)
	{
		super();
		this.items = items;
		this.saveNewMethod = saveNewMethod;
		this.deleteExistingMethod = deleteExistingMethod;
		this.initUI();
		Column<String> representationCol = this.grid.addColumn(it -> it).setSortable(true);
		this.grid.sort(GridSortOrder.asc(representationCol).build());
		
		this.lblType.setText(name);
		
		this.grid.setItems(items);
		
		UiHelper.setAriaLabel(this.btnNew, Aria.get("Values_add"));
		UiHelper.setAriaLabel(this.btnDelete, Aria.get("Values_remove"));
		UiHelper.setAriaLabel(this.btnSave, Aria.get("Values_save"));
	}
	
	/*********************************************************/
	
	protected boolean evalSaveEnabled()
	{
		String value = StringUtils.stripToEmpty(this.txtName.getValue());
		boolean no1 = (value.length() >= 3);
		return no1;
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		String newValue = this.txtName.getValue();
		if (StringUtils.isNotBlank(newValue))
		{
			if (!this.items.contains(newValue))
			{
				this.items.add(newValue);
				this.saveNewMethod.accept(newValue);
			}
			if (this.valueAtSelect != null && !newValue.equals(this.valueAtSelect))
			{
				// remove old (previous) value
				this.items.remove(this.valueAtSelect);
				this.deleteExistingMethod.accept(this.valueAtSelect);
			}
			this.grid.getDataProvider().refreshAll();
			this.grid.deselectAll();
			this.txtName.setValue("");
			this.txtName.focus();
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void grid_selectionChange(SelectionEvent<Grid<String>, String> event)
	{
		String selectedItem = event.getFirstSelectedItem().orElse(null);
		this.valueAtSelect = selectedItem;
		this.txtName.setValue(selectedItem != null ? selectedItem : "");
		this.btnDelete.setEnabled(selectedItem != null);
		this.btnSave.setEnabled(this.evalSaveEnabled());
	}
	
	/**
	 * Event handler delegate method for the {@link TextField} {@link #txtName}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtName_onInput(final InputEvent event)
	{
		this.btnSave.setEnabled(this.evalSaveEnabled());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDelete_onClick(ClickEvent<Button> event)
	{
		this.grid.getSelectedItems().forEach((obj) -> this.deleteExistingMethod.accept(obj));
		this.items.removeAll(this.grid.getSelectedItems());
		this.grid.getDataProvider().refreshAll();
		this.grid.deselectAll();
		this.txtName.setValue("");
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNew_onClick(ClickEvent<Button> event)
	{
		this.grid.deselectAll();
		this.valueAtSelect = null;
		this.txtName.setValue("");
		this.btnDelete.setEnabled(false);
		this.btnSave.setEnabled(false);
		this.txtName.focus();
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout2 = new HorizontalLayout();
		this.lblType = new Label();
		this.btnDelete = new Button();
		this.btnNew = new Button();
		this.grid = new Grid<>(String.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.txtName = new TextField();
		this.btnSave = new Button();
		
		this.setSpacing(false);
		this.setMaxHeight("500px");
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout2.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.lblType.setText("Label");
		this.btnDelete.setEnabled(false);
		this.btnDelete.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnDelete.setIcon(VaadinIcon.TRASH.create());
		this.btnNew.setIcon(VaadinIcon.PLUS.create());
		this.grid.addThemeVariants(
			GridVariant.LUMO_ROW_STRIPES,
			GridVariant.LUMO_COMPACT,
			GridVariant.LUMO_WRAP_CELL_CONTENT);
		this.grid.getStyle().set("flex-basis", "0");
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.horizontalLayout.setSpacing(false);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.label.setText("Value");
		this.label.getStyle().set("margin-right", "10px");
		this.txtName.setValueChangeTimeout(0);
		this.txtName.setValueChangeMode(ValueChangeMode.TIMEOUT);
		this.btnSave.setEnabled(false);
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		
		this.lblType.setWidthFull();
		this.lblType.setHeight(null);
		this.btnDelete.setSizeUndefined();
		this.btnNew.setSizeUndefined();
		this.horizontalLayout2.add(this.lblType, this.btnDelete, this.btnNew);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblType);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.END, this.btnDelete);
		this.label.setSizeUndefined();
		this.txtName.setWidthFull();
		this.txtName.setHeight(null);
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.label, this.txtName, this.btnSave);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.END, this.btnSave);
		this.horizontalLayout2.setSizeUndefined();
		this.grid.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.horizontalLayout2, this.grid, this.horizontalLayout);
		this.setFlexGrow(1.0, this.grid);
		this.setWidth("350px");
		this.setHeight(null);
		
		this.btnDelete.addClickListener(this::btnDelete_onClick);
		this.btnNew.addClickListener(this::btnNew_onClick);
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.txtName.addInputListener(this::txtName_onInput);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button				btnDelete, btnNew, btnSave;
	private Grid<String>		grid;
	private HorizontalLayout	horizontalLayout2, horizontalLayout;
	private Label				lblType, label;
	private TextField			txtName;
	// </generated-code>
	
}
