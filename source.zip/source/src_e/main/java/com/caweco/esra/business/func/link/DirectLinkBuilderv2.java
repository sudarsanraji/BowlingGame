package com.caweco.esra.business.func.link;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.caweco.esra.ui.sanctions.PageEsuAssessment;
import com.caweco.esra.ui.sanctions.PageFinancialScreening;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.router.RouteConfiguration;


public class DirectLinkBuilderv2
{
	/**
	 * Builds a link to PageEsuAssessment which navigates to a screening and a group.<br />
	 * e.g. http://localhost:8182/ESRA/esu/df51b24e-25b8-4438-9a5f-350ca05b9fa1/aaabbbccc-25b8-4438-9a5f-350ca05b9fa1/
	 * 
	 * @param item  a {@link Screening} item
	 * @param group a {@link MessageGroup}
	 * @return a link
	 */
	public static String getLink_PageEsuAssessment_toGroup(final Screening item, MessageGroup group)
	{
		return getLinkToScreening(PageEsuAssessment.class, item, group.getId().toString());
	}
	
	/**
	 * Builds a link to PageEsuAssessment which navigates to a screening and shows the public messages.<br />
	 * e.g. http://localhost:8182/ESRA/esu/df51b24e-25b8-4438-9a5f-350ca05b9fa1/pg/
	 * 
	 * @param item a {@link Screening} item
	 * @return a link
	 */
	public static String getLink_PageEsuAssessment_toPublic(final Screening item)
	{
		return getLinkToScreening(PageEsuAssessment.class, item, "pg");
		
	}
	
	/**
	 * Builds a link to PageEsuAssessment which navigates to a screening.<br />
	 * e.g. http://localhost:8182/ESRA/esu/df51b24e-25b8-4438-9a5f-350ca05b9fa1/
	 * 
	 * @param item a {@link Screening} item
	 * @return a link
	 */
	public static String getLink_PageEsuAssessment_toScreening(final Screening item)
	{
		return getLinkToScreening(PageEsuAssessment.class, item);
	}
	
	/**
	 * Builds a link to PageSanctionScreening which navigates to a screening.<br />
	 * e.g. http://localhost:8182/ESRA/screening/df51b24e-25b8-4438-9a5f-350ca05b9fa1
	 * 
	 * @param item a {@link Screening} item
	 * @return a link
	 */
	public static String getLink_PageSanctionScreening_toScreening(final Screening item)
	{
		return getLinkToScreening(PageFinancialScreening.class, item);
	}
	
	/**
	 * Builds a link to a page and to this screening.<br />
	 * Convenience for {@link DirectLinkBuilderv2#buildUrl(String, boolean, List)}
	 * <p>
	 * Uses {@link RouteConfiguration#forApplicationScope()} which requires that VaadinServlet.getCurrent() is populated.
	 * </p>
	 * 
	 * @param page
	 * @param item
	 * @param additionalParts
	 * @return
	 */
	public static String getLinkToScreening(Class<? extends Component> page, Screening item, String... additionalParts)
	{
		String applicationBaseUrl = ApplicationPropertyProvider.getAppURL();
		final String pageUrl = RouteConfiguration.forApplicationScope().getUrlBase(page).get();
		String screeningId = item.getScreeningID().toString();
		
		List<String> additional = new ArrayList<>();
		additional.add(pageUrl);
		additional.add(screeningId);
		additional.addAll(Arrays.asList(additionalParts));
		return buildUrl(applicationBaseUrl, true, additional);
	}
	
	/**
	 * Builds a link to a page and to this screening.<br />
	 * Convenience for {@link DirectLinkBuilderv2#buildUrl(String, boolean, List)}
	 * <p>
	 * Does <b>NOT</b> use {@link RouteConfiguration#forApplicationScope()}, so this can be used in background threads.
	 * </p>
	 * 
	 * @param pageUrl the page
	 * @param screeningId the screeningId
	 * @param additionalParts additional url parts
	 * @return
	 */
	public static String getLinkToScreening(String pageUrl, String screeningId, String... additionalParts)
	{
		String applicationBaseUrl = ApplicationPropertyProvider.getAppURL();
		
		List<String> additional = new ArrayList<>();
		additional.add(pageUrl);
		additional.add(screeningId);
		additional.addAll(Arrays.asList(additionalParts));
		return buildUrl(applicationBaseUrl, true, additional);
	}
	
	/**
	 * Cleans the "input":
	 * <p>
	 * Removes "*" and whitespace from the end of the input.<br />
	 * Ensures that the input ends with "/", even if the input is <code>null</code>.
	 * </p>
	 * 
	 * @param input
	 * @return a cleaned String
	 */
	public static String cleanUrlEnd(final String input)
	{
		String out = StringUtils.stripToEmpty(input);
		if(out.isEmpty())
			return "/";
		else
		{
			
			final Pattern pattern = Pattern.compile("(.*?)([\\s/\\*]*)$");
			final Matcher matcher = pattern.matcher(out);
			if(matcher.matches())
			{
				out = matcher.group(1);
			}
			return new StringBuilder(out).append("/").toString();
		}
		
	}
	
	
	/**
	 * Extends an Url with additional path parts.
	 * <p>
	 * <b>Example:</b><br />
	 * baseUrl: <code>http://localhost:8080/app/*</code><br />
	 * parts: "foo", "bar", "composed"<br />
	 * -> <code>http://localhost:8080/app/foo/bar/composed/</code>
	 * </p>
	 * 
	 * @param baseUrl        an existing url
	 * @param skipEmptyParts filter out empty path parts
	 * @param pathParts
	 * @return
	 */
	public static String buildUrl(final String baseUrl, final boolean skipEmptyParts, List<String> pathParts)
	{
		final StringBuilder sb = new StringBuilder(cleanUrlEnd(baseUrl));
		
		if (pathParts != null)
		{
			pathParts.forEach(partRaw ->
			{
				String part = StringUtils.stripToEmpty(partRaw);
				if (skipEmptyParts && part.isEmpty())
				{
					// skip entry
				}
				else
				{
					sb.append(part).append("/");
				}
			});
		}
		return sb.toString();
	}
	
}
