
package com.caweco.esra.ui.part.watchlist.common;

import java.util.UUID;

import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.usertask.UserTaskManager;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningCachedTask;
import com.caweco.esra.subsidary.frontend.SubsidiaryScreeningTaskF;
import com.caweco.esra.subsidary.frontend.SubsidiaryTaskDAO;
import com.caweco.esra.subsidary.frontend.SubsidiaryTaskManager;
import com.caweco.esra.ui.component.MarkerRedFlag;
import com.caweco.esra.ui.component.MarkerRedFlag.Type;
import com.caweco.esra.ui.part.watchlist.RemovableWatchlistElement;
import com.caweco.esra.ui.sanctions.dialogs.DialogSubsidiaryScreening;
import com.caweco.esra.ui.sanctions.dialogs.DialogSubsidiaryScreeningResult;
import com.caweco.esra.ui.sanctions.parts.PartWatchList;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.shared.Registration;
import com.vaadin.flow.shared.ui.LoadMode;

public class BeanWatchlistItemHeader extends HorizontalLayout
{

	private MarkerRedFlag            tagMarker;
	
	// If used as Company header
	private SubsidiaryScreeningTaskF funcSubScreening_currentTask;
	private Pair<Registration, UUID> funcSubScreening_taskChangeListener;
	private SearchEntryCompany       funcSubScreening_currentSearchEntryCompanyItem;
	
	public BeanWatchlistItemHeader(
		final WatchlistElementType type,
		final String typePrefixText,
		final String name)
	{
		super();
		UI.getCurrent().getPage().addJavaScript("../frontend/scripts/customhelper.js", LoadMode.EAGER);
		this.initUI();
		
		
		this.tagMarker = new MarkerRedFlag();
		this.tagMarker.setValue(null);
		this.tagMarker.setSizeUndefined();
		this.add(this.tagMarker);
		
		this.setTypePrefixText(typePrefixText);
		this.setName(name);
		
		this.setType(type);
		
		this.preventClickAndSpacePropagation();
		
		UiHelper.setAriaLabel(this.btnRemoveMe, Aria.get("PageSanctionScreening_finding_remove"));
		UiHelper.setAriaLabel(this.btnShowDetails, Aria.get("PageSanctionScreening_finding_info"));
		
		UiHelper.setAriaLabel(this.btnStartSubScreening, Aria.get("PageSanctionScreening_finding_subsidiary_start"));
		UiHelper.setAriaLabel(this.btnPendingSubScreening,
			Aria.get("PageSanctionScreening_finding_subsidiary_pending"));
		UiHelper.setAriaLabel(this.btnShowSubScreening, Aria.get("PageSanctionScreening_finding_subsidiary_show"));
	}
	
	public BeanWatchlistItemHeader hideTag()
	{
		this.tagMarker.setVisible(false);
		return this;
	}
	
	public void setTypePrefixText(String typePrefixText)
	{
		this.lblType.setText(typePrefixText);
	}
	
	/**
	 * Sets Tag value <b>and Tag's {@link Type} to {@link Type#ICON_WL} (!)</b>
	 * <p>
	 * Reason: It is not possible to get exact integer value from boolean in other type configurations!
	 * </p>
	 * 
	 * @param marked
	 * @return
	 */
	public BeanWatchlistItemHeader setMarkedB(Boolean marked)
	{
		this.tagMarker.setBooleanValue(marked);
		return this;
	}
	
	public BeanWatchlistItemHeader setMarked(Integer marked)
	{
		this.tagMarker.setValue(marked);
		return this;
	}
	
	public Integer getMarked()
	{
		return this.tagMarker.getValue();
	}
	
	public MarkerRedFlag getTagMarker()
	{
		return this.tagMarker;
	}
	
	public BeanWatchlistItemHeader setType(WatchlistElementType type)
	{
		// Header for ESU / PartScreeningOverview - Categories
		if(type == WatchlistElementType.ESU_QUESTCATEGORY)
		{
			this.tfComment.setVisible(false);
			this.btnRemoveMe.setVisible(false);
			this.lblType.setVisible(false);
			this.lblName.getStyle().set("font-weight", "bold");
			
			this.tagMarker.setType(Type.ICON_Q);
		}
		// Header for ESU / PartScreeningOverview - Watchlist part
		else if(type == WatchlistElementType.ESU_WATCHLIST)
		{
			this.tfComment.setVisible(false);
			this.btnRemoveMe.setVisible(false);
			this.lblType.setVisible(false);
			this.lblName.getStyle().set("font-weight", "bold");
			
			this.tagMarker.setType(Type.ICON_WL);
		}
		// Header for ESU / PartScreeningOverview - Company/Individual/Seaweb-Watchlist-entries
		else if(type == WatchlistElementType.ESU_WATCHLIST_ITEM)
		{
			this.tfComment.setVisible(true);
			this.tfComment.setReadOnly(true);
			this.lblType.getStyle().set("font-weight", "bold");
			this.lblName.getStyle().set("font-weight", "bold");
			this.btnRemoveMe.setVisible(false);
			
			this.tagMarker.setType(Type.ICON_WL);
			
			this.btnStartSubScreening.setEnabled(false);
			
		}
		// Header for ESU / PartScreeningOverview - Sub-Entries of Company-Watchlist-entry
		else if(type == WatchlistElementType.ESU_WATCHLIST_SUBITEM)
		{
			this.tfComment.setVisible(false);
			this.btnRemoveMe.setVisible(false);
			
			this.tagMarker.setType(Type.ICON_WL);
		}
		
		// Header for ESRA Questionnaires
		else if(type == WatchlistElementType.ESRA_QUESTCATEGORY)
		{
			this.tfComment.setVisible(false);
			this.btnRemoveMe.setVisible(false);
			this.lblType.setVisible(false);
			this.lblName.getStyle().set("font-weight", "bold");
			
			this.tagMarker.setType(Type.ICON_Q);
		}
		// Header for ESRA-Screening / PageSanctionScreening - Sub-Entries of Company-Watchlist-entry
		else if(type == WatchlistElementType.ESRA_WATCHLIST_SUBITEM)
		{
			this.tfComment.setVisible(false);
			this.btnRemoveMe.setVisible(false);
			
			this.tagMarker.setType(Type.ICON_WL);
		}
		// Header for ESRA-Screening / PageSanctionScreening - Company/Individual/Seaweb-Watchlist-entries
		else
		{
			this.tfComment.setVisible(true);
			this.btnRemoveMe.setVisible(true);
			this.lblType.getStyle().set("font-weight", "bold");
			this.lblName.getStyle().set("font-weight", "bold");
			
			this.tagMarker.setType(Type.ICON_WL);
		}
		
		return this;
	}
	
	public String getComment()
	{
		return this.tfComment.getValue();
	}
	
	public BeanWatchlistItemHeader setComment(String comment)
	{
		this.tfComment.setValue(comment);
		return this;
	}
	
	public BeanWatchlistItemHeader setName(String name)
	{
		this.lblName.setText(name);
		return this;
	}
	
	/**
	 * Sets a value to the date label.<br>
	 * If input is null, hides the label.
	 * 
	 * @param date
	 * @return
	 */
	public BeanWatchlistItemHeader setDate(@Nullable String date)
	{
		this.lblDate.setVisible(date != null);
		if(date != null)
		{
			this.lblDate.setText(date);
		}
		return this;
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnRemoveMe}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnRemoveMe_onClick(ClickEvent<Button> event)
	{
		RemovableWatchlistElement<?> watchlistItem = UIUtils.getNextParent(this, RemovableWatchlistElement.class);
		if(watchlistItem != null)
		{
			watchlistItem.removeSelfFromWatchlist();
		}
	}
	
	public BeanWatchlistItemHeader withDetailButton(ComponentEventListener<ClickEvent<Button>> listener)
	{
		this.btnShowDetails.addClickListener(listener);
		this.btnShowDetails.setVisible(true);
		return this;
	}
	
	protected BeanWatchlistItemHeader preventClickAndSpacePropagation()
	{
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.tfComment);
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.btnRemoveMe);
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.btnShowDetails);
		return this;
	}
	
	/**
	 * Use when setting SearchEntryCompany item
	 * 
	 * @return
	 */
	public BeanWatchlistItemHeader withSubsidiaryScreening(SearchEntryCompany se)
	{
		this.objSubsidiaries.setVisible(true);
		
		
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.btnStartSubScreening);
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.btnPendingSubScreening);
		this.getElement().executeJs("noClickAndSpaceEventPropagation($0);", this.btnShowSubScreening);
		
		this.funcSubScreening_currentSearchEntryCompanyItem = se;
		try
		{
			// Search for existing Task
			
			funcSubScreening_currentTask = SubsidiaryTaskDAO.getTask_bySearchEntryCompanyID_mostRecent(se.getId().toString());
			
			if(funcSubScreening_currentTask != null)
			{
				setTask_registerSubScreeningTaskStateListener(funcSubScreening_currentTask);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		// Button visibility
		btnStartSubScreening.setVisible(funcSubScreening_currentTask == null);
		if(funcSubScreening_currentTask != null)
		{
			if(funcSubScreening_currentTask.getState() == SubsidiaryScreeningTaskState.RUNNING)
			{
				btnPendingSubScreening.setVisible(true);
				btnShowSubScreening.setVisible(false);
			}
			else
			{
				btnPendingSubScreening.setVisible(false);
				btnShowSubScreening.setVisible(true);
			}
		}
		return this;
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnStartSubScreening}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnStartSubScreening_onClick(final ClickEvent<Button> event)
	{
		Screening screening       = UIUtils.getNextParent(this, PartWatchList.class).getScreening();
		
		// Deny Popup if screening not in Storage
		
		boolean   existsInStorage = ScreeningDAO.existsInStorage(screening);
		if(!existsInStorage)
		{
			Notificator
				.error("This Screening is not yet saved. Subsidiary Screening is only allowed for saved Screenings..");
		}
		else
		{
			DialogSubsidiaryScreening.show(this, screening, funcSubScreening_currentSearchEntryCompanyItem);
		}
	}
	
	protected void setTask_registerSubScreeningTaskStateListener(SubsidiaryScreeningTaskF task) 
	{
		if(funcSubScreening_taskChangeListener != null)
		{
			funcSubScreening_taskChangeListener.getLeft().remove();
		}
		
		funcSubScreening_currentTask = task;
		
		BeanWatchlistItemHeader c_e               = this;
		Registration            taskStateListener = 
			UserTaskManager.registerTaskStateListener(taskId_ -> 
			{
				BeanWatchlistItemHeader cc = c_e;
				cc.getUI().ifPresent(ui -> 
				{
					ui.access(() -> cc.onTaskUpdate(taskId_));
				});
			});
		
		funcSubScreening_taskChangeListener = Pair.of(taskStateListener, task.getId());
	}
	
	/**
	 * Called from Dialog {@link DialogSubsidiaryScreening}
	 * @param newTaskId
	 */
	public void updateOnStartSubScreening(String newTaskId)
	{
		SubsidiaryScreeningCachedTask cachedTask = SubsidiaryTaskManager.getCachedTask(newTaskId);

		setTask_registerSubScreeningTaskStateListener(cachedTask.getWrapped());
		
		onTaskUpdate(newTaskId);
		
		btnStartSubScreening.setVisible(false);
		btnPendingSubScreening.setVisible(true);
		btnShowSubScreening.setVisible(false);
	}
	
	/**
	 * Called from Dialog
	 */
	public void updateOnCancelSubScreening()
	{
		if(funcSubScreening_taskChangeListener != null)
		{
			funcSubScreening_taskChangeListener.getLeft().remove();
		}
		funcSubScreening_currentTask = null;
		
		btnStartSubScreening.setVisible(true);
		btnPendingSubScreening.setVisible(false);
		btnShowSubScreening.setVisible(false);
	}
	
	public void onTaskUpdate(String taskId)
	{
		if(funcSubScreening_taskChangeListener != null
			&& funcSubScreening_taskChangeListener.getRight().toString().equals(taskId))
		{
		
			SubsidiaryScreeningCachedTask task =
				SubsidiaryTaskManager.getCachedTask(funcSubScreening_taskChangeListener.getRight().toString());
			
			// RUNNING
			if(task.getState() == SubsidiaryScreeningTaskState.RUNNING)
			{
				btnStartSubScreening.setVisible(false);
				btnPendingSubScreening.setVisible(true);
				btnShowSubScreening.setVisible(false);
			}
			// WAIT FOR USER
			else if(task.getState() == SubsidiaryScreeningTaskState.DONE_OK)
			{
				btnStartSubScreening.setVisible(false);
				btnPendingSubScreening.setVisible(false);
				btnShowSubScreening.setVisible(true);
			}
			// FINISHED - SUCCESSFUL OR ERROR
			else
			{
				btnStartSubScreening.setVisible(false);
				btnPendingSubScreening.setVisible(false);
				btnShowSubScreening.setVisible(true);
			}
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnShowSubScreening}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnShowSubScreening_onClick(final ClickEvent<Button> event)
	{
		if(funcSubScreening_taskChangeListener != null)
		{
			DialogSubsidiaryScreeningResult.show(funcSubScreening_taskChangeListener.getRight());
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnPendingSubScreening}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnPendingSubScreening_onClick(final ClickEvent<Button> event)
	{
		// Placeholder. Button is not active when a task is running.
	}
	
	@Override
	protected void onDetach(DetachEvent detachEvent)
	{
		super.onDetach(detachEvent);
		if(funcSubScreening_taskChangeListener != null)
		{
			funcSubScreening_taskChangeListener.getLeft().remove();
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.lblType                = new Label();
		this.lblName                = new Label();
		this.lblDate                = new Div();
		this.objDetail              = new Div();
		this.btnShowDetails         = new Button();
		this.objSubsidiaries        = new Div();
		this.btnStartSubScreening   = new Button();
		this.btnPendingSubScreening = new Button();
		this.btnShowSubScreening    = new Button();
		this.tfComment              = new TextField();
		this.btnRemoveMe            = new Button();
		
		this.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.lblType.setText("Label");
		this.lblType.getStyle().set("margin-left", "1em !important");
		this.lblName.setText("Label");
		this.lblDate.setText("Date");
		this.lblDate.setVisible(false);
		this.objDetail.getStyle().set("display", "flex");
		this.objDetail.getStyle().set("justify-content", "end");
		this.btnShowDetails.setVisible(false);
		this.btnShowDetails.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		this.btnShowDetails.setIcon(VaadinIcon.SEARCH.create());
		this.objSubsidiaries.setVisible(false);
		this.objSubsidiaries.getStyle().set("display", "flex");
		this.objSubsidiaries.getStyle().set("justify-content", "end");
		this.btnStartSubScreening.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		this.btnStartSubScreening.setIcon(VaadinIcon.TREE_TABLE.create());
		this.btnPendingSubScreening.setVisible(false);
		this.btnPendingSubScreening.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		this.btnPendingSubScreening.setIcon(IronIcons.WATCH_LATER.create());
		this.btnShowSubScreening.setVisible(false);
		this.btnShowSubScreening.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		this.btnShowSubScreening.setIcon(IronIcons.TOC.create());
		this.tfComment.setPlaceholder("Add a comment...");
		this.tfComment.getStyle().set("padding", "unset");
		this.btnRemoveMe.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		this.btnRemoveMe.setIcon(VaadinIcon.TRASH.create());
		
		this.btnShowDetails.setSizeUndefined();
		this.objDetail.add(this.btnShowDetails);
		this.btnStartSubScreening.setSizeUndefined();
		this.btnPendingSubScreening.setSizeUndefined();
		this.btnShowSubScreening.setSizeUndefined();
		this.objSubsidiaries.add(this.btnStartSubScreening, this.btnPendingSubScreening, this.btnShowSubScreening);
		this.lblType.setSizeUndefined();
		this.lblName.setSizeUndefined();
		this.lblDate.setSizeUndefined();
		this.objDetail.setWidth("40px");
		this.objDetail.setHeight(null);
		this.objSubsidiaries.setWidth("40px");
		this.objSubsidiaries.setHeight(null);
		this.tfComment.setWidth("300px");
		this.tfComment.setHeight(null);
		this.btnRemoveMe.setSizeUndefined();
		this.add(this.lblType, this.lblName, this.lblDate, this.objDetail, this.objSubsidiaries, this.tfComment,
			this.btnRemoveMe);
		this.setFlexGrow(1.0, this.lblName);
		this.setWidthFull();
		this.setHeight(null);
		
		this.btnStartSubScreening.addClickListener(this::btnStartSubScreening_onClick);
		this.btnPendingSubScreening.addClickListener(this::btnPendingSubScreening_onClick);
		this.btnShowSubScreening.addClickListener(this::btnShowSubScreening_onClick);
		this.btnRemoveMe.addClickListener(this::btnRemoveMe_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button    btnShowDetails, btnStartSubScreening, btnShowSubScreening, btnPendingSubScreening, btnRemoveMe;
	private Label     lblType, lblName;
	private Div       lblDate, objDetail, objSubsidiaries;
	private TextField tfComment;
	// </generated-code>
	
}
