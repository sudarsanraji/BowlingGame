package com.caweco.esra.ui.beans;

import java.util.Objects;
import org.tinylog.Logger;

import com.caweco.esra.business.utils.CssHelper;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.HasValue.ValueChangeEvent;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.shared.Registration;

@Tag("color-selector")
public class ColorSelector extends Div implements HasValue<ValueChangeEvent<String>, String>
{
	private TextField						textfield;
	private ColorPicker						colorfield;
	private SerializablePredicate<String>	colorValidator	=
		color -> (CssHelper.isValidCssHexColor(color) || CssHelper.isValidCssColorKeyword(color));
	
	public ColorSelector()
	{
		super();
		this.initComponents();
		
	}
	
	private void initComponents()
	{
		this.textfield = new TextField();
		this.textfield.getElement().getClassList().add("color-text");
		
		this.colorfield = new ColorPicker();
		this.colorfield.getElement().getClassList().add("color-picker");
		
		this.add(this.textfield, this.colorfield);
		
		this.colorfield.addValueChangeListener(this::colorfield_valueChanged);
		this.textfield.addValueChangeListener(this::textfield_valueChanged);
	}
	
	private void textfield_valueChanged(ComponentValueChangeEvent<TextField, String> event)
	{
		if(event.isFromClient())
		{
			Logger.debug("Color: " + event.getValue());
			
			if(this.colorValidator.test(this.getValue()))
			{
				this.colorfield.setValue(event.getValue());
				
				// notify listener here (currently, listener are not implemented)
			}
			else
			{
				// revert
				event.getSource().setValue(event.getOldValue());
			}
		}
	}
	
	private void colorfield_valueChanged(ComponentValueChangeEvent<ColorPicker, String> event)
	{
		if(event.isFromClient())
		{
			this.textfield.setValue(event.getValue());
		}
	}
	
	@Override
	public void setValue(String value)
	{
		this.textfield.setValue(value != null ? value : "");
		this.colorfield.setValue(value);
	}
	
	@Override
	public String getValue()
	{
		String value = this.textfield.getValue();
		if(value.isEmpty())
		{
			// determine between "empty" and "null"
			return this.colorfield.getValue();
		}
		return value;
	}
	
	public String getPickerValue()
	{
		return this.colorfield.getValue();
	}
	
	public boolean isValid()
	{
		return this.colorValidator.test(this.getValue());
	}
	
	public void setColorValidator(SerializablePredicate<String> colorValidator)
	{
		Objects.requireNonNull(colorValidator);
		this.colorValidator = colorValidator;
	}
	
	public SerializablePredicate<String> getColorValidator()
	{
		return this.colorValidator;
	}
	
	public void setLabel(String label)
	{
		this.textfield.setLabel(label);
	}
	
	public String getLabel()
	{
		return this.textfield.getLabel();
	}
	
	@Override
	public Registration addValueChangeListener(ValueChangeListener<? super ValueChangeEvent<String>> listener)
	{
		return this.textfield.addValueChangeListener(listener);
	}
	
	@Override
	public void setReadOnly(boolean readOnly)
	{
		this.textfield.setReadOnly(readOnly);
		this.colorfield.setReadOnly(readOnly);
		
	}
	
	@Override
	public boolean isReadOnly()
	{
		return this.textfield.isReadOnly();
	}
	
	@Override
	public void setRequiredIndicatorVisible(boolean requiredIndicatorVisible)
	{
		throw new UnsupportedOperationException();
	}
	
	@Override
	public boolean isRequiredIndicatorVisible()
	{
		return false;
	}
	
}
