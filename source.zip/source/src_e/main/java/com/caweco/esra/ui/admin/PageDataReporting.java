
package com.caweco.esra.ui.admin;

import java.beans.Beans;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.navigation.AccessibleRule;
import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.reporting.ReportBuilderThread;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.core.LobDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.caweco.esra.ui.data.provider.CustomFilterableDataProvider;
import com.caweco.esra.ui.main.helper.TemporaryBinaryElement;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.rapidclipse.framework.server.ui.filter.FilterComponent;
import com.rapidclipse.framework.server.ui.filter.GridFilterSubjectFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.StreamResource;


@AccessibleRule(AuthorizationResources.CLIENTADMINCOMMON)
@PageTitle("Backend: CSV Export | ESRA")
@Route(value = "reporting", layout = AdminBackendContainer.class)
public class PageDataReporting extends VerticalLayout
{

	CustomFilterableDataProvider<ScreeningMetadataBase> dp;
	static Boolean reportCurrentlyBuilding = false;
	
	@Override
	protected void onAttach(AttachEvent attachEvent) {
		super.onAttach(attachEvent);

		if (CurrentUtil.getClient() != null) 
		{
			ListDataProvider<LineOfBusiness> dpLOB = DataProvider.ofCollection(LobDAO.getLineOfBusinesses(CurrentUtil.getClient()));
			dpLOB.setSortOrder(LineOfBusiness::getName, SortDirection.ASCENDING);
			this.selectLob.setDataProvider(dpLOB);
			
			ListDataProvider<OE> dpOE = DataProvider.ofCollection(ClientDAO.getOe(CurrentUtil.getClient()));
			dpOE.setSortOrder(OE::getName, SortDirection.ASCENDING);
			this.selectOE.setDataProvider(dpOE);
			
			ListDataProvider<Function> dpFunction = DataProvider.ofCollection(ClientDAO.getFunctions(CurrentUtil.getClient()));
			dpFunction.setSortOrder(Function::getName, SortDirection.ASCENDING);
			this.selectFunction.setDataProvider(dpFunction);
			
			ListDataProvider<ScreeningStatus> dpStatus = DataProvider.ofCollection(ScreeningStatus.asList_byStatus());
			dpStatus.setSortOrder(ScreeningStatus::getStatus, SortDirection.ASCENDING);
			this.selectStatus.setDataProvider(dpStatus);
			
			ListDataProvider<OeRegion> dpOeRegion = DataProvider.ofCollection(ClientDAO.getOeRegions(CurrentUtil.getClient()));
			dpOeRegion.setSortOrder(OeRegion::getName, SortDirection.ASCENDING);
			this.selectOeRegion.setDataProvider(dpOeRegion);
			
		
			this.dp = new CustomFilterableDataProvider<ScreeningMetadataBase>(
					(d,q) -> {
						Client c = CurrentUtil.getClient();
						String clientId = c.getUuid().toString();
						return ScreeningDAO.getScreenings(clientId, d,q)
						.stream(); 
					},
					qq -> ScreeningDAO.countScreenings(CurrentUtil.getClient(), qq));
	
			this.grid.setDataProvider(dp);
			this.filterComponent.connectWith(dp);
		}
		
		if(reportFile != null)
		{
			this.updateReportFile(reportFile, null);
		}
		if(reportCurrentlyBuilding)
		{
			this.startWaitingForNewReport();
		}
	}

	private ReportBuilderThread    reportThread;
	private static TemporaryBinaryElement reportFile;
	
	public PageDataReporting()
	{
		super();
		this.initUI();
		this.initGrid();
		
		if(!Beans.isDesignTime())
		{
			this.progressBar.setIndeterminate(true);
		}
	}
	
	@Override
	protected void onDetach(final DetachEvent detachEvent)
	{
		if(this.reportThread != null)
		{
			this.reportThread.interrupt();
			this.reportThread = null;
		}
	}
	
	private void initGrid()
	{
		
		//// Row sorting
		
		Column<ScreeningMetadataBase> dateColumn = this.grid.getColumnByKey("screeningDate");
		this.grid.sort(GridSortOrder.desc(dateColumn).build());
		
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void grid_selectionChange(final SelectionEvent<Grid<ScreeningMetadataBase>, ScreeningMetadataBase> event) {
		if (reportThread == null) {
			this.button.setEnabled(!event.getAllSelectedItems().isEmpty());
		}
	}
	
	/************************************************************************/
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #button}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void button_onClick(ClickEvent<Button> event)
	{
		// Prepare UI and purge fields if necessary
		if(this.reportThread != null)
		{
			this.reportThread.interrupt();
			this.reportThread = null;
		}
		this.startWaitingForNewReport();
		PageDataReporting.reportCurrentlyBuilding = true;
		
		// Start the data feed thread
		Set<ScreeningMetadataBase> selectedItems = this.grid.asMultiSelect().getSelectedItems();
		this.reportThread = ReportBuilderThread.New3(UI.getCurrent(), this, selectedItems, false);
		this.reportThread.start();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #button2}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void button2_onClick(final ClickEvent<Button> event) {
		
		Logger.info("Building report with all filtered screenings.");
		// Prepare UI and purge fields if necessary
		if(this.reportThread != null)
		{
			this.reportThread.interrupt();
			this.reportThread = null;
		}
		this.startWaitingForNewReport();
		PageDataReporting.reportCurrentlyBuilding = true;
		
		// Start the data feed thread
		List<ScreeningMetadataBase> selectedItems = grid.getDataProvider()
                .fetch(new Query<>())
                .collect(Collectors.toList());
		
		Logger.info("Fetched all filtered screenings.");
		
		this.reportThread = ReportBuilderThread.New3(UI.getCurrent(), this, selectedItems, false);
		this.reportThread.start();
		
		Logger.info("Started report thread.");
	}
	
	/**
	 * Update UI at start of the building of a new report.
	 */
	private void startWaitingForNewReport()
	{
		this.reportFile = null;
		
		this.button.setEnabled(false);
		this.progressBar.setVisible(true);
		
		this.anchorHolder.setVisible(false);
		this.anchorHolder.removeAll();

		this.labelStartReportHint.setVisible(true);
	}
	
	/**
	 * This method is called by an external Thread on return of a "Report generation" task.<br />
	 * So this must be wrapped in {@link UI#access(com.vaadin.flow.server.Command)} by this thread.
	 * <p>Either "newBinary" or "throwable" are set, but not both.</p>
	 * 
	 * @param newBinary
	 * @param throwable
	 */
	public void updateReportFile(TemporaryBinaryElement newBinary, final Throwable throwable)
	{
		PageDataReporting.reportFile = newBinary;
		PageDataReporting.reportCurrentlyBuilding = false;
		
		this.progressBar.setVisible(false);
		
		if(throwable != null)
		{
			Notificator.error("There was an error at building the report: " + throwable.getMessage());
			Logger.error("There was an error at building the report", throwable);
			throwable.printStackTrace();
		}
		else if (newBinary != null) {			
				final String filename = newBinary.getFileName();
				final StreamResource resource = new StreamResource(filename,
						() -> new ByteArrayInputStream(PageDataReporting.reportFile.getBinaryData()));

				final Anchor download = new Anchor(resource, "Download " + filename);
				download.getElement().setAttribute("download", true);
				this.anchorHolder.add(download);
				this.anchorHolder.setVisible(true);

				Logger.info("Report built and added to UI.");
				Logger.tag("PAM")
						.info(CurrentUtil.getUser().getFirstname() + " " + CurrentUtil.getUser().getLastname()
								+ " with roles " + CommonUtil.getLogString(CurrentUtil.getUser())
								+ " created the report " + newBinary.getFileName() + " from the admin page ");
		}
		this.button.setEnabled((this.grid.getSelectedItems() != null && !this.grid.getSelectedItems().isEmpty()));
		
		this.labelStartReportHint.setVisible(false);
		
		if(this.reportThread != null)
		{
			this.reportThread.interrupt();
			this.reportThread = null;
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectLob}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectLob_valueChanged(
			final ComponentValueChangeEvent<ComboBox<LineOfBusiness>, LineOfBusiness> event) {
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				Integer id = event.getValue().getId();
				dp.addPropertyFilter("lineOfBusiness", id);
			}
			else
			{
				dp.removePropertyFilter("lineOfBusiness");
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectFunction}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectFunction_valueChanged(final ComponentValueChangeEvent<ComboBox<Function>, Function> event) {
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				Integer id = event.getValue().getId();
				dp.addPropertyFilter("function", id);
			}
			else
			{
				dp.removePropertyFilter("function");
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectOE}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectOE_valueChanged(final ComponentValueChangeEvent<ComboBox<OE>, OE> event) {
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				Integer id = event.getValue().getId();
				dp.addPropertyFilter("oe", id);
			}
			else
			{
				dp.removePropertyFilter("oe");
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectStatus}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectStatus_valueChanged(
			final ComponentValueChangeEvent<ComboBox<ScreeningStatus>, ScreeningStatus> event) {
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				String name = event.getValue().name();
				dp.addPropertyFilter("status", name);
			}
			else
			{
				dp.removePropertyFilter("status");
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #selectOeRegion}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void selectOeRegion_valueChanged(final ComponentValueChangeEvent<ComboBox<OeRegion>, OeRegion> event) {
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				String id = event.getValue().getId().toString();
				dp.addPropertyFilter("oe.region", id);
			}
			else
			{
				dp.removePropertyFilter("oe.region");
			}
		}
	}

	/**
	 * Event handler delegate method for the {@link TextField} {@link #textField}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void textField_valueChanged(final ComponentValueChangeEvent<TextField, String> event) {
		
		if (event.isFromClient())
		{
			if (event.getValue() != null)
			{
				String text = event.getValue();
				dp.setPropertySearchText(text);
			}
			else
			{
				dp.setPropertySearchText(null);
			}
		}
	}



	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.filterComponent = new FilterComponent();
		this.textField = new TextField();
		this.horizontalLayout2 = new HorizontalLayout();
		this.selectLob = new ComboBox<>();
		this.selectFunction = new ComboBox<>();
		this.selectOE = new ComboBox<>();
		this.selectStatus = new ComboBox<>();
		this.selectOeRegion = new ComboBox<>();
		this.grid = new Grid<>(ScreeningMetadataBase.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.button = new Button();
		this.button2 = new Button();
		this.progressBar = new ProgressBar();
		this.labelStartReportHint = new Label();
		this.anchorHolder = new HorizontalLayout();
	
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.filterComponent.setVisible(false);
		this.selectLob.setPlaceholder("Line of Business");
		this.selectLob.setMaxWidth("250px");
		this.selectLob.setClearButtonVisible(true);
		this.selectLob.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(LineOfBusiness::getName));
		this.selectFunction.setPlaceholder("Function");
		this.selectFunction.setMaxWidth("250px");
		this.selectFunction.setClearButtonVisible(true);
		this.selectFunction.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(Function::getName));
		this.selectOE.setPlaceholder("OE");
		this.selectOE.setMaxWidth("250px");
		this.selectOE.setClearButtonVisible(true);
		this.selectOE.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(OE::getName));
		this.selectStatus.setPlaceholder("Status");
		this.selectStatus.setMaxWidth("250px");
		this.selectStatus.setClearButtonVisible(true);
		this.selectStatus.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(ScreeningStatus::getStatus));
		this.selectOeRegion.setPlaceholder("Region");
		this.selectOeRegion.setMaxWidth("250px");
		this.selectOeRegion.setClearButtonVisible(true);
		this.selectOeRegion.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(OeRegion::getName));
		this.grid.addColumn(ScreeningMetadataBase::getScreeningDate).setKey("screeningDate")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "screeningDate")).setSortable(true);
		this.grid.addColumn(ScreeningMetadataBase::getName).setKey("name")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "name")).setSortable(true);
		this.grid.addColumn(v -> Optional.ofNullable(v).map(ScreeningMetadataBase::getOe).map(OE::getName).orElse(null))
				.setKey("oe.name").setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "oe.name"))
				.setSortable(true);
		this.grid
				.addColumn(v -> Optional.ofNullable(v).map(ScreeningMetadataBase::getOe).map(OE::getRegion)
						.map(OeRegion::getName).orElse(null))
				.setKey("oe.region.name")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "oe.region.name")).setSortable(true);
		this.grid
				.addColumn(v -> Optional.ofNullable(v).map(ScreeningMetadataBase::getFunction).map(Function::getName)
						.orElse(null))
				.setKey("function.name")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "function.name")).setSortable(true);
		this.grid
				.addColumn(v -> Optional.ofNullable(v).map(ScreeningMetadataBase::getLineOfBusiness)
						.map(LineOfBusiness::getName).orElse(null))
				.setKey("lineOfBusiness.name")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "lineOfBusiness.name"))
				.setSortable(true);
		this.grid
				.addColumn(v -> Optional.ofNullable(v).map(ScreeningMetadataBase::getStatus).map(ScreeningStatus::getStatus)
						.orElse(null))
				.setKey("status.status")
				.setHeader(CaptionUtils.resolveCaption(ScreeningMetadataBase.class, "status.status")).setSortable(true);
		this.grid.setSelectionMode(Grid.SelectionMode.MULTI);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.label.setText("Create report of:");
		this.button.setEnabled(false);
		this.button.setText("Selected Entries");
		this.button.setIcon(VaadinIcon.PIE_BAR_CHART.create());
		this.button2.setText("All Filtered Entries");
		this.button2.setIcon(VaadinIcon.PIE_BAR_CHART.create());
		this.progressBar.setClassName("slow1");
		this.progressBar.setVisible(false);
		this.labelStartReportHint.setText("This operation may take some time.");
		this.labelStartReportHint.setVisible(false);
	
		this.filterComponent.connectWith(this.grid.getDataProvider());
		this.filterComponent.setFilterSubject(GridFilterSubjectFactory.CreateFilterSubject(this.grid,
				Arrays.asList("function.name", "lineOfBusiness.name", "name", "oe.name", "oe.region.name", "status.status"),
				Arrays.asList()));
	
		this.selectLob.setSizeUndefined();
		this.selectFunction.setSizeUndefined();
		this.selectOE.setSizeUndefined();
		this.selectStatus.setSizeUndefined();
		this.selectOeRegion.setSizeUndefined();
		this.horizontalLayout2.add(this.selectLob, this.selectFunction, this.selectOE, this.selectStatus,
				this.selectOeRegion);
		this.horizontalLayout2.setFlexGrow(1.0, this.selectLob);
		this.horizontalLayout2.setFlexGrow(1.0, this.selectFunction);
		this.horizontalLayout2.setFlexGrow(1.0, this.selectOE);
		this.horizontalLayout2.setFlexGrow(1.0, this.selectStatus);
		this.horizontalLayout2.setFlexGrow(1.0, this.selectOeRegion);
		this.label.setSizeUndefined();
		this.button.setSizeUndefined();
		this.button2.setSizeUndefined();
		this.progressBar.setWidth("150px");
		this.progressBar.setHeight("10px");
		this.labelStartReportHint.setSizeUndefined();
		this.anchorHolder.setSizeUndefined();
		this.horizontalLayout.add(this.label, this.button, this.button2, this.progressBar, this.labelStartReportHint,
				this.anchorHolder);
		this.filterComponent.setWidthFull();
		this.filterComponent.setHeight(null);
		this.textField.setSizeUndefined();
		this.horizontalLayout2.setSizeUndefined();
		this.grid.setSizeFull();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.filterComponent, this.textField, this.horizontalLayout2, this.grid, this.horizontalLayout);
		this.setFlexGrow(1.0, this.grid);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.START, this.horizontalLayout);
		this.setSizeFull();
	
		this.textField.addValueChangeListener(this::textField_valueChanged);
		this.selectLob.addValueChangeListener(this::selectLob_valueChanged);
		this.selectFunction.addValueChangeListener(this::selectFunction_valueChanged);
		this.selectOE.addValueChangeListener(this::selectOE_valueChanged);
		this.selectStatus.addValueChangeListener(this::selectStatus_valueChanged);
		this.selectOeRegion.addValueChangeListener(this::selectOeRegion_valueChanged);
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.button.addClickListener(this::button_onClick);
		this.button2.addClickListener(this::button2_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private ComboBox<Function> selectFunction;
	private Button button, button2;
	private ProgressBar progressBar;
	private HorizontalLayout horizontalLayout2, horizontalLayout, anchorHolder;
	private Label label, labelStartReportHint;
	private FilterComponent filterComponent;
	private ComboBox<LineOfBusiness> selectLob;
	private ComboBox<OE> selectOE;
	private TextField textField;
	private ComboBox<ScreeningStatus> selectStatus;
	private ComboBox<OeRegion> selectOeRegion;
	private Grid<ScreeningMetadataBase> grid;
	// </generated-code>
	
}
