
package com.caweco.esra.business.aa;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.caweco.esra.entities.meta.HasRepresentation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.rapidclipse.framework.security.authorization.Resource;
import com.rapidclipse.framework.security.authorization.ResourceEnum;
import com.rapidclipse.framework.server.resources.Caption;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.rapidclipse.framework.server.security.authorization.AuthorizationResource;


/**
 * Central collection of all authorization resources used in the project.
 */
@Caption("{%description}")
public enum AuthorizationResources
	implements ResourceEnum<AuthorizationResources>, AuthorizationResource, HasRepresentation
{
	/**
	 * Grants access to backend:
	 */
	@JsonProperty("BackendAccess")
	BACKENDACCESS("BackendAccess"),
	
	/**
	 * Grants access to backend and client related backend pages.
	 */
	@JsonProperty("ClientAdminCommon")
	CLIENTADMINCOMMON("ClientAdminCommon"),
	
	/**
	 * Grants access to ESU pages:
	 */
	@JsonProperty("ESUAccess")
	ESUACCESS("ESUAccess"),
	
	
	/**
	 * Allows search in all screenings of a client
	 */
	@JsonProperty("SearchOwnScreenings")
	SCREENINGSEARCH_OWN("SearchOwnScreenings"),
	
	/**
	 * Enables auto-assignment as screening service user for screenings with state SERVICE_REQUESTED.
	 */
	@JsonProperty("AutoAssignAsScreeningServiceUser")
	SCREENING_SERVICE_AUTOASSIGN(
		"AutoAssignAsScreeningServiceUser"),
	
	/**
	 * Allows search in all screenings with state SERVICE_REQUESTED of a client .
	 */
	@JsonProperty("SearchScreeningsInServiceRequestedState")
	SCREENINGSEARCH_SERVICEREQUESTED(
		"SearchScreeningsInServiceRequestedState"),
	
	/**
	 * Allows search in all screenings of a client
	 */
	@JsonProperty("SearchAllScreenings")
	SCREENINGSEARCH_ALL("SearchAllScreenings"),
	
	/**
	 * Grants access to Business Information Page
	 */
	@JsonProperty("AccessBusinessInformationPage")
	BUSINESSINFORMATION_ACCESS(
		"AccessBusinessInformationPage"),
	
	/**
	 * Grants access to Trade Sanctions Page
	 */
	@JsonProperty("AccessTradeSanctionPage")
	TRADESANCTION_ACCESS("AccessTradeSanctionPage"),
	
	/**
	 * Grants access to Financial Sanctions Page
	 */
	@JsonProperty("AccessFinancialSanctionPage")
	FINANCIALSANCTION_ACCESS("AccessFinancialSanctionPage")
	;
	
	
	/////////////////////////////
	// implementation details //
	///////////////////////////
	
	private final String	name = "";
	private String       description;
	
	@JsonIgnore
	private Resource		resource;
	
	private AuthorizationResources(final String name)
	{
		this.description = name;
	}
	
	@Override
	@JsonValue
	public String resourceName()
	{
		return this.name();
	}
	
	@Override
	public Resource resource()
	{
		if(this.resource == null)
		{
			this.resource = Authorization.resource(this.name());
		}
		
		return this.resource;
	}
	
	
	public static Stream<AuthorizationResources> stream()
	{
		return Stream.of(AuthorizationResources.values());
	}
	
	public static Set<AuthorizationResources> asSet()
	{
		return AuthorizationResources.stream().collect(Collectors.toSet());
	}
	
	@Override
	public String getRepresentation()
	{
		return this.description != null ? this.description : this.name();
	}
	
	public String getDescription()
	{
		return this.description;
	}
	
	public void setDescription(String description)
	{
		this.description = description;
	}
}
