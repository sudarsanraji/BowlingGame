
package com.caweco.esra.subsidary.frontend;

import java.util.List;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningData;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskDTO;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status.Family;


public class SubsidiaryTaskDAO
{
	
	public static String TASK_S_ALL         = "/tasks/subsidiary";                                    // getTasks
	public static String TASK_S_CREATE      = TASK_S_ALL;                                             // frontend_addRunningTask
	public static String TASK_S_READ        = TASK_S_ALL + "/{taskId}";                               // getTask_byTaskID
	
	public static String TASK_S_READ_RESULT = TASK_S_ALL + "/{taskId}/resultdata";                    // getTaskResultData
	public static String TASK_S_SEARCH_1    = TASK_S_ALL + "/byuser/{userId}";                        // getTasks_ByUser
	public static String TASK_S_SEARCH_6    = TASK_S_ALL + "/bysecmostrecent/{searchEntryCompanyId}"; // getTask_bySearchEntryCompanyID_mostRecent
	
	public static String TASK_S_HEARTBEAT   = TASK_S_ALL + "/{taskId}/heartbeat";                     // backend_receiveHeartbeat
	public static String TASK_S_UPDATE      = TASK_S_ALL + "/{taskId}";                               // backend_updateTask
	
	/**
	 * Register new Task
	 *
	 * @param newTask
	 */
	public static void frontend_addRunningTask(final SubsidiaryScreeningTaskF newTask)
	{
		SubsidiaryScreeningTaskDTO newTaskDto = SubsidiaryItemMapper.convertToDTO(newTask);
		
		// throws exception if not accepted
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_CREATE);
		Response        response      = webTarget.request().post(Entity.entity(newTaskDto, MediaType.APPLICATION_JSON), Response.class);
		
		// TODO: rework error handling
		Family family = response.getStatusInfo().getFamily();
		// closes the "original response entity data stream if open"
		String readEntity = response.readEntity(String.class);
		if (family != Response.Status.Family.SUCCESSFUL) 
		{
			throw new RuntimeException("REST error: " + readEntity);
		}
		
		// Screening state changes (Frontend state manager). See also Backend side!
		FrontendScreeningBlockingStateManager.blockScreening(newTask.getScreeningId().toString(),
			newTask.getId().toString());
		
	}
	
	//// DATA Access
	
	public static SubsidiaryScreeningData getTaskResultData(final String taskId)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_READ_RESULT)
			.resolveTemplate("taskId", taskId);
		try
		{
			return webTarget.request().get(SubsidiaryScreeningData.class);
		}
		catch(Exception e)
		{
			Logger.info(e);
			return null;
		}
	}
	
	public static SubsidiaryScreeningTaskF getTask_byTaskID(final String taskId)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_READ)
			.resolveTemplate("taskId", taskId);
		SubsidiaryScreeningTaskDTO result = webTarget.request().get(SubsidiaryScreeningTaskDTO.class);
		return SubsidiaryItemMapper.convert(result);
	}
	
	public static List<SubsidiaryScreeningTaskF> getTasks_ByUser(String userId)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_SEARCH_1)
			.resolveTemplate("userId", userId);
		List<SubsidiaryScreeningTaskDTO> result = webTarget.request().get(new GenericType<List<SubsidiaryScreeningTaskDTO>>(){});
		return result.stream().map(SubsidiaryItemMapper::convert).collect(Collectors.toList());
	}
	
	public static SubsidiaryScreeningTaskF getTask_bySearchEntryCompanyID_mostRecent(final String searchEntryCompanyId)
	{
		final WebTarget                webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_SEARCH_6)
			.resolveTemplate("searchEntryCompanyId", searchEntryCompanyId);
		List<SubsidiaryScreeningTaskDTO> result = webTarget.request().get(new GenericType<List<SubsidiaryScreeningTaskDTO>>(){});
		
		return result.isEmpty() ? null : SubsidiaryItemMapper.convert(result.get(0));
	}
	
	//// DATA Update
	
	/**
	 * Send Task data to backend <b>AS-IS. "ResultData" has to be added or removed BEFORE!.</b>
	 * @param newVersion
	 */
	public static void frontend_updateTask(final SubsidiaryScreeningTaskF newVersion)
	{
		SubsidiaryScreeningTaskDTO newVersionDto = SubsidiaryItemMapper.convertToDTO(newVersion);
		
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_UPDATE)
			.resolveTemplate("taskId", newVersion.getId().toString());
		Response response = webTarget.request().post(Entity.entity(newVersionDto, MediaType.APPLICATION_JSON), Response.class);
		
		// TODO: rework error handling
		
		Family family = response.getStatusInfo().getFamily();
		// closes the "original response entity data stream if open"
		String readEntity = response.readEntity(String.class);
		if (family != Response.Status.Family.SUCCESSFUL) 
		{
			throw new RuntimeException("REST error: " + readEntity);
		}
		

		// Screening state changes (Frontend state manager). See also Backend side!
		if(newVersion.getState().isBlocking())
		{
			FrontendScreeningBlockingStateManager.blockScreening(newVersion.getScreeningId().toString(), newVersion.getId().toString());
		}
		else {
			FrontendScreeningBlockingStateManager.unblockScreening(newVersion.getScreeningId().toString());
		}
	}
	
	//// FRONTEND-HEARTBEAT
	
	public static void frontend_sendHeartbeat(final String taskId)
	{
		final WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget(TASK_S_HEARTBEAT)
			.resolveTemplate("taskId", taskId);	
		
		Logger.debug("Task {} | TaskDAO | HEARTBEAT [ no. {} ]", taskId);
		
		Response response = webTarget.request().get(Response.class);
		
		// TODO: rework error handling
		
		Family family = response.getStatusInfo().getFamily();
		// closes the "original response entity data stream if open"
		String readEntity = response.readEntity(String.class);
		if (family != Response.Status.Family.SUCCESSFUL) 
		{
			throw new RuntimeException("REST error: " + readEntity);
		}
	}
}
