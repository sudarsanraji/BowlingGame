
package com.caweco.esra.business.func.rest;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.entities.config.ConfigRestEndpoint;


public class RestUtil
{
	
	private static final ConcurrentHashMap<String, RestClientSeaWeb2> INSTANCES_SEAWEB = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, RestClientBIH>     INSTANCES_BIH    = new ConcurrentHashMap<>();
	
	private RestUtil()
	{
		// Static helper class
	}
	
	/********************************************************************************/
	
	public static Optional<String> getAdditionalFromConfig(ConfigRestEndpoint cfg, String key)
	{
		if(cfg.getAdditional().containsKey(key))
		{
			return Optional.ofNullable(cfg.getAdditional().get(key));
		}
		else
		{
			return Optional.empty();
		}
	}
	
	/********************************************************************************/
	/* BIH */
	
	public static void refreshRestClient_BIH(String clientId)
	{
		ConfigRestEndpoint conf = ClientDAO.getEndpointConfigurationBih(clientId).orElse(ConfigRestEndpoint.getConfigBIH());
		RestClientBIH restClientBIH = new RestClientBIH(conf);
		
		INSTANCES_BIH.put(clientId,restClientBIH);
	}
	
	public static RestClientBIH getRestClient_BIH(String clientId)
	{
		return INSTANCES_BIH.computeIfAbsent(clientId, cid -> {
			ConfigRestEndpoint conf = ClientDAO.getEndpointConfigurationBih(cid).orElse(ConfigRestEndpoint.getConfigBIH());
			return new RestClientBIH(conf);
		});
	}
	
	public static void refreshRestClient_SEAWEB(String clientId)
	{
		ConfigRestEndpoint conf = ClientDAO.getEndpointConfigurationSeaweb(clientId).orElse(ConfigRestEndpoint.getConfigSEAWEB());
		RestClientSeaWeb2 restClientSeaWeb2 = new RestClientSeaWeb2(conf);
		
		INSTANCES_SEAWEB.put(clientId,restClientSeaWeb2);
	}	
	
	public static RestClientESRADB getRestClient_ESRADB()
	{
		return new RestClientESRADB();
	}
	
	public static RestClientSeaWeb2 getRestClient_SEAWEB(String clientId)
	{
		return INSTANCES_SEAWEB.computeIfAbsent(clientId, cid -> {
			ConfigRestEndpoint conf = ClientDAO.getEndpointConfigurationSeaweb(cid).orElse(ConfigRestEndpoint.getConfigSEAWEB());
			return new RestClientSeaWeb2(conf);
		});
	}
}
