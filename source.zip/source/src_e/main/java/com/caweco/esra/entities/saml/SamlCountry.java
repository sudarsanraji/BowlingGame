package com.caweco.esra.entities.saml;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.entities.meta.HasRepresentation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


public class SamlCountry implements SamlAttributeCriterion, HasRepresentation
{
	
	public SamlCountry()
	{
		//for Jackson
	}

	private String	attrName	= "urn:oid:2.5.4.6";
	private String	countryCode;
	private String			countryName;
	
	public SamlCountry(String countryCode)
	{
		super();
		Objects.requireNonNull(countryCode);
		this.countryCode = StringUtils.upperCase(countryCode);
	}
	
	public SamlCountry(String countryCode, String countryName)
	{
		super();
		Objects.requireNonNull(countryCode);
		this.countryCode = StringUtils.upperCase(countryCode);
		this.countryName = countryName;
	}
	
	public String getCountryName()
	{
		return this.countryName;
	}
	
	public void setCountryName(String countryName)
	{
		this.countryName = countryName;
	}
	
	public String getCountryCode()
	{
		return this.countryCode;
	}
	
	@Override
	@JsonProperty("attributeName")
	public String getAttributeName()
	{
		return this.attrName;
	}
	
	@JsonProperty("attributeName")
	public void setAttributeName(String attributeName)
	{
		 this.attrName = attributeName;
	}
	
	/**
	 * The okValue for is the {@link SamlCountry#countryCode}
	 * 
	 * @see {@link SamlCountry#getCountryCode}
	 */
	@Override
	public String getOkValue()
	{
		return this.countryCode;
	}
	
	@Override
	@JsonIgnore
	public String getRepresentation()
	{
		return this.countryName;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.countryCode == null) ? 0 : this.countryCode.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(this.getClass() != obj.getClass())
			return false;
		SamlCountry other = (SamlCountry)obj;
		if(this.countryCode == null)
		{
			if(other.countryCode != null)
				return false;
		}
		else if(!this.countryCode.equals(other.countryCode))
			return false;
		return true;
	}
	
}
