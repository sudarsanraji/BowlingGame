
package com.caweco.esra.ui.main.helper;

import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.core.ScreeningStatus;
import com.rapidclipse.framework.server.resources.Caption;


public interface ScreeningSearchResult<T extends ScreeningMetadataBase>
{
	enum Type
	{
		COMMON_MATCH(""),
		ID_MATCH(""), // NO_UCD (unused code) - kept for data consistency purposes 
		MULTI("multi");
		
		String representation;
		
		Type(String representation)
		{
			this.representation = representation;
		}
		
		public String getRepresentation()
		{
			return this.representation;
		}
	}
	
	public String getClientId();
	
	T getScreeningRaw();
	
	default Optional<Screening> fetchScreening()
	{
		return ScreeningDAO.find2(getClientId(), getId());
	}
	
	@Caption("Hit type")
	public Type getType();
	
	@Caption("Found in")
	public String getRepresentation();
	
	@Caption("Process ID")
	public String getId();
	
	@Caption("Process Name")
	public String getName();
	
	@Caption("Process Date")
	public LocalDate getScreeningDate();
	
	// @Caption("Requestor")
	// default User getOwner()
	// {
	// return this.getScreening().getScreeningOwner();
	// }
	
	@Caption("Line Of Business")
	public LineOfBusiness getLob();
	
	@Caption("Function")
	public Function getFunction();
	
	@Caption("Office")
	public OE getOe();
	
	@Caption("Status")
	public ScreeningStatus getStatus();
	
	@Caption("Process ID")
	public Set<Pair<String, String>> getMatches();
	
	public String getScreeningOwnerEmail();
	
	public String getScreeningServiceUserEmail();
	
}
