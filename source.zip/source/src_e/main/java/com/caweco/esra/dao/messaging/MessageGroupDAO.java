package com.caweco.esra.dao.messaging;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.MessageGroupCreateDTO;
import com.caweco.esra.dto.MessageGroupMemberDTO;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.MessageGroupCreator;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class MessageGroupDAO
{
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	public static void update(final MessageGroup group)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId() + "/");
		Response response = webTarget.request().put(Entity.entity(MessageGroupCreator.convertGroupToMetadataDTO(group), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	
	public static void insertScreeningMessageGroup(final Screening parent, final MessageGroup bean, final List<Message> messages)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		MessageGroupCreateDTO creatorDto = MessageGroupCreator.convertGroupToCreatorDTO(bean, CurrentUtil.getUser());
		
		WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() + "/screening/" + parent.getScreeningID() + "/messaging/");
		Response response = webTarget.request().post(Entity.entity(creatorDto, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}
	
	/**
	 * USE THIS READ-ONLY! DO NOT SAVE COLLECTION TO STORAGE!
	 */
	public static Map<UUID, MessageGroup> findAll(final HasMessages parent)
	{
		return parent.getMessageGroups(true);
	}
	
	public static MessageGroup findById(final HasMessages parent, final UUID id)
	{
		return parent.getMessageGroups(true).get(id);
	}
	
	/**
	 * USE THIS READ-ONLY! DO NOT SAVE COLLECTION TO STORAGE!
	 */
	public static List<MessageGroup> findByUser(final Screening parent, User user)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/screening/" + parent.getScreeningID() + "/messaging/groups/" + user.getEmailAddress());
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		if(response.getStatus() == 200)
		{
			JavaType type = om.getTypeFactory().constructCollectionType(List.class, MessageGroupMetadataDTO.class);
			
			try {
				List<MessageGroupMetadataDTO> a = om.readValue(responseBody, type);
				
				List<MessageGroup> actualList = new ArrayList<>();
				
				a.forEach(dto -> {
					actualList.add(MessageGroupCreator.convertMetadataDTOToGroup(dto));
				});
				
				return actualList;
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return new ArrayList<>();
			}
		}
		
		return new ArrayList<>();
	}

	
	
	/* **************************************************************************** */
	/* Extended */
	
	/**
	 * Checks if user is member or admin of this group.
	 * 
	 * @param messageGroup
	 * @param user
	 * @return true if user is member or admin, false otherwise
	 */
	public static boolean isMember(final MessageGroup messageGroup, User user)
	{
		if (messageGroup == null || user == null)
			return false;
		
		if (messageGroup.getMembers(true).keySet().contains(user))
			return true;
		
		if (messageGroup.getAdmins(true).contains(user))
			return true;
		
		return false;
	}
	
	/**
	 * Removes a user from this group.<br />
	 * If the group is now without a admin, the MessageGroup is returned for further processing (most likely for removal)
	 * 
	 * @param messageGroup
	 * @param userToRemove
	 * @return the {@link MessageGroup} if there is no admin any more. <code>Null</code> otherwise.
	 */
	public static MessageGroup removeMembers(MessageGroup messageGroup, Collection<User> userToRemove)
	{
		if (messageGroup != null && userToRemove != null)
		{
			// Remove user from members if user is member
				
			RestClientESRADB client = RestUtil.getRestClient_ESRADB();
			
			WebTarget webTarget = client.getMethodTarget("/messaging/" + messageGroup.getId() + "/members/remove");
			Response response = webTarget.request().post(Entity.entity(userToRemove, MediaType.APPLICATION_JSON));
			Logger.tag("REST").info(response.toString());
			
			return null;
		}
		else
		{
			return null;
		}
	}	
	
	// NEW METHODS
	
	public static Optional<MessageGroup> getPublicChannel(Screening screening) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/screening/" + screening.getScreeningID() + "/messaging/public");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() == 200)
		{
			MessageGroup responseBody = response.readEntity(MessageGroup.class);		
			return Optional.of(responseBody);
		}
		else
		{
			String responseBody = response.readEntity(String.class);
			System.out.println(responseBody);
			return Optional.empty();
		}
		
		
	}


	public static Optional<Map<User, Boolean>> getGroupMembers(MessageGroup messageGroup) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/messaging/" + messageGroup.getId() + "/members");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		if(response.getStatus() == 200)
		{
			JavaType type = om.getTypeFactory().constructCollectionType(List.class, MessageGroupMemberDTO.class);
			
			try {
				List<MessageGroupMemberDTO> a = om.readValue(responseBody, type);
				
				Map<User, Boolean> actualMap = new HashMap<>();
				
				a.forEach(dto -> {
					actualMap.put(UserCreator.convertMetadataDTOToUser(dto.getDto()), dto.isFollowing());
				});
				
				return Optional.of(actualMap);
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return Optional.empty();
			}
		}
		
		return Optional.empty();
	}


	public static Optional<List<User>> getGroupAdmins(MessageGroup messageGroup) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/messaging/" + messageGroup.getId() + "/admins");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		if(response.getStatus() == 200)
		{
			JavaType type = om.getTypeFactory().constructCollectionType(List.class, UserMetadataDTO.class);
			
			try {
				List<UserMetadataDTO> a = om.readValue(responseBody, type);
				
				List<User> actualList = new ArrayList<>();
				
				a.forEach(dto -> {
					actualList.add(UserCreator.convertMetadataDTOToUser(dto));
				});
				
				return Optional.of(actualList);
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return Optional.empty();
			}
		}
		
		return Optional.empty();
	}


	public static Optional<List<MessageGroup>> getChannelsOfScreening(Screening screening) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid() + "/screening/" + screening.getScreeningID() + "/messaging/groups");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		if(response.getStatus() == 200)
		{
			JavaType type = om.getTypeFactory().constructCollectionType(List.class, MessageGroupMetadataDTO.class);
			
			try {
				List<MessageGroupMetadataDTO> a = om.readValue(responseBody, type);
				
				List<MessageGroup> actualList = new ArrayList<>();
				
				a.forEach(dto -> {
					actualList.add(MessageGroupCreator.convertMetadataDTOToGroup(dto));
				});
				
				return Optional.of(actualList);
				
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return Optional.empty();
			}
		}
		
		return Optional.empty();
	}


	public static void removeMember(MessageGroup group, User user) {
		ArrayList<User> userList = new ArrayList<>();
		userList.add(user);
		
		removeMembers(group, userList);
	}


	public static void removeAdmin(MessageGroup group, User user) {
		ArrayList<User> userList = new ArrayList<>();
		userList.add(user);
		
		removeAdmins(group, userList);
	}


	private static void removeAdmins(MessageGroup group, ArrayList<User> userList) {
		if (group != null && userList != null)
		{
			// Remove user from members if user is member
					
			RestClientESRADB client = RestUtil.getRestClient_ESRADB();
			
			List<UserMetadataDTO> dtoList = new ArrayList<>();
			
			userList.forEach(user -> {
				dtoList.add(UserCreator.convertUserToMetadataDTO(user));
			});
			
			WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId() + "/members/remove");
			Response response = webTarget.request().post(Entity.entity(dtoList, MediaType.APPLICATION_JSON));
			Logger.tag("REST").info(response.toString());
		}
	}

	/**
	 * Saves current timestamp as "last read timestamp".
	 * @param group
	 * @param user
	 */
	public static void updateGroupLastReadMessagesTimestamp(MessageGroup group, User user) 
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/messaging/" + group.getId() + "/read/" + user.getEmailAddress());
		Response response = webTarget.request().post(Entity.entity("{}", MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}

}
