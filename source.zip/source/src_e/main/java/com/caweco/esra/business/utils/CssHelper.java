package com.caweco.esra.business.utils;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CssHelper
{
	protected static Pattern	PATTERN_HEXCOLOR		= getHexPattern();
	protected static Properties	COLORKEYWORD_HEXCOLOR	=
		FileHelper.loadPropertiesFromResources("predefined/cssColorKeywords.properties");
	
	/* ************************************************************************** */
	
	public static boolean isValidCssHexColor(String str)
	{
		
		if(str == null || str.isEmpty())
		{
			return false;
		}
		
		Matcher m = PATTERN_HEXCOLOR.matcher(str);
		return m.matches();
	}
	
	public static boolean isValidCssColorKeyword(String str)
	{
		
		if(str == null || str.isEmpty())
		{
			return false;
		}
		
		return COLORKEYWORD_HEXCOLOR.containsKey(str);
	}
	
	public static String getCssHexColorForCssColorKeyword(String str)
	{
		if(str == null || str.isEmpty())
		{
			return null;
		}
		
		return COLORKEYWORD_HEXCOLOR.getProperty(str);
	}
	
	/* ************************************************************************** */
	
	public static Pattern getHexPattern()
	{
		String HEX_PATTERN_STRING = "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$";
		
		Pattern pattern = Pattern.compile(HEX_PATTERN_STRING);
		return pattern;
	}
	
	/* ************************************************************************** */
	
}
