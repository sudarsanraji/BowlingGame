package com.caweco.esra.entities.messaging;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.caweco.esra.entities.User;


public interface HasMessages
{
	public MessageGroup getPublicMessages(boolean forceUpdate);

	public Map<UUID, MessageGroup> getMessageGroups(boolean forceUpdate);
	
	public Map<String, List<Message>> getPrivateMessages();
	
	public List<Message> getPrivateMessages(User user);
	
	public Object getMessagesParent();
	
}
