package com.caweco.esra.business.utils;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.Authorizer;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.creator.UserCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.caweco.esra.entities.User;
import com.caweco.esra.ui.main.PageSanctionSearch;
import com.rapidclipse.framework.security.authorization.Subject;
import com.rapidclipse.framework.server.navigation.Navigation;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.internal.RouteUtil;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;



public class CommonUtil
{
	private static final String EMPTY = "";
	
	private static final String NONE = "none";
	
	private static final String COMMA = ",";
	
	private static final String ACCESSDENIED = "accessdenied";
	
	private CommonUtil()
	{
	}
	
	////////////////
	//// SCOPE OPERATION
	
	public static void changeClient(Client newClient, boolean updateUser)
	{
		// Update Client in Session
		CurrentUtil.toSession(Client.class, newClient);
		
//		// Update Data in session that depend on client
//		CurrentUtil.toSession(RestClientBIH.class, null);
//		CurrentUtil.toSession(RestClientSeaWeb2.class, null);
		
		User user = CurrentUtil.getUser();
		
		if(updateUser)
		{
			// Update User: last visited client
			user.setLastVisitedClientId(newClient.getUuid());
			
			RestClientESRADB client = RestUtil.getRestClient_ESRADB();
			
			WebTarget webTarget = client.getMethodTarget("/user/" + user.getEmailAddress());
			
			UserMetadataDTO dto = UserCreator.convertUserToMetadataDTO(user);
			Response response = webTarget.request().post(Entity.entity(dto, MediaType.APPLICATION_JSON));
			Logger.tag("REST").info(response.toString());
		}
		
		Authorizer.updatePermissions(CurrentUtil.getVSession(), user);
		
		Navigation.navigateTo(PageSanctionSearch.class);
	}
	
	public static String getRoleString(User user) {
		Set <Role> roles = user.getRoles(true);
		if(!roles.isEmpty()) {
			List<String> roleNames = roles.stream().map(Role :: getName).collect(Collectors.toList());
			return String.join(COMMA, roleNames);
		} else {
			return EMPTY;
		}
	}
	
	public static String getLogString(User user) {
		String roleNames = getRoleString(user);
		String logRoleNames = roleNames.isEmpty()?NONE: roleNames;
		return logRoleNames;
	}
	public static String getCommaSeparatedRoleNames(Set<Role> roles) {
	    return roles.stream().map(Role::getName).collect(Collectors.joining(", "));
	}
	public static String getCommaSeparatedPermissions(Set<AuthorizationResources> resources) {
	    return resources.stream().map(AuthorizationResources::getRepresentation).collect(Collectors.joining(", "));
	}
	public static String getRoleStringByRoles(Set<com.rapidclipse.framework.security.authorization.Role> roles) {
		if (!roles.isEmpty()) {
			List<String> roleNames = roles.stream().map(com.rapidclipse.framework.security.authorization.Role::name)
					.collect(Collectors.toList());
			return String.join(COMMA, roleNames);
		} else {
			return EMPTY;
		}
	}
	
	public static void addFraudulentAccessLog(final Class<?> target, Subject user, boolean isAuthorized) {
		final Route route = null != target ? target.getAnnotation(Route.class) : null;
		if (null != route) {
			String apiName = RouteUtil.resolve(target, route);
			if (StringUtils.isNotBlank(apiName) && !ACCESSDENIED.equalsIgnoreCase(apiName) && !apiName.contains("kubernetes"))  {
				String name = null != user ? user.name() : EMPTY;
				String roles = null != user ? getRoleStringByRoles(user.roles()) : EMPTY;
				StringBuffer log = new StringBuffer("User ");
				log.append(name);
				log.append(" with roles ");
				log.append(roles);
				log.append(isAuthorized ? " attempted to access /" : " not authorized to access /");
				log.append(apiName);		        
				Logger.tag("PAM").info(log.toString());  
			}
		}
	}

}


