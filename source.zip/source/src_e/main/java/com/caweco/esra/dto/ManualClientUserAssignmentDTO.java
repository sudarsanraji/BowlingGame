package com.caweco.esra.dto;

import com.caweco.esra.entities.config.ManualClientUserAssignment;

public class ManualClientUserAssignmentDTO {

	private UserMetadataDTO user;
	private ManualClientUserAssignment userAssignment;
	
	
	public UserMetadataDTO getUser() {
		return user;
	}
	public void setUser(UserMetadataDTO user) {
		this.user = user;
	}
	public ManualClientUserAssignment getUserAssignment() {
		return userAssignment;
	}
	public void setUserAssignment(ManualClientUserAssignment userAssignment) {
		this.userAssignment = userAssignment;
	}
	
	
}
