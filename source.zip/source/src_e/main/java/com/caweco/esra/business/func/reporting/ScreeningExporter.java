package com.caweco.esra.business.func.reporting;

import com.caweco.esra.ui.main.helper.TemporaryBinaryElement;

public interface ScreeningExporter
{
	public TemporaryBinaryElement createBinaryElement() throws InterruptedException;
	
	public byte[] createWorkbook() throws InterruptedException;
}
