package com.caweco.esra.ui.component;

import java.io.ByteArrayInputStream;
import java.util.function.Consumer;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.core.FileDAO;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElement;
import com.caweco.esra.ui.sanctions.parts.filehandler.BinaryElementPendingDTO;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.server.StreamResource;

@Tag("esra-filebox-item")
public class FileboxItem extends Div
{
	final BinaryElement           file;
	private Consumer<FileboxItem> onDeleteClick;
	private Anchor                anchor;
	private Button                btn;
	private Button                downloadBtn;
	
	private String clientId;
	private String screeningId;
	
	public FileboxItem(BinaryElement file, String clientId, String screeningId, boolean isReadonly)
	{
		super();
		this.file = file;
		
		this.clientId = clientId;
		this.screeningId = screeningId;
		
		if(file instanceof BinaryElementPendingDTO)
		{
			this.anchor = this.createPendingAnchor();
		}
		else
		{
			this.anchor = this.createRemoteDownloadAnchor();
		}
		
		this.add(this.anchor);
		
		if(!isReadonly)
		{
			this.btn = this.createButton();	
			this.add(this.btn);
		}

		
	}
	
	public FileboxItem onDelete(Consumer<FileboxItem> onDeleteClick)
	{
		this.onDeleteClick = onDeleteClick;
		return this;
	}
	
	
	public BinaryElement getFile()
	{
		return this.file;
	}
	
	protected Anchor createRemoteDownloadAnchor()
	{
		final Anchor download = 
		new Anchor(
			new StreamResource(this.file.getFileName(), () -> FileDAO.allowFileDownload(this.clientId, this.screeningId, file.getId().toString())),
			this.file.getFileName());
		download.getElement().setAttribute("download", true);
		return download;
	}
	
	protected Anchor createPendingAnchor()
	{
		final Anchor download = 
		new Anchor(
	        new StreamResource(this.file.getFileName(), () -> new ByteArrayInputStream(((BinaryElementPendingDTO) this.file).getBinaryData())),
			this.file.getFileName());
		download.getElement().setAttribute("download", true);
		return download;
	}
	
	protected Button createButton()
	{
		Button btn0 = new Button();
		btn0.addThemeVariants(ButtonVariant.LUMO_TERTIARY_INLINE, ButtonVariant.LUMO_ICON);
		btn0.setIcon(VaadinIcon.CLOSE_CIRCLE_O.create());
		btn0.addClickListener(event ->
		{
			if (this.onDeleteClick != null)
			{
				this.onDeleteClick.accept(this);
			}
		});
		UiHelper.setAriaLabel(btn0, Aria.get("FileboxItem_remove"));
		return btn0;
	}
	
}
