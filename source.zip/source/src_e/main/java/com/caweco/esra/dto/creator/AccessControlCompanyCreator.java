package com.caweco.esra.dto.creator;

import java.util.HashSet;

import com.caweco.esra.dto.AccessControlCompanyDTO;
import com.caweco.esra.entities.access.AccessControlCompany;

public class AccessControlCompanyCreator {
	
	public static AccessControlCompanyDTO convertAccessControlToDTO(AccessControlCompany object)
	{
		AccessControlCompanyDTO dto = new AccessControlCompanyDTO();
		
		dto.setAllowedDepartments(object.getAllowedDepartments());
		dto.setCnId(object.getCnId());
		dto.setDisplayName(object.getDisplayName());
		dto.setDistinguishedName(object.getDistinguishedName());
		dto.setRepresentation(object.getRepresentation());
		
		return dto;
	}
	
	public static AccessControlCompany convertDTOToAccessControlCompany(AccessControlCompanyDTO dto)
	{
		AccessControlCompany company = new AccessControlCompany(dto.getDistinguishedName(), dto.getDisplayName());
		if(dto.getAllowedDepartments() != null)
		{
			company.setAllowedDepartments(dto.getAllowedDepartments());
		}
		else
		{
			company.setAllowedDepartments(new HashSet<>());
		}
		
		
		company.setCnId(dto.getCnId());
		return company;
	}
	

}
