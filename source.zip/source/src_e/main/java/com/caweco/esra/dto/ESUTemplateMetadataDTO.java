package com.caweco.esra.dto;

public class ESUTemplateMetadataDTO {

	private int		id = -1;
	private String	name;
	private boolean	active = true;
	private int		version = 1;
	
	
	public ESUTemplateMetadataDTO() {
		super();
	}
	
	public ESUTemplateMetadataDTO(int id, String name, boolean active, int version) {
		super();
		this.id = id;
		this.name = name;
		this.active = active;
		this.version = version;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return active;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + version;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ESUTemplateMetadataDTO other = (ESUTemplateMetadataDTO) obj;
		if (active != other.active)
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (version != other.version)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "ESUTemplateMetadataDTO [id=" + id + ", name=" + name + ", active=" + active + ", version=" + version
				+ "]";
	}
	
}
