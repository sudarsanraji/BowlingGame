package com.caweco.esra.ui.admin.access;

import java.util.Collection;
import java.util.Optional;

import javax.naming.NamingException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.ldap.LdapClientGids;
import com.caweco.esra.business.ldap.LdapUtils;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.access.AccessControlCompanyDAO;
import com.caweco.esra.entities.access.AccessControlCompany;
import com.caweco.esra.entities.ldap.LdapOrg;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.function.SerializableConsumer;


public class DialogNewLdapCompany extends Dialog
{
	public static DialogNewLdapCompany New()
	{
		return new DialogNewLdapCompany();
	}
	
	public static Logger LOG = LoggerFactory.getLogger(DialogNewLdapCompany.class);
	
	LdapClientGids       ldapClient;
	AccessControlCompany item;
	
	private SerializableConsumer<DialogNewLdapCompany> onOk;
	
	public DialogNewLdapCompany()
	{
		super();
		this.initUI();
		
		UiHelper.setAriaLabel(this.btnSearch, Aria.get("PageAccessControl_comp_search"));
		
		this.btnCancel.setText(this.getCancelButtonText());
		this.btnSave.setText(this.getConfirmButtonText());
		this.headline.setText(this.getHeader());
	}
	
	public DialogNewLdapCompany setOnOk(final SerializableConsumer<DialogNewLdapCompany> onOk)
	{
		this.onOk = onOk;
		return this;
	}
	
	
	public LdapOrg getItem()
	{
		return this.item;
	}
	
	
	public void cancel()
	{
		this.close();
	}
	
	
	public void save()
	{
		if (this.item != null)
		{
			AccessControlCompanyDAO.insert(this.item);
			
			if (this.onOk != null)
			{
				this.onOk.accept(this);
			}
			
			this.close();
		}
		else
		{
			Notificator.error("No item available!");
		}
	}
	
	
	public String getHeader()
	{
		return "New Company";
	}
	
	
	public String getConfirmButtonText()
	{
		return "OK";
	}
	
	
	public String getCancelButtonText()
	{
		return "Cancel";
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSearch}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSearch_onClick(ClickEvent<Button> event)
	{
		String value = StringUtils.stripToNull(this.tfValue.getValue());
		if (value != null)
		{
			try
			{
				if (this.ldapClient == null)
				{
					this.ldapClient = LdapUtils.getLdapClient();
				}
				
				Collection<LdapOrg> topLevelOrgs_Filtered = CollectionUtils
					.removeAll(this.ldapClient.getTopLevelOrgs_Filtered(value), AccessControlCompanyDAO
						.findAll(), AccessControlCompanyDAO.getEquator());
				
				this.grid.setItems(topLevelOrgs_Filtered);
				this.grid.setVisible(true);
			}
			catch (NamingException e)
			{
				LOG.error("Cannot connect to LDAP!", e);
				Notificator.error("Cannot connect to LDAP!");
			}
			
		}
		else
		{
			Notificator.error("Search text is empty!");
		}
		
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnCancel}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnCancel_onClick(ClickEvent<Button> event)
	{
		this.cancel();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(ClickEvent<Button> event)
	{
		this.save();
	}
	
	/**
	 * Event handler delegate method for the {@link Grid} {@link #grid}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void grid_selectionChange(SelectionEvent<Grid<LdapOrg>, LdapOrg> event)
	{
		if (event.isFromClient())
		{
			Optional<LdapOrg> firstSelectedItem = event.getFirstSelectedItem();
			
			this.btnSave.setEnabled(firstSelectedItem.isPresent());
			this.item = firstSelectedItem.map(AccessControlCompany::New).orElse(null);
		}
	}
	
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.dialogMain = new FlexLayout();
		this.headline = new H1();
		this.hr = new Hr();
		this.horizontalLayout = new HorizontalLayout();
		this.tfValue = new TextField();
		this.btnSearch = new Button();
		this.divError = new Div();
		this.grid = new Grid<>(LdapOrg.class, false);
		this.objActions = new FlexLayout();
		this.btnCancel = new Button();
		this.btnSave = new Button();
		
		this.setMaxHeight("80vh");
		this.dialogMain.setClassName("esra-dialog-main1");
		this.dialogMain.setMinWidth("400px");
		this.headline.setClassName("esra-hx-custom2");
		this.headline.setText("H5");
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.btnSearch.setIcon(VaadinIcon.SEARCH.create());
		this.divError.setVisible(false);
		this.divError.getStyle().set("font-size", "var(--lumo-font-size-s)");
		this.divError.getStyle().set("color", "var(--lumo-error-text-color)");
		this.grid.setVisible(false);
		this.grid.addColumn(LdapOrg::getDisplayName).setKey("displayName").setHeader("Name").setSortable(true);
		this.grid.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.objActions.setClassName("withGridGap");
		this.btnCancel.setText("Cancel");
		this.btnCancel.getStyle().set("flex", "1 1 0");
		this.btnSave.setEnabled(false);
		this.btnSave.setText("Save");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSave.getStyle().set("flex", "1 1 0");
		
		this.tfValue.setSizeUndefined();
		this.btnSearch.setSizeUndefined();
		this.horizontalLayout.add(this.tfValue, this.btnSearch);
		this.horizontalLayout.setFlexGrow(1.0, this.tfValue);
		this.btnCancel.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.objActions.add(this.btnCancel, this.btnSave);
		this.objActions.setFlexGrow(1.0, this.btnCancel);
		this.objActions.setFlexGrow(1.0, this.btnSave);
		this.headline.setSizeUndefined();
		this.hr.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.divError.setSizeUndefined();
		this.grid.setWidthFull();
		this.grid.setHeight("300px");
		this.objActions.setWidthFull();
		this.objActions.setHeight(null);
		this.dialogMain.add(this.headline, this.hr, this.horizontalLayout, this.divError, this.grid, this.objActions);
		this.dialogMain.setAlignSelf(FlexComponent.Alignment.CENTER, this.headline);
		this.dialogMain.setFlexGrow(1.0, this.horizontalLayout);
		this.dialogMain.setFlexGrow(1.0, this.grid);
		this.dialogMain.setSizeUndefined();
		this.add(this.dialogMain);
		this.setSizeUndefined();
		
		this.btnSearch.addClickListener(this::btnSearch_onClick);
		this.grid.addSelectionListener(this::grid_selectionChange);
		this.btnCancel.addClickListener(this::btnCancel_onClick);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button           btnSearch, btnCancel, btnSave;
	private FlexLayout       dialogMain, objActions;
	private H1               headline;
	private HorizontalLayout horizontalLayout;
	private Div              divError;
	private Hr               hr;
	private TextField        tfValue;
	private Grid<LdapOrg>    grid;
	// </generated-code>
	
}
