package com.caweco.esra.dao;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class ScreeningKeyDAO {
	
	public static void updateScreeningKey(Client client, ComplianceScreeningKeyData key) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/screeningKey/" + key.getKey());
		
		Response response =webTarget.request().put(Entity.entity(key, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the screening key "  + key.getDescription() + " to the client : " +  client.getClientDescription());
	}
	
	public static void createScreeningKey(Client client, ComplianceScreeningKeyData key) {
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid().toString() + "/screeningKey/");
		
		Response response = webTarget.request().post(Entity.entity(key, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" inserted the screening key "  + key.getDescription() + " to the client : " +  client.getClientDescription());
	}
}
