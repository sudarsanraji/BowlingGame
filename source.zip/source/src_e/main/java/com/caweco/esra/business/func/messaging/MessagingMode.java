package com.caweco.esra.business.func.messaging;

public enum MessagingMode {
	PRIVATE, GROUP, PUBLIC, UNSET;
}
