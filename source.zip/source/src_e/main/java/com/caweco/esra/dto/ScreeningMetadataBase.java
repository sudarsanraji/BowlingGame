
package com.caweco.esra.dto;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.ScreeningStatus;


public class ScreeningMetadataBase
{
	
	private String                   screeningID;
	private LocalDate                screeningDate;
	private LocalDate		         screeningEsuDate;
	private LocalDate		         screeningPublishDate;
	
	private String                   screeningOwner;
	private String                   screeningServiceUser;
	
	private String                   name;
	private LineOfBusiness           lineOfBusiness;
	private OE                       oe;
	private Function                 function;
	
	private ScreeningStatus          status;
	
	private Set<String>              esuTags      = new HashSet<>();
	private Set<String>              esuCountries = new HashSet<>();
	private Set<String>              prcCountries = new HashSet<>();
	
	private Map<String, Set<String>> matches;
	
	public String getScreeningID()
	{
		return this.screeningID;
	}
	
	public void setScreeningID(final String screeningID)
	{
		this.screeningID = screeningID;
	}
	
	public LocalDate getScreeningDate()
	{
		return this.screeningDate;
	}
	
	public void setScreeningDate(final LocalDate screeningDate)
	{
		this.screeningDate = screeningDate;
	}
	
	public String getScreeningOwner()
	{
		return this.screeningOwner;
	}
	
	public void setScreeningOwner(final String screeningOwner)
	{
		this.screeningOwner = screeningOwner;
	}
	
	public String getScreeningServiceUser()
	{
		return this.screeningServiceUser;
	}
	
	public void setScreeningServiceUser(final String screeningServiceUser)
	{
		this.screeningServiceUser = screeningServiceUser;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setName(final String name)
	{
		this.name = name;
	}
	
	public LineOfBusiness getLineOfBusiness()
	{
		return this.lineOfBusiness;
	}
	
	public void setLineOfBusiness(final LineOfBusiness lineOfBusiness)
	{
		this.lineOfBusiness = lineOfBusiness;
	}
	
	public OE getOe()
	{
		return this.oe;
	}
	
	public void setOe(final OE oe)
	{
		this.oe = oe;
	}
	
	public Function getFunction()
	{
		return this.function;
	}
	
	public void setFunction(final Function function)
	{
		this.function = function;
	}
	
	public ScreeningStatus getStatus()
	{
		return this.status;
	}
	
	public void setStatus(final ScreeningStatus status)
	{
		this.status = status;
	}
	
	public Set<String> getEsuTags()
	{
		return this.esuTags;
	}
	
	public void setEsuTags(final Set<String> esuTags)
	{
		this.esuTags = esuTags;
	}
	
	/*
	 * Returns the list of referral reasons. Please keep in mind that these were previously called ESU Countries.
	 */
	public Set<String> getEsuCountries()
	{
		return this.esuCountries;
	}
	
	public void setEsuCountries(final Set<String> esuCountries)
	{
		this.esuCountries = esuCountries;
	}
	
	public Map<String, Set<String>> getMatches()
	{
		return this.matches;
	}
	
	public void setMatches(final Map<String, Set<String>> matches)
	{
		this.matches = matches;
	}
	
	public Set<String> getPrcCountries()
	{
		return this.prcCountries;
	}
	
	public void setPrcCountries(final Set<String> prcCountries)
	{
		this.prcCountries = prcCountries;
	}

	public LocalDate getScreeningEsuDate() {
		return screeningEsuDate;
	}

	public void setScreeningEsuDate(LocalDate screeningEsuDate) {
		this.screeningEsuDate = screeningEsuDate;
	}
	
	public LocalDate getScreeningPublishDate() {
		return screeningPublishDate;
	}

	public void setScreeningPublishDate(LocalDate screeningPublishDate) {
		this.screeningPublishDate = screeningPublishDate;
	}
}
