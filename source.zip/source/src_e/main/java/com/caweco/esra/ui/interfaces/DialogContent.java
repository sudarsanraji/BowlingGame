
package com.caweco.esra.ui.interfaces;

import com.vaadin.flow.component.HasElement;


public interface DialogContent extends HasElement
{
	public void cancel();
	
	public void save();
	
	public String getHeader();
	
	public String getConfirmButtonText();
	
	public String getCancelButtonText();
}
