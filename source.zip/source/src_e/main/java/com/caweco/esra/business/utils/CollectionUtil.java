
package com.caweco.esra.business.utils;

import java.util.Enumeration;
import java.util.List;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;


public class CollectionUtil
{
	
	/**
	 * Converts a {@link Enumeration} to a {@link Stream} using a {@link Spliterator} implementation.
	 * 
	 * @param <T>
	 * @param enumeration
	 * @return a new sequential Stream
	 */
	public static <T> Stream<T> stream(Enumeration<T> enumeration)
	{
		// See https://stackoverflow.com/questions/33242577/how-do-i-turn-a-java-enumeration-into-a-stream
		
		return StreamSupport.stream(new Spliterators.AbstractSpliterator<T>(Long.MAX_VALUE, Spliterator.ORDERED)
		{
			@Override
			public boolean tryAdvance(Consumer<? super T> action)
			{
				if (enumeration.hasMoreElements())
				{
					action.accept(enumeration.nextElement());
					return true;
				}
				return false;
			}
			
			@Override
			public void forEachRemaining(Consumer<? super T> action)
			{
				while (enumeration.hasMoreElements())
					action.accept(enumeration.nextElement());
			}
		}, false);
	}
	
	/**
	 * Gets last n elements of the given List.
	 * <p>
	 * Attention: Uses {@link List#subList(int, int)} with all that this implies.
	 * </p>
	 * 
	 * @param in
	 *            the input List
	 * @param n
	 *            the number of elements
	 * @return a view of the List with last n elements
	 */
	public static <T> List<T> getLastNElements(final List<T> in, final int n)
	{
		List<T> tail = in.subList(Math.max(in.size() - n, 0), in.size());
		return tail;
	}
	
}
