package com.caweco.esra.dto;

import java.util.UUID;

import com.caweco.esra.entities.config.EsraClientConfiguration;

public class ClientMetadataDTO {
	
	private UUID uuid;
	private String clientDescription;
	
	private EsraClientConfiguration clientConfiguration;

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getClientDescription() {
		return clientDescription;
	}

	public void setClientDescription(String clientDescription) {
		this.clientDescription = clientDescription;
	}

	public EsraClientConfiguration getClientConfiguration() {
		return clientConfiguration;
	}

	public void setClientConfiguration(EsraClientConfiguration clientConfiguration) {
		this.clientConfiguration = clientConfiguration;
	}
	
	

}
