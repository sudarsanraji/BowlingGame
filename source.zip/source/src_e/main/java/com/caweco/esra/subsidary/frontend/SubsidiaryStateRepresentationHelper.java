
package com.caweco.esra.subsidary.frontend;

import com.caweco.esra.subsidary.common.SubNodeState;
import com.caweco.esra.subsidary.common.SubsidiaryScreeningTaskState;


public class SubsidiaryStateRepresentationHelper
{
	public static String getRepresentation(SubsidiaryScreeningTaskState state)
	{
		if(state == null)
			return "";
		
		switch(state)
		{
			case CREATED_WAITING:
				return "Waiting - Not yet started.";
			case RUNNING:
				return "Running";
			case DONE_ERROR:
				return "Error";
			case DONE_OK:
				return "OK - Waiting for user.";
			case DONE_SKIPPED:
				return "Cancelled";
			case APPLIED:
				return "OK - Results applied to screening.";
			case APPLIED_REPLACED:
				return "Subsidiary Screening replaced by new one.";
			default:
				return "Unknown state";
		}
	}
	
	public static String getNodeRepresentation(SubNodeState state)
	{
		if(state == null)
			return "";
		
		switch(state)
		{
			case CREATED_WAITING:
				return "Waiting..";
			case IN_PROGRESS:
				return "In progress";
			case FETCHED:
				return "Data fetched";
			case PROCESSING_DONE:
				return "OK";
			case DATA_ERROR:
				return "ERROR: Data failure.";
			case SKIPPED:
				return "STOP: Skipped";
			case STOP_THRESHOLD:
				return "STOP: Share below threshold";
			case STOP_MAXLEVEL:
				return "STOP: Exceed max child level threshold";
			case STOP_MAXSUBSIDIARIES:
				return "STOP: Exceed max subsidiary threshold";
			case STOP_UNKNOWN_SHARE:
				return "STOP: Unknown state";
			
			default:
				return "Unknown state";
		}
	}
}
