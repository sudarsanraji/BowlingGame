
package com.caweco.esra.business.func.reporting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import org.tinylog.Logger;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.ScreeningMetadataBase;
import com.caweco.esra.ui.admin.PageDataReporting;
import com.caweco.esra.ui.main.helper.TemporaryBinaryElement;
import com.vaadin.flow.component.UI;


public class ReportBuilderThread extends Thread
{
	
//	public static ReportBuilderThread New2(final UI ui, final PageDataReporting view, Collection<Screening> screenings, boolean isFullExport)
//	{
//		CSVScreeningExporter2 exporter = new CSVScreeningExporter2(screenings != null ? new ArrayList<>(screenings) : Collections.emptyList(), isFullExport);
//		return new ReportBuilderThread(ui, view, exporter);
//	}
	
	public static ReportBuilderThread New3(final UI ui, final PageDataReporting view, Collection<ScreeningMetadataBase> screenings, boolean isFullExport)
	{
		CSVScreeningExporter exporter = new CSVScreeningExporter(CurrentUtil.getClient(), screenings != null ? new ArrayList<>(screenings) : Collections.emptyList(), isFullExport);
		return new ReportBuilderThread(ui, view, exporter);
	}
	
	
	private final UI                ui;
	private final PageDataReporting view;
	private final ScreeningExporter  exporter;
	
	public ReportBuilderThread(final UI ui, final PageDataReporting view, ScreeningExporter exporter)
	{
		this.ui    = ui;
		this.view  = view;
		this.exporter = exporter;
	}
	
	@Override
	public void run()
	{
		
		Logger.info("Start Building Report");
		
		try
		{			
			// Export

			TemporaryBinaryElement temporaryBinaryElement = exporter.createBinaryElement();
			
			// UI Update
			if(!Thread.currentThread().isInterrupted())
			{
				this.ui.access(() -> {
					this.view.updateReportFile(temporaryBinaryElement, null);
				});
			}
			else
			{
				Logger.info("Skipped building report: Thread interrupted.");
			}
		}
		catch(final InterruptedException e)
		{
			Logger.info("Skipped building report: Thread interrupted.", e);
		}
		catch(final Exception e)
		{
			this.ui.access(() -> {
				this.view.updateReportFile(null, e);
			});
		}
		
	}
}
