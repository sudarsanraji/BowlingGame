package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.ScreeningFilterDTO;
import com.caweco.esra.entities.esu.ScreeningFilter;

public class ScreeningFilterCreator {

	public static ScreeningFilterDTO convertScreeningFilterToDTO(ScreeningFilter object) {
		
		ScreeningFilterDTO dto = new ScreeningFilterDTO();
		dto.setByFunction(object.filterByFunction());
		dto.setByLOB(object.filterByLOB());
		dto.setByOE(object.filterByOE());
		dto.setByStatus(object.filterByStatus());
		dto.setFunctionItems(object.getFunctionItems());
		dto.setLobItems(object.getLobItems());
		dto.setOeItems(object.getOeItems());
		dto.setStatusItems(object.getStatusItems());
		
		return dto;
	}

}
