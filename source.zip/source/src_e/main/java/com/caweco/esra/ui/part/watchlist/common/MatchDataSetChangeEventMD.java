package com.caweco.esra.ui.part.watchlist.common;

import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEvent;


public class MatchDataSetChangeEventMD
	extends ComponentEvent<Component>
{
	private static final long	serialVersionUID	= 1L;
	GsssMatch					item;
	MatchData					matchData;
	boolean						isNew				= false;
	
	public MatchDataSetChangeEventMD(
		Component source,
		GsssMatch item,
		boolean fromClient,
		MatchData matchData,
		boolean isNew)
	{
		super(source, fromClient);
		this.item = item;
		this.isNew = isNew;
		this.matchData = matchData;
	}
	
	public GsssMatch getItem()
	{
		return this.item;
	}
	
	public boolean isNew()
	{
		return this.isNew;
	}
	
	public MatchData getMatchData()
	{
		return this.matchData;
	}
}
