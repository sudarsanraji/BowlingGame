package com.caweco.esra.business.func.data;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.caweco.esra.business.utils.QuestionnaireUtils;
import com.caweco.esra.dao.questionnaire.QuestionResultDAO;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.MultiOptionAnswer;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionResult;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;
import com.caweco.esra.entities.questionnaire.SingleOptionAnswer;

public class QuestionnaireEvaluationUtil
{
	
	/**
	 * 
	 * @param result the collected Questionnaire Answer scores of a Screening for a Questionnaire
	 * @return
	 */
	public static int getResultScore(final QuestionnaireResult result)
	{
		final List<QuestionResult> resultsForCurrentQuestionnaireQuestions = QuestionResultDAO.getQuestionResultsForCurrentQuestionnaireQuestions(result);
		return getResultScore(resultsForCurrentQuestionnaireQuestions);
	}
	
	public static int getResultScore_forCategory(final QuestionCategory cat, final QuestionnaireResult result)
	{
		final List<Question> questionsOfCategory = QuestionnaireUtils.getQuestions_groupedByCategory(result).get(cat);
		if (questionsOfCategory == null)
		{
			return 0;
		}
		else
		{
			final Set<QuestionResult> resultsFor_questionsOfCategory = result.getResults().stream()
				.filter(qr -> questionsOfCategory.contains(qr.getQuestion())).collect(Collectors.toSet());
			return getResultScore(resultsFor_questionsOfCategory);
		}
		
	}
	
	/**
	 * Sums up the scores of {@link SingleOptionAnswer}s and {@link MultiOptionAnswer}s.
	 * <br /><b>Does not care if QuestionResult belongs to the correct Questionnaire!</b>
	 * @param questionResults
	 * @return
	 */
	public static int getResultScore(final Collection<QuestionResult> questionResults)
	{
		final AtomicInteger score = new AtomicInteger(0);
		
		if (questionResults != null)
		{
			questionResults.forEach(res ->
			{
				if (res.getAnswer() != null && res.getAnswer() instanceof SingleOptionAnswer)
				{
					final ChooseableValues value = ((SingleOptionAnswer) res.getAnswer()).getValue();
					if (value != null)
					{
						score.getAndAdd(value.getValue());
					}
				}
				else if (res.getAnswer() != null && res.getAnswer() instanceof MultiOptionAnswer)
				{
					((MultiOptionAnswer) res.getAnswer()).getAnswers().forEach(a ->
					{
						score.getAndAdd(a.getValue());
					});
				}
			});
		}
		
		return score.get();
	}
}
