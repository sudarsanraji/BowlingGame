package com.caweco.esra.ui.beans.mvcb;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.ui.component.MultiValueComboboxTag;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.ComponentUtil;
import com.vaadin.flow.component.ItemLabelGenerator;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.binder.HasItemsAndComponents.ItemComponent;
import com.vaadin.flow.data.provider.DataProvider;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.SortDirection;
import com.vaadin.flow.function.SerializableConsumer;
import com.vaadin.flow.function.SerializableFunction;
import com.vaadin.flow.shared.Registration;

public class MultiValueComboBox_20210201<T> extends VerticalLayout implements HasTags_20210201<T>
{
	/**
	 * Convenience method to create a MultiValueComboBox.<br />
	 * Uses a no-op as "storerForAvailableItems"
	 * @param storerForSelectedItems
	 * @param placeholder
	 * @return
	 */
	public static MultiValueComboBox_20210201<String> New(SerializableConsumer<Collection<String>>storerForSelectedItems, String placeholder) {
		return new MultiValueComboBox_20210201<>(it -> it, storerForSelectedItems,
		(result) -> {}).setPlaceholder(placeholder);
	}
	
	private final static Logger					LOG						=
		LoggerFactory.getLogger(MultiValueComboBox_20210201.class);
	
	private ComboBox<String>					cb						= new ComboBox<>();
	private ItemLabelGenerator<T>				itemToString			= it -> it.toString();
	private SerializableFunction<String, T>		itemBuilder;
	
	private Collection<T>						availableItemsOrig;
	private Collection<T>						itemsOrig				= new HashSet<>();
	private Map<String, T>						availableItems			= new HashMap<>();
	private Set<T>								items					= new HashSet<>();
	
	/**
	 * If set, does not work on extra collections for "availableItems" and "items" but uses same collections as "itemsOrig" and "availableItemsOrig"
	 */
	private boolean								directStore				= false;
	
	/**
	 * Storer for "items"
	 */
	private SerializableConsumer<Collection<T>>	storerItems;
	/**
	 * Storer for "available items"
	 */
	private SerializableConsumer<Collection<T>>	storerAvailableItems;
	
	public MultiValueComboBox_20210201(SerializableFunction<String, T> itemBuilder, SerializableConsumer<Collection<T>>	storerItems, SerializableConsumer<Collection<T>> storerAvailableItems)
	{
		super();
		Objects.requireNonNull(itemBuilder);
		this.itemBuilder = itemBuilder;
		this.storerItems = storerItems;
		this.storerAvailableItems = storerAvailableItems;
		
		this.initUI();
		
		this.cb.setSizeUndefined();
		this.horizontalLayout.add(this.cb);
		this.horizontalLayout.setFlexGrow(1.0, this.cb);
		
		this.cb.addValueChangeListener(event ->
		{
			if(StringUtils.isNotBlank(event.getValue()))
			{
				this.addItem(event.getValue());
				event.getSource().setValue("");
				
				LOG.debug("cb_valueChanged: {}", event.getValue());
			}
		});
		
	}
	
	public void addItem(String item)
	{
		String possibleNewEntry = StringUtils.stripToNull(item);
		
		if(possibleNewEntry != null)
		{
			if(this.availableItems.containsKey(possibleNewEntry))
			{
				T itemObj = this.availableItems.get(possibleNewEntry);
				
				if(!this.items.contains(itemObj))
				{
					this.addItemT(itemObj);
				}
				else
				{
					// No change
				}
			}
			else
			{
				Optional<T> foundInItems = this.items.stream().filter(
					it -> StringUtils.equalsIgnoreCase(this.itemToString.apply(it), possibleNewEntry)).findFirst();
				if(foundInItems.isPresent())
				{
					// Is in "items", but not in "availableItems"
					
					this.availableItems.put(possibleNewEntry, foundInItems.get());
					this.cb.getDataProvider().refreshAll();
				}
				else
				{
					T itemObj = this.createItem(possibleNewEntry);
					
					this.addItemT(itemObj);
				}
			}
		}
		else
		{
			// No handling for null/empty values
		}
	}
	
	/**
	 * Set the selected items of this component.<br />
	 * This items are displayed as "tags" below the ComboBox.
	 * @param items the selected items
	 * @return
	 */
	public MultiValueComboBox_20210201<T> setItems(final Collection<T> items)
	{
		this.flexLayout.removeAll();
		
		this.itemsOrig = items;
		
		this.items = this.itemsOrig != null ? new HashSet<>(this.itemsOrig) : new HashSet<>();
		
		this.items.forEach(item ->
		{
			final MultiValueComboboxTag<T> tagLabel = new MultiValueComboboxTag<T>(item, this.itemToString.apply(item), this);
			this.flexLayout.add(tagLabel);
		});
		
		ComponentUtil.fireEvent(
			this,
			this.createValueChange(false));
		
		return this;
	}
	
	/**
	 * Set the item collection a user can choose a item from.<br />
	 * This items are the selectable/available items of the ComboBox.
	 * @param items the selectable items
	 * @return
	 */
	public MultiValueComboBox_20210201<T> setAvailableItems(final Collection<T> items)
	{
		this.availableItemsOrig = items;
		if(this.availableItemsOrig != null)
		{
			this.availableItems =
				this.availableItemsOrig.stream().collect(Collectors.toMap(it -> this.itemToString.apply(it), it -> it));
		}
		else
		{
			this.availableItems = new HashMap<String, T>();
		}
		
		ListDataProvider<String> dataProvider = DataProvider.ofCollection(this.availableItems.keySet());
		dataProvider.setSortOrder(it -> it, SortDirection.ASCENDING);
		this.cb.setDataProvider(dataProvider);
		
		return this;
	}
	
	public Map<String, T> getAvailableItems()
	{
		return this.availableItems;
	}
	
	/**
	 * Writes items to original item collection and saves "original item collection" using given "storer".<br />
	 * Writes also new "availableItems" to original available item collection and saves this "original collection" using given "storer".<br />
	 */
	public void storePendingChanges()
	{
		if(this.itemsOrig != null)
		{
			if(this.itemsOrig != this.items)
			{
				
				this.itemsOrig.clear();
				this.itemsOrig.addAll(this.items);
			}
			this.storerItems.accept(this.itemsOrig);
		}
		
		if(this.availableItemsOrig != null)
		{
			HashSet<T> newAvItems = new HashSet<>(this.availableItems.values());
			newAvItems.removeAll(this.availableItemsOrig);
			this.availableItemsOrig.addAll(newAvItems);
			this.storerAvailableItems.accept(this.availableItemsOrig);
		}
		
	}
	
	/**
	 * <b>Resets all changes in "selected items" and "available items"!</b>
	 * 
	 * @param directStore
	 */
	public void setDirectStoring(boolean directStore)
	{
		this.directStore = directStore;
		if(directStore)
		{
			this.items = (Set<T>)this.itemsOrig;
			
			this.setAvailableItems(this.availableItemsOrig);
		}
	}
	
	public void setItemBuilder(SerializableFunction<String, T> itemBuilder)
	{
		Objects.requireNonNull(itemBuilder);
		this.itemBuilder = itemBuilder;
	}
	
	public ComboBox<String> getComboBox()
	{
		return this.cb;
	}
	
	public String getTitle()
	{
		return this.label.getText();
	}
	
	public MultiValueComboBox_20210201<T> setTitle(final String title) // NO_UCD - setter
	{
		if(title != null)
		{
			this.label.setText(title);
			this.label.setVisible(true);
		}
		else
		{
			this.label.setText("");
			this.label.setVisible(false);
		}
		return this;
	}
	
	public String getPlaceholder()
	{
		return this.cb.getPlaceholder();
	}
	
	public MultiValueComboBox_20210201<T> setPlaceholder(final String placeholder)
	{
		
		if(placeholder != null)
		{
			this.cb.setPlaceholder(placeholder + " ...");
		}
		else
		{
			this.cb.setPlaceholder(null);
		}
		return this;
	}
	
	public void removeAllItems()
	{
		// Items
		if(this.directStore)
		{
			this.items.clear();
		}
		else
		{
			this.items = new HashSet<T>();
		}
		
		// UI
		this.flexLayout.removeAll();
		
		// Store
		if(this.directStore && this.storerItems != null)
		{
			this.storerItems.accept(this.items);
		}
		
		// Send ValueChangeEvent
		ComponentUtil.fireEvent(
			this,
			this.createValueChange(false));
	}
	
	////
	// Tb be called from Tags
	
	@Override
	public void delete(final ItemComponent<T> tag)
	{
		// Items
		this.items.remove(tag.getItem());
		
		// UI
		
		this.flexLayout.remove((Component) tag);
		
		// Store
		if(this.directStore)
		{
			this.storerItems.accept(this.items);
		}
		
		// Send ValueChangeEvent
		ComponentUtil.fireEvent(
			this,
			this.createValueChange(true));
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.flexLayout = new FlexLayout();
		
		this.setSpacing(false);
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.BASELINE);
		this.label.setText("Label");
		this.label.setVisible(false);
		this.label.setMinWidth("70px");
		this.flexLayout.setClassName("esra-tagbox-container");
		
		this.label.setSizeUndefined();
		this.horizontalLayout.add(this.label);
		this.horizontalLayout.setSizeUndefined();
		this.flexLayout.setSizeUndefined();
		this.add(this.horizontalLayout, this.flexLayout);
		this.setSizeUndefined();
	} // </generated-code>
	
	// <generated-code name="variables">
	private FlexLayout			flexLayout;
	private HorizontalLayout	horizontalLayout;
	private Label				label;
	// </generated-code>
	
	private void addItemT(T item)
	{

		// Items
		this.items.add(item);
		
		// UI
		final MultiValueComboboxTag<T> tagLabel = new MultiValueComboboxTag<T>(item, this.itemToString.apply(item), this);
		this.flexLayout.add(tagLabel);
		
		// Store
		if(this.directStore)
		{
			this.storerItems.accept(this.items);
		}
		
		// Send ValueChangeEvent
		ComponentUtil.fireEvent(
			this,
			this.createValueChange(true));
	}
	
	private T createItem(String in)
	{
		T itemObj = this.itemBuilder.apply(in);
		this.availableItems.put(this.itemToString.apply(itemObj), itemObj);
		this.cb.getDataProvider().refreshAll();
		
		if(this.directStore)
		{
			this.storerAvailableItems.accept(this.availableItemsOrig);
		}
		
		return itemObj;
	}
	
	public void setValue(Set<T> value)
	{
		this.setItems(value);
		
	}
	
	public Set<T> getValue()
	{
		return Collections.unmodifiableSet(this.items);
	}
	
	private ValueSetChangeEvent_20210201 createValueChange(boolean fromClient)
	{
		return new ValueSetChangeEvent_20210201(this, fromClient);
	}
	
	public Registration addChangeListener(
		ComponentEventListener<ValueSetChangeEvent_20210201> listener)
	{
		return this.addListener(ValueSetChangeEvent_20210201.class, listener);
	}

	public SerializableConsumer<Collection<T>> getStorerItems() {
		return storerItems;
	}

	public void setStorerItems(SerializableConsumer<Collection<T>> storerItems) {
		this.storerItems = storerItems;
	}

	public SerializableConsumer<Collection<T>> getStorerAvailableItems() {
		return storerAvailableItems;
	}

	public void setStorerAvailableItems(SerializableConsumer<Collection<T>> storerAvailableItems) {
		this.storerAvailableItems = storerAvailableItems;
	}
	
	
}
