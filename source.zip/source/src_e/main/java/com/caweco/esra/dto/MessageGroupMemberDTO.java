package com.caweco.esra.dto;

public class MessageGroupMemberDTO {

	private UserMetadataDTO dto;
	private boolean isFollowing;
	
	public UserMetadataDTO getDto() {
		return dto;
	}
	public void setDto(UserMetadataDTO dto) {
		this.dto = dto;
	}
	public boolean isFollowing() {
		return isFollowing;
	}
	public void setFollowing(boolean isFollowing) {
		this.isFollowing = isFollowing;
	}
	
	
}
