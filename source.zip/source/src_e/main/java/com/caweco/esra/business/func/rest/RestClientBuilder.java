
package com.caweco.esra.business.func.rest;

import java.security.NoSuchAlgorithmException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.SSLContext;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.entities.config.ConfigRestEndpoint;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;


public class RestClientBuilder
{
	
	private RestClientBuilder()
	{
		// Static helper class
	}
	
	public static final AtomicInteger                      CLIENT_BUILD_COUNT_BIH    = new AtomicInteger(0);
	public static final AtomicInteger                      CLIENT_BUILD_COUNT_DB     = new AtomicInteger(0);
	public static final AtomicInteger                      CLIENT_BUILD_COUNT_SEAWEB = new AtomicInteger(0);
	
	private static Client                                  INSTANCE_BIH;
	private static Client                                  INSTANCE_ESRADB;
	
	public static Client getClientBIH()
	{
		if(INSTANCE_BIH == null)
		{
			INSTANCE_BIH = buildClientBIH();
		}
		return INSTANCE_BIH;
	}
	
	public static Client getClientESRADB()
	{
		if(INSTANCE_ESRADB == null)
		{
			INSTANCE_ESRADB = buildClientESRADB();
		}
		return INSTANCE_ESRADB;
	}
	
	public static Client getClientSeaweb(ConfigRestEndpoint configurationForEsraClient)
	{
		Client c = buildClientSeaweb(configurationForEsraClient);
		return c;
	}
	
	/********************************************************************************/
	/* BIH REST client */
	
	protected static Client buildClientBIH()
	{
		try
		{
			/*final SSLContext sslcontext = SSLContext.getInstance("SSL");
			
			
			 * sslcontext.init( null, new TrustManager[]{ new X509TrustManager() {
			 * 
			 * @Override public void checkClientTrusted(final X509Certificate[] arg0, final
			 * String arg1) throws CertificateException { }
			 * 
			 * @Override public void checkServerTrusted(final X509Certificate[] arg0, final
			 * String arg1) throws CertificateException { }
			 * 
			 * @Override public X509Certificate[] getAcceptedIssuers() { return new
			 * X509Certificate[0]; } }}, new java.security.SecureRandom());
			 */
			
			final ClientConfig clientConfig = new ClientConfig();
			clientConfig
				// Logger
				.register(lf())
				// Jackson
				// No need to register ObjectMapperProvider if no special configuration is required:
				.register(ObjectMapperProvider.class)
				.register(JacksonFeature.class);
			
			final Client client =
				ClientBuilder.newBuilder()
					.withConfig(clientConfig)
					.sslContext(SSLContext.getDefault())
					.hostnameVerifier((s1, s2) -> true)
					.build();
			
			CLIENT_BUILD_COUNT_BIH.incrementAndGet();
			
			return client;
			
		} catch(Exception e) {
			org.tinylog.Logger.error(e, "Cannot build BIH REST client.");
		}
		
		return null;
			
	}
	
	/********************************************************************************/
	/* SEAWEB REST client */
	
	protected static Client buildClientSeaweb(ConfigRestEndpoint configuration)
	{
		final HttpAuthenticationFeature token;
		if(configuration == null)
		{
			configuration = ConfigRestEndpoint.getConfigSEAWEB();
		}
		
		token = HttpAuthenticationFeature.basic(
			configuration.getEndpointUsername(),
			configuration.getEndpointPassword());
		
		final LoggingFeature lf = lf();
		
		CLIENT_BUILD_COUNT_SEAWEB.incrementAndGet();
		
		ClientConfig config = new ClientConfig();
		
		String proxyURL = ApplicationPropertyProvider.getProxyURL();
		
		if(proxyURL != null)
		{
			config.property(ClientProperties.PROXY_URI, ApplicationPropertyProvider.getProxyURL());			
		}
		
		return ClientBuilder.newClient(config)
			.register(token)
			.register(lf)
			.register(JacksonFeature.class);
	}
	
	/********************************************************************************/
	/* ESRADB REST client */
	
	protected static Client buildClientESRADB()
	{
		// Cannot get ConfigRestEndpoint from DB to configure connection to DB...
		// -> Use always default config..
		ConfigRestEndpoint configuration = ConfigRestEndpoint.getConfigESRADB();
		
		final HttpAuthenticationFeature token = HttpAuthenticationFeature.basic(
			configuration.getEndpointUsername(),
			configuration.getEndpointPassword());
		
		final LoggingFeature lf = lf();
		
		CLIENT_BUILD_COUNT_DB.incrementAndGet();
		
		return ClientBuilder.newClient()
			.register(token)
			.register(lf)
			.register(JacksonFeature.class)
			.register(MultiPartFeature.class)
			.register(ObjectMapperProvider2.class);
	}
	
	/********************************************************************************/
	/* INTERNALS */
	
	/**
	 * <b>INTERNAL</b><br />
	 * Important : Jersey uses JDK built-in logging feature : `java.util.logging`
	 * 
	 * @return
	 */
	public static LoggingFeature lf()
	{
		return new LoggingFeature(
			Logger.getLogger(LoggingFeature.DEFAULT_LOGGER_NAME),
			Level.FINEST,
			LoggingFeature.Verbosity.HEADERS_ONLY,
			null);
	}
	
}
