package com.caweco.esra.business.aa;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.User;
import com.onelogin.saml2.Auth;
import com.onelogin.saml2.authn.AuthnRequestParams;
import com.onelogin.saml2.exception.Error;
import com.onelogin.saml2.exception.SettingsException;
import com.onelogin.saml2.settings.Saml2Settings;
import com.rapidclipse.framework.security.authorization.Subject;
import com.rapidclipse.framework.server.navigation.AuthNavigationController;
import com.rapidclipse.framework.server.security.authentication.AccessibleView;
import com.rapidclipse.framework.server.security.authentication.Authentication;
import com.rapidclipse.framework.server.util.ReflectionUtils;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.router.HasErrorParameter;
import com.vaadin.flow.router.NavigationState;
import com.vaadin.flow.router.Router;
import com.vaadin.flow.server.SynchronizedRequestHandler;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;


/**
 * RequestHandler which checks if a user is logged in and starts the SAML authentication process if login is necessary
 * and the user is not already logged in.
 *
 */
public class AuthenticationInitializer extends SynchronizedRequestHandler
{
	
	private static final long   serialVersionUID = 1L;
	private static final Logger LOG              = LoggerFactory.getLogger(AuthenticationInitializer.class);
	
	@Override
	public boolean synchronizedHandleRequest(
		final VaadinSession session,
		final VaadinRequest request,
		final VaadinResponse response)
		throws IOException
	{
		
		/*if(!DB.isRunning()) {
			final HttpServletResponse response1 = (HttpServletResponse)response;
			response1.sendRedirect("loginfailed");
			return true;
		}*/
		
		AuthenticationInitializer.LOG.debug("### Authenticator");
		
		if (AuthenticationInitializer.isUserLoggedIn(session))
		{
			// Is Authenticated -> Is not for me -> continue with other handlers
			// ["false" to proceed other handlers]
			
			AuthenticationInitializer.LOG.debug("# Skip here: Is already logged in.");
			
			return false;
			
		}
		else if (AuthenticationInitializer.isAccessibleTarget(session, request))
		{
			// Not authenticated, but no Authentication necessary: Target is accessible or error page
			// -> Is not for me -> continue with other handlers
			// ["false" to proceed other handlers]
			
			AuthenticationInitializer.LOG.debug("# Skip here: No Login necessary.");
			
			return false;
		}
		else
		{
			AuthenticationInitializer.LOG.info("# Start Logging in...");
			try
			{
				AuthenticationInitializer.authenticate(session);
				return true;
			}
			catch (SettingsException | Error e)
			{
				// Convert to IOException
				throw new IOException(e);
			}
		}
	}
	
	/**
	 * Returns <code>true</code> if a user is registered in the current session, <code>false</code> otherwise.
	 * <p>
	 * Replacement for {@link Authentication#isUserLoggedIn()}, as this checks for a {@link User} instead of a
	 * {@link Subject}
	 * </p>
	 *
	 * @param session a {@link VaadinSession}
	 * @return Returns <code>true</code> if a user is in set in Session
	 */
	public static boolean isUserLoggedIn(final VaadinSession session)
	{
		return session.getAttribute(User.class) != null;
	}
	
	/**
	 * Checks if the Navigation target component is a {@link AccessibleView} or {@link HasErrorParameter}
	 * <p>
	 * Similar to {@link AuthNavigationController#isAuthenticated(Class)}
	 * </p>
	 *
	 * @param session a {@link VaadinSession} for the request
	 * @param request a {@link VaadinRequest} to handle
	 * @return
	 */
	public static boolean isAccessibleTarget(final VaadinSession session, final VaadinRequest request)
	{
		try
		{
			final Optional<Class<? extends Component>> navigationTarget = AuthenticationInitializer
				.findNavigationTarget(session, request);
			if (navigationTarget.isPresent())
			{
				return ReflectionUtils.isAnnotationPresent(navigationTarget.get(), AccessibleView.class)
					|| HasErrorParameter.class.isAssignableFrom(navigationTarget.get());
			}
			else
			{
				return false;
			}
			
		}
		catch (final Exception e)
		{
			AuthenticationInitializer.LOG.debug("Could not obtain accessible info.", e);
			return false;
		}
	}
	
	/**
	 * Obtain Navigation target component for path and parameter map of current request.
	 *
	 * @param session obtain the Router
	 * @param session The {@link VaadinSession} to obtain the Router.
	 * @param request The current {@link VaadinRequest} to obtain pathInfo and parameter map.
	 * @return a component class
	 */
	public static Optional<Class<? extends Component>> findNavigationTarget(
		final VaadinSession session,
		final VaadinRequest request)
	{
		try
		{
			final Router router = session.getService().getRouter();
			return router.resolveNavigationTarget(request.getPathInfo(), request.getParameterMap())
				.map(NavigationState::getNavigationTarget);
		}
		catch (final Exception e)
		{
			AuthenticationInitializer.LOG.debug("Could not obtain navigation target.", e);
			return Optional.empty();
		}
	}
	
	/**
	 * Builds a SAML auth Request object and <b>redirects</b> to SAML endpoint.
	 * <p>
	 * Stores SAML Request id to the session.
	 * </p>
	 * 
	 * @param session
	 * @throws IOException
	 * @throws SettingsException
	 * @throws Error
	 */
	public static void authenticate(
		final VaadinSession session
		) throws IOException, SettingsException, Error
	{
		final HttpServletRequest  request  = (HttpServletRequest) VaadinService.getCurrentRequest();
		final HttpServletResponse response = (HttpServletResponse) VaadinService.getCurrentResponse();
		AuthenticationInitializer.authenticate(session, request, response);
	}
	
	/**
	 * Builds a SAML auth Request object and <b>redirects</b> to SAML endpoint.
	 * <p>
	 * Stores SAML Request id to the session.
	 * </p>
	 *
	 * @param session
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws SettingsException
	 * @throws Error
	 */
	public static void authenticate(
		final VaadinSession session,
		final HttpServletRequest request,
		final HttpServletResponse response) throws IOException, SettingsException, Error
	{
		String pathInfo = request.getPathInfo();
		String requestURI = request.getRequestURI();
		
		if (pathInfo != null && pathInfo.length() > 1)
		{
			CurrentUtil.toSession(session, "lastRequestURI", requestURI);
		}
		

		final Saml2Settings saml2Settings     = ApplicationPropertyProvider.getSaml2Settings(null);
		
		final Auth          auth              = new Auth(saml2Settings, request, response);
		
		final String        target            = auth.login(pathInfo, new AuthnRequestParams(false, false, true), true, null);
		final String        lastSamlRequestId = auth.getLastRequestId();
		CurrentUtil.toSession(session, "lastSamlRequestId", lastSamlRequestId);
		
		AuthenticationInitializer.LOG.trace("SAML request: " + target);
		AuthenticationInitializer.LOG.trace("SAML request id: " + lastSamlRequestId);
		
		response.sendRedirect(target);
	}
	
	
}
