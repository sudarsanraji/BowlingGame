package com.caweco.esra.business.utils;

import java.util.Optional;

import org.tinylog.Logger;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.ui.dialogs.DialogBigMessage;
import com.caweco.esra.ui.sanctions.RefreshDataPage;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.notification.Notification.Position;

public class ScreeningUtil {
	
	public static void refreshData(final Screening screening, final RefreshDataPage page, final Client client, final String mail) {
		final RefreshThread thread = new RefreshThread(screening, Optional.of(page), client, mail, Optional.of(UI.getCurrent()));
		thread.start();
	}
	
	public static void refreshData(final Screening screening, final Client client, final String mail) {
		final RefreshThread thread = new RefreshThread(screening, Optional.empty(), client, mail, Optional.empty());
		thread.start();
	}
	
	
	public static void copyScreening(final Screening screening) {
		if (screening != null) {

			if (!screening.existsInBackend()) {
				Notificator.warn("Cannot copy a Screening that wasn't saved yet", 10000);
				return;
			}
			if (CurrentUtil.getUser() != null) {
				final Screening copiedScreening = Screening.New(screening.getClientId(), CurrentUtil.getUser());
				if (null != copiedScreening) {
					copiedScreening.setName("Copy of " + screening.getName());
					copiedScreening.setWatchlistCompanyEntries(screening.getWatchlistCompanyEntries(false));
					copiedScreening.setWatchlistSearchEntriesGsss(screening.getWatchlistSearchEntriesGsss(false));
					copiedScreening.setVesselsSeaWeb(screening.getVesselsSeaWeb(false));
					copiedScreening.setOe(screening.getOe());
					copiedScreening.setFunction(screening.getFunction());
					copiedScreening.setLineOfBusiness(screening.getLineOfBusiness());
					copiedScreening.setLastChanged(screening.getLastChanged());
					copiedScreening.setLastChangedBy(screening.getLastChangedBy());
					copiedScreening.setMonitoring(screening.getMonitoring());

					if (screening.getTradeSanctionResult(false).getQuestionnaire() == null) {
						System.out.println("Screening has no trade sanction result.");
					} else if (!screening.getTradeSanctionResult(false).getQuestionnaire().isActive()) {
						Notificator.warn(
								"Screening was copied without attached Trade Sanctions Questionnaire, as the selected questionnaire is no longer active.",
								20000, Position.MIDDLE);
					} else {
						copiedScreening.setTradeSanctionResult(screening.getTradeSanctionResult(false));
					}

					ScreeningDAO.saveScreening(copiedScreening, false);

					final String mail = CurrentUtil.getUser().getEmailAddress();
					final Client client = CurrentUtil.getClient();

					ScreeningUtil.refreshData(copiedScreening, client, mail);

					Logger.info(new StringBuilder().append("--------------------------------\n")
							.append("Copied screening. ").append("Client: ")
							.append(client == null ? "UNSET" : client.getUuid()).append(" / Screening: ")
							.append(screening.getScreeningID()).append(" / New Screening: ")
							.append(copiedScreening.getScreeningID()).toString());

					UI.getCurrent().getPage().executeJs("updateClipboardNoElement($0);",
							copiedScreening.getScreeningID().toString());
					DialogBigMessage.New().withTopic("Screening has been copied")
							.withContent("A copy of the new case has been created and the new ID ("
									+ copiedScreening.getScreeningID()
									+ ") has been stored in your clipboard.\nYou can find the new case in the menu by pasting (Ctrl+V) the ID in the search field.\nPlease note: The Business Information has not been copied.")
							.withColor("red").go();
				}

			}

		}
	}
	
}
