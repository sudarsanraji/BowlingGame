package com.caweco.esra.entities.rest.namematch;

import java.io.Serializable;


public class Hint implements Serializable
{
	private String value;
	
	public String getValue()
	{
		return value;
	}
	
	public void setValue(String value)
	{
		this.value = value;
	}
	
}
