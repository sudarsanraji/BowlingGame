
package com.caweco.esra.business.func.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import jakarta.ws.rs.ext.ContextResolver;


public class ObjectMapperProvider2 implements ContextResolver<ObjectMapper>
{
	// https://eclipse-ee4j.github.io/jersey.github.io/documentation/latest/user-guide.html#json.jackson
	
	final ObjectMapper defaultObjectMapper;
	
	public ObjectMapperProvider2()
	{
		this.defaultObjectMapper = createDefaultMapper();
	}
	
	@Override
	public ObjectMapper getContext(final Class<?> type)
	{
		return this.defaultObjectMapper;
	}
	
	private static ObjectMapper createDefaultMapper()
	{
		final ObjectMapper result = new ObjectMapper()
			.findAndRegisterModules()
			.registerModule(new JavaTimeModule());
		return result;
	}
}
