package com.caweco.esra.entities.rest.namematch;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.caweco.esra.entities.rest.general.GsssMatch;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * Response class for CARA There are three different response forms from the rest service. a) bvdMatch response b)
 * gsssMatch response c) no match response
 * 
 * @author JA
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class NMResponse implements Serializable
{
	private String			sessionHandle;
	private String[]		statusMessage;
	private String			nameToSearch;
	
	private long			numberOfGSSSHits;
	private List<BvdMatch>	bvdMatchResults		= new ArrayList<>();
	private List<GsssMatch>	gsssMatchResults	= new ArrayList<>();
	
	private String			customField1;
	private String			customField2;
	private String			customField3;
	private String			customField4;
	private String			customField5;
	
	public NMResponse()
	{
		// empty Constructor for Framework
	}
	
	public String getSessionHandle()
	{
		return this.sessionHandle;
	}
	
	public void setSessionHandle(final String sessionHandle)
	{
		this.sessionHandle = sessionHandle;
	}
	
	public String[] getStatusMessage()
	{
		return this.statusMessage;
	}
	
	public void setStatusMessage(final String[] statusMessage)
	{
		this.statusMessage = statusMessage;
	}
	
	public String getNameToSearch()
	{
		return this.nameToSearch;
	}
	
	public void setNameToSearch(final String nameToSearch)
	{
		this.nameToSearch = nameToSearch;
	}
	
	public long getNumberOfGSSSHits()
	{
		return this.numberOfGSSSHits;
	}
	
	public void setNumberOfGSSSHits(final long numberOfGSSSHits)
	{
		this.numberOfGSSSHits = numberOfGSSSHits;
	}
	
	public List<BvdMatch> getBvdMatchResults()
	{
		return this.bvdMatchResults;
	}
	
	public void setBvdMatchResults(final List<BvdMatch> bvdMatchResults)
	{
		this.bvdMatchResults = bvdMatchResults;
	}
	
	public List<GsssMatch> getGsssMatchResults()
	{
		 if (this.gsssMatchResults == null) {
		        this.gsssMatchResults = new ArrayList<>();
		    }
		 return new ArrayList<>(this.gsssMatchResults);
	}
	
	public void setGsssMatchResults(final List<GsssMatch> gsssMatchResults)
	{
		this.gsssMatchResults = gsssMatchResults;
	}
	
	public String getCustomField1()
	{
		return this.customField1;
	}
	
	public void setCustomField1(final String customField1)
	{
		this.customField1 = customField1;
	}
	
	public String getCustomField2()
	{
		return this.customField2;
	}
	
	public void setCustomField2(final String customField2)
	{
		this.customField2 = customField2;
	}
	
	public String getCustomField3()
	{
		return this.customField3;
	}
	
	public void setCustomField3(final String customField3)
	{
		this.customField3 = customField3;
	}
	
	public String getCustomField4()
	{
		return this.customField4;
	}
	
	public void setCustomField4(final String customField4)
	{
		this.customField4 = customField4;
	}
	
	public String getCustomField5()
	{
		return this.customField5;
	}
	
	public void setCustomField5(final String customField5)
	{
		this.customField5 = customField5;
	}
}
