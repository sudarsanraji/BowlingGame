package com.caweco.esra.business.properties;

public class RestSettingsProvider
{
	////////
	//// SETTING VALUES - CANNOT BE OVERRIDDEN
	
	/**
	 * SEARCHDEFINITION aka "customField1" in BIH requests
	 */
	public static final String DEFAULT_SEARCHDEFINITION_VALUE = "AGCS_SNS";
	
	/**
	 * BUSINESSUNIT aka "customField2" in BIH requests
	 */
	public static final String DEFAULT_BUSINESSUNIT_VALUE     = "GROUP LEGAL & COMPLIANCE";
	
	/**
	 * SEARCHTYPE aka "searchType" in BIH requests
	 */
	public static final String DEFAULT_SEARCHTYPE_VALUE       = "CARA_DEFAULT";
	
	////////
	//// INITIAL SETTING VALUES - WILL BE OVERRIDDEN
	
	//// BIH
	
	/**
	 * The default BIH REST endpoint url if not otherwise defined.
	 */
	public static final String DEFAULT_REST_URL_BIH           = "https://sla19460.srv.allianz:25002/agcs/bih/api/service/cara/rest/CompanyService";
	
	/**
	 * The default BIH REST username if not otherwise defined.
	 */
	public static final String DEFAULT_REST_USERNAME_BIH      = "CARA-ESRA-00001";
	
	/**
	 * The default BIH REST pwd if not otherwise defined.
	 */
	public static final String DEFAULT_REST_PASSWORD_BIH      = "CARAEsra$123";
	
	/**
	 * The default BIH REST systemname if not otherwise defined.
	 */
	public static final String DEFAULT_REST_SYSNAME_BIH       = "ESRA";
	
	//// SEAWEB
	
	public static final String DEFAULT_REST_HOST_SEAWEB       = "maritimewebservices.ihs.com";
	
	/**
	 * The default SEAWEB REST endpoint url if not otherwise defined.
	 */
	public static final String DEFAULT_REST_URL_SEAWEB        = "https://" + DEFAULT_REST_HOST_SEAWEB
		+ "/MaritimeWCF/APSShipService.svc/RESTful/";
	
	/**
	 * The default CARA REST username if not otherwise defined.
	 */
	public static final String DEFAULT_REST_USERNAME_SEAWEB   = "allkha545";
	
	/**
	 * The default CARA REST pwd url if not otherwise defined.
	 */
	public static final String DEFAULT_REST_PASSWORD_SEAWEB   = "759195";
	
	
	// ---- ESRA DB ----
	
	public static final String DEFAULT_REST_HOST_ESRADB       = ApplicationPropertyProvider.getESRADBBaseURL();
	
	/**
	 * The default ESRADB REST endpoint url if not otherwise defined.
	 */
	public static final String DEFAULT_REST_URL_ESRADB        = DEFAULT_REST_HOST_ESRADB
		+ "/";
	
	/**
	 * The default ESRADB REST username if not otherwise defined.
	 */
	public static final String DEFAULT_REST_USERNAME_ESRADB   = "iGJHahzkB2NHf4XdapxrJ3EmJurb9LTi2Jwp9LU4wEPzDjsuDkpHr6cbmmYdFBfR";
	
	/**
	 * The default ESRADB REST pwd url if not otherwise defined.
	 */
	public static final String DEFAULT_REST_PASSWORD_ESRADB   = "YZr4rw3o9MmCcrwzrs3tWMVZYHXxgfZiUymt4C3KepuKhacEtzTEo8vyZxaxiR6D";
	
}
