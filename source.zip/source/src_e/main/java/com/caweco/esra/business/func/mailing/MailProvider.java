package com.caweco.esra.business.func.mailing;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Optional;
import java.util.OptionalInt;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.SimpleEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.entities.config.ConfigMailServer;


/**
 * Provides a method to create and preconfigure Email objects.
 * Other methods create Email objects and send them to the Server
 *
 */
public class MailProvider
{
	private static final Logger LOG = LoggerFactory.getLogger(MailProvider.class);
	
	/**
	 * Prepare a {@link Email} object according to the provided parameter.
	 *
	 * @param asHtml
	 *            a flag to choose between SimpleEmail and HtmlEmail
	 * @param subject
	 *            the email subject
	 * @param text
	 *            the email body
	 * @param emailSettings
	 *            a MailServerSettings object for configuration
	 * @param sender
	 *            the sender email address
	 * @return a configured Email object without recipients
	 * @throws EmailException
	 */
	public Email prepareMail(
		final boolean asHtml,
		final String subject,
		final String text,
		final ConfigMailServer emailSettings,
		final String sender) throws EmailException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
		/*
		 * Check necessary data [With custom Exception messages]
		 */
		if(emailSettings == null)
		{
			throw new EmailException("No Email settings available!");
		}
		if(emailSettings.getSmtpServerURL() == null)
		{
			throw new EmailException("Necessary SMTP settings is not set. (Email Server)");
		}
		if(emailSettings.getSmtpServerURL().isEmpty())
		{
			throw new EmailException("Necessary SMTP settings is empty. (Email Server)");
		}
		
		if(sender == null || sender.isEmpty())
		{
			throw new EmailException("Necessary info is not available. (Sender emailaddress)");
		}
		
		final Email email = this.getEmail(asHtml);
		
		/*
		 * (1) DATA & COMMON Settings
		 */
		
		// configure SMTP connection
		email.setHostName(emailSettings.getSmtpServerURL());
		
		// configure charset
		email.setCharset(StandardCharsets.UTF_8.name());
		
		// set data
		email.setFrom(sender);
		email.setSubject(subject);
		// set message for text emails
		email.setMsg(text);
		
		// set html AND text message for html emails
		if(asHtml && email instanceof HtmlEmail)
		{
			((HtmlEmail)email).setHtmlMsg(text);
		}
		
		/*
		 * (2) AUTH Settings
		 */
		
		final String usernameTrimmed = StringUtils.trimToNull(emailSettings.getSmtpUsername());
		final String pw = StringUtils.isBlank(emailSettings.getSmtpPassword()) ? null : emailSettings.getSmtpPassword();
		
		if(usernameTrimmed != null && pw != null)
		{
			email.setAuthentication(usernameTrimmed, pw);
		}
		else
		{
			// without Auth
			LOG.debug("Trying to send mail without authentication");
		}
		
		/*
		 * (3) TRANSPORT Security Settings
		 */
		
		final OptionalInt validPortAsIntO = MailProvider.getValidPortAsIntFromSmtpPortString(emailSettings);
		final Optional<String> validPortAsStringO = MailProvider.getValidPortAsStringFromSmtpPortString(emailSettings);
		
		// Default values: smptPort value not set or cannot be parsed
		if(emailSettings.isSsh())
		{
			
			// SSL
			email.setSmtpPort(validPortAsIntO.orElse(465));
			email.setSslSmtpPort(validPortAsStringO.orElse("465"));
			email.setSSLOnConnect(true);
			email.setSSLCheckServerIdentity(true);
			
		}
		else if(emailSettings.isTls())
		{
			
			// StartTLS
			email.setSmtpPort(validPortAsIntO.orElse(587));
			email.setStartTLSEnabled(true);
			
		}
		else
		{
			// No transport security
			email.setSmtpPort(validPortAsIntO.orElse(25));
		}
		
		return email;
	}
	
	/**
	 * Internal helper to get correct Email depending on "asHtml" flag.
	 *
	 * @param asHtml
	 *            the flag
	 * @return a HtmlEmail if asHtml = true, a SimpleEmail otherwise
	 */
	private Email getEmail(final boolean asHtml)
	{
		if(asHtml)
		{
			return new HtmlEmail();
		}
		else
		{
			return new SimpleEmail();
		}
	}
	
	public static OptionalInt getValidPortAsIntFromSmtpPortString(final ConfigMailServer settings)
	{
		
		final int fromSmtpPort = NumberUtils.toInt(settings.getSmtpPort());
		
		if(fromSmtpPort > 0 && fromSmtpPort <= 65535)
		{
			// SmtpPort string not null parsed to a valid port number
			return OptionalInt.of(fromSmtpPort);
		}
		else
		{
			return OptionalInt.empty();
		}
	}
	
	public static Optional<String> getValidPortAsStringFromSmtpPortString(final ConfigMailServer settings)
	{
		
		final int fromSmtpPort = NumberUtils.toInt(settings.getSmtpPort());
		
		if(fromSmtpPort > 0 && fromSmtpPort <= 65535)
		{
			// SmtpPort string not null parsed to a valid port number
			return Optional.of(settings.getSmtpPort());
		}
		else
		{
			return Optional.empty();
		}
	}
}
