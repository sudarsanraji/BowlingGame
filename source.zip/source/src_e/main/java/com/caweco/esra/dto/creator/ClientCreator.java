package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.ClientDTO;
import com.caweco.esra.dto.ClientMetadataDTO;
import com.caweco.esra.entities.Client;

public class ClientCreator {
	
	public static ClientDTO convertClientToDto(Client client)
	{
		ClientDTO dto = new ClientDTO();
		dto.setId(client.getUuid().toString());
		dto.setClientDescription(client.getClientDescription());
		dto.setLobs(client.getLobs(true));
		dto.setEsuTemplates(ESUTemplateCreator.convertCollection(client, client.getEsuTemplatesRaw()));
		dto.setOes(client.getOes(true));
		dto.setFunctions(client.getFunctions(true));
		dto.setLobs(client.getLobs(true));
		dto.setOeRegions(client.getOeRegions(false));
		return dto;
	}
	
	public static ClientMetadataDTO convertClientToMetadataDto(Client client)
	{
		ClientMetadataDTO dto = new ClientMetadataDTO();
		dto.setUuid(client.getUuid());
		dto.setClientConfiguration(client.getClientConfiguration());
		dto.setClientDescription(client.getClientDescription());
		return dto;
	}
    
    public static Client convertMetadataDTOToClient(ClientMetadataDTO dto) {
        Client client = new Client();
        client.setUuid(dto.getUuid());
        client.setClientDescription(dto.getClientDescription());
        client.setClientConfiguration(dto.getClientConfiguration());
        
        return client;
    }
}
	
