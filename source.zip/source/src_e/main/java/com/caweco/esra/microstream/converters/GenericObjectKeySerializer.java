package com.caweco.esra.microstream.converters;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;

public class GenericObjectKeySerializer<T> extends JsonSerializer<T>{

//	ObjectMapper mapper = new ObjectMapper();
//	
//	@Override
//	public Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
//		// TODO Auto-generated method stub
//		return mapper.readValue(key, GsssMatch.class);
//	}

	ObjectMapper mapper = new ObjectMapper();

	@Override
	public void serialize(T value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		// TODO Auto-generated method stub
		gen.writeFieldName(mapper.writeValueAsString(value));
	}


}
