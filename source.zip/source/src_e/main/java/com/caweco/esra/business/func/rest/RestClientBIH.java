package com.caweco.esra.business.func.rest;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.business.properties.RestSettingsProvider;
import com.caweco.esra.dev.mockup.MockupDataprovider;
import com.caweco.esra.entities.config.ConfigRestEndpoint;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CISearch;
import com.caweco.esra.entities.rest.monitoring.CMSearch;
import com.caweco.esra.entities.rest.namematch.NMResponse;
import com.caweco.esra.entities.rest.namematch.NMSearch;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.vaadin.flow.component.UI;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.Response.StatusType;


public class RestClientBIH
{
	private static final Logger                               LOG                            = LoggerFactory
		.getLogger(RestClientBIH.class);
	public static final String                                BIH_URLPROTOCOLPART            = "http://";
	
	public static final String                                BIH_URLMAINPART                = "/agcs/bih/api/service/cara/rest/CompanyService";
	
	/**
	 * For use in {@link ConfigRestEndpoint} class
	 */
	public static final String                                BIH_PORT_KEY                   = "BIH_PORT";
	/**
	 * For use in {@link ConfigRestEndpoint} class
	 */
	public static final String                                BIH_CUSTOMFIELD1_KEY           = "BIH_CUSTOMFIELD1";
	
	

	/**
	 * URL path part for BIH NAME_MATCH_SERVICE
	 */
	protected static final String                             HEADER_NAME_MATCH_SERVICE      = "namematch";
	/**
	 * URL path part for BIH COMPANY_INFO_SERVICE
	 */
	protected static final String                             HEADER_COMPANY_INFO_SERVICE    = "comanyinfo";
	

	/**
	 * Predefined BIH server
	 */
	public static List<Triple<String, String, List<Integer>>> BIH_SERVER                     = getBihServer();
	
	private static List<Triple<String, String, List<Integer>>> getBihServer()
	{
		// @formatter:off
		
		final List<Triple<String, String, List<Integer>>> bihServers =
			Arrays.asList(
					Triple.of(ApplicationPropertyProvider.getDevBihUrlNew(), "BIH CARA-DEV_NEW_URL", Arrays.asList(8080)),
					Triple.of(ApplicationPropertyProvider.getUatBihUrlNew(), "BIH CARA-UAT_NEW_URL", Arrays.asList(8080)),	
					Triple.of(ApplicationPropertyProvider.getProdBihUrlNew(), "BIH CARA-PROD_NEW_URL", Arrays.asList(25002)),
					Triple.of(ApplicationPropertyProvider.getDrBihUrlNew(), "BIH CARA-DR_NEW_URL", Arrays.asList(443)),
					Triple.of(ApplicationPropertyProvider.getProdBihUrlOld(), "BIH CRP2-PROD", Arrays.asList(25002)),
					Triple.of(ApplicationPropertyProvider.getDrBihUrlOld(), "BIH CRP2-DR", Arrays.asList(443)),
					Triple.of(ApplicationPropertyProvider.getExtraBihUrlPlaceholder(), "BIH CARA-TEST_URL", Arrays.asList(443))
					/*
					Triple.of("bih-cara-sit3.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-SIT3", Arrays.asList(443)),
					Triple.of("bih-cara-sit5.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-SIT5", Arrays.asList(25002)),
					Triple.of("bih-cara-ete2.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-ETE2", Arrays.asList(443)),
					Triple.of("bih-cara-ete3.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-ETE3", Arrays.asList(443)),
					Triple.of("bih-cara-ete4.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-ETE4", Arrays.asList(25002)),
					Triple.of("bih-cara.agcs-uat-01.agcs-tem-uat.ew3.aws.aztec.cloud.allianz", "BIH CRP2-UAT", Arrays.asList(25002)),
					Triple.of("bih-cara-maint.agcs-uat-01.agcs-tem-uat.ew3.aws.aztec.cloud.allianz", "BIH CRP2-MAINT", Arrays.asList(25002)),
					Triple.of("bih-cara-perf.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-PERF", Arrays.asList(443))
					Triple.of("bih-cara.agcs-dev-01.agcs-tem-dev.ec1.aws.aztec.cloud.allianz", "BIH CRP2-DEV", Arrays.asList(25002))
				    Triple.of("sla19460.srv.allianz", "BIH DEV", Arrays.asList(25002)),//, 25052, 25102)),
				    Triple.of("sla20285.srv.allianz", "BIH SIT", Arrays.asList(25052)), //, 25002, 25102)),
				    Triple.of("sla22064.srv.allianz", "BIH MNT", Arrays.asList(25152)), //, 25002, 25052, 25102)),
				    Triple.of("sla20261.srv.allianz", "BIH UAT", Arrays.asList(25002)),
				    Triple.of("sla20451.srv.allianz", "BIH Live", Arrays.asList(25002)),
			    */
			);
		
		// @formatter:on
		
		return bihServers;
	}
	
	private final WebTarget    webTarget;
	
	private final ConfigRestEndpoint esraRestConfiguration;
	
	public RestClientBIH(final ConfigRestEndpoint esraRestConfiguration)
	{
		this.esraRestConfiguration = esraRestConfiguration;
		this.webTarget = RestClientBuilder.getClientBIH().target(this.getCurrentUrl());
	}
	
	protected String getCurrentUrl()
	{
		// Pre-set "serverToUse" to first server in list
		
		Triple<String, String, List<Integer>> serverToUse  = BIH_SERVER.iterator().next();
		
		// Pre-set "bihPortToUse" (use default port for now)
		
		String                                bihPortToUse = "" + serverToUse.getRight().iterator().next();
		
		//// Read configuration
		
		if (this.esraRestConfiguration != null)
		{
			// Get ServerDescription from configuration
			final Optional<Triple<String, String, List<Integer>>> serverByConfiguration = BIH_SERVER.stream()
				.filter(t -> t.getLeft().equals(this.esraRestConfiguration.getEndpointBaseURL())).findFirst();
			
			// Change server & port(use default port for now)
			
			if (serverByConfiguration.isPresent())
			{
				serverToUse = serverByConfiguration.get();
				bihPortToUse = "" + serverToUse.getRight().iterator().next();
			}
			
		  // Update port from configuration

			if (this.esraRestConfiguration.getAdditional().containsKey(BIH_PORT_KEY))
			{
				bihPortToUse = this.getPortFromConfig();
			}
			
		}
		
		final String url = buildUrl(serverToUse, bihPortToUse);
		
		return url;
	}
	
	
	/**
	 * Gets and checks the port entry of the current configuration: <br />
	 * Returns the port as string if
	 * <ul>
	 * <li>configuration contains key {@link RestClientBIH#BIH_PORT_KEY}</li>
	 * <li>the port value is a integer and</li>
	 * <li>the port value is >= 0</li>
	 * </ul>
	 * Returns <code>null</code> otherwise.
	 * 
	 * @return
	 */
	private String getPortFromConfig()
	{
		if (this.esraRestConfiguration != null && this.esraRestConfiguration.getAdditional().containsKey(BIH_PORT_KEY))
		{
			final String portFromConfig = this.esraRestConfiguration.getAdditional().get(BIH_PORT_KEY);
			try
			{
				
				// Check if port is a number
				
				final int portFromConfigAsInt = Integer.parseInt(portFromConfig);
				
				// Check if port number is >= 0
				
				if (portFromConfigAsInt >= 0)
				{
					return "" + portFromConfigAsInt;
				}
				else
				{
					LOG.warn("Cannot get BIH PORT String from configuration. Provided value \"{}\" is parsed to non-allowed negative value.", portFromConfig);
					return null;
				}
			}
			catch (final NumberFormatException e)
			{
				LOG.warn("Cannot parse BIH PORT String from configuration.", e);
				return null;
			}
		}
		else
		{
			return null;
		}
	}
	

	
	public static String buildUrl(final Triple<String, String, List<Integer>> serverDescription, @Nullable final String bih_port)
	{
		final StringBuilder sb = new StringBuilder(BIH_URLPROTOCOLPART);
		sb.append(serverDescription.getLeft());
		if (bih_port != null && StringUtils.isNotBlank(bih_port))
		{
			sb.append(":").append(bih_port);
		}
		
		sb.append(RestClientBIH.BIH_URLMAINPART);
		
		final String url = sb.toString();
		
		LOG.debug("## REST: USE BIH URL: {}", url);
		
		return url;
	}
	
	////////
	//// NameMatch
	
	protected NMSearch buildNMSearch(final String searchFor, final String nameType, @Nullable final String country)
	{
		if (this.esraRestConfiguration == null)
		{
			final NMSearch nmSearch = new NMSearch(
				RestSettingsProvider.DEFAULT_REST_USERNAME_BIH,
				RestSettingsProvider.DEFAULT_REST_PASSWORD_BIH,
				RestSettingsProvider.DEFAULT_REST_SYSNAME_BIH,
				RestSettingsProvider.DEFAULT_SEARCHTYPE_VALUE,
				searchFor,
				nameType);
			if (StringUtils.isNotBlank(country))
			{
				nmSearch.setCountry(country);
			}
			
			return nmSearch;
		}
		else
		{
			final NMSearch nmSearch = new NMSearch(
				this.esraRestConfiguration.getEndpointUsername(),
				this.esraRestConfiguration.getEndpointPassword(),
				this.esraRestConfiguration.getSystemName(),
				RestSettingsProvider.DEFAULT_SEARCHTYPE_VALUE,
				searchFor,
				nameType);
			
			RestUtil.getAdditionalFromConfig(this.esraRestConfiguration, BIH_CUSTOMFIELD1_KEY).ifPresent(cf1 ->
			{
				nmSearch.setCustomField1(cf1);
			});
			
			
			if (StringUtils.isNotBlank(country))
			{
				nmSearch.setCountry(country);
			}
			
			return nmSearch;
		}
	}
	
	
	public CompletionStage<NMResponse> getNameMatchStage(final String searchFor, final String nameType, @Nullable final String country)
	{
		// * @param username
		// * @param password
		// * @param system
		// * @param searchType
		// * @param nameToSearch
		// * @param nameType
		
		if (ApplicationPropertyProvider.useMockdata_CARA())
		{
			if (!searchFor.startsWith("bypass"))
			{
				final CompletableFuture<NMResponse> completableFuture = CompletableFuture
					.supplyAsync(() -> MockupDataprovider.getNameMatch_(searchFor, nameType, country));
				return completableFuture;
			}
		}
		
		final NMSearch buildNMSearch = this.buildNMSearch(searchFor, nameType, country);
		
		return this.getNameMatchStage(this.webTarget, buildNMSearch);
	}

	protected CompletionStage<NMResponse> getNameMatchStage(final WebTarget target, final NMSearch item)
	{
		final WebTarget currentTarget = target;
		return currentTarget
			.request(MediaType.APPLICATION_JSON)
			.header("servicename", HEADER_NAME_MATCH_SERVICE)
			.rx()
			.post(Entity.json(item), NMResponse.class);
	}
	
	
	////////
	//// CompanyInfo
	
	
	protected CISearch buildCISearch(final String searchFor)
	{
		if (this.esraRestConfiguration == null)
		{
			final CISearch ciSearch = new CISearch(
				RestSettingsProvider.DEFAULT_REST_USERNAME_BIH,
				RestSettingsProvider.DEFAULT_REST_PASSWORD_BIH,
				RestSettingsProvider.DEFAULT_REST_SYSNAME_BIH,
				RestSettingsProvider.DEFAULT_SEARCHTYPE_VALUE,
				searchFor);
			return ciSearch;
		}
		else
		{
			final CISearch ciSearch = new CISearch(
				this.esraRestConfiguration.getEndpointUsername(),
				this.esraRestConfiguration.getEndpointPassword(),
				this.esraRestConfiguration.getSystemName(),
				RestSettingsProvider.DEFAULT_SEARCHTYPE_VALUE,
				searchFor);
			
			RestUtil.getAdditionalFromConfig(this.esraRestConfiguration, BIH_CUSTOMFIELD1_KEY).ifPresent(cf1 ->
			{
				ciSearch.setCustomField1(cf1);
			});
			
			return ciSearch;
		}
	}
	
	
	public CompletionStage<CIResponse> getCompanyInfoStage(final String searchFor)
	{
		LOG.info(searchFor);
		
		if (ApplicationPropertyProvider.useMockdata_CARA())
		{
			final CompletableFuture<CIResponse> completableFuture = CompletableFuture
				.supplyAsync(() -> MockupDataprovider.getCompanyInfo_(searchFor));
			return completableFuture;
			
		}
		final CISearch CISearch = this.buildCISearch(searchFor);
		return this.getCompanyInfoStage(this.webTarget, CISearch);
	}
	
	
	protected CompletionStage<CIResponse> getCompanyInfoStage(final WebTarget target, final CISearch item)
	{
		final WebTarget currentTarget = target;
		
		return currentTarget
			.request(MediaType.APPLICATION_JSON)
			.header("servicename", HEADER_COMPANY_INFO_SERVICE)
			.rx()
			.post(Entity.json(item), CIResponse.class);
	}
	
	
	////////
	//// Monitoring
	
	/**
	 * Starts a REST call to {@link RestClientBIH#ENDPOINT_COMPANY_MONITOR_SERVICE}.<br />
	 * Returns a Pair of values:
	 * <ul>
	 * <li>The status type of the POST response</li>
	 * <li>The response as String</li>
	 * </ul>
	 * 
	 * @param item
	 * @param untilDate
	 * @param reference
	 * @return
	 */
	public Pair<String, StatusType> startMonitoring(final CIResponse item, final LocalDate untilDate, final String reference)
	{
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yy");
		CMSearch                cmSearch;
		
		
		if (this.esraRestConfiguration == null)
		{
			cmSearch = new CMSearch(
				RestSettingsProvider.DEFAULT_REST_USERNAME_BIH,
				RestSettingsProvider.DEFAULT_REST_PASSWORD_BIH,
				RestSettingsProvider.DEFAULT_REST_SYSNAME_BIH,
				item.getSessionHandle(),
				item.getCompanyBvdId(),
				item.getCompanyInfoBvd().getName());
		}
		else
		{
			cmSearch = new CMSearch(
				this.esraRestConfiguration.getEndpointUsername(),
				this.esraRestConfiguration.getEndpointPassword(),
				this.esraRestConfiguration.getSystemName(),
				item.getSessionHandle(),
				item.getCompanyBvdId(),
				item.getCompanyInfoBvd().getName());
		}
		
		if (item.getCompanyInfoBvd().getBeneficialOwners() != null)
		{
			cmSearch.getBeneficialOwners().putAll(item.getCompanyInfoBvd().getBeneficialOwners());
		}
		
		if (item.getCompanyInfoBvd().getBoIntermediaries() != null)
		{
			cmSearch.getBoIntermediaries().putAll(item.getCompanyInfoBvd().getBoIntermediaries());
		}
		
		if (item.getCompanyInfoBvd().getOtherUltimateBeneficiaries() != null)
		{
			cmSearch.getOtherUltimateBeneficiaries().putAll(item.getCompanyInfoBvd().getOtherUltimateBeneficiaries());
		}
		
		cmSearch.setGlobalUltimateOwner(item.getCompanyInfoBvd().getGlobalUltimateOwner());
		
		if (untilDate != null)
		{
			cmSearch.setMonitorToDate(untilDate.format(formatter));
		}
		if (reference != null)
		{
			cmSearch.setCustomField3(reference);
		}
		
		return this.startMonitoring(cmSearch);
	}
	
	public Pair<String, StatusType> startMonitoring(final CMSearch item)
	{
		
		LOG.debug("# Monitoring call to " + this.webTarget.getUri());
		
		// Sprint-Meeting 03.07.2020: VORERST DEAKTIVIERT!
		
		/*
		 * TODO: ACTIVATE MONITORING
		 */
		org.tinylog.Logger.error("Monitoring currently disabled! [Sprint-Meeting 03.07.2020]");
		if (UI.getCurrent() != null)
		{
			Notificator.error("Monitoring currently disabled! [Sprint-Meeting 03.07.2020]");
		}
		
		// TODO: REMOVE DEV CODE
		
//		final Entity<CMSearch> json = Entity.json(item);
		try
		{
			final String writeValueAsString = new ObjectMapperProvider().getContext(this.getClass()).writerWithDefaultPrettyPrinter()
				.writeValueAsString(item);
			System.out.println(writeValueAsString);
		}
		catch (final JsonProcessingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Pair.of("", Status.NOT_IMPLEMENTED);
		
		
		/*
		 * TO ACTIVATE MONITORING, ENABLE THIS CODE
		 */
		
//		// @formatter:off
//
//		Response postResponse = this.getTarget()
//			.request(MediaType.APPLICATION_JSON)
//			.header("servicename", HEADER_COMPANY_MONITOR_SERVICE)
//			.post(Entity.json(item));
//
//		// @formatter:on
		//
		// final StatusType statusInfo = postResponse.getStatusInfo();
		//
		// System.out.println("Monitoring request result status code: " + statusInfo.getStatusCode());
		//
		// final String result = postResponse.readEntity(String.class);
		// return Pair.of(result, statusInfo);
		
	}
	
	
	public WebTarget getWebTarget()
	{
		return this.webTarget;
	}
	
	public ConfigRestEndpoint getConfiguration()
	{
		return this.esraRestConfiguration;
	}
	
	
	/*******************************************************************/
	
	public String getCurrentUsername()
	{
		final String value = Optional.ofNullable(this.esraRestConfiguration)
			.map(ConfigRestEndpoint::getEndpointUsername)
			.orElseGet(() -> RestSettingsProvider.DEFAULT_REST_USERNAME_BIH);
		return value;
	}
	
	public String getCurrentPwd()
	{
		final String value = Optional.ofNullable(this.esraRestConfiguration)
			.map(ConfigRestEndpoint::getEndpointPassword)
			.orElseGet(() -> RestSettingsProvider.DEFAULT_REST_PASSWORD_BIH);
		return value;
	}
	
	public String getCurrentSystemname()
	{
		final String value = Optional.ofNullable(this.esraRestConfiguration)
			.map(ConfigRestEndpoint::getSystemName)
			.orElseGet(() -> RestSettingsProvider.DEFAULT_REST_SYSNAME_BIH);
		return value;
	}
	
	public String getCurrentCARASearchType()
	{
		final String value = Optional.ofNullable(this.esraRestConfiguration)
			.map(ConfigRestEndpoint::getEndpointUsername)
			.orElseGet(() -> RestSettingsProvider.DEFAULT_SEARCHTYPE_VALUE);
		return value;
	}
	
	public String getCurrentCustomField1()
	{
		final String value = Optional.ofNullable(this.esraRestConfiguration)
			.map(ConfigRestEndpoint::getAdditional)
			.map(add -> add.get(BIH_CUSTOMFIELD1_KEY))
			.filter(Objects::nonNull)
			.orElseGet(() -> RestSettingsProvider.DEFAULT_SEARCHDEFINITION_VALUE);
		return value;
	}
	
}
