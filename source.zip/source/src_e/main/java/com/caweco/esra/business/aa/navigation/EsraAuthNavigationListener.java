package com.caweco.esra.business.aa.navigation;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import org.apache.commons.lang3.BooleanUtils;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.aa.AuthorizationUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.rapidclipse.framework.security.authorization.Resource;
import com.rapidclipse.framework.security.authorization.Subject;
import com.rapidclipse.framework.server.security.authentication.Authentication;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.rapidclipse.framework.server.security.authorization.UnauthorizedNavigationRequestHandler;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterListener;
import com.vaadin.flow.router.ListenerPriority;


@ListenerPriority(1000) // Will be performed after AuthNavigationListener, as AuthNavigationListener has higher priority
public class EsraAuthNavigationListener implements BeforeEnterListener
{
	
	@Override
	public void beforeEnter(BeforeEnterEvent event)
	{
		// Check if user is authenticated is performed by AuthNavigationListener
		
		if(!this.isAuthorized(event.getNavigationTarget()))
		{
			CommonUtil.addFraudulentAccessLog(event.getNavigationTarget(), Authentication.getUser(), false);
			final UnauthorizedNavigationRequestHandler handler =
				Authorization.getUnauthorizedNavigationRequestHandler();
			if(handler != null)
			{
				handler.handle(event);
			}
		} else {
			CommonUtil.addFraudulentAccessLog(event.getNavigationTarget(), Authentication.getUser(), true);
		}
	}
	
	/**
	 * Access granted if there is no {@link AccessibleRule} and if the AccessibleRule is valid.
	 * 
	 * @param target
	 * @return
	 */
	public boolean isAuthorized(final Class<?> target)
	{
		if(target == null)
			return false;
		
		final AccessibleRule rule = target.getAnnotation(AccessibleRule.class);
		if(rule == null)
		{
			return true;
		}
		else if(rule.appAdmin() && AuthorizationUtil.isAppAdmin())
		{
			return true;
		}
		else
		{
			
			final Collection<Resource> resources = this.getResourcesFor(rule);
			if(resources == null || resources.isEmpty())
			{
				return false;
			}
			
			final Subject user = Authentication.getUser();
			if(user == null)
			{
				return false;
			}
			
			boolean userHasOneOfThePermissions = resources.stream().map(user::hasPermission).filter(BooleanUtils::isTrue)
				.findFirst().isPresent();
			return userHasOneOfThePermissions;
			
		}
	}
	
	public Collection<Resource> getResourcesFor(AccessibleRule rule)
	{
		final AuthorizationResources[] names = rule.value();
		if(names != null && names.length > 0)
		{
			return Arrays.stream(names).map(AuthorizationResources::resource).collect(Collectors.toList());
		}
		
		return null;
	}
	
}
