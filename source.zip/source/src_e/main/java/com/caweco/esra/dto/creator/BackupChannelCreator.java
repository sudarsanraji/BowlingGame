package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.BackupChannelDTO;
import com.caweco.esra.entities.config.BackupChannel;

public class BackupChannelCreator {
	
	public static BackupChannelDTO convertBackupChannelToDTO(BackupChannel object)
	{
		BackupChannelDTO dto = new BackupChannelDTO();
		dto.setFolderName(object.getFolderName());
		dto.setMaxFolderCount(object.getMaxFolderCount());
		dto.setName(object.getName());
		return dto;
	}
	
	public static BackupChannel convertDTOToBackupChannel(BackupChannelDTO dto)
	{
		BackupChannel channel = new BackupChannel();
		channel.setFolderName(dto.getFolderName());
		channel.setName(dto.getName());
		channel.setMaxFolderCount(dto.getMaxFolderCount());
		return channel;
	}

	

}
