package com.caweco.esra.business.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SysUtils
{
	/**
	 * The System property key for servers/hosts that have to be accessed <b>without proxy</b>.<br/>
	 * Key: <b>http.nonProxyHosts</b>
	 */
	public static String		SYSTEMPROPERTYNAME_NONPROXYHOSTS	= "http.nonProxyHosts";
	
	private static final Logger	LOG									=
		LoggerFactory.getLogger(SysUtils.class);
	
	public static String printProp(String name, boolean print)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("## SYSTEM PROPERTY ").append("\"").append(name).append("\": ").append(System.getProperty(name));
		
		String all = sb.toString();
		if(print)
			LOG.info(all);
		
		return all;
	}
	
}
