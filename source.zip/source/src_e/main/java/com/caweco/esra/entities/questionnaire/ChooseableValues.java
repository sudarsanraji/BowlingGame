package com.caweco.esra.entities.questionnaire;

import java.util.Objects;

import com.caweco.esra.ui.interfaces.HasAutoIncrementID;
import com.rapidclipse.framework.server.resources.Caption;


public class ChooseableValues implements HasAutoIncrementID
{
	private int		id;
	private String	text;
	private Integer	value;
	
	public ChooseableValues()
	{
		//for Jackson
	}
	
	public ChooseableValues(final String text, final Integer value)
	{
		super();
		this.text = text;
		this.value = value;
	}
	
	@Caption("Chooseable value")
	public String getText()
	{
		return this.text;
	}
	
	public void setText(final String text)
	{
		this.text = text;
	}
	
	@Caption("Weight")
	public Integer getValue()
	{
		return this.value;
	}
	
	public void setValue(final Integer value)
	{
		this.value = value;
	}
	
	public int getId()
	{
		return id;
	}
	
	public void setId(Integer id)
	{
		this.id = id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChooseableValues other = (ChooseableValues) obj;
		return id == other.id && text.equals(other.text);
	}
	
	
	
}
