package com.caweco.esra.business.report;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.entities.rest.information.CompanyInfo;

public class ReportCIResponse
{
	public static ReportCIResponse FromSearchEntry(final SearchEntryCompany c)
	{
		final CIResponse r = c.getItem();
		return new ReportCIResponse(
			r.getCompanyBvdId(),
			r.getCompanyInfoBvd(),
			r.getCompanyGsssMatchResults(),
			r.getBenOwnGsssMatchResults(),
			r.getInterGsssMatchResults(),
			r.getGuoGsssMatchResults(),
			c.getMatchData(),
			c.getCreated()
		);
	}

	private final String companyBvdId;
	private final CompanyInfo companyInfoBvd;
	private final CompanyGsssMatch companyGsssMatchResults;
	private final Map<String, CompanyGsssMatch> benOwnGsssMatchResults;
	private final Map<String, CompanyGsssMatch> interGsssMatchResults;
	private final CompanyGsssMatch guoGsssMatchResults;
	private final Map<GsssMatch, MatchData> matchData;
	private final Instant created;

	public ReportCIResponse(
		final String companyBvdId,
		final CompanyInfo companyInfoBvd,
		final CompanyGsssMatch companyGsssMatchResults,
		final Map<String, CompanyGsssMatch> benOwnGsssMatchResults,
		final Map<String, CompanyGsssMatch> interGsssMatchResults,
		final CompanyGsssMatch guoGsssMatchResults,
		final Map<GsssMatch, MatchData> matchData,
		final Instant created
	)
	{
		this.companyBvdId = companyBvdId;
		this.companyInfoBvd = companyInfoBvd;
		this.companyGsssMatchResults = companyGsssMatchResults;
		this.benOwnGsssMatchResults = benOwnGsssMatchResults;
		this.interGsssMatchResults = interGsssMatchResults;
		this.guoGsssMatchResults = guoGsssMatchResults;
		this.matchData = matchData;
		this.created = created;
	}

	public String getCompanyBvdId()
	{
		return this.companyBvdId;
	}

	public CompanyInfo getCompanyInfoBvd()
	{
		return this.companyInfoBvd;
	}

	public CompanyGsssMatch getCompanyGsssMatchResults()
	{
		return this.companyGsssMatchResults;
	}

	public Map<String, CompanyGsssMatch> getBenOwnGsssMatchResults()
	{
		return this.benOwnGsssMatchResults;
	}

	public Map<String, CompanyGsssMatch> getInterGsssMatchResults()
	{
		return this.interGsssMatchResults;
	}

	public CompanyGsssMatch getGuoGsssMatchResults()
	{
		return this.guoGsssMatchResults;
	}

	public Instant getCreated()
	{
		return this.created;
	}

	public Map<GsssMatch, MatchData> getMatchData() {
		return matchData;
	}
}
