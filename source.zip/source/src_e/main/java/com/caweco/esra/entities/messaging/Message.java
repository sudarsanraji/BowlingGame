package com.caweco.esra.entities.messaging;

import java.time.Instant;
import java.util.UUID;

import com.caweco.esra.business.func.data.PresentationUtil;
import com.caweco.esra.entities.User;


public class Message
{
	private UUID	id		= UUID.randomUUID();
	private Instant	created	= Instant.now();
	private String	createdBy;
	
	private String	message;
	
	private String	userInfo;
	private Instant	lastEdited;
	
	public Message()
	{
	}
	
	public Message(final User creator)
	{
		this.createdBy = creator.getEmailAddress();
		this.userInfo = PresentationUtil.getRepresentation(creator);
	}
	
	public UUID getId()
	{
		return this.id;
	}
	
	public void setId(final UUID id)
	{
		this.id = id;
	}
	
	public String getCreatedBy()
	{
		return this.createdBy;
	}
	
	public void setCreatedBy(final String createdBy)
	{
		this.createdBy = createdBy;
	}
	
	public Instant getCreated()
	{
		return this.created;
	}
	
	public void setCreated(final Instant created)
	{
		this.created = created;
	}
	
	public String getMessage()
	{
		return this.message;
	}
	
	public Message setMessage(final String message)
	{
		this.message = message;
		return this;
	}
	
	public String getUserInfo()
	{
		return this.userInfo;
	}
	
	public void setUserInfo(final String userInfo)
	{
		this.userInfo = userInfo;
	}
	
	public Instant getLastEdited()
	{
		return this.lastEdited;
	}
	
	public void setLastEdited(final Instant lastEdited)
	{
		this.lastEdited = lastEdited;
	}
	
}
