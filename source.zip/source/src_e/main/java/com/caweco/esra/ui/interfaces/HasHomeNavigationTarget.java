package com.caweco.esra.ui.interfaces;

import com.vaadin.flow.component.Component;


public interface HasHomeNavigationTarget
{
	Class<? extends Component> getHomeTarget();
}
