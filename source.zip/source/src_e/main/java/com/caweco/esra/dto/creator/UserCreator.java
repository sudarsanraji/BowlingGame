package com.caweco.esra.dto.creator;

import com.caweco.esra.dto.UserMetadataDTO;
import com.caweco.esra.dto.UserMetadataNoAttributesDTO;
import com.caweco.esra.entities.User;

public class UserCreator {
	
	public static UserMetadataDTO convertUserToMetadataDTO(User user)
	{
		UserMetadataDTO dto = new UserMetadataDTO();
		dto.setActive(user.isActive());
		dto.setCurrentLogin(user.getCurrentLogin());
		dto.setAppAdmin(user.isAppAdmin());
		dto.setDepartment(user.getDepartment());
		dto.setEmailAddress(user.getEmailAddress());
		dto.setFirstname(user.getFirstname());
		dto.setLastLogin(user.getLastLogin());
		dto.setLastname(user.getLastname());
		dto.setLastVisitedClientID(user.getLastVisitedClientId());
		return dto;
	}
	
	public static User convertMetadataDTOToUser(UserMetadataDTO dto)
	{
		User user = new User();
		user.setActive(dto.isActive());
		user.setCurrentLogin(dto.getCurrentLogin());
		user.setDepartment(dto.getDepartment());
		user.setAppAdmin(dto.isAppAdmin());
		user.setEmailAddress(dto.getEmailAddress());
		user.setFirstname(dto.getFirstname());
		user.setLastLogin(dto.getLastLogin());
		user.setLastname(dto.getLastname());
		user.setLastVisitedClientId(dto.getLastVisitedClientID());
		return user;
	}
	
	public static User convertMetadataNoAttributesDTOToUser(UserMetadataNoAttributesDTO dto)
	{
		User user = new User();
		user.setActive(dto.isActive());
		user.setCurrentLogin(dto.getCurrentLogin());
		user.setDepartment(dto.getDepartment());
		user.setAppAdmin(dto.isAppAdmin());
		user.setEmailAddress(dto.getEmailAddress());
		user.setFirstname(dto.getFirstname());
		user.setLastLogin(dto.getLastLogin());
		user.setLastname(dto.getLastname());
		user.setLastVisitedClientId(dto.getLastVisitedClientID());
		return user;
	}
	
	public static UserMetadataNoAttributesDTO convertUserToMetadataAttributesDTO(User user)
	{
		UserMetadataNoAttributesDTO dto = new UserMetadataNoAttributesDTO();
		dto.setActive(user.isActive());
		dto.setCurrentLogin(user.getCurrentLogin());
		dto.setAppAdmin(user.isAppAdmin());
		dto.setDepartment(user.getDepartment());
		dto.setEmailAddress(user.getEmailAddress());
		dto.setFirstname(user.getFirstname());
		dto.setLastLogin(user.getLastLogin());
		dto.setLastname(user.getLastname());
		dto.setLastVisitedClientID(user.getLastVisitedClientId());
		return dto;
	}

}
