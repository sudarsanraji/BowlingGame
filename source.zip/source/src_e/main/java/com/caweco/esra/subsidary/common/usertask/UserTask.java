package com.caweco.esra.subsidary.common.usertask;

import java.time.Instant;
import java.util.UUID;


public interface UserTask
{
	public Instant getCreated();
	
	public UUID getId();
	
	public String getUser();
	
	public String getSummary();
}
