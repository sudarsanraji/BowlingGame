package com.caweco.esra.dto;

public class QuestionnaireUsageDTO {

	private boolean inUse;

	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}
	
	
}
