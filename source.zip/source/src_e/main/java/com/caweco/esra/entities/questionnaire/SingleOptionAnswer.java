package com.caweco.esra.entities.questionnaire;

public class SingleOptionAnswer extends Answer
{
	private ChooseableValues value;
	
	/**
	 * 
	 */
	public SingleOptionAnswer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ChooseableValues getValue()
	{
		return this.value;
	}
	
	public void setValue(final ChooseableValues value)
	{
		this.value = value;
	}
	
}
