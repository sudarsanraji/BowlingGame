package com.caweco.esra.ui.interfaces;

import com.caweco.esra.entities.core.Screening;

public interface HasScreening
{
	public Screening getScreening();
	
}
