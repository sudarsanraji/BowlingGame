package com.caweco.esra.ui.admin.beans;

import java.beans.Beans;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.func.rest.RestClientBIH;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.properties.RestSettingsProvider;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.ClientConfigurationDAO;
import com.caweco.esra.entities.config.ConfigRestEndpoint;
import com.caweco.esra.entities.config.EsraClientConfiguration;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;


public class FormRestEndpointBIHConfig extends VerticalLayout
{
	private ConfigRestEndpoint     endpointConfig;
	private List<BihServerWrapper> availableServer = new ArrayList<BihServerWrapper>();
	
	
	public FormRestEndpointBIHConfig()
	{
		super();
		this.initUI();
		
		this.txtCustomField1.setPlaceholder(RestSettingsProvider.DEFAULT_SEARCHDEFINITION_VALUE);
		
		this.availableServer = RestClientBIH.BIH_SERVER.stream().map(BihServerWrapper::wrap).collect(Collectors.toList());
		
		this.cbBihEndpoint.setItems(this.availableServer);
		
		if (!Beans.isDesignTime())
		{
			if (CurrentUtil.getClient() != null)
			{
				EsraClientConfiguration clientConfiguration = CurrentUtil.getClient().getClientConfiguration();
				this.setConfiguration(clientConfiguration);
			}
			else
			{
				this.setEnabled(false);
			}
		}
	}
	
	public FormRestEndpointBIHConfig setConfiguration(EsraClientConfiguration configuration)
	{
		
		this.endpointConfig = configuration.getConfigRestCara();
		
		if (this.endpointConfig != null)
		{
			this.setEnabled(true);
			this.binder.readBean(this.endpointConfig);
			
			// Value for Field "customField1" (if available)
			
			RestUtil.getAdditionalFromConfig(this.endpointConfig, RestClientBIH.BIH_CUSTOMFIELD1_KEY).ifPresent(cf1 ->
			{
				this.txtCustomField1.setValue(cf1);
			});
			
			// Server
			
			Optional<BihServerWrapper> mappedWrapper = this.availableServer.stream()
				.filter(bwr -> bwr.getUrl().equals(this.endpointConfig.getEndpointBaseURL())).findFirst();
			mappedWrapper.ifPresent(bwr ->
			{
				this.cbBihEndpoint.setValue(bwr);
				this.numberFieldPort.setPlaceholder("" + bwr.getPorts().iterator().next());
			});
			
			// Port (if available)
			
			RestUtil.getAdditionalFromConfig(this.endpointConfig, RestClientBIH.BIH_PORT_KEY).ifPresent(port ->
			{
				try
				{
					this.numberFieldPort.setValue(Double.parseDouble(port));
				}
				catch (Exception e)
				{
					// TODO: handle exception
					e.printStackTrace();
				}
				
			});
		}
		else
		{
			this.setEnabled(false);
		}
		return this;
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(ClickEvent<Button> event)
	{
		if (this.numberFieldPort.isInvalid())
		{
			Notificator.error("Invalid port value!");
			return;
		}
		
		try
		{
			BihServerWrapper newValue = this.cbBihEndpoint.getValue();
			if (newValue != null)
			{
				this.endpointConfig.setEndpointBaseURL(newValue.getUrl());
				
				// Port
				Optional<String> customPortAsString = this.numberFieldPort.getOptionalValue().map(val -> "" + val.intValue());
				if (customPortAsString.isPresent())
				{
					this.endpointConfig.getAdditional().put(RestClientBIH.BIH_PORT_KEY, customPortAsString.get());
					System.out.println(customPortAsString.get());
				}
				else
				{
					this.endpointConfig.getAdditional().remove(RestClientBIH.BIH_PORT_KEY);
					System.out.println("NULL");
				}
				
				// customField1
				String customField1Value = StringUtils.stripToNull(this.txtCustomField1.getValue());
				if (customField1Value != null)
				{
					this.endpointConfig.getAdditional().put(RestClientBIH.BIH_CUSTOMFIELD1_KEY, customField1Value);
				}
				else
				{
					this.endpointConfig.getAdditional().remove(RestClientBIH.BIH_CUSTOMFIELD1_KEY);
				}
				
				this.binder.writeBean(this.endpointConfig);
				ClientConfigurationDAO.updateBIHEndpointConfiguration(CurrentUtil.getClient(), this.endpointConfig);
				

				RestUtil.refreshRestClient_BIH(CurrentUtil.getClient().getUuid().toString());
				
				Notificator.success("Changes saved.");
			}
			else
			{
				Notificator.error("No server selected!");
			}
		}
		catch (ValidationException e)
		{
			e.printStackTrace();
			Notificator.error(e.getMessage());
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #cbBihEndpoint}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void cbBihEndpoint_valueChanged(ComponentValueChangeEvent<ComboBox<BihServerWrapper>, BihServerWrapper> event)
	{
		BihServerWrapper value = event.getValue();
		if (value != null)
		{
			this.numberFieldPort.setPlaceholder("" + value.getPorts().iterator().next());
			this.numberFieldPort.clear();
		}
		else
		{
			this.numberFieldPort.clear();
		}
		
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout = new HorizontalLayout();
		this.txtEndpointRepresentation = new TextField();
		this.div = new Div();
		this.div2 = new Div();
		this.horizontalLayout2 = new HorizontalLayout();
		this.cbBihEndpoint = new ComboBox<>();
		this.numberFieldPort = new NumberField();
		this.horizontalLayout3 = new HorizontalLayout();
		this.txtEndpointUsername = new TextField();
		this.txtEndpointPassword = new PasswordField();
		this.horizontalLayout4 = new HorizontalLayout();
		this.txtSystemName = new TextField();
		this.txtCustomField1 = new TextField();
		this.btnSave = new Button();
		this.binder = new Binder<>();
		
		this.setSpacing(false);
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout.setJustifyContentMode(FlexComponent.JustifyContentMode.EVENLY);
		this.txtEndpointRepresentation.setLabel("Endpoint name");
		this.txtEndpointRepresentation.getStyle().set("flex-basis", "0");
		this.div.getStyle().set("flex-basis", "0");
		this.div2.getStyle().set("flex-basis", "0");
		this.cbBihEndpoint.setRequired(true);
		this.cbBihEndpoint.setRequiredIndicatorVisible(true);
		this.cbBihEndpoint.setLabel("URL");
		this.cbBihEndpoint.getStyle().set("flex-basis", "0");
		this.cbBihEndpoint
			.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(v -> CaptionUtils.resolveCaption(v, "{%name} [{%url}]")));
		this.numberFieldPort.setMin(0.0);
		this.numberFieldPort.setMax(65535.0);
		this.numberFieldPort.setLabel("Port");
		this.numberFieldPort.setClearButtonVisible(true);
		this.horizontalLayout3.setJustifyContentMode(FlexComponent.JustifyContentMode.EVENLY);
		this.txtEndpointUsername.setRequired(true);
		this.txtEndpointUsername.setRequiredIndicatorVisible(true);
		this.txtEndpointUsername.setLabel("Username");
		this.txtEndpointUsername.getStyle().set("flex-basis", "0");
		this.txtEndpointPassword.setRequired(true);
		this.txtEndpointPassword.setRequiredIndicatorVisible(true);
		this.txtEndpointPassword.setLabel("Password");
		this.txtEndpointPassword.getStyle().set("flex-basis", "0");
		this.txtSystemName.setRequired(true);
		this.txtSystemName.setRequiredIndicatorVisible(true);
		this.txtSystemName.setLabel("SystemName");
		this.txtSystemName.getStyle().set("flex-basis", "0");
		this.txtCustomField1.setLabel("CARA Configuration");
		this.txtCustomField1.getStyle().set("flex-basis", "0");
		this.btnSave.setText("Update");
		this.btnSave.setMinWidth("200px");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		
		this.binder.forField(this.txtEndpointPassword).asRequired().withNullRepresentation("")
			.bind(ConfigRestEndpoint::getEndpointPassword, ConfigRestEndpoint::setEndpointPassword);
		this.binder.forField(this.txtEndpointRepresentation).withNullRepresentation("")
			.bind(ConfigRestEndpoint::getEndpointRepresentation, ConfigRestEndpoint::setEndpointRepresentation);
		this.binder.forField(this.txtEndpointUsername).asRequired().withNullRepresentation("")
			.bind(ConfigRestEndpoint::getEndpointUsername, ConfigRestEndpoint::setEndpointUsername);
		this.binder.forField(this.txtSystemName).asRequired().withNullRepresentation("")
			.bind(ConfigRestEndpoint::getSystemName, ConfigRestEndpoint::setSystemName);
		
		this.txtEndpointRepresentation.setSizeUndefined();
		this.div.setSizeUndefined();
		this.div2.setSizeUndefined();
		this.horizontalLayout.add(this.txtEndpointRepresentation, this.div, this.div2);
		this.horizontalLayout.setFlexGrow(1.0, this.txtEndpointRepresentation);
		this.horizontalLayout.setFlexGrow(1.0, this.div);
		this.horizontalLayout.setFlexGrow(1.0, this.div2);
		this.cbBihEndpoint.setSizeUndefined();
		this.numberFieldPort.setSizeUndefined();
		this.horizontalLayout2.add(this.cbBihEndpoint, this.numberFieldPort);
		this.horizontalLayout2.setFlexGrow(2.0, this.cbBihEndpoint);
		this.txtEndpointUsername.setSizeUndefined();
		this.txtEndpointPassword.setSizeUndefined();
		this.horizontalLayout3.add(this.txtEndpointUsername, this.txtEndpointPassword);
		this.horizontalLayout3.setFlexGrow(1.0, this.txtEndpointUsername);
		this.horizontalLayout3.setFlexGrow(1.0, this.txtEndpointPassword);
		this.txtSystemName.setSizeUndefined();
		this.txtCustomField1.setSizeUndefined();
		this.horizontalLayout4.add(this.txtSystemName, this.txtCustomField1);
		this.horizontalLayout4.setFlexGrow(1.0, this.txtSystemName);
		this.horizontalLayout4.setFlexGrow(1.0, this.txtCustomField1);
		this.horizontalLayout.setSizeUndefined();
		this.horizontalLayout2.setSizeUndefined();
		this.horizontalLayout3.setSizeUndefined();
		this.horizontalLayout4.setSizeUndefined();
		this.btnSave.setSizeUndefined();
		this.add(this.horizontalLayout, this.horizontalLayout2, this.horizontalLayout3, this.horizontalLayout4, this.btnSave);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.END, this.btnSave);
		this.setWidthFull();
		this.setHeight(null);
		
		this.cbBihEndpoint.addValueChangeListener(this::cbBihEndpoint_valueChanged);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button                     btnSave;
	private NumberField                numberFieldPort;
	private Binder<ConfigRestEndpoint> binder;
	private HorizontalLayout           horizontalLayout, horizontalLayout2, horizontalLayout3, horizontalLayout4;
	private PasswordField              txtEndpointPassword;
	private Div                        div, div2;
	private TextField                  txtEndpointRepresentation, txtEndpointUsername, txtSystemName, txtCustomField1;
	private ComboBox<BihServerWrapper> cbBihEndpoint;
	// </generated-code>
	
}
