package com.caweco.esra.dto;

public class QuestionResultDTO {
	private Integer		questionId;
	private AnswerDTO	answer;
	private Boolean		completed	= false;
	
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public AnswerDTO getAnswer() {
		return answer;
	}
	public void setAnswer(AnswerDTO answer) {
		this.answer = answer;
	}
	public Boolean getCompleted() {
		return completed;
	}
	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}
	
	
}
