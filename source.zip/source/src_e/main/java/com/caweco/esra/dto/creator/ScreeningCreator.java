package com.caweco.esra.dto.creator;

import java.util.Optional;
import java.util.UUID;

import com.caweco.esra.dto.ScreeningMetadataDTO;
import com.caweco.esra.entities.core.Screening;

public class ScreeningCreator {
	
	public static ScreeningMetadataDTO convertScreening(final Screening screening)
	{
		final ScreeningMetadataDTO dto = new ScreeningMetadataDTO();
		dto.setCreated(screening.getCreated());
		dto.setCreatedBy(screening.getCreatedBy());
		dto.setEsuCountries(screening.getEsuCountries());
		dto.setPrcCountries(screening.getPrcCountries());
		dto.setEsuTags(screening.getEsuTags());
		dto.setESUTemplateResult(screening.getESUTemplateResult());
		dto.setEsuWorker(screening.getEsuWorker() != null ? UserCreator.convertUserToMetadataAttributesDTO(screening.getEsuWorker()) : null);
		dto.setFunction(screening.getFunction());
		dto.setLastChanged(screening.getLastChanged());
		dto.setLastChangedBy(screening.getLastChangedBy());
		dto.setLatestMonitoring(screening.getMonitoring());
		dto.setLineOfBusiness(screening.getLineOfBusiness());
		dto.setName(screening.getName());
		dto.setOe(screening.getOe());
		dto.setScreeningDate(screening.getScreeningDate());
		dto.setScreeningEsuDate(screening.getScreeningEsuDate().isPresent() ? screening.getScreeningEsuDate().get() : null);
		dto.setScreeningPublishDate(screening.getScreeningPublishDate().isPresent() ? screening.getScreeningPublishDate().get() : null);
		dto.setScreeningID(screening.getScreeningID().toString());
		dto.setScreeningOwner(UserCreator.convertUserToMetadataAttributesDTO(screening.getScreeningOwner()));
		dto.setScreeningService(UserCreator.convertUserToMetadataAttributesDTO(screening.getScreeningServiceUser()));
		dto.setStatus(screening.getStatus());
		dto.setArchived(screening.isArchived());
		
		
		return dto;
	}
	
	public static Screening convertMetadataDTOToScreening(String clientId, final ScreeningMetadataDTO metadataDto)
	{
		final Screening screening = new Screening(clientId);
		screening.setCreatedBy(metadataDto.getCreatedBy());
		screening.setCreated(metadataDto.getCreated());
		screening.setEsuCountries(metadataDto.getEsuCountries());
		screening.setPrcCountries(metadataDto.getPrcCountries());
		screening.setEsuTags(metadataDto.getEsuTags());
		screening.setESUTemplateResult(metadataDto.getESUTemplateResult());
		screening.setEsuWorker(metadataDto.getEsuWorker() != null ? UserCreator.convertMetadataNoAttributesDTOToUser(metadataDto.getEsuWorker()) : null);
		screening.setFunction(metadataDto.getFunction());
		screening.setLastChanged(metadataDto.getLastChanged());
		screening.setLastChangedBy(metadataDto.getLastChangedBy());
		screening.setMonitoring(metadataDto.getLatestMonitoring());
		screening.setName(metadataDto.getName());
		screening.setOe(metadataDto.getOe());
		screening.setScreeningDate(metadataDto.getScreeningDate());
		screening.setScreeningEsuDate(metadataDto.getScreeningEsuDate() != null ? Optional.of(metadataDto.getScreeningEsuDate()) : null);
		screening.setScreeningPublishDate(metadataDto.getScreeningPublishDate() != null ? Optional.of(metadataDto.getScreeningPublishDate()) : null);
		screening.setScreeningOwner(UserCreator.convertMetadataNoAttributesDTOToUser(metadataDto.getScreeningOwner()));
		screening.setScreeningServiceUser(UserCreator.convertMetadataNoAttributesDTOToUser(metadataDto.getScreeningService()));
		screening.setStatus(metadataDto.getStatus());
		screening.setScreeningID(UUID.fromString(metadataDto.getScreeningID()));
		screening.setLineOfBusiness(metadataDto.getLineOfBusiness());
		screening.setArchived(metadataDto.isArchived());
		
		screening.setExistsInBackend(true);
		
		return screening;
	}
}
