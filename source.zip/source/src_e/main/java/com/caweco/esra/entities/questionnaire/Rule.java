package com.caweco.esra.entities.questionnaire;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


public class Rule
{
	/**
	 * Conditions, AT LEAST ONE must be valid. [Connected with OR (!)]
	 */
	private Set<ANDCondition> ands = new HashSet<>();
	
	/**
	 * 
	 */
	public Rule()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Conditions, AT LEAST ONE must be valid. [Connected with <b>OR (!)</b>]<br />
	 * Hint: The (sub-)conditions of a {@link ANDCondition} are connected with AND. See {@link ANDCondition#getAnds()}
	 * 
	 * @return
	 */
	public Set<ANDCondition> getAnds()
	{
		return this.ands.equals(null) ? new HashSet<>() : this.ands;
	}
	
	public void setAnds(final Set<ANDCondition> ands)
	{
		this.ands = ands;
	}
	
	public Rule cloneRule(final Questionnaire q, final boolean isLocal)
	{
		
		final Rule rule = new Rule();
		final HashSet<ANDCondition> acset = new HashSet<>();
		
		for(final ANDCondition ac : this.ands)
		{
			
			final HashSet<ConditionObject> coset = new HashSet<>();
			
			for(final ConditionObject co : ac.getAnds())
			{
				
				final Question question = q.getQuestions(!isLocal).stream().filter(
					qu -> {
						return qu.getQuestionText().equals(co.getQuestion(!isLocal).getQuestionText());
					}).findAny().get();
				
				coset.add(new ConditionObject(
						co.getQuestionIDs(),
						question,
						co.getValue()
						));
			}
			acset.add(new ANDCondition(coset));
		}
		rule.setAnds(acset);
		return rule;
	}
	
	public Rule copy(final List<Question> questions)
	{
		final var copy = new Rule();
		if(this.getAnds() != null)
		{
			copy.setAnds(this.getAnds().stream()
				.map(c -> c.copy(questions))
				.collect(Collectors.toSet()));
		}
		return copy;
	}
}
