
package com.caweco.esra.business.properties;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.onelogin.saml2.settings.Saml2Settings;
import com.onelogin.saml2.settings.SettingsBuilder;


public class ApplicationPropertyProvider
{
	
	//// STORAGE & BACKUP
	
	/**
	 * Key: <b><code>allianz.certificate.location</code></b>
	 */
	public static String STORAGE_AZCERT_LOCATION = "allianz.certificate.location";
	
	/**
	 * Key: <b><code>storage.backup.aws.basefoldername</code></b>
	 */
	public static String ESRA_DB_BASEURL = "esra.db.base_url";
	
	/**
	 * Key: <b><code>storage.backup.aws.basefoldername</code></b>
	 */
	public static String STORAGE_BACKUP_AWS_BASEFOLDER = "storage.backup.aws.basefoldername";
	
	//// AUTH & LOGIN
	/**
	 * Key: <b><code>onelogin.saml2.sp.entityid</code></b>
	 */
	public static String SAML_ID = "onelogin.saml2.sp.entityid";
	
	/**
	 * Key: <b><code>default.admin.user.mails</code></b>
	 */
	public static String ADMINS = "default.admin.user.mails";
	
	/**
	 * Key: <b><code>authentication.endpoint</code></b><br />
	 * Values: <b><code>allianz</code></b>
	 */
	public static String AUTHENTICATION_ENDPOINT = "authentication.endpoint";
	
	/**
	 * Key: <b><code>esra.base.url</code></b><br />
	 * Describes the base URL of ESRA - used for linking
	 */
	public static String ESRA_BASE_URL = "esra.base.url";
	
	/**
	 * Key: <b><code>allianz.proxy.url</code></b><br />
	 * URL of the proxy service used to connect to e.g. Seaweb
	 */
	public static String ALLIANZ_PROXY_URL = "allianz.proxy.url";
	
	/**
	 * Key: <b><code>flag.storage.backup.suspended</code></b>
	 * <ul>
	 * <li>"true": Suspends all backups. No full backup, no rolling backup.</li>
	 * <li>unset/other: Performs backups if not restricted by other settings.</li>
	 * </ul>
	 */
	public static String FLAG_AUTHENTICATION_SUSPENDED = "flag.authentication.suspended";
	public static String USE_MOCKUPDATA_CARA = "flag.usemockdata.cara";
	public static String DEV_MAILTOCONSOLE = "flag.dev.mail_only_to_console";
	public static String MOCKUP_DATA_DIR = "mockdata.path";
	
	public static String UPLOAD_ALLOWED_TYPES = "upload.allowed.types";
	
    /**
     * Key: <b><code>backup.aws.access_key</code></b>
     */
    public static String BACKUP_AWS_ACCESSKEY = "backup.aws.access_key";
    
    /**
     * Key: <b><code>backup.aws.secret_key</code></b>
     */
    public static String BACKUP_AWS_SECRETKEY = "backup.aws.secret_key";
    
    /**
     * Key: <b><code>backup.aws.bucket_name</code></b>
     */
    public static String BACKUP_AWS_BUCKETNAME = "backup.aws.bucket_name";
    
    /**
     * Key: <b><code>backup.aws.region</code></b>
     */
    public static String BACKUP_AWS_REGION = "backup.aws.region";
    
    public static String ENV_BANNER = "esra.env.banner";
    
    public static String DEV_BIH_URL_NEW = "dev.bih.cara.url.new";
    
    public static String UAT_BIH_URL_NEW = "uat.bih.cara.url.new";
    
    public static String PROD_BIH_URL_OLD = "prod.bih.cara.url.old";
    
    public static String PROD_BIH_URL_NEW = "prod.bih.cara.url.new";
    
    public static String DR_BIH_URL_NEW = "dr.bih.cara.url.new";
    
    public static String DR_BIH_URL_OLD = "dr.bih.cara.url.old";
    
    public static String EXTRA_BIH_URL_PLACEHOLDER = "extra.bih.cara.url.placeholder";



	
	/////////
	///
	///
	
	public static String getProxyURL()
	{
		final String URL = ApplicationPropertyProvider.prop.getProperty(ALLIANZ_PROXY_URL);
		return URL;
	}
	
	public static String getAppURL()
	{
		final String URL = ApplicationPropertyProvider.prop.getProperty(SAML_ID);
		return URL;
	}
	
	public static String getESRADBBaseURL()
	{
		final String URL = ApplicationPropertyProvider.prop.getProperty(ESRA_DB_BASEURL);
		return URL;
	}
	
	public static String getEsraBaseURL()
	{
		final String URL = ApplicationPropertyProvider.prop.getProperty(ESRA_BASE_URL);
		return URL;
	}
	
	public static String getAllianzCertificateLocation()
	{
		final String URL = ApplicationPropertyProvider.prop.getProperty(STORAGE_AZCERT_LOCATION);
		return URL;
	}
	
	/**
	 * Obtain the email addresses of Application-admins defined in the {@link ESRABaseSettingsProvider#PATH} properties
	 * file.
	 * 
	 * @return
	 */
	public static List<String> getAdmins()
	{
		
		final ArrayList<String> arrayList = new ArrayList<>();
		
		final Optional<String> mails = Optional.ofNullable(ApplicationPropertyProvider.prop.getProperty(ADMINS));
		if(mails.isPresent())
		{
			Stream.of(mails.get().split(",")).map(StringUtils::trimToNull).filter(Objects::nonNull).forEach(
				mail -> arrayList.add(mail));
		}
		return arrayList;
	}
	
	
	/**
	 * Obtain the allowed file types, specified in the {@link ESRABaseSettingsProvider#PATH} properties
	 * file.
	 * 
	 * @return
	 */
	public static String[] getAllowedFileTypes()
	{
		
		final ArrayList<String> arrayList = new ArrayList<>();
		
		final Optional<String>  fileTypes     = Optional.ofNullable(ApplicationPropertyProvider.prop.getProperty(UPLOAD_ALLOWED_TYPES));
		if (fileTypes.isPresent())
		{
			Stream.of(fileTypes.get().split(",")).map(StringUtils::trimToNull).filter(Objects::nonNull)
				.forEach(type -> arrayList.add("." + type));
		}
		return arrayList.toArray(new String[arrayList.size()]);
	}
	
	/**
	 * Checks if the saml id property starts with "https".
	 *
	 * @return true if property is available and starts with "https:"
	 */
	public static boolean isWithHttps()
	{
		return getProperty(SAML_ID)
			// Property is available?
			.filter(Objects::nonNull)
			// Starts with https?
			.filter(value -> StringUtils.startsWith(value, "https:")).isPresent();
	}
	
	public static String getAuthenticationEndpoint()
	{
		final List<String> allowedValues = Arrays.asList("allianz", "auth0");
		return getProperty(AUTHENTICATION_ENDPOINT).filter(it -> allowedValues.contains(it)).orElse("allianz");
	}
	
	public static boolean isAuthenticationSuspended()
	{
		return getProperty(FLAG_AUTHENTICATION_SUSPENDED).filter(v -> Objects.equals(v, "true")).isPresent();
	}
	
	public static boolean sendMailsToConsole()
	{
		return getProperty(DEV_MAILTOCONSOLE).filter(v -> Objects.equals(v, "true")).isPresent();
	}
	
	public static boolean useMockdata_CARA()
	{
		return getProperty(USE_MOCKUPDATA_CARA).filter(v -> Objects.equals(v, "true")).isPresent();
	}
	
	public static String getMockdataDirectory()
	{
		final String value = ApplicationPropertyProvider.prop.getProperty(MOCKUP_DATA_DIR);
		return value;
	}
	
    public static String getBackupAccessKey()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(BACKUP_AWS_ACCESSKEY);
        return value;
    }
    
    public static String getBackupSecretKey()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(BACKUP_AWS_SECRETKEY);
        return value;
    }
    
    public static String getBackupBucketname()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(BACKUP_AWS_BUCKETNAME);
        return value;
    }
    
    public static String getBackupAWSRegion()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(BACKUP_AWS_REGION);
        return value;
    }
    
    public static String getEnvBanner()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(ENV_BANNER);
        return value;
    }
    
    public static String getDevBihUrlNew()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(DEV_BIH_URL_NEW);
        return value;
    }
    
    public static String getUatBihUrlNew()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(UAT_BIH_URL_NEW);
        return value;
    }
    
    public static String getProdBihUrlNew()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(PROD_BIH_URL_NEW);
        return value;
    }
	
    public static String getProdBihUrlOld()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(PROD_BIH_URL_OLD);
        return value;
    }
	
    public static String getDrBihUrlNew()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(DR_BIH_URL_NEW);
        return value;
    }
	
    public static String getDrBihUrlOld()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(DR_BIH_URL_OLD);
        return value;
    }
    
    public static String getExtraBihUrlPlaceholder()
    {
        final String value = ApplicationPropertyProvider.prop.getProperty(EXTRA_BIH_URL_PLACEHOLDER);
        return value;
    }
    
	
	////////////
	/// COMMON
	
	public static Optional<String> getProperty(final String key)
	{
		return Optional.ofNullable(ApplicationPropertyProvider.prop.getProperty(key));
	}
	
	////////////
	/// SAML
	
	public static Saml2Settings getSaml2Settings(
		@Nullable final Map<String, Object> more)
		throws Error, IOException, com.onelogin.saml2.exception.Error
	{
		
		final String filename = getAuthenticationEndpoint() + ".saml.properties";
		
		final SettingsBuilder builder =
			new SettingsBuilder().fromFile(filename).fromProperties(ApplicationPropertyProvider.prop);
		if(more != null)
		{
			builder.fromValues(more);
		}
		final Saml2Settings settings = builder.build();
		
		return settings;
	}
	
	////////////
	/// INTERNAL
	
	public static final Logger LOG = LoggerFactory.getLogger(ApplicationPropertyProvider.class);
	public static Properties prop = new Properties();
	
	static
	{
		readProperties();
		System.out.println(prop);
	}
	

	/**
	 * Reads a .properties file from the "/storage" directory. See {@link BaseConfigProvider.PROPERTIES_PATH}.
	 * 
	 */
	public static void readProperties()
	{
		final Properties tempProps = new Properties();
		final Properties appProps = new Properties();
		
		try(BufferedReader reader =
			Files.newBufferedReader(Paths.get(ESRABaseSettingsProvider.PATH), StandardCharsets.UTF_8))
		{
			tempProps.load(reader);
			tempProps.forEach((k, v) ->
			{
				// Prevent errors caused by illegal whitespace characters
				final String cleaned = StringUtils.trimToNull(v.toString());
				if(cleaned != null)
				{
					appProps.put(k, cleaned);
				}
			});
			
			appProps.forEach((k, v) ->
			{
				ApplicationPropertyProvider.LOG.debug("Setting from property file (trimmed): [key={}, value={}]", k, v);
			});
			
			ApplicationPropertyProvider.LOG.info(
				"Loaded {} settings from config file {}.",
				appProps.size(),
				Paths.get(ESRABaseSettingsProvider.PATH).toAbsolutePath());
			
		}
		catch(final IOException e)
		{
			ApplicationPropertyProvider.LOG.error(
				"Config file {} not available.",
				Paths.get(ESRABaseSettingsProvider.PATH).toAbsolutePath());
		}
		
		ApplicationPropertyProvider.prop = appProps;
	}
}
