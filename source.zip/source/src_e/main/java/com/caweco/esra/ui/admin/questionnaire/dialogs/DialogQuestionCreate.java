package com.caweco.esra.ui.admin.questionnaire.dialogs;

import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.entities.questionnaire.DateChooserQuestion;
import com.caweco.esra.entities.questionnaire.DurationChooserQuestion;
import com.caweco.esra.entities.questionnaire.FreeTextQuestion;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionType;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.Rule;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;
import com.caweco.esra.ui.admin.questionnaire.PartChooserQuestionConfig;
import com.caweco.esra.ui.admin.questionnaire.PartSimpleQuestionConfig;
import com.caweco.esra.ui.admin.questionnaire.rules.BeanRuleGroupContainer;
import com.caweco.esra.ui.admin.questionnaire.rules.PartRuleBaseContainer;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.KeyDownEvent;
import com.vaadin.flow.component.KeyPressEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;
import com.vaadin.flow.component.tabs.TabsVariant;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.renderer.TextRenderer;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializableConsumer;


public class DialogQuestionCreate extends Dialog
{
	private SerializableConsumer<DialogQuestionCreate>	onOkConsumer;
	private final Questionnaire								questionnaire;
	private Question									question;
	private final PartSimpleQuestionConfig					partSimpleQuestion;
	private final PartChooserQuestionConfig					partChooserQuestion;
	private Boolean										addNewQuestion			= false;
	private QuestionCategory							category;
	private PartRuleBaseContainer						partRuleBaseContainer;
	
	/**
	 * For creating a new Question
	 * 
	 * @param questionnaire
	 * @param category
	 */
	public DialogQuestionCreate(final Questionnaire questionnaire, final QuestionCategory category)
	{
		super();
		this.questionnaire = questionnaire;
		this.category = category;
		this.initUI();
		
		this.partChooserQuestion = new PartChooserQuestionConfig(this);
		this.partSimpleQuestion = new PartSimpleQuestionConfig();
		
		this.questionTypeChooser.setItems(QuestionType.values());

	}
	
	/**
	 * Dialog for existing questions.
	 * 
	 * @param questionnaire
	 * @param question
	 */
	public DialogQuestionCreate(final Questionnaire questionnaire, final Question question)
	{
		super();
		this.questionnaire = questionnaire;
		this.question = question;
		
		this.initUI();
		
		this.partChooserQuestion = new PartChooserQuestionConfig(this);
		this.partSimpleQuestion = new PartSimpleQuestionConfig();
		
		this.questionTypeChooser.setItems(QuestionType.values());
		
		if(question instanceof FreeTextQuestion)
		{
			this.questionTypeChooser.setValue(QuestionType.FREETEXT);
		}
		else if(question instanceof SingleOptionQuestion)
		{
			this.questionTypeChooser.setValue(QuestionType.SINGLE);
			this.partChooserQuestion.readBean((SingleOptionQuestion)this.question);
		}
		else if(question instanceof MultiOptionQuestion)
		{
			this.questionTypeChooser.setValue(QuestionType.MULTI);
			this.partChooserQuestion.readBean((MultiOptionQuestion)this.question);
		}
		else if(question instanceof DateChooserQuestion)
		{
			this.questionTypeChooser.setValue(QuestionType.DATE);
		}
		else if(question instanceof DurationChooserQuestion)
		{
			this.questionTypeChooser.setValue(QuestionType.DURATION);
		}
		
		this.questionTypeChooser.setEnabled(false);
		this.lblTitle.setText("Edit Question");
		
		this.txtQuestionText.setValue(question.getQuestionText() != null ? question.getQuestionText() : "");
		this.partSimpleQuestion.readBean(this.question);
		
		this.checkValidity();
		
	}
	
	/**
	 * Event handler delegate method for the {@link RadioButtonGroup} {@link #questionTypeChooser}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void questionTypeChooser_valueChanged(
		final ComponentValueChangeEvent<RadioButtonGroup<QuestionType>, QuestionType> event)
	{
		this.div2.removeAll();
		
		if(this.questionTypeChooser.getValue() != null)
		{
			
			if(event.getValue().equals(QuestionType.FREETEXT))
			{
				if(this.question == null)
				{
					this.question = new FreeTextQuestion();
				}
				this.div2.add(this.partSimpleQuestion);
			}
			else if(event.getValue().equals(QuestionType.DATE))
			{
				if(this.question == null)
				{
					this.question = new DateChooserQuestion();
				}
				this.div2.add(this.partSimpleQuestion);
			}
			else if(event.getValue().equals(QuestionType.DURATION))
			{
				if(this.question == null)
				{
					this.question = new DurationChooserQuestion();
				}
				this.div2.add(this.partSimpleQuestion);
			}
			else if(event.getValue().equals(QuestionType.MULTI))
			{
				if(this.question == null)
				{
					this.question = new MultiOptionQuestion();
				}
				this.div2.add(this.partChooserQuestion);
				this.div2.add(this.partSimpleQuestion);
			}
			else if(event.getValue().equals(QuestionType.SINGLE))
			{
				if(this.question == null)
				{
					this.question = new SingleOptionQuestion();
				}
				this.div2.add(this.partChooserQuestion);
				this.div2.add(this.partSimpleQuestion);
			}
			if (this.question != null && this.category != null) {
				this.question.setCategory(this.category);
			}
			this.tabs.setSelectedTab(this.tabAnswersConfig);
			this.tabRuleConfig.setEnabled(this.question != null);
		}
		
		this.checkValidity();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		this.save();
		
		if(this.onOkConsumer != null)
		{
			this.onOkConsumer.accept(this);
		}
		
		this.close();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnCancel}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnCancel_onClick(final ClickEvent<Button> event)
	{	
		this.close();
	}
	
	/**
	 * Event handler delegate method for the {@link Tabs} {@link #tabs}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void tabs_onSelectedChange(final SelectedChangeEvent event)
	{
		if(event.getSelectedTab().equals(this.tabRuleConfig))
		{
			this.div2.removeAll();
			
			if(this.partRuleBaseContainer != null)
			{
				this.div2.add(this.partRuleBaseContainer);
			}
			else
			{
				this.partRuleBaseContainer = new PartRuleBaseContainer(this.questionnaire, this.question);
				this.div2.add(this.partRuleBaseContainer);
			}
		}
		else
		{
			this.div2.removeAll();
			
			final QuestionType currentQuestionType = this.questionTypeChooser.getValue();
			if (currentQuestionType != null && (currentQuestionType.equals(QuestionType.MULTI) || currentQuestionType.equals(QuestionType.SINGLE)) && this.partChooserQuestion != null)
			{
				this.div2.add(this.partChooserQuestion);
			}
			this.div2.add(this.partSimpleQuestion);
		}
	}
	
	private Rule getRule()
	{
		final Rule rule = new Rule();
		
		this.partRuleBaseContainer.getChildren().forEach(c ->
		{
			if(c instanceof BeanRuleGroupContainer)
			{
				if(((BeanRuleGroupContainer)c).getANDCondition() != null)
				{
					rule.getAnds().add(((BeanRuleGroupContainer)c).getANDCondition());
				}
			}
		});
		
		if(rule.getAnds().size() < 1)
		{
			return null;
		}
		return rule;
	}
	
	public Question getQuestion()
	{
		return this.question;
	}
	
	public Questionnaire getQuestionnaire()
	{
		return this.questionnaire;
	}
	
	public DialogQuestionCreate onOkListener(
		final SerializableConsumer<DialogQuestionCreate> onOkConsumer)
	{
		this.onOkConsumer = onOkConsumer;
		return this;
	}
	
	private boolean isValid()
	{
		QuestionType questionType = this.questionTypeChooser.getValue();
		
		if(this.txtQuestionText.getValue().isEmpty())
		{
			return false;
		}
		
		if(questionType.equals(QuestionType.MULTI) || questionType.equals(QuestionType.SINGLE))
		{
			return !this.partChooserQuestion.getAnswers().isEmpty();
		}
		
		return true;
	}
	
	private void save()
	{
		this.question.setQuestionText(this.txtQuestionText.getValue());
		
		try
		{
			this.partSimpleQuestion.writeBean(this.question);
		}
		catch(final ValidationException e)
		{
			e.printStackTrace();
		}
		
		if(this.question instanceof MultiOptionQuestion)
		{
			try
			{
				this.partChooserQuestion.writeBean((MultiOptionQuestion)this.question);
			}
			catch(final ValidationException e)
			{
				e.printStackTrace();
			}
		}
		if(this.question instanceof SingleOptionQuestion)
		{
			try
			{
				this.partChooserQuestion.writeBean((SingleOptionQuestion)this.question);
			}
			catch(final ValidationException e)
			{
				e.printStackTrace();
			}
		}
		
		if(this.partRuleBaseContainer != null)
		{
			this.question.setRule(this.getRule());
		}
		
		if(!this.questionnaire.getQuestions(false).contains(this.question))
		{
			this.question.setId(QuestionDAO.getNextQuestionID(this.questionnaire.getQuestions(false)));
			this.questionnaire.getQuestions(false).add(this.question);
			QuestionDAO.insert(this.questionnaire, this.question);
		}
		else
		{
			QuestionDAO.update(this.questionnaire, this.question);
		}
	}
	
	public Boolean getContinueWithNewQuestion()
	{
		return this.addNewQuestion;
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSaveAndNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSaveAndNew_onClick(final ClickEvent<Button> event)
	{
		this.save();
		
		this.addNewQuestion = true;
		
		if(this.onOkConsumer != null)
		{
			this.onOkConsumer.accept(this);
		}
		
		this.close();
	}
	
	/**
	 * Event handler delegate method for the {@link TextArea} {@link #txtQuestionText}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtQuestionText_valueChanged(final ComponentValueChangeEvent<TextArea, String> event) {
		this.checkValidity();
	}
	
	public void checkValidity()
	{
		this.btnSave.setEnabled(isValid());
		this.btnSaveAndNew.setEnabled(isValid());
	}

	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.verticalLayout = new VerticalLayout();
		this.lblTitle = new Label();
		this.questionTypeChooser = new RadioButtonGroup<>();
		this.txtQuestionText = new TextArea();
		this.tabs = new Tabs();
		this.tabAnswersConfig = new Tab();
		this.tabRuleConfig = new Tab();
		this.div2 = new Div();
		this.horizontalLayout = new HorizontalLayout();
		this.btnCancel = new Button();
		this.btnSave = new Button();
		this.btnSaveAndNew = new Button();
	
		this.verticalLayout.setSpacing(false);
		this.verticalLayout.setPadding(false);
		this.verticalLayout.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.lblTitle.setText("New Question");
		this.lblTitle.getStyle().set("font-weight", "bold");
		this.lblTitle.getStyle().set("font-size", "20px");
		this.lblTitle.getStyle().set("color", "blue");
		this.questionTypeChooser.setRenderer(new TextRenderer<>(ItemLabelGeneratorFactory.NonNull(QuestionType::getName)));
		this.txtQuestionText.setPlaceholder("Type your question here");
		this.txtQuestionText.setValueChangeMode(ValueChangeMode.EAGER);
		this.tabs.addThemeVariants(TabsVariant.LUMO_CENTERED);
		this.tabAnswersConfig.setClassName("menu");
		this.tabAnswersConfig.setLabel("Question configuration");
		this.tabRuleConfig.setClassName("menu");
		this.tabRuleConfig.setEnabled(false);
		this.tabRuleConfig.setLabel("Rule definition");
		this.div2.getStyle().set("overflow-x", "hidden");
		this.div2.getStyle().set("overflow-y", "auto");
		this.div2.getStyle().set("flex-basis", "0");
		this.btnCancel.setText("Cancel");
		this.btnSave.setEnabled(false);
		this.btnSave.setText("Save");
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnSaveAndNew.setEnabled(false);
		this.btnSaveAndNew.setText("Save and New");
		this.btnSaveAndNew.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
	
		this.tabs.add(this.tabAnswersConfig, this.tabRuleConfig);
		this.btnCancel.setWidthFull();
		this.btnCancel.setHeight(null);
		this.btnSave.setWidthFull();
		this.btnSave.setHeight(null);
		this.btnSaveAndNew.setWidthFull();
		this.btnSaveAndNew.setHeight(null);
		this.horizontalLayout.add(this.btnCancel, this.btnSave, this.btnSaveAndNew);
		this.lblTitle.setSizeUndefined();
		this.txtQuestionText.setWidth(null);
		this.txtQuestionText.setHeight("130px");
		this.tabs.setSizeUndefined();
		this.div2.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.verticalLayout.add(this.lblTitle, this.questionTypeChooser, this.txtQuestionText, this.tabs, this.div2,
				this.horizontalLayout);
		this.verticalLayout.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblTitle);
		this.verticalLayout.setFlexGrow(1.0, this.div2);
		this.verticalLayout.setSizeFull();
		this.add(this.verticalLayout);
		this.setWidth("800px");
		this.setHeight("800px");
	
		this.tabs.setSelectedIndex(0);
	
		this.questionTypeChooser.addValueChangeListener(this::questionTypeChooser_valueChanged);
		this.txtQuestionText.addValueChangeListener(this::txtQuestionText_valueChanged);
		this.tabs.addSelectedChangeListener(this::tabs_onSelectedChange);
		this.btnCancel.addClickListener(this::btnCancel_onClick);
		this.btnSave.addClickListener(this::btnSave_onClick);
		this.btnSaveAndNew.addClickListener(this::btnSaveAndNew_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button							btnCancel, btnSave, btnSaveAndNew;
	private TextArea						txtQuestionText;
	private Tab								tabAnswersConfig, tabRuleConfig;
	private VerticalLayout					verticalLayout;
	private HorizontalLayout				horizontalLayout;
	private Label							lblTitle;
	private Div								div2;
	private Tabs							tabs;
	private RadioButtonGroup<QuestionType>	questionTypeChooser;
	// </generated-code>
	
}
