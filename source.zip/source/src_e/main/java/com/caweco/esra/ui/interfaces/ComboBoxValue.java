package com.caweco.esra.ui.interfaces;

import com.rapidclipse.framework.server.resources.Caption;


public interface ComboBoxValue
{
	public void setName(String name);
	
	@Caption("Name")
	public String getName();
	
	@Caption("ID")
	public Integer getId();
	
	public void setId(Integer id);
	
	public void setActive(Boolean active);
	
	@Caption("Active")
	public Boolean getActive();
	
}
