package com.caweco.esra.business.func.reporting;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import com.caweco.esra.dao.ClientDAO;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;
import com.caweco.esra.ui.admin.parts.PartUserForm;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.server.VaadinSession;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.tinylog.Logger;

public class UARReportBuilderThread extends Thread {

	private final UI ui;
	private final PartUserForm view;
	private static final  String[] HEADERS = { "First Name", "Last Name", "Email Address", "Department", "Is Active", "Is Admin",
			"Last Login", "Roles", "Clients" };
	private static String NO_NAME_FOR_ROLE = "Role without name";
	private static String NO_ROLE_ASSIGNED = "No roles assigned";
	private static String NO_CLIENT_ASSIGNED = "No clients assigned";
	private static String REPORT_NAME = "ESRA_UAR_";
	private static String EXCEL_SHEET_NAME = "ESRA UAR Report -";
	private static String NO_LAST_LOGIN_AVAILABLE = "No last login available";
	private static String UNKNOWN = "(unknown)";
	
	public UARReportBuilderThread(final UI ui, final PartUserForm view) {
		this.ui = ui;
		this.view = view;
	}
	@Override
	public void run() {
		generateReport();
	}
	/**
	 * Generates an Excel workbook containing a report and prepares it for download.
	 * This method creates a new workbook, adds a sheet with a header row, populates
	 * the sheet with data, auto-sizes the columns, and then saves the workbook for download.
	 * If an IOException occurs during the creation of the workbook, it logs an error message.
	 */
	private void generateReport() {
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet(EXCEL_SHEET_NAME);
			createHeaderRow(sheet);
			populateDataRows(sheet);
			autoSizeColumns(sheet);
			saveAndPrepareDownload(workbook);
		} catch (IOException e) {
			logError("Error creating workbook");
		}
	}
	/**
	 * Creates a header row in the specified Excel sheet with predefined column titles.
	 * This method sets up the first row of the sheet with headers such as "Firstname",
	 * "Lastname", "Email Address", etc. Each header cell is styled with bold text,
	 * a grey background, and medium borders.
	 *
	 * @param sheet the Excel sheet where the header row will be created
	 */
	private void createHeaderRow(Sheet sheet) {
	    Row headerRow = sheet.createRow(0);
	    int columnIndex = 0;
	    for (String header : HEADERS) {
	        Cell cell = headerRow.createCell(columnIndex++);
	        cell.setCellValue(header);
	        CellStyle headerStyle = sheet.getWorkbook().createCellStyle();
	        Font font = sheet.getWorkbook().createFont();
	        font.setBold(true);
	        headerStyle.setFont(font);
	        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        headerStyle.setBorderTop(BorderStyle.THIN);
	        headerStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setBorderBottom(BorderStyle.THIN);
	        headerStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setBorderLeft(BorderStyle.THIN);
	        headerStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
	        headerStyle.setBorderRight(BorderStyle.THIN);
	        headerStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
	        cell.setCellStyle(headerStyle);
	    }
	}
	/**
	 * Populates data rows in the Excel sheet with user information.
	 * 
	 * @param sheet the Excel sheet where data rows are populated
	 */
	private void populateDataRows(Sheet sheet) {
		AtomicInteger rowNum = new AtomicInteger(1);
		List<User> users = view.getGrid().getDataProvider().fetch(new Query<>()).collect(Collectors.toList());
		Workbook workbook = sheet.getWorkbook();
		CellStyle borderStyle = workbook.createCellStyle();
		borderStyle.setBorderTop(BorderStyle.MEDIUM);
		borderStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		borderStyle.setBorderBottom(BorderStyle.MEDIUM);
		borderStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		borderStyle.setBorderLeft(BorderStyle.MEDIUM);
		borderStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		borderStyle.setBorderRight(BorderStyle.MEDIUM);
		borderStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		users.parallelStream().forEach(user -> {
			synchronized (sheet) {
				Row row = sheet.createRow(rowNum.getAndIncrement());
				fillUserRow(row, user, borderStyle);
			}
		});
	}
	
	/**
	 * Fills a given Excel row with user information, applying a specified cell style.
	 * This method populates the row with the user's first name, last name, email address,
	 * department, active status, admin status, last login time, roles, and client descriptions.
	 * If any user information is null, a default value is used.
	 *
	 * @param row the Excel row to be filled with user data
	 * @param user the User object containing the data to be inserted into the row
	 * @param borderStyle the CellStyle to be applied to each cell in the row
	 */
	private void fillUserRow(Row row, User user, CellStyle borderStyle) {
		createCellWithStyle(row, 0, user.getFirstname() != null ? user.getFirstname() : "null", borderStyle);
		createCellWithStyle(row, 1, user.getLastname() != null ? user.getLastname() : "null", borderStyle);
		createCellWithStyle(row, 2, user.getEmailAddress() != null ? user.getEmailAddress() : "null", borderStyle);
		createCellWithStyle(row, 3, user.getDepartment() != null ? user.getDepartment() : "null", borderStyle);
		createCellWithStyle(row, 4, String.valueOf(user.isActive()), borderStyle);
		createCellWithStyle(row, 5, String.valueOf(user.isAppAdmin()), borderStyle);
		createCellWithStyle(row, 6,
				user.getLastLogin() != null
						? user.getLastLogin().atZone(ZoneId.systemDefault()).toLocalDateTime().toString()
						: NO_LAST_LOGIN_AVAILABLE,
				borderStyle);
		Set<Client> clients = ClientDAO.findByUser(user);
		String roles = getRoles(user,clients);
		createCellWithStyle(row, 7, roles, borderStyle);
		String clientDescriptions = getClientDescriptions(clients);
		createCellWithStyle(row, 8, clientDescriptions, borderStyle);
	}
	/**
	 * Creates a cell with a given value and applies a specified style.
	 * 
	 * @param row         the row to create the cell in
	 * @param columnIndex the index of the column for the cell
	 * @param value       the value to set in the cell
	 * @param style       the style to apply to the cell
	 */
	private void createCellWithStyle(Row row, int columnIndex, String value, CellStyle style) {
		Cell cell = row.createCell(columnIndex);
		cell.setCellValue(value);
		cell.setCellStyle(style);
	}
	/**
	 * Retrieves and formats the roles of a user.
	 * 
	 * @param user the user whose roles are retrieved
	 * @return a formatted string of roles
	 */
	private String getRoles(User user,Set<Client> clients) {
		StringBuilder rolesBuilder = new StringBuilder();
		UserDAO.getRoles(user).forEach(role -> {
			Optional<Client> optClient = clients.stream().filter(client -> client.getRoles(true).contains(role))
					.findFirst();
			rolesBuilder.append(role.getName() != null ? role.getName() : NO_NAME_FOR_ROLE);
			rolesBuilder
					.append(optClient.isPresent() ? "(" + optClient.get().getClientDescription() + ")" : UNKNOWN);
			rolesBuilder.append(", ");
		});
		return rolesBuilder.length() > 0 ? rolesBuilder.substring(0, rolesBuilder.length() - 2) : NO_ROLE_ASSIGNED;

	}
	/**
	 * Retrieves the descriptions of the given set of clients.
	 *
	 * @param clients the set of clients to retrieve descriptions from
	 * @return a comma-separated string of client descriptions, or a default message if no clients are assigned
	 */
	private String getClientDescriptions(Set<Client> clients) {
		Set<String> clientDescriptionSet = new HashSet<>();
		clients.forEach(client -> clientDescriptionSet.add(client.getClientDescription()));
		return clientDescriptionSet.isEmpty() ? NO_CLIENT_ASSIGNED : String.join(", ", clientDescriptionSet);
	}
	/**
	 * Automatically sizes all columns in the given sheet based on the content of the first row.
	 *
	 * @param sheet the Excel sheet whose columns need to be auto-sized
	 */
	private void autoSizeColumns(Sheet sheet) {
		int numberOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
		for (int i = 0; i < numberOfColumns; i++) {
			sheet.autoSizeColumn(i);
		}
	}
	/**
	 * Saves the given workbook to a byte array output stream and prepares it for download.
	 * This method writes the workbook to an output stream, creates a StreamResource for downloading,
	 * and sets it in the Vaadin session. It also updates the UI to provide a download link.
	 *
	 * @param workbook the Excel workbook to be saved and prepared for download
	 */
    private void saveAndPrepareDownload(Workbook workbook) {
	    try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	        workbook.write(outputStream);
	        String filename = REPORT_NAME + getCurrentFormattedDateTime() + ".xlsx";
	        StreamResource resource = new StreamResource(filename,
	                () -> new ByteArrayInputStream(outputStream.toByteArray()));
	        this.ui.access(() -> {
	            VaadinSession session = VaadinSession.getCurrent();
	            if (session != null) {
	                session.setAttribute("downloadResource", resource);
	            }
	            view.setupDownloadLink(resource, filename);
	        });
	    } catch (IOException e) {
	        logError("Error writing workbook to output stream");
	    }
	}
	/**
	 * Gets the current date and time formatted for filenames.
	 * 
	 * @return the formatted current date and time as a string
	 */
	private String getCurrentFormattedDateTime() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
		return now.format(formatter);
	}
	/**
	 * Logs errors to the console (replace with actual logging mechanism).
	 * 
	 * @param message the error message to log
	 */
	private void logError(String message) {
		Logger.error(message);
}
}
