package com.caweco.esra.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.aa.AuthorizationResources;
import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.RoleMetadataDTO;
import com.caweco.esra.dto.creator.RoleCreator;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.Role;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rapidclipse.framework.server.data.DataAccessObject;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class RoleDAO implements DataAccessObject<Role>
{
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	/**
	 * Uses {@link CurrentUtil#getClient()} to obtain the necessary (parent-)client.
	 * 
	 * @return all roles of the client.
	 */
	public static Set<Role> findAll()
	{
		return CurrentUtil.getClient().getRoles(true);
	}
	
	public static Set<Role> findAll(Client parent)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		WebTarget webTarget = client.getMethodTarget("/client/" + parent.getUuid() + "/roles");
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(List.class, RoleMetadataDTO.class);
		
		try {
			List<RoleMetadataDTO> a = om.readValue(responseBody, type);
			
			Set<Role> roleSet = new HashSet<>();
			
			a.forEach(dto -> {
				roleSet.add(RoleCreator.convertMetadataDTOToRole(dto));
			});
			
			return roleSet;
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static void insert(Role role)
	{
		
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();	
		WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() + "/role/");
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().post(Entity.entity(RoleCreator.convertRoleToMetadataDTO(role), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the role " + role.getName() + " into the system");	
	}
	
	
	public static void update(final Role role)
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();	
		WebTarget webTarget = restClient.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() + "/role/" + role.getId());
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().post(Entity.entity(RoleCreator.convertRoleToMetadataDTO(role), MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" updated the role " + role.getName() + " into the system");	
	
	}
	
	/**
	 * Removes the given role from the current client.<br />
	 * Also removes the role from all user. (not just the user of the current client).
	 * <p>
	 * Uses {@link CurrentUtil#getClient()} to obtain the necessary (parent-)client.
	 * </p>
	 * 
	 * @param role
	 */
	public static void deleteFull(Role role)
	{
		Set<Role> holder = findAll();
		holder.remove(role);
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() + "/role/" + role.getId());
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" deleted the role " + role.getName() + " from the system");	
	}

	public static void addPermissions(Set<AuthorizationResources> resources, String clientId, String roleId) {
		System.out.println("addPermissions is being executed in RoleDAO of ESRA");
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + clientId + "/role/" + roleId + "/addPerm/");
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().put(Entity.entity(resources, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());	
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" performed the add permission operation " + " to the role: " + roleId + " belonging to the client: " + clientId + ". Now the new roles are : " + CommonUtil.getCommaSeparatedPermissions(resources) );	
		
	}

	public static void removePermissions(Set<AuthorizationResources> resources, String clientId, String roleId) {
		
		System.out.println("removePermissions is being executed in RoleDAO of ESRA1");
		ArrayList<String> permissionsToRemove = new ArrayList<>();
		System.out.println("removePermissions is being executed in RoleDAO of ESRA2");
		resources.forEach((authres) -> {
			permissionsToRemove.add(authres.getDescription());
		});
		
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + clientId + "/roles/" + roleId + "/removePerm/");
		Logger.tag("REST").info(webTarget.getUri());
		Response response = webTarget.request().put(Entity.entity(permissionsToRemove, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" performed the remove permission operation " + " to the role: " + roleId + " belonging to the client: " + clientId + ". Now the new roles are : " + CommonUtil.getCommaSeparatedPermissions(resources) );		
	}
}
