package com.caweco.esra.microstream.converters;

import java.io.IOException;

import com.caweco.esra.entities.rest.general.GsssMatch;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.KeyDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class GenericObjectKeyDeserializer extends KeyDeserializer{

	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
		// TODO Auto-generated method stub
		return mapper.readValue(key, GsssMatch.class);
	}




}
