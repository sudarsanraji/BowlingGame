package com.caweco.esra.dto;

import java.time.Instant;

public class MessageGroupCreateDTO {
	private String id;
	private Instant created;
	private String createdBy;
	private String name;
	private boolean isActive;
	private UserMetadataDTO creator;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Instant getCreated() {
		return created;
	}
	public void setCreated(Instant created) {
		this.created = created;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	public UserMetadataDTO getCreator() {
		return creator;
	}
	public void setCreator(UserMetadataDTO creator) {
		this.creator = creator;
	}
	
	
	
}
