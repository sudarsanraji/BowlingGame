package com.caweco.esra.business.report;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.func.data.PresentationUtil;
import com.caweco.esra.business.utils.MapUtils;
import com.caweco.esra.business.utils.Pair;
import com.caweco.esra.business.utils.Triple;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.core.MatchData;
import com.caweco.esra.entities.core.MatchRating;
import com.caweco.esra.entities.core.ScreeningReportData;
import com.caweco.esra.entities.core.SearchEntryCompany;
import com.caweco.esra.entities.core.SearchEntryGsss;
import com.caweco.esra.entities.core.SearchEntrySeaweb2Vessel;
import com.caweco.esra.entities.esra.seaweb2.ComplianceScreeningKeyData;
import com.caweco.esra.entities.questionnaire.Answer;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.DateChooserAnswer;
import com.caweco.esra.entities.questionnaire.DurationChooserAnswer;
import com.caweco.esra.entities.questionnaire.FreeTextAnswer;
import com.caweco.esra.entities.questionnaire.MultiOptionAnswer;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionnaireResultReportData;
import com.caweco.esra.entities.questionnaire.SingleOptionAnswer;
import com.caweco.esra.entities.rest.general.GsssMatch;
import com.caweco.esra.entities.rest.information.CIResponse;
import com.caweco.esra.entities.rest.information.CompanyGsssMatch;
import com.caweco.esra.entities.rest.information.CompanyInfo;
import com.caweco.esra.entities.rest.seaweb2.APSShipDetail_v2;
import com.caweco.esra.ui.sanctions.bean.SearchType;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.server.VaadinSession;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import one.microstream.X;

public final class ScreeningReport
{
	private static final Logger LOG = LoggerFactory.getLogger(ScreeningReport.class);
	private static final Comparator<GsssMatch> gsssMatchSorter = Comparator.comparingDouble(GsssMatch::getHitScore)
		.reversed()
		.thenComparing(Comparator.comparing(GsssMatch::getName, String.CASE_INSENSITIVE_ORDER));
	private static final Comparator<ReportGsssMatch> reportGsssMatchSorter = Comparator.comparingDouble(
		ReportGsssMatch::getHitScore
	).reversed().thenComparing(ReportGsssMatch::getName, String.CASE_INSENSITIVE_ORDER);
	
	private static final Comparator<CIResponse> comparatorCIResponse = Comparator.comparing(it -> {
		final Optional<CompanyInfo> map = Optional.ofNullable(it)
			.map(CIResponse::getCompanyInfoBvd);
		return map.map(CompanyInfo::getName).orElse("");
	});
	
	private static final Comparator<CIResponseWrapper> comparatorReportCIResponse = Comparator.comparing(it -> {
		final Optional<CompanyInfo> map = Optional.ofNullable(it)
			.map(CIResponseWrapper::getResponse)
			.map(ReportCIResponse::getCompanyInfoBvd);
		return map.map(CompanyInfo::getName).orElse("");
	});

	/**
	 * Helper function that is called from the company information report. This will
	 * help create the datasource for the gsss matches subreport.
	 */
	public static JRBeanCollectionDataSource createGsssMatchesSubreportDatasource( // NO_UCD - I'm being used in JasperReports
		final CompanyGsssMatch company,
		final Map<String, CompanyGsssMatch> benOwnMatches,
		final Map<String, CompanyGsssMatch> intermedMatches,
		final Map<GsssMatch, MatchData> matchData
	)
	{
		final Function<Map<String, CompanyGsssMatch>, List<ReportGsssMatch>> gsssMatchMapper = map ->
		{
			return map.values()
				.stream()
				.filter(X::isNotNull)
				.map(CompanyGsssMatch::getGsssMatchResults)
				.filter(X::isNotNull)
				.flatMap(Collection::stream)
				.sorted(gsssMatchSorter)
				.map(e -> ReportGsssMatch.from(e, matchData.get(e), null))
				.collect(Collectors.toList());
		};

		final List<ReportGsssMatch> matches = new ArrayList<>();

		if (company.getGsssMatchResults() != null && !company.getGsssMatchResults().isEmpty())
		{
			matches.addAll(
				company.getGsssMatchResults()
					.stream()
					.sorted(gsssMatchSorter)
					.map(e -> {
						return ReportGsssMatch.from(e, matchData.get(e), null);
					})
					.collect(Collectors.toList())
			);
		}

		matches.addAll(gsssMatchMapper.apply(benOwnMatches));
		matches.addAll(gsssMatchMapper.apply(intermedMatches));

		return new JRBeanCollectionDataSource(matches);
	}

	/**
	 * Helper function that is called in the questionnaire question & answer
	 * subreport. Helps retrieving an answer text for any {@link Answer}.
	 */
	public static String convertAnswerToText(final Answer a) // NO_UCD - I'm being used in JasperReports 
	{
		if (a == null)
		{
			return "";
		}

		final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy");

		if (a instanceof SingleOptionAnswer)
		{
			return convertSingleOptionAnswer((SingleOptionAnswer)a);
		}
		else if (a instanceof DurationChooserAnswer)
		{
			return convertDurationChooserAnswer((DurationChooserAnswer)a);
		}
		else if (a instanceof DateChooserAnswer)
		{
			final LocalDate date = ((DateChooserAnswer)a).getDatetime();
			if (date == null)
			{
				return "";
			}

			return date.format(fmt);
		}
		else if (a instanceof FreeTextAnswer)
		{
			return ((FreeTextAnswer)a).getText();
		}
		else if (a instanceof MultiOptionAnswer)
		{
			final Set<ChooseableValues> vals = ((MultiOptionAnswer)a).getAnswers();
			if (vals == null)
			{
				return "";
			}

			final StringBuilder str = new StringBuilder();
			vals.forEach(v ->
			{
				final String text = v.getText();

				if (text != null)
				{
					if (str.length() != 0)
					{
						str.append('\n');
					}

					str.append(v.getText());
				}
			});

			return str.toString();
		}
		else
		{
			LOG.error(
				"Unkown answer encountered: " + a.getClass().getCanonicalName() + ". Failed to create answer output."
			);
			return "";
		}
	}

	public static String parseSeawebFlag(final Client client, final String flag, final String _number) // NO_UCD - I'm being used in JasperReports
	
	{
		if (_number == null || _number.isEmpty())
		{
			return "---";
		}
		final int number;
		try {
	        number = Integer.parseInt(_number);
	    } catch (NumberFormatException e) {
	        LOG.error("Invalid number format for: " + _number);
	        return "INVALID NUMBER";
	    }
		final String OK = "OK";
		final String SEVERE = "SEVERE";

		final Optional<ComplianceScreeningKeyData> keydata = client.getSeaweb2ScreeningKeyConfig(false)
				.stream()
				.filter(ComplianceScreeningKeyData::isActive)
				.filter(key -> StringUtils.isNotBlank(key.getKey()))
				.filter(key -> key.getKey().equals(flag))
				.findFirst();
		if (!keydata.isPresent())
		{
			System.out.println("Key for flag not present: " + flag);
			return "MISSING KEY";
		}

		if (number < 1)
		{
			return OK;
		}
		return number >= keydata.get().getMinValueForRed() ? SEVERE : OK;
	}

	private static String convertDurationChooserAnswer(final DurationChooserAnswer a)
	{
		final StringBuilder str = new StringBuilder();
		final LocalDate start = a.getStart();
		final LocalDate end = a.getEnde();
		final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy");

		if (start != null)
		{
			str.append("Start: ");
			str.append(start.format(fmt));

			if (end != null)
			{
				str.append('\n');
			}
		}

		if (end != null)
		{
			str.append("End: ");
			str.append(end.format(fmt));
		}

		return str.toString();
	}

	private static String convertSingleOptionAnswer(final SingleOptionAnswer a)
	{
		final ChooseableValues val = a.getValue();
		if (val == null)
		{
			return "";
		}
		return val.getText();
	}

	private static final Pair<String, Object> TOC_ANCHOR = new Pair<>("toc_anchor", "toc_anchor");

	private final ScreeningReportData screeningReportData;
	private final UI ui;
	private final ScreeningReportProgressCollector progressListener;
	private final Client client;

	Map<SearchType, List<SearchEntryGsss>> itemsGsssGrouped = new HashMap<>();

	public ScreeningReport(
		final ScreeningReportData screeningReportData,
		final Client client,
		final UI ui,
		final MonitoringDataSource.Listener progressListener
	)
	{
		this.client = client;
		this.screeningReportData = X.notNull(screeningReportData);
		this.ui = X.notNull(ui);
		this.progressListener = new ScreeningReportProgressCollector(X.notNull(progressListener));

		final List<SearchEntryGsss> itemsGsss = this.screeningReportData.getWatchlistSearchEntriesGsss();
		
		this.itemsGsssGrouped = itemsGsss.stream()
			.collect(Collectors.groupingBy(SearchEntryGsss::getSearchtype));
	}

	private void addCompaniesToc(final TocItem container)
	{
		final List<TocSubItem> companies = new ArrayList<>();
		final List<SearchEntryCompany> itemsComp = this.screeningReportData.getWatchlistCompanyEntries();

		if (!itemsComp.isEmpty())
		{
			itemsComp.stream()
				.map(SearchEntryCompany::getItem)
				.sorted(comparatorCIResponse)
				.forEach(r ->
				{
					if (
						r.getCompanyInfoBvd() != null && r.getCompanyInfoBvd().getName() != null
							&& !r.getCompanyInfoBvd().getName().isEmpty()
					)
					{
						companies.add(new TocSubItem(r.getCompanyInfoBvd().getName(), r.getCompanyInfoBvd().getName()));
					}
				});
		}

		if (!companies.isEmpty())
		{
			final TocSubItem item = new TocSubItem("Companies");
			item.getSubItems().addAll(companies.stream().distinct().collect(Collectors.toList()));
			container.getSubitems().add(item);
		}
	}

	private void collectGsssGroup(final TocItem container, final String groupName, final SearchType searchType)
	{
		if (!this.itemsGsssGrouped.containsKey(searchType) || this.itemsGsssGrouped.get(searchType).isEmpty())
		{
			return;
		}

		final TocSubItem tocGroupItem = new TocSubItem(groupName);
		container.getSubitems().add(tocGroupItem);

		this.itemsGsssGrouped.get(searchType)
			.stream()
			.collect(Collectors.groupingBy(SearchEntryGsss::getResponse_nameToSearch))
			.entrySet()
			.stream()
			.sorted((a, b) -> a.getKey().compareTo(b.getKey()))
			.forEach(keyvalpair ->
			{
				final List<TocSubItem> items = keyvalpair.getValue()
					.stream()
					.flatMap(entry -> entry.getMatchData().entrySet().stream())
					.filter(entry -> !entry.getValue().getRating().equals(MatchRating.FALSE_POSITIVE.name()))
					.map(Map.Entry::getKey)
					.sorted(gsssMatchSorter)
					.map(e -> new TocSubItem(e.getName(), e.getName()))
					.distinct()
					.collect(Collectors.toList());

				final TocSubItem tocItem = new TocSubItem(keyvalpair.getKey());
				tocItem.getSubItems().addAll(items);
				tocGroupItem.getSubItems().add(tocItem);
			});

		final boolean hasFalsePositive = this.itemsGsssGrouped.get(searchType)
			.stream()
			.flatMap(entry -> entry.getMatchData().entrySet().stream())
			.filter(entry -> entry.getValue().getRating().equals(MatchRating.FALSE_POSITIVE.name()))
			.count() > 0;

		if (hasFalsePositive)
		{
			final String contentType = searchType == SearchType.INDIVIDUAL ? "Individuals"
				: searchType == SearchType.AIRCRAFT ? "Aircrafts"
				: "Vessels";

			tocGroupItem.getSubItems().add(new TocSubItem("False Positives", contentType));
		}
	}

	private TocItem createFinancialSanctionsToc()
	{
		final TocItem financialSanctions = new TocItem("Financial Sanctions");
		this.addCompaniesToc(financialSanctions);
		this.collectGsssGroup(financialSanctions, "Individuals", SearchType.INDIVIDUAL);
		this.collectGsssGroup(financialSanctions, "Vessels", SearchType.VESSEL);
		this.collectGsssGroup(financialSanctions, "Aircrafts", SearchType.AIRCRAFT);
		this.addSeaWeb(financialSanctions);
		return financialSanctions;
	}

	private void addSeaWeb(final TocItem toc)
	{
		final List<SearchEntrySeaweb2Vessel> searchEntries = this.screeningReportData.getVesselsSeaWeb();

		if (searchEntries == null || searchEntries.isEmpty())
		{
			return;
		}

		final TocSubItem seawebTocItem = new TocSubItem("SeaWeb");
		toc.getSubitems().add(seawebTocItem);

		for (final SearchEntrySeaweb2Vessel searchEntry : searchEntries)
		{
			final APSShipDetail_v2 details = searchEntry.getShipDetails();
			seawebTocItem.getSubItems().add(new TocSubItem(details.getShipName(), details.getIHSLRorIMOShipNo()));
		}
	}

	private void createTradeSanctionsToc(final List<TocItem> toc)
	{
		if (this.screeningReportData.getTradeSanctionResult() == null)
		{
			return;
		}

		final TocItem tc = new TocItem("Trade Sanctions", "toc_trade_sanctions");

		if (
			this.screeningReportData.getTradeSanctionResult().getQuestionnaire() == null || this.screeningReportData
				.getTradeSanctionResult()
				.getQuestionnaire()
				.getCategories() == null
		)
		{
			LOG.info("Could not add Trade Sanction Categories, as they were null.");
		}
		else
		{
			this.screeningReportData.getTradeSanctionResult()
				.getQuestionnaire()
				.getCategories()
				.stream()
				.map(QuestionCategory::getCategory)
				.sorted()
				.forEach(c ->
				{
					tc.getSubitems().add(new TocSubItem(c, c));
				});
		}

		toc.add(tc);
	}

	private MonitoringDataSource createTocPrintDataSource()
	{
		final List<TocItem> toc = new ArrayList<>();

		toc.add(this.createFinancialSanctionsToc());
		this.createTradeSanctionsToc(toc);

		final QuestionnaireResultReportData busInfo = this.screeningReportData.getBusinessInformationResult();
		if (
			busInfo != null && busInfo.getQuestionnaire() != null
				&& busInfo.getResults() != null
				&& !busInfo.getResults().isEmpty()
		)
		{
			toc.add(new TocItem("Business Information", "toc_business_information"));
		}

		if (
			this.screeningReportData.getEsuCountries() != null && !this.screeningReportData.getEsuCountries().isEmpty() || this.screeningReportData
				.getEsuTags() != null && !this.screeningReportData.getEsuTags().isEmpty()
				|| this.screeningReportData.getESUTemplateResult() != null && !this.screeningReportData.getESUTemplateResult().isEmpty() || this.screeningReportData.getPrcCountries() != null && !this.screeningReportData.getPrcCountries().isEmpty()
		)
		{
			toc.add(new TocItem("Legal Evaluation", "toc_esu"));
		}

		return this.progressListener.createDataSource(toc);
	}

	private MonitoringDataSource createHeaderPrintDataSource()
	{
		final List<TocItem> toc = new ArrayList<>();
		toc.add(new TocItem("Dummy Item", "dummy_item"));
		return this.progressListener.createDataSource(toc);
	}

	private Triple<MonitoringDataSource, MonitoringDataSource, MonitoringDataSource> createSearchEntryGsssDataSource()
	{
		final Function<SearchType, List<ReportGsssMatch>> gsssMatchGetter = type ->
		{
			final Comparator<Pair<String, ReportGsssMatch>> comp = (a, b) -> a.getFirst().compareTo(b.getFirst());

			// The pair business was done to allow for comparing with the nameToSearch which is not accessible from the flatMapped stream.
			return this.itemsGsssGrouped.get(type)
				.stream()
				.flatMap(
					entry -> entry.getMatchData()
						.entrySet()
						.stream()
						.map(e -> new Triple<>(entry.getResponse_nameToSearch(), e, entry.getCreated()))
				)
				.filter(entry -> !entry.getSecond().getValue().getRating().equals(MatchRating.FALSE_POSITIVE.name()))
				.map(
					e -> new Pair<>(
						e.getFirst(),
						ReportGsssMatch.from(e.getSecond().getKey(), e.getSecond().getValue(), e.getThird())
					)
				)
				.filter(X::isNotNull)
				.sorted(comp.thenComparing(Pair::getSecond, reportGsssMatchSorter))
				.map(Pair::getSecond)
				.collect(Collectors.toList());
		};

		MonitoringDataSource matchesAir = null;
		MonitoringDataSource matchesInd = null;
		MonitoringDataSource matchesVessel = null;

		if (this.itemsGsssGrouped.containsKey(SearchType.AIRCRAFT))
		{
			final List<ReportGsssMatch> matchesAirL = gsssMatchGetter.apply(SearchType.AIRCRAFT);

			if (!matchesAirL.isEmpty())
			{
				matchesAir = this.progressListener.createDataSource(matchesAirL);
			}
		}

		if (
			this.itemsGsssGrouped.containsKey(SearchType.INDIVIDUAL) && !this.itemsGsssGrouped.get(
				SearchType.INDIVIDUAL
			).isEmpty()
		)
		{
			final List<ReportGsssMatch> matchesIndL = gsssMatchGetter.apply(SearchType.INDIVIDUAL);

			if (!matchesIndL.isEmpty())
			{
				matchesInd = this.progressListener.createDataSource(matchesIndL);
			}
		}

		if (
			this.itemsGsssGrouped.containsKey(SearchType.VESSEL) && !this.itemsGsssGrouped.get(SearchType.VESSEL)
				.isEmpty()
		)
		{
			final List<ReportGsssMatch> matchesVesselL = gsssMatchGetter.apply(SearchType.VESSEL);

			if (!matchesVesselL.isEmpty())
			{
				matchesVessel = this.progressListener.createDataSource(matchesVesselL);
			}
		}

		return new Triple<>(matchesAir, matchesInd, matchesVessel);
	}

	private MonitoringDataSource createCompaniesDataSource()
	{
		final List<CIResponseWrapper> collect = this.screeningReportData.getWatchlistCompanyEntries()
			.stream()
			.map(e -> new CIResponseWrapper(ReportCIResponse.FromSearchEntry(e)))
			.sorted(comparatorReportCIResponse)
			.collect(Collectors.toList());
		return this.progressListener.createDataSource(collect);
	}

	public StreamResource export()
	{
		// Create all datasources first, so we can properly show the progress on the ui.
		final MonitoringDataSource headerPrintDatasource = this.createHeaderPrintDataSource();
		final MonitoringDataSource tocPrintDatasource = this.createTocPrintDataSource();
		final MonitoringDataSource companiesDatasource = this.createCompaniesDataSource();
		final Triple<MonitoringDataSource, MonitoringDataSource, MonitoringDataSource> ds = this
			.createSearchEntryGsssDataSource();
		final MonitoringDataSource individualsDataSource = ds.getSecond();
		final MonitoringDataSource aircraftsDataSource = ds.getFirst();
		final MonitoringDataSource vesselsDataSource = ds.getThird();
		final MonitoringDataSource tradeSanctionResult = this.progressListener.createDataSource(
			Arrays.asList(this.screeningReportData.getTradeSanctionResult())
		);
		final MonitoringDataSource businessInformationDataSource = this.progressListener.createDataSource(
			Arrays.asList(this.screeningReportData.getBusinessInformationResult())
		);
		final MonitoringDataSource esuDatasource = this.progressListener.createDataSource(
			Arrays.asList(this.screeningReportData)
		);

		final List<JasperPrint> prints = new ArrayList<>();

		System.out.println("Creating header print...");
		prints.add(this.createHeaderPrint(headerPrintDatasource));

		System.out.println("Creating screening information print...");
		prints.add(this.createScreeningInformationPrint());

		System.out.println("Creating toc print...");
		prints.add(this.createTocPrint(tocPrintDatasource));

		System.out.println("Add companies print...");
		if (this.screeningReportData.getWatchlistCompanyEntries().size() > 0)
		{
			prints.add(this.createCompanyInformationsPrint(companiesDatasource));
		}

		System.out.println("Adding gsss matches print...");
		this.addGsssMatchesExports(prints, aircraftsDataSource, individualsDataSource, vesselsDataSource);

		System.out.println("Adding seaweb entries...");
		this.addSeaWebEntries(prints);

		System.out.println("Add trade sanction result print...");
		if (this.screeningReportData.getTradeSanctionResult() != null)
		{
			prints.add(
				this.createQuestionnaireResultPrint(
					"Trade Sanctions",
					tradeSanctionResult,
					"toc_trade_sanctions",
					this.screeningReportData.getTradeSanctionResult().getResultScore()
				)
			);
		}

		System.out.println("Add business information result print...");
		final QuestionnaireResultReportData busInfo = this.screeningReportData.getBusinessInformationResult();
		if (
			busInfo != null && busInfo.getQuestionnaire() != null
				&& busInfo.getResults() != null
				&& !busInfo.getResults().isEmpty()
		)
		{
			prints.add(
				this.createQuestionnaireResultPrint(
					"Business Information",
					businessInformationDataSource,
					"toc_business_information",
					-1 // -1 means don't show anything
				)
			);
		}

		System.out.println("Add esu print...");
		if (
			this.screeningReportData.getEsuCountries() != null && !this.screeningReportData.getEsuCountries().isEmpty() || this.screeningReportData
				.getEsuTags() != null && !this.screeningReportData.getEsuTags().isEmpty()
				|| this.screeningReportData.getESUTemplateResult() != null && !this.screeningReportData.getESUTemplateResult().isEmpty() || this.screeningReportData.getPrcCountries() != null && !this.screeningReportData.getPrcCountries().isEmpty()
		)
		{
			prints.add(this.createEsuPrint(esuDatasource));
		}

		System.out.println("Esporing prints now...");
		final ByteArrayOutputStream out = this.exportPrints(prints);
		System.out.println("Done!");
		return this.createStreamResource(out);
	}

	private void addSeaWebEntries(final List<JasperPrint> prints)
	{
		final List<String> activeFlags = this.client.getSeaweb2ScreeningKeyConfig(true)
			.stream()
			.filter(ComplianceScreeningKeyData::isActive)
			.filter(key -> StringUtils.isNotBlank(key.getKey()))
			.map(key -> key.getKey())
			.collect(Collectors.toList());

		final Map<String, Object> params = MapUtils.createMap(
			this.createArrowParameter(),
			TOC_ANCHOR,
			new Pair<>("client", this.client),
			new Pair<>("activeFlags", activeFlags)
		);
		prints.add(
			ReportUtils.fillReport(
				Reports.SEAWEB.get(this.ui),
				params,
				this.screeningReportData.getVesselsSeaWeb()
					.stream()
					.map(SearchEntrySeaweb2Vessel::getShipDetails)
					.collect(Collectors.toList())
			)
		);
	}

	private void addGsssMatchesExports(
		final List<JasperPrint> prints,
		final MonitoringDataSource aircraftsDatasource,
		final MonitoringDataSource individualsDataSource,
		final MonitoringDataSource vesselsDataSource
	)
	{
		final BiFunction<SearchType, Boolean, List<GsssMatch>> matchesFilterer = (
			type,
			falsePositives
		) -> this.itemsGsssGrouped.get(type)
			.stream()
			.flatMap(entry -> entry.getMatchData().entrySet().stream())
			.filter(entry -> falsePositives == entry.getValue().getRating().equals(MatchRating.FALSE_POSITIVE.name()))
			.map(Map.Entry::getKey)
			.filter(X::isNotNull)
			.sorted(gsssMatchSorter)
			.sorted((a, b) -> Double.compare(b.getHitScore(), a.getHitScore()))
			.collect(Collectors.toList());

		final BiConsumer<SearchType, MonitoringDataSource> addGsssPrint = (type, datasource) ->
		{
			if (this.itemsGsssGrouped.containsKey(type) && !this.itemsGsssGrouped.get(type).isEmpty())
			{
				final List<GsssMatch> matches = matchesFilterer.apply(type, false);
				final List<GsssMatch> falsePositives = matchesFilterer.apply(type, true);

				if (!matches.isEmpty())
				{
					prints.add(this.createGsssMatchesPrint(datasource));
				}

				if (!falsePositives.isEmpty())
				{
					prints.add(this.createFalsePositivePrint(type));
				}
			}
		};

		addGsssPrint.accept(SearchType.INDIVIDUAL, individualsDataSource);
		addGsssPrint.accept(SearchType.VESSEL, vesselsDataSource);
		addGsssPrint.accept(SearchType.AIRCRAFT, aircraftsDatasource);
	}

	private JasperPrint createFalsePositivePrint(final SearchType searchType)
	{
		final List<FalsePositive> list = this.itemsGsssGrouped.get(searchType)
			.stream()
			.flatMap(entry -> entry.getMatchData().entrySet().stream())
			.filter(entry -> entry.getValue().getRating().equals(MatchRating.FALSE_POSITIVE.name()))
			.filter(entry -> entry.getValue() != null && entry.getKey() != null)
			.sorted(Comparator.comparing(e -> e.getKey(), gsssMatchSorter))
			.sorted((a, b) -> Double.compare(b.getKey().getHitScore(), a.getKey().getHitScore()))
			.map(
				e -> new FalsePositive.Builder().withFactivalId(e.getKey().getFactivaEntryID())
					.withHitscore(e.getKey().getHitScoreNormalized())
					.withName(e.getKey().getName())
					.withReason(e.getValue().getRatingStatement())
					.withType(MatchRating.toRating(e.getValue().getRating()).getRepresentation())
					.build()
			)
			.collect(Collectors.toList());

		final String contentType = searchType == SearchType.INDIVIDUAL ? "Individuals"
			: searchType == SearchType.AIRCRAFT ? "Aircrafts"
			: "Vessels";

		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("contentType", contentType),
			this.createArrowParameter(),
			TOC_ANCHOR
		);

		return ReportUtils.fillReport(Reports.FALSE_POSITIVES.get(this.ui), params, list);
	}

	// Has to be a method as the input stream is mutated.
	private Pair<String, Object> createArrowParameter()
	{
		return new Pair<>("arrow", ReportUtils.getImage("arrow.png", this.ui));
	}

	private JasperPrint createCompanyInformationsPrint(final MonitoringDataSource datasource)
	{
		final Map<String, Object> subreport_params = MapUtils.createMap(
			new Pair<>("beneficial_owners_subreport", Reports.BENEFICIAL_OWNER_LIST_SUBREPORT.get(this.ui)),
			new Pair<>("ultimate_beneficiaries_subreport", Reports.ULTIMATE_BENEFICIARIES_LIST_SUBREPORT.get(this.ui)),
			new Pair<>("intermediaries_subreport", Reports.INTERMEDIARIES_LIST_SUBREPORT.get(this.ui)),
			new Pair<>("gsss_matches_subreport", Reports.GSSS_MATCHES_SUBREPORT.get(this.ui)),
			TOC_ANCHOR,
			this.createArrowParameter()
		);

		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("company_info_subreport_parameters", subreport_params),
			new Pair<>("company_info_subreport", Reports.COMPANY_INFORMATION_SUBREPORT.get(this.ui)),
			new Pair<>("gsss_matches_subreport", Reports.GSSS_MATCHES_SUBREPORT_NO_FOOTER.get(this.ui)),
			TOC_ANCHOR,
			this.createArrowParameter()
		);

		final Map<String, Object> intermediariesSubreportParameters = new HashMap<>();
		intermediariesSubreportParameters.put(
			"intermediary_helper_subreport",
			Reports.INTERMEDIARIES_LIST_SUBREPORT.get(this.ui)
		);

		subreport_params.put("intermediaries_subreport_parameters", intermediariesSubreportParameters);

		params.put("gsss_matches_subreport_parameters", this.createGsssMatchesSubreportParameters());

		return ReportUtils.fillReport(Reports.COMPANY_INFORMATION.get(this.ui), params, datasource);
	}

	private JasperPrint createEsuPrint(final MonitoringDataSource datasource)
	{
		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>(
				"gsss_matches_subreport_string_wrapper_subreport",
				Reports.GSSS_MATCHES_SUBREPORT_STRING_WRAPPER_SUBREPORT.get(this.ui)
			),
			new Pair<>("toc_esu", "toc_esu"),
			TOC_ANCHOR,
			this.createArrowParameter()
		);
		return ReportUtils.fillReport(Reports.ESU.get(this.ui), params, datasource);
	}

	private JasperPrint createGsssMatchesPrint(final MonitoringDataSource datasource)
	{
		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("toc", true),
			this.createArrowParameter(),
			TOC_ANCHOR
		);
		params.putAll(this.createGsssMatchesSubreportParameters());
		return ReportUtils.fillReport(Reports.GSSS_MATCHES_SUBREPORT.get(this.ui), params, datasource);
	}

	private Map<String, Object> createGsssMatchesSubreportParameters()
	{
		return MapUtils.createMap(
			new Pair<>(
				"gsss_matches_subreport_string_wrapper_subreport",
				Reports.GSSS_MATCHES_SUBREPORT_STRING_WRAPPER_SUBREPORT.get(this.ui)
			),
			new Pair<>(
				"gsss_matches_subreport_identifications_subreport",
				Reports.GSSS_MATCHES_SUBREPORT_IDENTIFICATIONS_SUBREPORT.get(this.ui)
			),
			new Pair<>(
				"gsss_matches_subreport_linked_profiles_subreport",
				Reports.GSSS_MATCHES_SUBREPORT_LINKED_PROFILES_SUBREPORT.get(this.ui)
			),
			this.createArrowParameter(),
			TOC_ANCHOR
		);
	}

	private JasperPrint createHeaderPrint(final MonitoringDataSource datasource)
	{
		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("logo", ReportUtils.getImage("logo.png", this.ui)),
			new Pair<>("screening_date", this.screeningReportData.getScreeningDate()),
			new Pair<>("name", this.screeningReportData.getName()),
			new Pair<>("header_subreport", Reports.HEADER_SUBREPORT.get(this.ui)),
			new Pair<>("header_subreport_subreport", Reports.HEADER_SUBREPORT_SUBREPORT.get(this.ui)),
			TOC_ANCHOR
		);

		return ReportUtils.fillReport(Reports.HEADER.get(this.ui), params, datasource);
	}
	
	private JasperPrint createTocPrint(final MonitoringDataSource datasource)
	{
		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("logo", ReportUtils.getImage("logo.png", this.ui)),
			new Pair<>("screening_date", this.screeningReportData.getScreeningDate()),
			new Pair<>("name", this.screeningReportData.getName()),
			new Pair<>("header_subreport", Reports.HEADER_SUBREPORT.get(this.ui)),
			new Pair<>("header_subreport_subreport", Reports.HEADER_SUBREPORT_SUBREPORT.get(this.ui)),
			TOC_ANCHOR
		);

		return ReportUtils.fillReport(Reports.TOC.get(this.ui), params, datasource);
	}

	private JasperPrint createQuestionnaireResultPrint(
		final String title,
		final MonitoringDataSource datasource,
		final String link,
		final int resultScore
	)
	{
		final Map<String, Object> params = MapUtils.createMap(
			new Pair<>("questions_and_answers_subreport", Reports.QUESTIONS_AND_ANSWERS_SUBREPORT.get(this.ui)),
			new Pair<>("title", title),
			new Pair<>("toc", link),
			new Pair<>("score", resultScore),
			TOC_ANCHOR,
			this.createArrowParameter()
		);

		return ReportUtils.fillReport(Reports.QUESTIONNAIRE_RESULT.get(this.ui), params, datasource);
	}

	private Client getCurrentClient()
	{
		/*
		 * As we are currently are in a different thread we also have to make sure to
		 * lock the session when accessing, or we would just get null.
		 */
		final Client[] client = new Client[1];
		this.ui.getSession().accessSynchronously(() ->
		{
			client[0] = VaadinSession.getCurrent().getAttribute(Client.class);
		});
		return client[0];
	}

	/**
	 * Creates a {@link List} of all available {@link SearchEntryGsss#getCreated()},
	 * paired with the search name
	 */
	private List<Pair<String, Instant>> createCreatedList()
	{
		final List<Pair<String, Instant>> list = new ArrayList<>();

		// Add company entries
		{
			final List<SearchEntryCompany> lazy = this.screeningReportData.getWatchlistCompanyEntries();

			if (lazy != null)
			{
				final List<SearchEntryCompany> loadedList = lazy;
					loadedList.forEach(e ->
					{
						if (
							e != null && e.getCreated() != null
								&& e.getItem() != null
								&& e.getItem().getCompanyInfoBvd() != null
								&& e.getItem().getCompanyInfoBvd().getName() != null
								&& !e.getItem().getCompanyInfoBvd().getName().isEmpty()
						)
						{
							list.add(new Pair<>(e.getItem().getCompanyInfoBvd().getName(), e.getCreated()));
						}
					});
				
			}
		}

		// Add individual gsss entries
		{
			final List<SearchEntryGsss> loadedList = this.screeningReportData.getWatchlistSearchEntriesGsss();

			if (loadedList != null)
			{
				loadedList.forEach(e ->
				{
					if (
						e.getResponse_nameToSearch() != null && !e.getResponse_nameToSearch().isEmpty()
							&& e.getCreated() != null
					)
					{
						list.add(new Pair<>(e.getResponse_nameToSearch(), e.getCreated()));
					}
				});
			}
		}

		// Add SeaWeb entries
		{
			final List<SearchEntrySeaweb2Vessel> seaweb = this.screeningReportData.getVesselsSeaWeb();

			if (seaweb != null && !seaweb.isEmpty())
			{
				seaweb.forEach(
					e -> list.add(
						new Pair<>(PresentationUtil.getRepresentation_ForMainWatchlistHeader(e), e.getCreated())
					)
				);
			}
		}

		return list;
	}

	private JasperPrint createScreeningInformationPrint()
	{
		return ReportUtils.fillReport(
			Reports.SCREENING_INFORMATION.get(this.ui),
			MapUtils.createMap(
				new Pair<>("toc_screening_information", "toc_screening_information"),
				new Pair<>("client", this.getCurrentClient().getClientDescription()),
				new Pair<>("change_entry_subreport", Reports.SCREENING_INFORMATION_CHANGE_ENTRY_SUBREPORT.get(this.ui)),
				new Pair<>("created_list", this.createCreatedList()),
				new Pair<>("created_list_subreport", Reports.CREATED_LIST_SUBREPORT.get(this.ui)),
				TOC_ANCHOR,
				this.createArrowParameter()
			),
			this.progressListener.createDataSource(Arrays.asList(this.screeningReportData))
		);
	}

	private StreamResource createStreamResource(final ByteArrayOutputStream out)
	{
		String name = this.screeningReportData.getName() == null ? "" : this.screeningReportData.getName();
		name = name.replaceAll("/", "_");
		
		final String resourceName = "Screening_" + name + ".pdf";
		return new StreamResource(resourceName, () -> new ByteArrayInputStream(out.toByteArray()));
	}
	

	private ByteArrayOutputStream exportPrints(final List<JasperPrint> prints)
	{
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		final JRPdfExporter exporter = new JRPdfExporter();

		exporter.setExporterInput(SimpleExporterInput.getInstance(prints));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

		try
		{
			exporter.exportReport();
		}
		catch (final JRException e)
		{
			throw new RuntimeException(e);
		}

		return out;
	}
}