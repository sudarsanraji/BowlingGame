package com.caweco.esra.entities.core;

public interface HasMatchData
{
	
	String getComment();
	
	HasMatchData setComment(String comment);
	
	String getRating();
	
	HasMatchData setRating(String rating);
	
	String getRatingStatement();
	
	HasMatchData setRatingStatement(String ratingStatement);
	
	String getUsername();
	
	HasMatchData setUsername(String username);
	
}
