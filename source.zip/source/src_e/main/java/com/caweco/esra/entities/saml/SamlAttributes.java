package com.caweco.esra.entities.saml;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jetbrains.annotations.Nullable;


/**
 * Wrapper for attributes of a SAML response of the ESRA SAML endpoint.<br />
 * <code>[https://saml.allianz.com/saml/opensso/SSO/esra/]</code>
 * <p>
 * Following fragment from the endpoint's metadata.xml shows the available attributes:
 * 
 * <pre>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:1.3.6.1.7" FriendlyName="mail"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.10" FriendlyName="organizationName"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.6" FriendlyName="Country"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.42" FriendlyName="givenname"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.4" FriendlyName="surname"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="o" FriendlyName="Company"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.97" FriendlyName="Division"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="dgebene5" FriendlyName="Department"/>
 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="ou" FriendlyName="Department"/>
 * </pre>
 * </p>
 */
public class SamlAttributes
{
	public SamlAttributes()
	{
		
	}
	
	private Instant						date;
	
	private Map<String, List<String>>	attributes;
	
	public SamlAttributes(@Nullable Map<String, List<String>> attributes)
	{
		super();
		this.setDate(Instant.now());
		if(attributes != null)
		{
			this.attributes = copySamlAttributes(attributes);
		}
	}
	
	private Map<String, List<String>> copySamlAttributes(Map<String, List<String>> attributes2)
	{
		Map<String, List<String>> copy = new HashMap<>();
		
		if (attributes2 != null)
		{
			attributes2.forEach((k,v) ->
			{
				List<String> valueCopy = new ArrayList<>(v);
				copy.put(k, valueCopy);
			});
		}
		
		return copy;
	}

	public Map<String, List<String>> getAttributes()
	{
		return this.attributes;
	}
	
	/* *************************************************************** */
	
	/**
	 * <p>
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:1.3.6.1.7" FriendlyName="mail"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getMail()
	{
		return this.getAttributeFirstValue("urn:oid:1.3.6.1.7");
	}
	
	/**
	 * <p>
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.10" FriendlyName="organizationName"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getOrganizationName()
	{
		return this.getAttributeFirstValue("urn:oid:2.5.4.10");
	}
	
	/**
	 * <p>
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.6" FriendlyName="Country"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getCountry()
	{
		return this.getAttributeFirstValue("urn:oid:2.5.4.6");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.42" FriendlyName="givenname"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getGivenname()
	{
		return this.getAttributeFirstValue("urn:oid:2.5.4.42");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.4" FriendlyName="surname"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getSurname()
	{
		return this.getAttributeFirstValue("urn:oid:2.5.4.4");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="o" FriendlyName="Company"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getCompany()
	{
		return this.getAttributeFirstValue("o");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="urn:oid:2.5.4.97" FriendlyName="Division"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getDivision()
	{
		return this.getAttributeFirstValue("urn:oid:2.5.4.97");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="dgebene5" FriendlyName="Department"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getDepartment()
	{
		return this.getAttributeFirstValue("dgebene5");
	}
	
	/**
	 * Returns attribute according to following metadata.xml fragment:
	 * 
	 * <pre>
	 * &lt;saml:Attribute NameFormat="urn:oasis:names:tc:SAML:2.0:attrname-format:uri" Name="ou" FriendlyName="Department"/>
	 * </pre>
	 * 
	 * @return the first attribute value if available.
	 */
	public Optional<String> getDepartment_ou()
	{
		return this.getAttributeFirstValue("ou");
	}
	
	public Instant getDate()
	{
		return this.date;
	}
	
	public void setDate(Instant date)
	{
		this.date = date;
	}
	
	/* *************************************************************** */
	
	/**
	 * Returns the first saml attribute value for a attribute name.
	 * 
	 * @param attributeName
	 * @return
	 */
	public Optional<String> getAttributeFirstValue(String attributeName)
	{
		Optional<String> res = this.getAttributeValues(attributeName).flatMap(l -> l.stream().findFirst());
		return res;
	}
	
	/**
	 * Returns the saml attribute value list for a attribute name.
	 * 
	 * @param attributeName
	 * @return
	 */
	public Optional<List<String>> getAttributeValues(String attributeName)
	{
		Optional<List<String>> res = Optional.ofNullable(this.attributes.get(attributeName));
		return res;
	}
	
	/* *************************************************************** */
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.attributes == null) ? 0 : this.attributes.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(this == obj)
			return true;
		if(obj == null)
			return false;
		if(this.getClass() != obj.getClass())
			return false;
		SamlAttributes other = (SamlAttributes)obj;
		if(this.attributes == null)
		{
			if(other.attributes != null)
				return false;
		}
		else if(!this.attributes.equals(other.attributes))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SamlAttributes [date=" + date + ", attributes=" + attributes + "]";
	}
	
	/* *************************************************************** */
	
	
}
