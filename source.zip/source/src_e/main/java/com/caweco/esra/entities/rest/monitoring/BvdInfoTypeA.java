
package com.caweco.esra.entities.rest.monitoring;

public interface BvdInfoTypeA
{
	String getName();

	String getBvdId();

	String getCity();

	String getCountry();
}
