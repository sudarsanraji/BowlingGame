package com.caweco.esra.dao;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.config.ConfigMailServer;
import com.caweco.esra.entities.config.ConfigRestEndpoint;
import com.caweco.esra.entities.config.EsraClientConfiguration;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class ClientConfigurationDAO {

	public static void updateConfiguration(Client client, EsraClientConfiguration clientConfig) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/config");
		
		Response response = webTarget.request().put(Entity.entity(clientConfig, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
	}

	public static void updateMailConfiguration(Client client, ConfigMailServer config) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/config/mail");
		
		Response response = webTarget.request().put(Entity.entity(config, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());		
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" performed Mail configuration update from Admin page.");		
	}

	public static void updateBIHEndpointConfiguration(Client client, ConfigRestEndpoint endpointConfig) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/config/endpoints/bih");
		
		Response response = webTarget.request().put(Entity.entity(endpointConfig, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" performed BIHEndPointConfiguration update from Admin page.");		
	}

	public static void updateSeawebConfiguration(Client client, ConfigRestEndpoint endpointConfig) {
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/client/" + client.getUuid() + "/config/endpoints/seaweb");
		
		Response response = webTarget.request().put(Entity.entity(endpointConfig, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" performed the updateSeawebConfiguration update from Admin page.");		
	}

}
