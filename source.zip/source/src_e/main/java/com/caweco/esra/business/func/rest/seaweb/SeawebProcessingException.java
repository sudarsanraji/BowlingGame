package com.caweco.esra.business.func.rest.seaweb;

import com.caweco.esra.entities.rest.seaweb2.APSStatus_v2;

public class SeawebProcessingException extends RuntimeException
{
	
	protected String errorLevel; // NO_UCD - needed for exception
	protected String errorMessage; // NO_UCD - needed for exception
	
	public SeawebProcessingException(final APSStatus_v2 apsStatus_v2)
	{
		super(apsStatus_v2.getErrorLevel() + ": " + apsStatus_v2.getErrorMessage());
		this.errorLevel = apsStatus_v2.getErrorLevel();
		this.errorMessage = apsStatus_v2.getErrorMessage();
	}
	
}
