package com.caweco.esra.dao.messaging;

import java.util.ArrayList;
import java.util.List;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.Response;


public class MessageGroupService
{	
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	//// SERVICE METHODS
	
	public static MessageGroup getPublicMessageHolder(final HasMessages r)
	{
		return r.getPublicMessages(true);
		
	}
	
	public static List<Message> getOrCreateMyNotes(final Screening r, final User u)
	{
		RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = client.getMethodTarget("/client/" + CurrentUtil.getClient().getUuid().toString() + "/screening/" + r.getScreeningID() + "/notes/" + u.getEmailAddress());
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(List.class, Message.class);
		
		try {
			return om.readValue(responseBody, type);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ArrayList<>();
		}
	}
	
	
	
}
