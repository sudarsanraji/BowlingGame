package com.caweco.esra.dao.access;

import java.util.HashSet;
import java.util.Set;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dto.ClientAssignmentRuleLdapDTO;
import com.caweco.esra.dto.creator.ClientAssignmentRuleLdapCreator;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.access.ClientAssignmentRuleLdap;
import com.caweco.esra.entities.ldap.LdapAttributes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class ClientAssignmentRuleDAO
{
	static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	/*************************************************************/
	// LDAP
	
	public static Set<ClientAssignmentRuleLdap> findAll_allClients_ldap()
	{
		RestClientESRADB restClient = RestUtil.getRestClient_ESRADB();
		
		WebTarget webTarget = restClient.getMethodTarget("/accesscontrol/ClientAssignmentRules/");
		
		Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		String responseBody = response.readEntity(String.class);
		
		JavaType type = om.getTypeFactory().constructCollectionType(Set.class, ClientAssignmentRuleLdapDTO.class);
		
		try {
            Set<ClientAssignmentRuleLdapDTO> dtoSet = om.readValue(responseBody, type);
            
            Set<ClientAssignmentRuleLdap> actualObjectSet = new HashSet<ClientAssignmentRuleLdap>();
            
            dtoSet.forEach(dto -> {
            	actualObjectSet.add(ClientAssignmentRuleLdapCreator.convertDTOToClientAssignment(dto));
            });
            
            return actualObjectSet;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static void updateAutoAssignment(User user, LdapAttributes attributes, boolean hasAccess) {
		
//		@Post("/updateAutoAssignment/{userEmail}")
//		public void updateAutoAssignment(@PathVariable String userEmail, @Body LdapAttributes attributes,
//			@QueryValue Boolean hasAccess)
		
		
		final WebTarget                  webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget("/accesscontrol/updateAutoAssignment/{userEmail}")
		.resolveTemplate("userEmail", user.getEmailAddress());
		
		Response                   response  =
			webTarget.queryParam("hasAccess", hasAccess).request().post(Entity.entity(attributes, MediaType.APPLICATION_JSON));

		Logger.tag("REST").info(response.toString());
	}

	public static void remove(ClientAssignmentRuleLdap clientAssignmentRuleLdap)
	{
//		@Delete("{clientId}/assignmentRules/{ruleId}")
		
		WebTarget webTarget = RestUtil.getRestClient_ESRADB().getMethodTarget("/client/{clientId}/assignmentRules/{ruleId}")
			.resolveTemplate("clientUuid", clientAssignmentRuleLdap.getClientToAssignTo().getUuid().toString())
			.resolveTemplate("ruleId", clientAssignmentRuleLdap.getUuid().toString());

		Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" removed the client assignment rule "  + clientAssignmentRuleLdap.getRepresentation() + " from the system" );
	}

	
	/*************************************************************/

}
