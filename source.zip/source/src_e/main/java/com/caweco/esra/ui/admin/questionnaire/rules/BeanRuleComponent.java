package com.caweco.esra.ui.admin.questionnaire.rules;

import java.util.stream.Collectors;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.Pair;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.ConditionObject;
import com.caweco.esra.entities.questionnaire.MultiOptionQuestion;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.SingleOptionQuestion;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;


public class BeanRuleComponent extends HorizontalLayout
{
	
	private final Questionnaire	questionnaire;
	private final VerticalLayout	parentContainer;
	private ConditionObject	condition;
	private final Question		question;
	
	/**
	 * 
	 */
	public BeanRuleComponent(final Questionnaire questionnaire, final Question question, final VerticalLayout parentContainer)
	{
		super();
		this.questionnaire = questionnaire;
		this.question = question;
		this.parentContainer = parentContainer;
		
		this.initUI();
		
		UiHelper.setAriaLabel(this.btnAdd, Aria.get("Quest_questionRule_AND_add"));
		UiHelper.setAriaLabel(this.btnRemove, Aria.get("Quest_questionRule_remove"));
		
		final boolean isNewQuestion = (questionnaire.getQuestions(false).indexOf(question) == -1);
		
		if(isNewQuestion)
		{
			this.cboQuestionChooser.setItems(
				questionnaire.getQuestions(false).stream().filter(
					qu -> (qu.getCategory() != null
						&& qu.getCategory().equals(UI.getCurrent().getSession().getAttribute(QuestionCategory.class)))
						&& (qu instanceof MultiOptionQuestion || qu instanceof SingleOptionQuestion)
						&& !qu.equals(this.question)).collect(
							Collectors.toList()));
		}
		else
		{
			this.cboQuestionChooser.setItems(
				questionnaire.getQuestions(false).stream().filter(
					qu -> (qu.getCategory() != null
						&& qu.getCategory().equals(UI.getCurrent().getSession().getAttribute(QuestionCategory.class)))
						&& (qu instanceof MultiOptionQuestion || qu instanceof SingleOptionQuestion)
						&& !qu.equals(this.question)
						&& questionnaire.getQuestions(false).indexOf(qu) < questionnaire.getQuestions(false).indexOf(
							question)).collect(
								Collectors.toList()));
		}
		
	}
	
	public BeanRuleComponent(
		final Questionnaire questionnaire,
		final Question question,
		final VerticalLayout parentContainer,
		final ConditionObject condition)
	{
		super();
		this.questionnaire = questionnaire;
		this.question = question;
		this.parentContainer = parentContainer;
		this.condition = condition;
		
		this.initUI();
		
		this.cboQuestionChooser.setItems(
			questionnaire.getQuestions(false).stream().filter(
				qu -> (qu instanceof MultiOptionQuestion || qu instanceof SingleOptionQuestion)
					&& !qu.equals(this.question)
					&& questionnaire.getQuestions(false).indexOf(qu) < questionnaire.getQuestions(false).indexOf(
						question)).collect(
							Collectors.toList()));
		
		this.cboQuestionChooser.setValue(condition.getQuestion(false));
		this.cboChoosedValue.setValue(condition.getValue());
	}
	
	public void setConnectorVisible(final Boolean b)
	{
		this.label.setVisible(b);
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnAdd}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnAdd_onClick(final ClickEvent<Button> event)
	{
		if(this.cboQuestionChooser.getValue() != null && this.cboChoosedValue.getValue() != null)
		{
			final BeanRuleComponent ruleComponent =
				new BeanRuleComponent(this.questionnaire, this.question, this.parentContainer);
			ruleComponent.setWidthFull();
			ruleComponent.setConnectorVisible(true);
			this.parentContainer.add(ruleComponent);
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnRemove}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnRemove_onClick(final ClickEvent<Button> event)
	{
		if(this.getCSSContainerComponentCount() <= 1 && this.parentContainer.getComponentCount() < 2)
		{
			this.cboQuestionChooser.setValue(null);
			this.cboChoosedValue.setValue(null);
		}
		else
		{
			this.parentContainer.remove(this);
			
			if(this.parentContainer.getComponentCount() <= 0)
			{
				final BeanRuleGroupContainer groupToDelete =
					UIUtils.getNextParent(this.parentContainer, BeanRuleGroupContainer.class);
				groupToDelete.getBaseTarget().remove(groupToDelete);
			}
		}
	}
	
	private int getCSSContainerComponentCount()
	{
		return UIUtils.getNextParent(this, BeanRuleGroupContainer.class).getBaseTarget().getComponentCount();
	}
	
	public ConditionObject getCondition()
	{
		if(this.cboQuestionChooser.getValue() != null && this.cboChoosedValue.getValue() != null)
		{
			return new ConditionObject(
				new Pair<Integer, Integer>(this.questionnaire.getQuestionnaireID(), this.cboQuestionChooser.getValue().getId()),
				this.cboQuestionChooser.getValue(),
				this.cboChoosedValue.getValue()
				);
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #cboChoosedValue}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void cboChoosedValue_valueChanged(
		final ComponentValueChangeEvent<ComboBox<ChooseableValues>, ChooseableValues> event)
	{
		if(event.getValue() != null)
		{
			this.btnAdd.setEnabled(true);
		}
		else
		{
			this.btnAdd.setEnabled(false);
		}
	}
	
	/**
	 * Event handler delegate method for the {@link ComboBox} {@link #cboQuestionChooser}.
	 *
	 * @see HasValue.ValueChangeListener#valueChanged(HasValue.ValueChangeEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void cboQuestionChooser_valueChanged(final ComponentValueChangeEvent<ComboBox<Question>, Question> event)
	{
		if(event.getValue() != null)
		{
			final Question bean = this.cboQuestionChooser.getValue();
			if(bean instanceof MultiOptionQuestion)
			{
				this.cboChoosedValue.setItems(((MultiOptionQuestion)bean).getValues());
			}
			else if(bean instanceof SingleOptionQuestion)
			{
				this.cboChoosedValue.setItems(((SingleOptionQuestion)bean).getValues());
			}
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.label = new Label();
		this.cboQuestionChooser = new ComboBox<>();
		this.cboChoosedValue = new ComboBox<>();
		this.btnRemove = new Button();
		this.btnAdd = new Button();
		
		this.setMinHeight("40px");
		this.label.setText("And");
		this.cboQuestionChooser.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(Question::getQuestionText));
		this.cboChoosedValue.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(ChooseableValues::getText));
		this.btnRemove.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnRemove.setIcon(VaadinIcon.MINUS.create());
		this.btnAdd.addThemeVariants(ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ICON);
		this.btnAdd.setIcon(VaadinIcon.PLUS.create());
		
		this.label.setSizeUndefined();
		this.cboQuestionChooser.setSizeUndefined();
		this.cboChoosedValue.setSizeUndefined();
		this.btnRemove.setSizeUndefined();
		this.btnAdd.setSizeUndefined();
		this.add(this.label, this.cboQuestionChooser, this.cboChoosedValue, this.btnRemove, this.btnAdd);
		this.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.setFlexGrow(1.0, this.cboQuestionChooser);
		this.setFlexGrow(1.0, this.cboChoosedValue);
		this.setWidthFull();
		this.setHeight(null);
		
		this.cboQuestionChooser.addValueChangeListener(this::cboQuestionChooser_valueChanged);
		this.cboChoosedValue.addValueChangeListener(this::cboChoosedValue_valueChanged);
		this.btnRemove.addClickListener(this::btnRemove_onClick);
		this.btnAdd.addClickListener(this::btnAdd_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private ComboBox<Question>			cboQuestionChooser;
	private Button						btnRemove, btnAdd;
	private ComboBox<ChooseableValues>	cboChoosedValue;
	private Label						label;
	// </generated-code>
	
}
