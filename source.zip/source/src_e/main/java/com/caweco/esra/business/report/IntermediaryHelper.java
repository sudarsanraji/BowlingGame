package com.caweco.esra.business.report;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.caweco.esra.business.utils.IntUtils;
import com.caweco.esra.business.utils.Pair;
import com.caweco.esra.entities.rest.general.Intermediary;

/*
 * Intermediaries#intermediaries is actually a recursive graph instead of a flat list/map. 
 * To help make recursive subreports in jasper, 
 * this helper was created. We create the actual tree out of the flat map.
 */
public class IntermediaryHelper {
	public static IntermediaryHelper createIntermediaryTree(final Map<String, Intermediary> intermediaries) {
		final List<Intermediary> sorted = createSortedIntermediaryList(intermediaries);
		IntermediaryHelper previous = createHelperFromIntermediary(sorted.get(0), null);

		for (int i = 1; i < sorted.size(); i++) {
			previous = createHelperFromIntermediary(sorted.get(i), previous);
		}

		return previous;
	}

	private static IntermediaryHelper createHelperFromIntermediary(final Intermediary i,
			final IntermediaryHelper inner) {
		return new IntermediaryHelper(i.getName(), i.getBvdId(), i.getType(), i.getAddress(), i.getCity(),
				i.getPostcode(), i.getCountry(), i.getWebsite(), i.getIsListed(), i.getDirectPercentage(),
				i.getTotalPercentage(), inner);
	}

	// Creates a sorted map in reverse order
	private static List<Intermediary> createSortedIntermediaryList(final Map<String, Intermediary> intermediaries) {
		// The number is at the end and there is probably never going to be more than
		// 9999 entries anyways...
		return intermediaries.entrySet().stream()
				.map(e -> new Pair<>(IntUtils.parseIntFromStringWithChars(
						e.getKey().substring(e.getKey().length() - 4, e.getKey().length())), e.getValue()))
				.sorted((a, b) -> b.getFirst().compareTo(a.getFirst())).map(Pair::getSecond)
				.collect(Collectors.toList());
	}

	private final String name;
	private final String bvdId;
	private final String type;
	private final String address;
	private final String city;
	private final String postcode;
	private final String country;
	private final String website;
	private final String isListed;
	private final String directPercentage;
	private final String totalPercentage;
	private final IntermediaryHelper subentry;

	public IntermediaryHelper(String name, String bvdId, String type, String address, String city, String postcode,
			String country, String website, String isListed, String directPercentage, String totalPercentage,
			IntermediaryHelper subentry) {
		this.name = name;
		this.bvdId = bvdId;
		this.type = type;
		this.address = address;
		this.city = city;
		this.postcode = postcode;
		this.country = country;
		this.website = website;
		this.isListed = isListed;
		this.directPercentage = directPercentage;
		this.totalPercentage = totalPercentage;
		this.subentry = subentry;
	}

	public String getName() {
		return name;
	}

	public String getBvdId() {
		return bvdId;
	}

	public String getType() {
		return type;
	}

	public String getAddress() {
		return address;
	}

	public String getCity() {
		return city;
	}

	public String getPostcode() {
		return postcode;
	}

	public String getCountry() {
		return country;
	}

	public String getWebsite() {
		return website;
	}

	public String getIsListed() {
		return isListed;
	}

	public String getDirectPercentage() {
		return directPercentage;
	}

	public String getTotalPercentage() {
		return totalPercentage;
	}

	public IntermediaryHelper getSubentry() {
		return subentry;
	}
}
