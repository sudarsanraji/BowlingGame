package com.caweco.esra.business.report;

public class CIResponseWrapper
{
	private final ReportCIResponse response;

	public CIResponseWrapper(final ReportCIResponse response)
	{
		this.response = response;
	}

	public ReportCIResponse getResponse()
	{
		return this.response;
	}
}
