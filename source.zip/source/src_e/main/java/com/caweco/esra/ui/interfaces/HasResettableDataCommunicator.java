package com.caweco.esra.ui.interfaces;

/**
 * 
 * Workaround for Vaadin issue 7152: "Component inside a Grid becomes unusable after removeAll and readding".<br />
 * <p>
 * This is the case e.g. in Watchlist: When a Watchlistelement's flag changes from red to green ore green to red the
 * element is removed and added to another place.
 * </p>
 * 
 * @see <a href="https://github.com/vaadin/flow/issues/7152">https://github.com/vaadin/flow/issues/7152</a>
 */
public interface HasResettableDataCommunicator
{
	public void resetDataCommunicators();
}
