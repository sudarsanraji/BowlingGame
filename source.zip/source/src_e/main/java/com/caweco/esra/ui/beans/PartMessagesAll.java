package com.caweco.esra.ui.beans;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections4.iterators.ReverseListIterator;
import org.tinylog.Logger;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.utils.CollectionUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.messaging.MessageDAO;
import com.caweco.esra.dao.messaging.MessageGroupDAO;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.messaging.HasMessages;
import com.caweco.esra.entities.messaging.Message;
import com.caweco.esra.entities.messaging.MessageGroup;
import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.shared.Registration;
import com.caweco.esra.ui.broadcaster.Broadcaster;


@SuppressWarnings("serial")
public class PartMessagesAll<T extends HasMessages> extends VerticalLayout
{
	


	private int           initialElementNumber = 5;
	
	private List<Message> messages;
	private boolean       withDeleteButton     = false;
	private boolean       isClear              = true;
	private T             item;
	private MessageGroup  group;
	private Screening     screening;
	
	private Registration  broadcasterRegistration;
	
	public PartMessagesAll(T item)
	{
		super();
		this.initUI();
		
		this.item = item;
	}
	
	@Override
	protected void onAttach(AttachEvent attachEvent)
	{		
		final UI ui = attachEvent.getUI();
		
		this.broadcasterRegistration = Broadcaster.register((newMessage, group) ->
		{
			ui.access(() -> this.handleNewEntry(newMessage, group));
		});
		super.onAttach(attachEvent);
	}
	
	@Override
	protected void onDetach(DetachEvent detachEvent)
	{
		if (broadcasterRegistration != null) {
			broadcasterRegistration.remove();
		}
		super.onDetach(detachEvent);
	}
	
	
	/**
	 * The "messages" list must be persistable if "withDeleteButton" is true! <br />
	 * "group" parameter <b>not</b> necessary for private messages, "screening" parameter <b>only</b> necessary for private
	 * messages
	 * 
	 * @param messages
	 * @param withDeleteButton
	 * @param group            parameter <b>not</b> necessary for private messages
	 * @param screening        parameter <b>only</b> necessary for private messages
	 * @return the Component
	 */
	public PartMessagesAll<T> setItems(List<Message> messages, boolean withDeleteButton, MessageGroup group, Screening screening)
	{
		//// CLEANUP if necessary
		if (!this.isClear)
		{
			this.reset();
		}
		
		//// MESSAGES
		
		this.messages = messages;
		this.withDeleteButton = withDeleteButton;
		
		this.screening = screening;
		this.group = group;
		
		showMessages(true);
		if (group != null)
		{
			updateGroupReadMessagesTimestamp();
		}
		
		this.isClear = false;
		return this;
	}
	
	/**
	 * Saves current timestamp as "last read timestamp".
	 * 
	 * @return
	 */
	private void updateGroupReadMessagesTimestamp()
	{
		MessageGroupDAO.updateGroupLastReadMessagesTimestamp(this.group, CurrentUtil.getUser());
	}
	
	
	/**
	 * 
	 * Just updates the GUI and adds this message.
	 * 
	 * @param newMessage
	 * @param groupOfNewMessage
	 */
	public void handleNewEntry(final Message newMessage, final MessageGroup groupOfNewMessage)
	{
		if (this.group == null && groupOfNewMessage == null)
		{
			// private messages
			addElement(newMessage, true);
		}
		else if (this.group != null && groupOfNewMessage != null && Objects.equals(groupOfNewMessage.getId(), this.group.getId()))
		{
			// Group message. Normally added via broadcast
			addElement(newMessage, true);
		}
		else {
			Logger.debug("Ignore new message. Current group id {} does not fit to group id of message ({}).", 
				this.group == null ? "NONE" : this.group.getId(),
					groupOfNewMessage == null ? "NONE" : groupOfNewMessage.getId());
		}
	}
	
	
	/**
	 * <p>
	 * Resets the component. <br />
	 * Removes data and resets settings to initial state.
	 * </p>
	 */
	public void reset()
	{
		//// DATA
		withDeleteButton = false;
		messages = null;
		
		//// GUI
		this.messageHolder.removeAll();
		this.btnViewAll.setVisible(true);
		this.btnViewAll.setEnabled(false);
		
		//// flag
		isClear = true;
	}
	
	public int getInitialElementNumber()
	{
		return this.initialElementNumber;
	}
	
	/**
	 * Sets the number of visible messages at the beginning.
	 * 
	 * @param initialElementNumber
	 */
	public void setInitialElementNumber(final int initialElementNumber)
	{
		this.initialElementNumber = initialElementNumber;
	}
	
	/////////////
	//// INTERNAL
	
	/**
	 * Internal:
	 * <p>
	 * First, removes existing GUI components for Messages.<br />
	 * Then shows messages: if "limit" is true the last n messages, or otherwise all available messages of the list.
	 * </p>
	 * <p>
	 * The number of elements (n) is defined by "startElementNumber".<br />
	 * Uses {@link MessageManager#addElements(List, boolean)} to iterate add MessageCssElement elements.
	 * </p>
	 * 
	 * @param limit the "limit" flag to determine if all Messages have to be shown or a limited number.
	 */
	protected void showMessages(final boolean limit)
	{
		this.messageHolder.removeAll();
		
		List<Message> messagesEffective  = messages != null ? messages : new ArrayList<Message>();
		
		//// View all button
		int availableItemsSize = (messages != null) ? messages.size() : 0;
		
		if (limit)
		{
			messagesEffective = CollectionUtil.getLastNElements(messages, this.initialElementNumber);
			
			this.btnViewAll.setVisible(true);
			if (availableItemsSize > this.initialElementNumber)
			{
				// more elements available
				this.btnViewAll.setEnabled(true);
			}
			else
			{
				this.btnViewAll.setEnabled(false);
			}
		}
		else
		{
			this.btnViewAll.setVisible(false);
		}
		
		addElements(messagesEffective);
	}
	
	/**
	 * Removes message from storage and GUI.
	 * <p>
	 * <b>Only for private messages!</b>
	 * </p>
	 * 
	 * @param m the message to remove
	 */
	protected void removeElement(final PartMessageSingle m)
	{
		if (group != null)
		{
			MessageDAO.deleteMessage(this.messages, m.getMessageItem(), group);
		}
		else
		{
			MessageDAO.deleteNote(this.messages, CurrentUtil.getClient(), screening, m.getMessageItem());
		}
		this.messageHolder.remove(m);
		
		Notificator.success("Message deleted!");
	}
	
	/**
	 * Internal: Iterate over given "input" list in reverse order, and add MessageCssElement for each. <br />
	 * Uses {@link MessageManager#addElement(RadarMessage, boolean, boolean)}
	 * 
	 * @param input
	 */
	protected void addElements(final List<Message> input)
	{
		
		ReverseListIterator<Message> reverseListIterator = new ReverseListIterator<>(input);
		while (reverseListIterator.hasNext())
		{
			addElement(reverseListIterator.next(), false);
		}
	}
	
	/**
	 * Internal: Create PartMessageSingle component for a Message and add to holder layout.
	 * 
	 * @param m       the Message
	 * @param asFirst Add as first element if set
	 */
	protected void addElement(final Message m, final boolean asFirst)
	{
		PartMessageSingle mE = buildElement(m, withDeleteButton);
		if (asFirst)
		{
			this.messageHolder.addComponentAsFirst(mE);
		}
		else
		{
			this.messageHolder.add(mE);
		}
	}
	
	/**
	 * Creates a new PartMessageSingle with or without "delete" button.
	 * 
	 * @param m                the Message
	 * @param withDeleteButton
	 * @return the PartMessageSingle component
	 */
	protected PartMessageSingle buildElement(final Message m, final boolean withDeleteButton)
	{
		if (withDeleteButton)
		{
			PartMessageSingle mE = new PartMessageSingle(m, this::removeElement);
			return mE;
		}
		else
		{
			PartMessageSingle mE = new PartMessageSingle(m, false);
			return mE;
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnViewAll}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnViewAll_onClick(final ClickEvent<Button> event)
	{
		this.btnViewAll.setEnabled(false);
		this.hr2.setVisible(false);
		showMessages(false);
	}
	
	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.btnViewAll = new Button();
		this.hr2 = new Hr();
		this.messageHolder = new VerticalLayout();
		
		this.setSpacing(false);
		this.setPadding(false);
		this.btnViewAll.setText("VIEW ALL");
		this.btnViewAll.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.messageHolder.setPadding(false);
		this.messageHolder.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.messageHolder.getStyle().set("overflow-x", "hidden");
		this.messageHolder.getStyle().set("overflow-y", "auto");
		
		this.btnViewAll.setSizeUndefined();
		this.hr2.setSizeUndefined();
		this.messageHolder.setSizeUndefined();
		this.add(this.btnViewAll, this.hr2, this.messageHolder);
		this.setHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH, this.messageHolder);
		this.setFlexGrow(1.0, this.messageHolder);
		this.setSizeFull();
		
		this.btnViewAll.addClickListener(this::btnViewAll_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button         btnViewAll;
	private VerticalLayout messageHolder;
	private Hr             hr2;
	// </generated-code>
	
}
