package com.caweco.esra.entities.questionnaire;

import java.time.LocalDate;


public class DateChooserAnswer extends Answer
{
	private LocalDate datetime;
	
	public DateChooserAnswer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	public LocalDate getDatetime()
	{
		return this.datetime;
	}
	
	public void setDatetime(final LocalDate datetime)
	{
		this.datetime = datetime;
	}
	
}
