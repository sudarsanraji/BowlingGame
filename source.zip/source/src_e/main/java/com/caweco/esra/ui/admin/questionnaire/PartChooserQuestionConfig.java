package com.caweco.esra.ui.admin.questionnaire;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.tuple.Pair;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.QuestionnaireUtils;
import com.caweco.esra.dao.questionnaire.QuestionDAO;
import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.HasChooseableValues;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.QuestionnaireCategory;
import com.caweco.esra.ui.admin.questionnaire.dialogs.DialogQuestionCreate;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.rapidclipse.framework.server.resources.CaptionUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.ColumnTextAlign;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.grid.dnd.GridDragEndEvent;
import com.vaadin.flow.component.grid.dnd.GridDragStartEvent;
import com.vaadin.flow.component.grid.dnd.GridDropEvent;
import com.vaadin.flow.component.grid.dnd.GridDropMode;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.selection.SelectionListener;

public class PartChooserQuestionConfig extends VerticalLayout
{
	private ChooseableValues chooseableValue;
	private List<ChooseableValues> choosableValuesListCopy = new ArrayList<ChooseableValues>();
	private final Pair<Questionnaire, Boolean> item;
	private boolean questionExists = false;

	private final DialogQuestionCreate parent;

	/**
	 * 
	 */
	public PartChooserQuestionConfig(final DialogQuestionCreate parent)
	{
		super();
		this.parent = parent;
		this.initUI();

		final Optional<Pair<Questionnaire, Boolean>> it = CurrentUtil.fromSession("overviewCurrentQuestionnaire");
		this.item = it.get();

		this.nrWeight.setVisible(!this.item.getLeft().getCategory().equals(QuestionnaireCategory.BUSINESS_INFORMATION));
		this.btnRemove.setVisible(!this.item.getRight());
	}

	/**
	 * This is only called for existing Questions!
	 * 
	 * @param <T>
	 * @param question
	 */
	public <T extends Question & HasChooseableValues> void readBean(final T question)
	{
		this.binder.readBean(question);
		this.questionExists = true;

		if (question.getValues() != null)
		{
			this.choosableValuesListCopy = new ArrayList<ChooseableValues>(question.getValues());
		}
		else
		{
			this.choosableValuesListCopy = new ArrayList<ChooseableValues>();
		}

		this.gridChooseableValues.setItems(this.choosableValuesListCopy);
	}

	public <T extends Question & HasChooseableValues> void writeBean(final T question) throws ValidationException
	{
		this.binder.writeBean(question);
		question.setValues(this.choosableValuesListCopy);
	}
	
	public List<ChooseableValues> getAnswers()
	{
		return this.choosableValuesListCopy;
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnAdd}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnAdd_onClick(final ClickEvent<Button> event)
	{
		if (this.chooseableValue != null)
		{
			this.chooseableValue.setText(this.txtValue.getValue());
			this.chooseableValue.setValue(this.nrWeight.getValue().intValue());

			QuestionDAO.update(this.parent.getQuestionnaire(), this.parent.getQuestion());

			this.gridChooseableValues.getDataProvider().refreshAll();
		}
		else
		{
			final ChooseableValues newChooseableValue = new ChooseableValues(
				this.txtValue.getValue(),
				this.nrWeight.getValue().intValue()
			);

			if (this.questionExists == false)
			{
				newChooseableValue.setId(QuestionDAO.getNextChooseableValueID(this.choosableValuesListCopy));
			}
			this.choosableValuesListCopy.add(newChooseableValue);

			QuestionDAO.update(this.parent.getQuestionnaire(), this.parent.getQuestion());

			this.gridChooseableValues.setItems(this.choosableValuesListCopy);

		}

		this.gridChooseableValues.select(null);

		this.txtValue.clear();
		this.nrWeight.setValue(0d);

		this.txtValue.focus();
		
		this.parent.checkValidity();
	}

	/**
	 * Event handler delegate method for the {@link Grid}
	 * {@link #gridChooseableValues}.
	 *
	 * @see SelectionListener#selectionChange(SelectionEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridChooseableValues_selectionChange(final SelectionEvent<Grid<ChooseableValues>, ChooseableValues> event)
	{
		final Optional<ChooseableValues> cvO = event.getFirstSelectedItem();
		this.chooseableValue = cvO.orElse(null);

		if (cvO.isPresent())
		{
			this.txtValue.setValue(this.chooseableValue.getText());
			this.nrWeight.setValue(this.chooseableValue.getValue().doubleValue());
			this.btnAdd.setText("Save");
			this.btnAdd.setIcon(IronIcons.SAVE.create());

		}
		else
		{
			this.btnAdd.setText("Add");
			this.btnAdd.setIcon(VaadinIcon.PLUS.create());

			this.txtValue.clear();
			this.nrWeight.setValue(0d);
		}

		if (cvO.isPresent())
		{
			final Question question = this.parent.getQuestion();
			Optional<Question> firstOtherQuestionWithARuleWithThisChooseableValues = Optional.empty();

			if (question != null && question.getCategory() != null)
			{

				final List<Question> questionsByCategory = QuestionDAO.findByCategory(
					this.item.getLeft(),
					question.getCategory()
				);
				firstOtherQuestionWithARuleWithThisChooseableValues =
				// @formatter:off
					questionsByCategory.stream()
					.filter(q -> !q.equals(question))
					.filter(q -> QuestionnaireUtils.hasMatchingRule(q, cvO.get()))
					.findFirst();
					// @formatter:on

			}
			this.btnRemove.setEnabled(!firstOtherQuestionWithARuleWithThisChooseableValues.isPresent());
		}
		else
		{
			this.btnRemove.setEnabled(false);
		}
	}

	/**
	 * Event handler delegate method for the {@link Grid}
	 * {@link #gridChooseableValues}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridChooseableValues_onGridDragStart(final GridDragStartEvent<ChooseableValues> event)
	{
		this.chooseableValue = event.getDraggedItems().get(0);
		this.gridChooseableValues.setDropMode(GridDropMode.BETWEEN);
	}

	/**
	 * Event handler delegate method for the {@link Grid}
	 * {@link #gridChooseableValues}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridChooseableValues_onGridDrop(final GridDropEvent<ChooseableValues> event)
	{
		final Optional<ChooseableValues> dropTargetItem = event.getDropTargetItem();

		QuestionDAO.reorderChooseableValues(
			this.item.getKey(),
			this.parent.getQuestion(),
			this.choosableValuesListCopy,
			this.chooseableValue,
			dropTargetItem.get(),
			event.getDropLocation()
		);

		this.gridChooseableValues.setItems(this.choosableValuesListCopy);
	}

	/**
	 * Event handler delegate method for the {@link Grid}
	 * {@link #gridChooseableValues}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void gridChooseableValues_onGridDragEnd(final GridDragEndEvent<ChooseableValues> event)
	{
		this.chooseableValue = null;
		this.gridChooseableValues.setDropMode(null);
	}

	/**
	 * Event handler delegate method for the {@link Button} {@link #btnRemove}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnRemove_onClick(final ClickEvent<Button> event)
	{
		final Optional<ChooseableValues> cvO = this.gridChooseableValues.getSelectionModel().getFirstSelectedItem();
		if (cvO.isPresent())
		{

			this.choosableValuesListCopy.remove(cvO.get());
			this.gridChooseableValues.setItems(this.choosableValuesListCopy);
			this.gridChooseableValues.select(null);
		}
		
		this.parent.checkValidity();

	}

	/*
	 * WARNING: Do NOT edit!<br>The content of this method is always regenerated by
	 * the UI designer.
	 */
	// <generated-code name="initUI">
	private void initUI() {
		this.label = new Label();
		this.gridChooseableValues = new Grid<>(ChooseableValues.class, false);
		this.horizontalLayout = new HorizontalLayout();
		this.txtValue = new TextField();
		this.nrWeight = new NumberField();
		this.btnAdd = new Button();
		this.btnRemove = new Button();
		this.binder = new Binder<>();
	
		this.setSpacing(false);
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.getStyle().set("margin", "var(--lumo-space-xs) 0");
		this.label.setText("Choosable values");
		this.gridChooseableValues.setRowsDraggable(true);
		this.gridChooseableValues.setMinHeight("130px");
		this.gridChooseableValues.setMaxHeight("200px");
		this.gridChooseableValues.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
		this.gridChooseableValues.getStyle().set("flex-basis", "0");
		this.gridChooseableValues.addColumn(ChooseableValues::getText).setKey("text")
				.setHeader(CaptionUtils.resolveCaption(ChooseableValues.class, "text")).setSortable(true);
		this.gridChooseableValues.addColumn(ChooseableValues::getValue).setKey("value")
				.setHeader(CaptionUtils.resolveCaption(ChooseableValues.class, "value")).setSortable(true).setFlexGrow(0)
				.setTextAlign(ColumnTextAlign.END);
		this.gridChooseableValues.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.txtValue.setPlaceholder("Add chooseable value here");
		this.nrWeight.setAutoselect(true);
		this.nrWeight.setValue(0.0);
		this.btnAdd.setText("Add");
		this.btnAdd.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnAdd.setIcon(VaadinIcon.PLUS.create());
		this.btnRemove.setText("Remove");
		this.btnRemove.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
		this.btnRemove.setIcon(VaadinIcon.TRASH.create());
	
		this.txtValue.setSizeUndefined();
		this.nrWeight.setSizeUndefined();
		this.btnAdd.setWidth("120px");
		this.btnAdd.setHeight(null);
		this.btnRemove.setWidth("120px");
		this.btnRemove.setHeight(null);
		this.horizontalLayout.add(this.txtValue, this.nrWeight, this.btnAdd, this.btnRemove);
		this.horizontalLayout.setFlexGrow(1.0, this.txtValue);
		this.label.setSizeUndefined();
		this.gridChooseableValues.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.label, this.gridChooseableValues, this.horizontalLayout);
		this.setFlexGrow(1.0, this.gridChooseableValues);
		this.setWidthFull();
		this.setHeight(null);
	
		this.gridChooseableValues.addSelectionListener(this::gridChooseableValues_selectionChange);
		this.gridChooseableValues.addDragStartListener(this::gridChooseableValues_onGridDragStart);
		this.gridChooseableValues.addDropListener(this::gridChooseableValues_onGridDrop);
		this.gridChooseableValues.addDragEndListener(this::gridChooseableValues_onGridDragEnd);
		this.btnAdd.addClickListener(this::btnAdd_onClick);
		this.btnRemove.addClickListener(this::btnRemove_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button btnAdd, btnRemove;
	private Binder<Question> binder;
	private NumberField nrWeight;
	private HorizontalLayout horizontalLayout;
	private Label label;
	private Grid<ChooseableValues> gridChooseableValues;
	private TextField txtValue;
	// </generated-code>

}
