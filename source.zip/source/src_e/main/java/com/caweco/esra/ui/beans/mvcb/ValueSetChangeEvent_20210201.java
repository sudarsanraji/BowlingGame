package com.caweco.esra.ui.beans.mvcb;

import com.vaadin.flow.component.ComponentEvent;


@SuppressWarnings("rawtypes")
public class ValueSetChangeEvent_20210201 extends ComponentEvent<MultiValueComboBox_20210201>
{
	private static final long serialVersionUID = 1L;
	
	public ValueSetChangeEvent_20210201(
		MultiValueComboBox_20210201 source,
		boolean fromClient)
	{
		super(source, fromClient);
	}
}
