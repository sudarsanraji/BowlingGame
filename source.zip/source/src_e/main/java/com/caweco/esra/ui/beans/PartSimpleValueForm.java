package com.caweco.esra.ui.beans;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.entities.Client;
import com.flowingcode.vaadin.addons.ironicons.IronIcons;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.InputEvent;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.component.grid.GridSortOrder;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.Setter;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.selection.SelectionEvent;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializableBiFunction;
import com.vaadin.flow.function.SerializableConsumer;
import com.vaadin.flow.function.SerializableFunction;
import com.vaadin.flow.function.SerializableRunnable;
import com.vaadin.flow.function.ValueProvider;


public class PartSimpleValueForm<T> extends VerticalLayout
{
	private Grid<T>					grid2	= new Grid<>();
	private Binder<T>				binder2	= new Binder<>();
	
	private final Collection<T>		items;
	private T						item;
	
	SerializableFunction<String, T>	itemBuilder;
	Setter<T, String>				setter;
	ValueProvider<T, String>		getter	= it -> it.toString();
	
	SerializableRunnable			onItemsetChange;
	
	private SerializableBiFunction<T, Client, Boolean> deletableRule;
	private Client                                     client;
	
	private SerializableConsumer<T> saveExistingMethod;
	private SerializableConsumer<T> deleteExistingMethod;
	private SerializableConsumer<T> saveNewMethod;
	
	
	public PartSimpleValueForm(
		SerializableFunction<String, T> itemBuilder,
		Setter<T, String> setter,
		ValueProvider<T, String> getter,
		final String name,
		final Collection<T> items,
	 SerializableConsumer<T> saveExistingMethod,
	 SerializableConsumer<T> deleteExistingMethod,	 
	 SerializableConsumer<T> saveNewMethod)
	{
		super();
		Objects.requireNonNull(itemBuilder);
		Objects.requireNonNull(getter);
		Objects.requireNonNull(setter);
		this.items = items;
		this.itemBuilder = itemBuilder;
		this.setter = setter;
		this.getter = getter;
		this.saveExistingMethod = saveExistingMethod;
		this.saveNewMethod = saveNewMethod;
		this.deleteExistingMethod = deleteExistingMethod;
		
		this.initUI();
		
		this.grid2.setSizeUndefined();
		this.grid2.getElement().getStyle().set("flex-basis", "0");
		this.grid2.addThemeVariants(
			GridVariant.LUMO_ROW_STRIPES,
			GridVariant.LUMO_COMPACT,
			GridVariant.LUMO_WRAP_CELL_CONTENT);
		
		// @formatter:off
		Column<T> representationCol = this.grid2.addColumn(it -> this.getter.apply(it))
			.setKey("representation").setSortable(true)
			.setAutoWidth(true).setFlexGrow(1);
		// @formatter:on
		
		this.grid2.sort(GridSortOrder.asc(representationCol).build());
		
		this.grid2.setSelectionMode(Grid.SelectionMode.SINGLE);
		this.grid2.setItems(items);
		this.grid2.addSelectionListener(this::grid2_selectionChange);
		
		this.replace(this.div, this.grid2);
		this.setFlexGrow(1.0, this.grid2);
		
		this.lblType.setText(name);
		
		this.binder2.forField(this.txtName).withNullRepresentation("").bind(this.getter, this.setter);
		
		this.setNewItemToForm();
		
		UiHelper.setAriaLabel(this.btnNew, Aria.get("Values_add"));
		UiHelper.setAriaLabel(this.btnDelete, Aria.get("Values_remove"));
		UiHelper.setAriaLabel(this.btnSave, Aria.get("Values_save"));
	}
	
	public PartSimpleValueForm<T> setOnItemsetChange(SerializableRunnable onItemsetChange)
	{
		this.onItemsetChange = onItemsetChange;
		return this;
	}
	
	public PartSimpleValueForm<T> withDeleteButton()
	{
		this.btnDelete.setVisible(true);
		return this;
	}
	
	public PartSimpleValueForm<T> withDeletableRule(SerializableBiFunction<T, Client, Boolean> deletableRule, Client client)
	{
		this.deletableRule = deletableRule;
		this.client = client;
		return this;
	}
	
	
	/*********************************************************/
	
	protected boolean evalSaveEnabled()
	{
		String value = StringUtils.stripToEmpty(this.txtName.getValue());
		boolean no1 = (value.length() >= 3);
		return no1;
	}
	
	protected void setNewItemToForm()
	{
		this.setItemToForm(this.itemBuilder.apply(""), true);
	}
	
	protected void setItemToForm(T item, boolean isNew)
	{
		this.item = item;
		this.binder2.readBean(this.item);
		this.btnSave.setEnabled(this.evalSaveEnabled());
		if (!isNew && this.deletableRule != null && this.client != null)
		{
			Boolean isDeletable = this.deletableRule.apply(this.item, this.client);
			this.btnDelete.setEnabled(BooleanUtils.isTrue(isDeletable));
		}
		else
		{
			this.btnDelete.setEnabled(!isNew);
		}
		this.txtName.focus();
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnSave}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnSave_onClick(final ClickEvent<Button> event)
	{
		try
		{
			this.binder2.writeBean(this.item);
			
			if(this.items.contains(this.item))
			{
				this.saveExistingMethod.accept(this.item);
				this.grid2.getDataProvider().refreshItem(this.item);
			}
			else
			{
				this.items.add(this.item);
				this.saveNewMethod.accept(this.item);
				this.grid2.getDataProvider().refreshAll();
				
				if(this.onItemsetChange != null)
				{
					this.onItemsetChange.run();
				}
			}
			
			this.setNewItemToForm();
		}
		catch(final ValidationException e)
		{
			e.printStackTrace();
		}
	}
	
	private void grid2_selectionChange(SelectionEvent<Grid<T>, T> event)
	{
		Optional<T> selected = event.getFirstSelectedItem();
		if (selected.isPresent())
		{
			this.setItemToForm(selected.get(), false);
		}
		else
		{
			this.setNewItemToForm();
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnNew}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnNew_onClick(final ClickEvent<Button> event)
	{
		this.grid2.deselectAll();
		this.setNewItemToForm();
	}
	
	/**
	 * Event handler delegate method for the {@link TextField} {@link #txtName}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void txtName_onInput(final InputEvent event)
	{
		this.btnSave.setEnabled(this.evalSaveEnabled());
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnDelete}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnDelete_onClick(ClickEvent<Button> event)
	{
		this.grid2.getSelectionModel().getFirstSelectedItem().ifPresent(it ->
		{
			this.items.remove(it);
			
			this.deleteExistingMethod.accept(this.item);
			this.grid2.getDataProvider().refreshAll();
			this.grid2.deselectAll();
			
			this.setNewItemToForm();
			
			if(this.onItemsetChange != null)
			{
				this.onItemsetChange.run();
			}
		});
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.horizontalLayout2 = new HorizontalLayout();
		this.lblType = new Label();
		this.btnDelete = new Button();
		this.btnNew = new Button();
		this.div = new Div();
		this.horizontalLayout = new HorizontalLayout();
		this.label = new Label();
		this.txtName = new TextField();
		this.btnSave = new Button();
		
		this.setSpacing(false);
		this.setMaxHeight("500px");
		this.setPadding(false);
		this.setDefaultHorizontalComponentAlignment(FlexComponent.Alignment.STRETCH);
		this.horizontalLayout2.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.lblType.setText("Label");
		this.btnDelete.setEnabled(false);
		this.btnDelete.setVisible(false);
		this.btnDelete.setIcon(VaadinIcon.TRASH.create());
		this.btnNew.setIcon(VaadinIcon.PLUS.create());
		this.horizontalLayout.setSpacing(false);
		this.horizontalLayout.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.CENTER);
		this.label.setText("Value");
		this.label.getStyle().set("margin-right", "10px");
		this.txtName.setValueChangeTimeout(0);
		this.txtName.setValueChangeMode(ValueChangeMode.TIMEOUT);
		this.btnSave.setEnabled(false);
		this.btnSave.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
		this.btnSave.setIcon(IronIcons.SAVE.create());
		
		this.lblType.setWidthFull();
		this.lblType.setHeight(null);
		this.btnDelete.setSizeUndefined();
		this.btnNew.setSizeUndefined();
		this.horizontalLayout2.add(this.lblType, this.btnDelete, this.btnNew);
		this.horizontalLayout2.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.lblType);
		this.label.setSizeUndefined();
		this.txtName.setWidthFull();
		this.txtName.setHeight(null);
		this.btnSave.setSizeUndefined();
		this.horizontalLayout.add(this.label, this.txtName, this.btnSave);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.CENTER, this.label);
		this.horizontalLayout.setVerticalComponentAlignment(FlexComponent.Alignment.END, this.btnSave);
		this.horizontalLayout2.setSizeUndefined();
		this.div.setSizeUndefined();
		this.horizontalLayout.setSizeUndefined();
		this.add(this.horizontalLayout2, this.div, this.horizontalLayout);
		this.setFlexGrow(1.0, this.div);
		this.setWidth("350px");
		this.setHeight(null);
		
		this.btnDelete.addClickListener(this::btnDelete_onClick);
		this.btnNew.addClickListener(this::btnNew_onClick);
		this.txtName.addInputListener(this::txtName_onInput);
		this.btnSave.addClickListener(this::btnSave_onClick);
	} // </generated-code>
	
	// <generated-code name="variables">
	private Button				btnDelete, btnNew, btnSave;
	private HorizontalLayout	horizontalLayout2, horizontalLayout;
	private Label				lblType, label;
	private Div					div;
	private TextField			txtName;
	// </generated-code>
	
}
