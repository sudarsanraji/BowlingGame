package com.caweco.esra.dao.questionnaire;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.QuestionResult;
import com.caweco.esra.entities.questionnaire.QuestionnaireResult;

public class QuestionResultDAO
{
	/**
	 * A {@link QuestionnaireResult} may contain {@link QuestionResult} items for Questions that do not belong to current Questionnaire.
	 * <br /> This method returns only those QuestionResult items that belong to the {@link Question}s of current Questionnaire.
	 * @param res a QuestionnaireResult
	 * @return a list of QuestionResult items
	 */
	public static List<QuestionResult> getQuestionResultsForCurrentQuestionnaireQuestions(final QuestionnaireResult res)
	{
		if (res.getQuestionnaire() == null || res.getResults() == null || res.getResults().isEmpty())
		{
			return Collections.emptyList();
		}
		
		List<QuestionResult> results = res.getResults();
		List<Question> questionsOfCurrentQuestionnaire = res.getQuestionnaire().getQuestions(true);
		List<QuestionResult> knownResults = results.stream().filter(qr -> questionsOfCurrentQuestionnaire.contains(qr.getQuestion())).collect(Collectors.toList());
		
		return knownResults;
	}
}
