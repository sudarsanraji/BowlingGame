package com.caweco.esra.entities.rest.information;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CIResponse
{
	private String							sessionHandle;
	private String[]						statusMessage;
	private String							companyBvdId;
	
	private CompanyInfo						companyInfoBvd;
	private CompanyGsssMatch				companyGsssMatchResults;
	private Map<String, CompanyGsssMatch>	benOwnGsssMatchResults	= new HashMap<>();
	private Map<String, CompanyGsssMatch>	interGsssMatchResults	= new HashMap<>();
	// CARA v5
	private CompanyGsssMatch				guoGsssMatchResults;
	
	private String							customField1;
	private String							customField2;
	private String							customField3;
	private String							customField4;
	private String							customField5;
	
	public CIResponse()
	{
		// Empty for Framework
	}
	
	public String getSessionHandle()
	{
		return this.sessionHandle;
	}
	
	public void setSessionHandle(final String sessionHandle)
	{
		this.sessionHandle = sessionHandle;
	}
	
	public String[] getStatusMessage()
	{
		return this.statusMessage;
	}
	
	public void setStatusMessage(final String[] statusMessage)
	{
		this.statusMessage = statusMessage;
	}
	
	public String getCompanyBvdId()
	{
		return this.companyBvdId;
	}
	
	public void setCompanyBvdId(final String companyBvdId)
	{
		this.companyBvdId = companyBvdId;
	}
	
	public CompanyInfo getCompanyInfoBvd()
	{
		return this.companyInfoBvd;
	}
	
	public void setCompanyInfoBvd(final CompanyInfo companyInfoBvd)
	{
		this.companyInfoBvd = companyInfoBvd;
	}
	
	public CompanyGsssMatch getCompanyGsssMatchResults()
	{
		return this.companyGsssMatchResults;
	}
	
	public void setCompanyGsssMatchResults(CompanyGsssMatch companyGsssMatchResults)
	{
		this.companyGsssMatchResults = companyGsssMatchResults;
	}
	
	public Map<String, CompanyGsssMatch> getBenOwnGsssMatchResults()
	{
		return this.benOwnGsssMatchResults;
	}
	
	public void setBenOwnGsssMatchResults(final Map<String, CompanyGsssMatch> benOwnGsssMatchResults)
	{
		this.benOwnGsssMatchResults = benOwnGsssMatchResults;
	}
	
	public Map<String, CompanyGsssMatch> getInterGsssMatchResults()
	{
		return this.interGsssMatchResults;
	}
	
	public void setInterGsssMatchResults(final Map<String, CompanyGsssMatch> interGsssMatchResults)
	{
		this.interGsssMatchResults = interGsssMatchResults;
	}
	
	public CompanyGsssMatch getGuoGsssMatchResults()
	{
		return this.guoGsssMatchResults;
	}
	
	public void setGuoGsssMatchResults(CompanyGsssMatch guoGsssMatchResults)
	{
		this.guoGsssMatchResults = guoGsssMatchResults;
	}
	
	public String getCustomField1()
	{
		return this.customField1;
	}
	
	public void setCustomField1(final String customField1)
	{
		this.customField1 = customField1;
	}
	
	public String getCustomField2()
	{
		return this.customField2;
	}
	
	public void setCustomField2(final String customField2)
	{
		this.customField2 = customField2;
	}
	
	public String getCustomField3()
	{
		return this.customField3;
	}
	
	public void setCustomField3(final String customField3)
	{
		this.customField3 = customField3;
	}
	
	public String getCustomField4()
	{
		return this.customField4;
	}
	
	public void setCustomField4(final String customField4)
	{
		this.customField4 = customField4;
	}
	
	public String getCustomField5()
	{
		return this.customField5;
	}
	
	public void setCustomField5(final String customField5)
	{
		this.customField5 = customField5;
	}

	@Override
	public String toString() {
		String companyGsssMatchResultsString = companyGsssMatchResults != null ? companyGsssMatchResults.toString()
				: "none";
		String companyInfoBvdString = companyInfoBvd != null ? companyInfoBvd.toString() : "none";
		String guoGsssMatchResultsString = guoGsssMatchResults != null ? guoGsssMatchResults.toString() : "none";
		return "CIResponse [sessionHandle=" + sessionHandle + ", statusMessage=" + Arrays.toString(statusMessage)
				+ ", companyBvdId=" + companyBvdId + ", companyInfoBvd=" + companyInfoBvdString + ", companyGsssMatchResults="
				+ companyGsssMatchResultsString + ", benOwnGsssMatchResults=" + benOwnGsssMatchResults
				+ ", interGsssMatchResults=" + interGsssMatchResults + ", guoGsssMatchResults=" + guoGsssMatchResultsString
				+ ", customField1=" + customField1 + ", customField2=" + customField2 + ", customField3=" + customField3
				+ ", customField4=" + customField4 + ", customField5=" + customField5 + "]";
	}
	
	
}
