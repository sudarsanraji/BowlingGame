
package com.caweco.esra.ui.dialogs;

import java.util.Objects;

import com.caweco.esra.ui.interfaces.DialogContent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.dom.Element;
import com.vaadin.flow.function.SerializableConsumer;
import com.vaadin.flow.function.SerializableRunnable;


public class DialogContentImpl<C extends Component> implements DialogContent
{
	
	private static final long serialVersionUID = 1L;
	
	public static <C extends Component> DialogContentImpl<C> New(final C content)
	{
		return new DialogContentImpl<>(content);
	}
	
	private final C							content;
	private SerializableConsumer<C>			onOk;
	private SerializableRunnable			onCancel;
	private SerializableConsumer<Throwable>	onException;
	
	private String							header		= "Select items";
	private String							textSave	= "Save";
	private String							textCancel	= "Cancel";
	
	private String							width		= null;
	private String							height		= null;
	
	public DialogContentImpl(final C content)
	{
		super();
		Objects.requireNonNull(content);
		this.content = content;
	}
	
	@Override
	public Element getElement()
	{
		return this.content.getElement();
	}
	
	public C getContent()
	{
		return this.content;
	}
	
	/**
	 * No further action.
	 */
	@Override
	public void cancel()
	{
		// No Action.
	}
	
	/**
	 * No further action.
	 */
	@Override
	public void save()
	{
		// No Action.
	}
	
	@Override
	public String getHeader()
	{
		return this.header;
	}
	
	@Override
	public String getConfirmButtonText()
	{
		return this.textSave;
	}
	
	@Override
	public String getCancelButtonText()
	{
		return this.textCancel;
	}
	
	/**
	 * Sets it's parent {@link DialogContainer#onOk(SerializableConsumer)} action.
	 * 
	 * @param onOk
	 * @return
	 */
	public DialogContentImpl<C> setOnOk(final SerializableConsumer<C> onOk)
	{
		this.onOk = onOk;
		return this;
	}
	
	/**
	 * Sets it's parent {@link DialogContainer#onCancel(Runnable)} action.
	 * 
	 * @param onCancel
	 * @return
	 */
	public DialogContentImpl<C> setOnCancel(final SerializableRunnable onCancel) // NO_UCD - getter
	{
		this.onCancel = onCancel;
		return this;
	}
	
	/**
	 * Sets it's parent {@link DialogContainer#exceptionally(SerializableConsumer)} action.
	 * 
	 * @param onException
	 * @return
	 */
	public DialogContentImpl<C> setOnException(final SerializableConsumer<Throwable> onException) // NO_UCD - getter
	{
		this.onException = onException;
		return this;
	}
	
	public DialogContentImpl<C> setTextHeader(final String header)
	{
		this.header = header;
		return this;
	}
	
	public DialogContentImpl<C> setTextSave(final String textSave) // NO_UCD - getter
	{
		this.textSave = textSave;
		return this;
	}
	
	public DialogContentImpl<C> setTextCancel(final String textCancel) // NO_UCD - getter
	{
		this.textCancel = textCancel;
		return this;
	}
	
	public DialogContentImpl<C> setWidth(final String width)
	{
		this.width = width;
		return this;
	}
	
	public DialogContentImpl<C> setHeight(final String height)
	{
		this.height = height;
		return this;
	}
	
	public DialogContainer<DialogContentImpl<C>> show()
	{
		// Compose Dialog
		final DialogContainer<DialogContentImpl<C>> dialogContainer = new DialogContainer<>(this);
		
		// Apply data/actions to parent
		dialogContainer.setWidth(this.width);
		dialogContainer.setHeight(this.height);
		if(onOk != null)
			dialogContainer.onOk(dci -> onOk.accept(dci.getContent()));
		if(onException != null)
			dialogContainer.exceptionally(onException);
		if(onCancel != null)
			dialogContainer.onCancel(onCancel);
		
		dialogContainer.open();
		return dialogContainer;
	}
	
}
