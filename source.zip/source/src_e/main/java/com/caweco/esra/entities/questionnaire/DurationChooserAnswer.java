package com.caweco.esra.entities.questionnaire;

import java.time.LocalDate;


public class DurationChooserAnswer extends Answer
{
	
	private LocalDate	start;
	private LocalDate	ende;
	
	public DurationChooserAnswer()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public LocalDate getStart()
	{
		return this.start;
	}
	
	public void setStart(final LocalDate start)
	{
		this.start = start;
	}
	
	public LocalDate getEnde()
	{
		return this.ende;
	}
	
	public void setEnde(final LocalDate ende)
	{
		this.ende = ende;
	}
	
}
