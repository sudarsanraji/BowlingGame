package com.caweco.esra.dto;

import java.util.Set;

import com.caweco.esra.entities.config.EsraClientConfiguration;
import com.caweco.esra.entities.core.ESUTemplate;
import com.caweco.esra.entities.core.Function;
import com.caweco.esra.entities.core.LineOfBusiness;
import com.caweco.esra.entities.core.OE;
import com.caweco.esra.entities.core.OeRegion;

public class ClientDTO {
	private String id;
	private String clientDescription;
	//private Set<Role> roles;
	private Set<ESUTemplate> esuTemplates;
	private Set<String> esuTags;
	private Set<String> esuCountries;
	
	private Set<OE> oes;
	private Set<Function> functions;
	private Set<LineOfBusiness> lobs;
	private Set<OeRegion> oeRegions;
	
	private EsraClientConfiguration clientConfiguration;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClientDescription() {
		return clientDescription;
	}

	public void setClientDescription(String clientDescription) {
		this.clientDescription = clientDescription;
	}

	public Set<ESUTemplate> getEsuTemplates() {
		return esuTemplates;
	}

	public void setEsuTemplates(Set<ESUTemplate> esuTemplates) {
		this.esuTemplates = esuTemplates;
	}

	public Set<String> getEsuTags() {
		return esuTags;
	}

	public void setEsuTags(Set<String> esuTags) {
		this.esuTags = esuTags;
	}

	public Set<String> getEsuCountries() {
		return esuCountries;
	}

	public void setEsuCountries(Set<String> esuCountries) {
		this.esuCountries = esuCountries;
	}

	public Set<OE> getOes() {
		return oes;
	}

	public void setOes(Set<OE> oes) {
		this.oes = oes;
	}

	public Set<Function> getFunctions() {
		return functions;
	}

	public void setFunctions(Set<Function> functions) {
		this.functions = functions;
	}

	public Set<LineOfBusiness> getLobs() {
		return lobs;
	}

	public void setLobs(Set<LineOfBusiness> lobs) {
		this.lobs = lobs;
	}

	public Set<OeRegion> getOeRegions() {
		return oeRegions;
	}

	public void setOeRegions(Set<OeRegion> oeRegions) {
		this.oeRegions = oeRegions;
	}

	public EsraClientConfiguration getClientConfiguration() {
		return clientConfiguration;
	}

	public void setClientConfiguration(EsraClientConfiguration clientConfiguration) {
		this.clientConfiguration = clientConfiguration;
	}
	
	
}
