package com.caweco.esra.ui.page.common;

public interface HasContext<T extends PageContext>
{
	public T getContext();
}
