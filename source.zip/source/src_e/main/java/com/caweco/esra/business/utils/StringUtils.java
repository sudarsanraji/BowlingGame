package com.caweco.esra.business.utils;

import java.util.function.Predicate;

public final class StringUtils {
	public static int indexOfFirstMatch(final String s, final Predicate<Character> p) {
		for (int i = 0; i < s.length(); i++) {
			if (p.test(s.charAt(i))) {
				return i;
			}
		}

		return -1;
	}

	private StringUtils() {
		throw new UnsupportedOperationException();
	}
}
