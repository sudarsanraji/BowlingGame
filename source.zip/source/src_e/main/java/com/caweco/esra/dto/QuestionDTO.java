package com.caweco.esra.dto;

import java.util.List;

import com.caweco.esra.entities.questionnaire.ChooseableValues;
import com.caweco.esra.entities.questionnaire.QuestionCategory;
import com.caweco.esra.entities.questionnaire.QuestionType;

public class QuestionDTO {

	private Integer id;
	private QuestionCategory category;
	private String questionTest;
	private String helperText;
	private Boolean active;
	private Boolean standard;
	private String instructionText;
	private QuestionType questionType;
	private List<ChooseableValues> values;
	private RuleDTO rule;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public QuestionCategory getCategory() {
		return category;
	}
	public void setCategory(QuestionCategory category) {
		this.category = category;
	}
	public String getQuestionTest() {
		return questionTest;
	}
	public void setQuestionTest(String questionTest) {
		this.questionTest = questionTest;
	}
	public String getHelperText() {
		return helperText;
	}
	public void setHelperText(String helperText) {
		this.helperText = helperText;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public Boolean getStandard() {
		return standard;
	}
	public void setStandard(Boolean standard) {
		this.standard = standard;
	}
	public String getInstructionText() {
		return instructionText;
	}
	public void setInstructionText(String instructionText) {
		this.instructionText = instructionText;
	}
	
	public QuestionType getQuestionType() {
		return questionType;
	}
	public void setQuestionType(QuestionType questionType) {
		this.questionType = questionType;
	}
	public List<ChooseableValues> getValues() {
		return values;
	}
	public void setValues(List<ChooseableValues> values) {
		this.values = values;
	}
	public RuleDTO getRule() {
		return rule;
	}
	public void setRule(RuleDTO rule) {
		this.rule = rule;
	}
	
	
	
}
