package com.caweco.esra.dto.creator;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.tinylog.Logger;

import com.caweco.esra.business.utils.Pair;
import com.caweco.esra.dto.ANDConditionDTO;
import com.caweco.esra.dto.ConditionObjectDTO;
import com.caweco.esra.dto.QuestionDTO;
import com.caweco.esra.dto.RuleDTO;
import com.caweco.esra.entities.questionnaire.ANDCondition;
import com.caweco.esra.entities.questionnaire.ConditionObject;
import com.caweco.esra.entities.questionnaire.Question;
import com.caweco.esra.entities.questionnaire.Questionnaire;
import com.caweco.esra.entities.questionnaire.Rule;

public class RuleCreator {
	public static RuleDTO convertRuleToDTO(Rule rule) {
	
		RuleDTO dto = new RuleDTO();
		Set<ANDConditionDTO> andDtoSet = new HashSet<>();

		rule.getAnds().forEach(and -> {
			ANDConditionDTO andDto = new ANDConditionDTO();
			Set<ConditionObjectDTO> conditionDtoSet = new HashSet<>();
			
			and.getAnds().forEach(condition -> {
				ConditionObjectDTO conObjDTO = new ConditionObjectDTO();
				conObjDTO.setValue(condition.getValue());
				conObjDTO.setQuestionId(condition.getQuestion(false).getId());
				conObjDTO.setQuestionText(condition.getQuestion(false).getQuestionText());
				conditionDtoSet.add(conObjDTO);
			});
			
			andDto.setAnds(conditionDtoSet);
			andDtoSet.add(andDto);
		});
	
		dto.setAnds(andDtoSet);
		return dto;
	}

	public static Rule convertDTOToRule(Integer questionnaireId, RuleDTO dto) {
		Rule rule = new Rule();
		Set<ANDCondition> andSet = new HashSet<>();
		
		dto.getAnds().forEach(andDto -> {
			ANDCondition and = new ANDCondition();
			Set<ConditionObject> conditionSet = new HashSet<>();
			
			andDto.getAnds().forEach(conditionDto -> {
				ConditionObject conObj = new ConditionObject(
						new Pair<Integer, Integer>(questionnaireId, conditionDto.getQuestionId()), 
						conditionDto.getValue()
				);
				
				conditionSet.add(conObj);
			});
			
			and.setAnds(conditionSet);
			andSet.add(and);
		});
		
		rule.setAnds(andSet);
		return rule;
	}

	public static Rule createRuleBasedOnImport(Questionnaire questionnaire, RuleDTO dto, List<Question> questions, QuestionDTO question, HashMap<Integer, Integer> legacyQuestionnaireIDs) {
		Rule rule = new Rule();
		HashSet<ANDCondition> andSet = new HashSet<>();
		rule.setAnds(andSet);
		
		dto.getAnds().forEach(and -> {
			ANDCondition newAnd = new ANDCondition();
			newAnd.setAnds(new HashSet<>());
			
			and.getAnds().forEach(conditionDto -> {
				ConditionObject condition = new ConditionObject();
				
				List<Question> possibleQuestions = questions.stream().filter(q -> {
					return conditionDto.getQuestionText().equals(q.getQuestionText());
				}).collect(Collectors.toList());
				
				Question optSelQuestion;
				
				if(possibleQuestions.size() == 0)
				{
					Logger.error("## Definite data consistency problem during import process: Could not figure the matching question for a rule of QuestionDTO {} (ID: {}). Tried matching Question Text, but there is not a single one with matching text. Skipping condition object.",
							question.getQuestionTest(),
							question.getId()
							);
					return;
				}
				if(possibleQuestions.size() == 1)
				{
					optSelQuestion = possibleQuestions.get(0);
				}
				else
				{
					long amountOfMatchingIds = legacyQuestionnaireIDs.entrySet().stream().filter(entry -> entry.getValue().equals(conditionDto.getQuestionId())).count();
					
					if(amountOfMatchingIds != 1)
					{
						Logger.error("## Definite data consistency problem during import process: Could not figure the matching question for a rule of QuestionDTO {} (ID: {}). Tried matching Question Text and then IDs, but there have either been duplicates or none at all spotted. (Amount of possible IDs: {}, Amount of possible Questions: {}) Skipping condition object.",
								question.getQuestionTest(),
								question.getId(),
								amountOfMatchingIds,
								possibleQuestions.size()
								);
						return;
					}
					
					Optional<Entry<Integer, Integer>> actualNewQuestionID = legacyQuestionnaireIDs.entrySet().stream().filter(entry -> entry.getValue().equals(conditionDto.getQuestionId())).findFirst();
								
					System.out.println(actualNewQuestionID);
					Optional<Question> possibleQuestion = possibleQuestions.stream().filter(q -> q.getId().equals(actualNewQuestionID.get().getKey())).findFirst();
					
					if(possibleQuestion.isEmpty()) {
						Logger.error("## Definite data consistency problem during import process: Could not figure the matching question for a rule of QuestionDTO {} (ID: {}). A single matching ID was spotted, however the question text did not match up. (Amount of possible IDs: {}, Amount of possible Questions: {}) Skipping condition object.",
								question.getQuestionTest(),
								question.getId(),
								amountOfMatchingIds,
								possibleQuestions.size()
								);
						return;
					}
					optSelQuestion = possibleQuestion.get();
						
				}
				
				condition.setValue(conditionDto.getValue());
				condition.setQuestion(optSelQuestion);
				condition.setQuestionIDs(new Pair<Integer, Integer>(questionnaire.getQuestionnaireID(), question.getId()));
				newAnd.getAnds().add(condition);
				
			});
			
			if(newAnd.getAnds().size() > 0)
			{
				andSet.add(newAnd);
			}
			else
			{
				Logger.error("## Skipping a ANDConditions as all Condition Objects has been deemed invalid. Debug Info: Question \"{}\"(ID: {})",
						question.getQuestionTest(),
						question.getId()
						);
			}
			
		});
		
		if(andSet.size() > 0)
		{
			return rule;
		}
		else
		{
			Logger.error("## Not creating a rule for Question \"{}\"(ID: {}), as either it had no ANDCondition or all ANDConditions have been deemed invalid.",
					question.getQuestionTest(),
					question.getId()
					);
			return null;
		}
	}
}
