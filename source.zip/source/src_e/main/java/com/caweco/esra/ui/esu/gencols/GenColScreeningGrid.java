
package com.caweco.esra.ui.esu.gencols;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import com.caweco.esra.business.func.common.Notificator;
import com.caweco.esra.business.properties.Aria;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.business.utils.UiHelper;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.dao.core.ScreeningDAO;
import com.caweco.esra.entities.User;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.ui.dialogs.DialogContentImpl;
import com.caweco.esra.ui.esu.EsuView;
import com.caweco.esra.ui.main.ShowReportPopup;
import com.caweco.esra.ui.main.helper.ScreeningEsuMultiResultItem;
import com.caweco.esra.ui.sanctions.PageEsuAssessment;
import com.flowingcode.vaadin.addons.ironicons.SocialIcons;
import com.rapidclipse.framework.server.data.renderer.RenderedComponent;
import com.rapidclipse.framework.server.ui.ItemLabelGeneratorFactory;
import com.rapidclipse.framework.server.ui.UIUtils;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.RouterLink;


public class GenColScreeningGrid extends HorizontalLayout implements RenderedComponent<ScreeningEsuMultiResultItem>
{
	
	public static GenColScreeningGrid New()
	{
		return new GenColScreeningGrid();
	}
	
	private ScreeningEsuMultiResultItem item;
	
	public GenColScreeningGrid()
	{
		super();
		this.initUI();
		
		UiHelper.setAriaLabel(this.rlEsuEdit, Aria.get("PageEsuWorklist_item_edit"));
		UiHelper.setAriaLabel(this.btnCreatePDF, Aria.get("PageEsuWorklist_item_pdfSummary"));
		UiHelper.setAriaLabel(this.btnAssingESUWorker, Aria.get("PageEsuWorklist_item_reviewer"));
		
		UiHelper.setTitle(this.rlEsuEdit, Aria.get("PageEsuWorklist_item_edit"));
		UiHelper.setTitle(this.btnCreatePDF, Aria.get("PageEsuWorklist_item_pdfSummary"));
		UiHelper.setTitle(this.btnAssingESUWorker, Aria.get("PageEsuWorklist_item_reviewer"));
		
		this.setViewType();
	}
	
	public GenColScreeningGrid setViewType()
	{
		this.btnAssingESUWorker.setVisible(true);
		
		return this;
	}
	
	@Override
	public void renderComponent(final ScreeningEsuMultiResultItem value)
	{
		this.item = value;
		
		// Prevent "edit" if screening is finalized
		if(ScreeningDAO.hasFrozenState(this.item))
		{
			Button btnRLView = new Button(VaadinIcon.EYE.create());
			btnRLView.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
			rlEsuEdit.setRoute(PageEsuAssessment.class, this.item.getId());
			rlEsuEdit.getElement().appendChild(btnRLView.getElement());

			this.btnAssingESUWorker.setEnabled(false);
		}
		else
		{
			Button btnRLView = new Button(VaadinIcon.EDIT.create());
			btnRLView.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
			rlEsuEdit.setRoute(PageEsuAssessment.class, this.item.getId());
			rlEsuEdit.getElement().appendChild(btnRLView.getElement());

			// Allow reassign if current user is assigned as "EsuWorker"
			if(Objects.equals(value.getScreeningServiceUserEmail(), CurrentUtil.getUser().getEmailAddress()))
			{
				this.btnAssingESUWorker.setEnabled(true);
			}
		}
		
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnCreatePDF}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnCreatePDF_onClick(final ClickEvent<Button> event)
	{
		final Optional<Screening> scr_ = this.item.fetchScreening();
		
		if(scr_.isPresent())
		{
			
			new ShowReportPopup(scr_.get()).open();
		}
		else
		{
			Notificator.error("Cannot obtain full Screening!");
		}
	}
	
	/**
	 * Event handler delegate method for the {@link Button} {@link #btnAssingESUWorker}.
	 *
	 * @see ComponentEventListener#onComponentEvent(ComponentEvent)
	 * @eventHandlerDelegate Do NOT delete, used by UI designer!
	 */
	private void btnAssingESUWorker_onClick(final ClickEvent<Button> event)
	{
		// Re-check: Prevent save if Screening FROZEN as last defense
		if(!ScreeningDAO.hasFrozenState(this.item))
		{
			final Set<User>      user   = UserDAO.findAll();
			final ComboBox<User> cbUser = new ComboBox<>();
			cbUser.setItemLabelGenerator(ItemLabelGeneratorFactory.NonNull(User::getRepresentation));
			cbUser.setWidth("300px");
			cbUser.setHeight(null);
			cbUser.setItems(user);
			DialogContentImpl.New(cbUser).setTextHeader("Select new reviewer").setOnOk(c -> {
				final User newReviewer = c.getValue();
				if(newReviewer != null)
				{
					final Optional<Screening> scr_ = this.item.fetchScreening();
					if(scr_.isPresent())
					{
						scr_.get().setEsuWorker(newReviewer);
						ScreeningDAO.update(scr_.get(), false);
						ScreeningDAO.logChange(scr_.get(), CurrentUtil.getUser(), false);
						
						Notificator.success("Reviewer changed!");
						
						UIUtils.getNextParent(this, Grid.class).getDataProvider().refreshAll();
					}
					else
					{
						Notificator.error("Cannot obtain full Screening!");
					}
				}
				
			}).show();
		}
	}
	
	/* WARNING: Do NOT edit!<br>The content of this method is always regenerated by the UI designer. */
	// <generated-code name="initUI">
	private void initUI()
	{
		this.rlEsuEdit = new RouterLink();
		this.btnCreatePDF = new Button();
		this.btnAssingESUWorker = new Button();
		
		this.setSpacing(false);
		this.btnCreatePDF.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
		this.btnCreatePDF.setIcon(VaadinIcon.SEARCH.create());
		this.btnAssingESUWorker.setVisible(false);
		this.btnAssingESUWorker.addThemeVariants(ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
		this.btnAssingESUWorker.setIcon(SocialIcons.PERSON_ADD.create());
		
		this.btnCreatePDF.setSizeUndefined();
		this.btnAssingESUWorker.setSizeUndefined();
		this.add(this.rlEsuEdit, this.btnCreatePDF, this.btnAssingESUWorker);
		this.setSizeFull();
		
		this.btnCreatePDF.addClickListener(this::btnCreatePDF_onClick);
		this.btnAssingESUWorker.addClickListener(this::btnAssingESUWorker_onClick);
	} // </generated-code>

	// <generated-code name="variables">
	private Button		btnCreatePDF, btnAssingESUWorker;
	private RouterLink	rlEsuEdit;
	// </generated-code>
	
}
