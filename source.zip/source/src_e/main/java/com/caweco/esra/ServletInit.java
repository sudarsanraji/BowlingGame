
package com.caweco.esra;

import java.beans.Beans;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caweco.esra.business.aa.AuthenticationHandler;
import com.caweco.esra.business.aa.AuthenticationInitializer;
import com.caweco.esra.business.aa.Authorizer;
import com.caweco.esra.business.aa.navigation.NoOpRouteResourcesProvider;
import com.caweco.esra.business.properties.ApplicationPropertyProvider;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.entities.User;
import com.rapidclipse.framework.server.security.authorization.Authorization;
import com.vaadin.flow.server.ServiceException;
import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.SessionDestroyEvent;
import com.vaadin.flow.server.SessionDestroyListener;
import com.vaadin.flow.server.SessionInitEvent;
import com.vaadin.flow.server.SessionInitListener;
import com.vaadin.flow.server.UIInitEvent;
import com.vaadin.flow.server.UIInitListener;
import com.vaadin.flow.server.VaadinServiceInitListener;
import com.vaadin.flow.server.VaadinSession;


public class ServletInit // NO_UCD - needed for Vaadin
	implements VaadinServiceInitListener, UIInitListener, SessionInitListener, SessionDestroyListener
{
	public static final Logger LOG = LoggerFactory.getLogger(ServletInit.class);
	
	@Override
	public void serviceInit(final ServiceInitEvent event)
	{
		// This causes a loop!
//		JulTinylogBridge.activate();
		
		Locale.setDefault(Locale.ENGLISH);
		
		event.getSource().addUIInitListener(this);
		event.getSource().addSessionInitListener(this);
		
		
		
		// Disable default authentication by AuthNavigationListener.beforeEnter(BeforeEnterEvent event);
		// which uses AuthNavigationController.isAuthorized(final Class<?> target)
		// which uses Authorization.getRouteResourcesProvider().getResourcesFor(target)
		// Authentication on navigation is replaced by EsraAuthNavigationListener
		Authorization.setRouteResourcesProvider(new NoOpRouteResourcesProvider());
	}
	
	@Override
	public void uiInit(final UIInitEvent event)
	{
		
	}
	
	@Override
	public void sessionInit(final SessionInitEvent event) throws ServiceException
	{
		VaadinSession.getCurrent().getSession().setMaxInactiveInterval(7200);
		
		// This causes a loop!
//		JulTinylogBridge.activate();
		
		ServletInit.LOG.info("## SESSION INIT - " + event.getSession().getSession().getId());
		
		if (Locale.getDefault() != Locale.ENGLISH)
		{
			Locale.setDefault(Locale.ENGLISH);
		}
		// To get <html lang="en">
		event.getSession().setLocale(Locale.getDefault());

		if(!Beans.isDesignTime())
		{
			final VaadinSession session = event.getSession();
			
			if(ApplicationPropertyProvider.isAuthenticationSuspended())
			{
				
				final User user = UserDAO.getOrCreate("extern.kuemmel_christian@allianz.com");
				user.setAppAdmin(true);
				
				AuthenticationHandler.handleAttributesAndUpdateUser(session, user, null);
				AuthenticationHandler.logIn(session, user);
				
				ServletInit.LOG.info(
					"User {} Logged in. Changed SessionId and added user to session.",
					user.getEmailAddress());
			}
			else
			{
				// Ensure user is authenticated
				// First here -> "called in reverse order" -> Called as second
				session.addRequestHandler(new AuthenticationInitializer());
				
				// Handles SAML responses
				// Second here -> "called in reverse order" -> Called as first
				session.addRequestHandler(new AuthenticationHandler());
				
				// Init AuthorizationManager
				Authorizer.getOrCreateAuthorizationManager(session);
			}
			
		}
	}
	
	@Override
	public void sessionDestroy(final SessionDestroyEvent event)
	{
		ServletInit.LOG.info("## SESSION DESTROY ######");
	}
	
}
