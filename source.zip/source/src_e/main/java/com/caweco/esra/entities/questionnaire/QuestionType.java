package com.caweco.esra.entities.questionnaire;

public enum QuestionType
{
	FREETEXT("Freetext"),
	DATE("Date Chooser"),
	DURATION("Duration chooser"),
	MULTI("Multioption"),
	SINGLE("Singleoption");
	
	private String name;
	
	QuestionType(String string)
	{
		this.name = string;
	}
	
	public String getName()
	{
		return this.name;
	}
}
