package com.caweco.esra.ui.page.common;

import java.util.Optional;
import java.util.UUID;

import com.caweco.esra.entities.Client;
import com.caweco.esra.entities.User;

public class PageContext
{
	protected Client client;
	protected User user;

	public Optional<UUID> getClientId()
	{
		return Optional.ofNullable(client).map(Client::getUuid);
	}
	
	public Client getClient()
	{
		return client;
	}
	
	public void setClient(Client client)
	{
		this.client = client;
	}
	public Optional<User> getUser()
	{
		return Optional.ofNullable(user);
	}
	public void setUser(User user)
	{
		this.user = user;
	}
}
