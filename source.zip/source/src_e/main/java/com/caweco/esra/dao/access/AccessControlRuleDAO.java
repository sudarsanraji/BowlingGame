package com.caweco.esra.dao.access;

import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.tinylog.Logger;

import com.caweco.esra.business.func.rest.RestClientESRADB;
import com.caweco.esra.business.func.rest.RestUtil;
import com.caweco.esra.business.utils.CommonUtil;
import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.entities.access.AccessControlRuleLdap;
import com.caweco.esra.entities.ldap.LdapAttributes;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;


public class AccessControlRuleDAO
{
	private static ObjectMapper om = new ObjectMapper().findAndRegisterModules();
	
	/**********************************************************/
	// LDAP
	
	public static Set<AccessControlRuleLdap> findAll_Ldap()
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldaprules");
		
		final Response response = webTarget.request().get();
		Logger.tag("REST").info(response.toString());
		
		final String responseBody = response.readEntity(String.class);
		
		final JavaType type = om.getTypeFactory().constructCollectionType(Set.class, AccessControlRuleLdap.class);
		
		try {
			return om.readValue(responseBody, type);
		} catch (final JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new HashSet<>();
		}
	}
	
	public static Optional<AccessControlRuleLdap> getFirstMatchingRuleLdap(final LdapAttributes attr)
	{
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldaprules/check");
		
		final Response response = webTarget.request().post(Entity.entity(attr, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		
		if(response.getStatus() != 200) {
			final String responseBody = response.readEntity(String.class);
			
			Logger.tag("REST").info(responseBody);
		}
		
		if(response.getStatus() == 404) {
			return Optional.empty();
		}
		
		final AccessControlRuleLdap responseBody = response.readEntity(AccessControlRuleLdap.class);

		return Optional.of(responseBody);
	}
	
	public static boolean hasAppAccessByLdapRule(final LdapAttributes attr)
	{
		final Optional<AccessControlRuleLdap> firstFittingRule = getFirstMatchingRuleLdap(attr);
		return firstFittingRule.isPresent();
	}

	public static void delete(final AccessControlRuleLdap accessControlRuleLdap) {
		
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldaprules/" + accessControlRuleLdap.getId().toString());
		
		final Response response = webTarget.request().delete();
		Logger.tag("REST").info(response.toString());
	}

	public static void create(final AccessControlRuleLdap rule) {
		final RestClientESRADB client = RestUtil.getRestClient_ESRADB();
		
		final WebTarget webTarget = client.getMethodTarget("/accesscontrol/ldaprules/");
		if(Objects.isNull(rule.getId()))
		{
			rule.setId(UUID.randomUUID());
		}
		
		final Response response = webTarget.request().post(Entity.entity(rule, MediaType.APPLICATION_JSON));
		Logger.tag("REST").info(response.toString());
		Logger.tag("PAM").info(CurrentUtil.getUser().getFirstname() + " "+ CurrentUtil.getUser().getLastname() + " with roles "+  CommonUtil.getLogString(CurrentUtil.getUser())
		+" added the access control rule "  + rule.getRepresentation() + " to the system" );
	}
}
