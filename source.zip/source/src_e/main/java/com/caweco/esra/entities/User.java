
package com.caweco.esra.entities;

import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.caweco.esra.business.utils.CurrentUtil;
import com.caweco.esra.dao.UserDAO;
import com.caweco.esra.entities.core.Screening;
import com.caweco.esra.entities.esu.ScreeningFilter;
import com.caweco.esra.entities.meta.HasRepresentation;
import com.caweco.esra.entities.saml.SamlAttributes;
import com.rapidclipse.framework.server.resources.Caption;
import com.rapidclipse.framework.server.security.authorization.AuthorizationRole;
import com.rapidclipse.framework.server.security.authorization.AuthorizationSubject;


@Caption("{%lastname}, {%firstname}")
public class User implements AuthorizationSubject, HasRepresentation
{
	private String								emailAddress;
	private String								firstname;
	private String								lastname;
	private String								department;
	private boolean								active				= true;
	private boolean								appAdmin			= false;
	
	private Optional<Set<Role>>					roles				= Optional.empty();
	
	//// SETTINGS
	
	/*
	 * Client-specific Usersetting: ScreeningFilter
	 * Key: Client-ID, Value: ScreeningFilter
	 */
	private Map<UUID, ScreeningFilter>	screeningFilter		= new HashMap<>();
	/*
	 * Client-specific Usersetting: ScreeningFavourites
	 * Key: Client-ID, Value: set of Screenings
	 */
	private Map<UUID, Set<Screening>>		screeningFavourites	= new HashMap<>();
	
	//// STATE SETTINGS
	private Instant								lastLogin;
	private Instant								currentLogin;
	private UUID								lastVisitedClientId;
	
	private SamlAttributes						lastSamlAttributes;
	
	public User()
	{
		super();
	}
	
	/**
	 * 
	 * @param emailAddress
	 */
	public User(final String emailAddress)
	{
		super();
		this.emailAddress = emailAddress;
	}
	
	public Set<Role> getRoles(boolean forceUpdate)
	{
		if(this.roles.isPresent() && !forceUpdate)
		{
			return this.roles.get();
		}
		else
		{
			this.roles = Optional.of(UserDAO.getRoles(this));
			return this.roles.get();
		}
	}
	
	public void setRoles(Optional<Set<Role>> roles)
	{
		this.roles = roles;
	}
	
	@Caption("Active")
	public boolean isActive()
	{
		return this.active;
	}
	
	public void setActive(final boolean active)
	{
		this.active = active;
	}
	
	@Caption("Firstname")
	public String getFirstname()
	{
		return this.firstname;
	}
	
	public void setFirstname(final String firstname)
	{
		this.firstname = firstname;
	}
	
	@Caption("Lastname")
	public String getLastname()
	{
		return this.lastname;
	}
	
	public void setLastname(final String lastname)
	{
		this.lastname = lastname;
	}
	
	@Caption("Department")
	public String getDepartment()
	{
		return this.department;
	}
	
	public void setDepartment(final String department)
	{
		this.department = department;
	}
	
	@Caption("Email")
	public String getEmailAddress()
	{
		return this.emailAddress;
	}
	
	public void setEmailAddress(final String emailAddress)
	{
		this.emailAddress = emailAddress;
	}
	
	@Override
	public String subjectName()
	{
		return this.getEmailAddress();
	}
	
	@Override
	public Collection<? extends AuthorizationRole> roles()
	{
		final Client client = CurrentUtil.getClient();
		return this.getRolesForClient(client);
	}
	
	private Collection<? extends AuthorizationRole> getRolesForClient(Client client)
	{
		return UserDAO.getRolesForClient(this, client);
	}
	
	public boolean isAppAdmin()
	{
		return this.appAdmin;
	}
	
	public void setAppAdmin(final boolean appAdmin)
	{
		this.appAdmin = appAdmin;
	}
	
	public Map<UUID, ScreeningFilter> getScreeningFilter()
	{

		return this.screeningFilter == null ? new HashMap<>() : this.screeningFilter;
	}
	
	public Map<UUID, Set<Screening>> getScreeningFavourites()
	{
		return this.screeningFavourites == null ? new HashMap<>() : this.screeningFavourites;
	}
	
	public Instant getLastLogin()
	{
		return this.lastLogin;
	}
	
	public void setLastLogin(Instant lastLogin)
	{
		this.lastLogin = lastLogin;
	}
	
	public Instant getCurrentLogin()
	{
		return this.currentLogin;
	}
	
	public void setCurrentLogin(Instant currentLogin)
	{
		this.currentLogin = currentLogin;
	}
	
	public UUID getLastVisitedClientId()
	{
		return this.lastVisitedClientId;
	}
	
	public void setLastVisitedClientId(UUID lastVisitedClientId)
	{
		this.lastVisitedClientId = lastVisitedClientId;
	}
	
	@Override
	public String getRepresentation()
	{
		final String combined =
			StringUtils.stripToNull(
				Stream.of(this.lastname, this.firstname).map(StringUtils::stripToNull).filter(
					Objects::nonNull).collect(Collectors.joining(", ")));
		return combined != null ? combined : "[Not available/" + this.emailAddress + "]";
	}
	
	public SamlAttributes getLastSamlAttributes()
	{
		return this.lastSamlAttributes;
	}
	
	public void setLastSamlAttributes(SamlAttributes lastSamlAttributes)
	{
		this.lastSamlAttributes = lastSamlAttributes;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(emailAddress);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(emailAddress, other.emailAddress);
	}

	public Set<Role> getClientRoles(Client client, boolean forceUpdate) {
		Set<Role> clientRoles = this.getRoles(forceUpdate).stream().filter((role) -> {
			return client.getRoles(forceUpdate).contains(role);
		}).collect(Collectors.toSet());
		
		return clientRoles;
	}
	
	@Override
	public String toString() {
		String lastSamlAttributesString = lastSamlAttributes != null ? lastSamlAttributes.toString() : "none";
		
		return "User [emailAddress=" + emailAddress + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", department=" + department + ", active=" + active + ", appAdmin=" + appAdmin + ", roles=" + roles
				+ ", screeningFilter=" + screeningFilter + ", screeningFavourites=" + screeningFavourites
				+ ", lastLogin=" + lastLogin + ", currentLogin=" + currentLogin + ", lastVisitedClientId="
				+ lastVisitedClientId + ", lastSamlAttributes=" + lastSamlAttributesString + "]";
	}
	
}
