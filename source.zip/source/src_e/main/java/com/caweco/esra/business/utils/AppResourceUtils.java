package com.caweco.esra.business.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;

import com.rapidclipse.framework.server.resources.ApplicationResource;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.server.VaadinServlet;

public final class AppResourceUtils {
	public static InputStream getInputStream(final Class<?> requestor, final String path, final UI ui) {
		final InputStream[] stream = new InputStream[1];

		try {
			ui.access(() -> {
				try {
					final File file = new File(getRootPath(VaadinServlet.getCurrent().getServletContext()), path);
					if (file.exists()) {
						try (FileInputStream fileInputStream = new FileInputStream(file)) {
							stream[0] = fileInputStream;
							return;
						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					}
				} catch (final IOException e) {
					throw new RuntimeException(e);
				}
				Class<?> clazz = requestor;
				if (clazz == null) {
					clazz = ApplicationResource.class;
				}

				InputStream is = clazz.getResourceAsStream(path);
				if (is == null) {
					if (path.startsWith("/")) {
						is = clazz.getResourceAsStream(path.substring(1));
					} else {
						is = clazz.getResourceAsStream("/" + path);
					}
				}

				stream[0] = is;
			});
		} catch (final Exception e) {
			throw new RuntimeException(e);
		}

		return stream[0];
	}

	private static String getRootPath(final ServletContext servletContext) throws MalformedURLException {
		final String rootPath = servletContext.getRealPath("/");
		if (rootPath != null) {
			return rootPath;
		}

		return servletContext.getResource("/").getFile();
	}

	private AppResourceUtils() {
		throw new UnsupportedOperationException();
	}
}
